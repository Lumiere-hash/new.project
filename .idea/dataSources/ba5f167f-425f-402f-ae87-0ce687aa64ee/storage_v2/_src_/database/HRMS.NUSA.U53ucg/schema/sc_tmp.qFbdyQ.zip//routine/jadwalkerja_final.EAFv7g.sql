create function jadwalkerja_final() returns trigger
    language plpgsql
as
$$
DECLARE
VR_CEK INTEGER;
VR_CEK_CLOSING CHARACTER(12); --VAR UNTUK CEK CLOSING
VR_CEKTGL_CLOSING DATE;

BEGIN

if (new.status='F')and(old.status='I') then 
	--select * from sc_trx.jadwalkerja limit 1
	--select * from sc_tmp.jadwalkerja limit 1
	DELETE FROM SC_TRX.JADWALKERJA WHERE KDREGU=NEW.KDREGU AND TGL=NEW.TGL AND coalesce(KODEJAMKERJA,'')='OFF';
	VR_CEK:=COUNT(*) FROM SC_TRX.JADWALKERJA WHERE KDREGU=NEW.KDREGU AND TGL=NEW.TGL;
	IF VR_CEK=0 THEN
		INSERT INTO SC_TRX.JADWALKERJA
		(kdregu,kodejamkerja,inputdate,inputby,tgl) 
		(SELECT kdregu,kodejamkerja,inputdate,inputby,tgl
		FROM SC_TMP.JADWALKERJA WHERE KDREGU=NEW.KDREGU AND TGL=NEW.TGL AND STATUS='F' AND coalesce(KODEJAMKERJA,'')!='OFF');
	
	ELSE 
		UPDATE SC_TRX.JADWALKERJA 
		SET KODEJAMKERJA=NEW.KODEJAMKERJA, UPDATEDATE=NEW.INPUTDATE, UPDATEBY=NEW.INPUTBY
	WHERE KDREGU=NEW.KDREGU AND TGL=NEW.TGL ;
	
	END IF;
	DELETE FROM SC_TMP.JADWALKERJA WHERE STATUS='F' AND KDREGU=NEW.KDREGU AND TGL=NEW.TGL;

end if;
return new;

end;
$$;

alter function jadwalkerja_final() owner to postgres;

