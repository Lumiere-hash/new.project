create function pr_p21_detail() returns trigger
    language plpgsql
as
$$
BEGIN
		
	IF (tg_op = 'UPDATE') THEN	---(tg_op = 'INSERT') or triger ubah update
			update sc_tmp.p21_master set status='H' where nodok=new.nodok and nik=new.nik;
		if (new.status='H' and old.status='I') then --H untuk hitung ulang
			update sc_tmp.p21_master set 
			total_pajak=(select sum(nominal) from sc_tmp.p21_detail where nodok=new.nodok and nik=new.nik and no_urut='63'),
			total_potongan=(select sum(nominal) from sc_tmp.p21_detail where nodok=new.nodok and nik=new.nik and aksi='B'),
			total_pendapatan=(select sum(nominal) from sc_tmp.p21_detail where nodok=new.nodok and nik=new.nik and aksi='A'),
			gaji_netto=(select sum(nominal) from sc_tmp.p21_detail where nodok=new.nodok and nik=new.nik and no_urut='20')
			where nodok=new.nodok and nik=new.nik;
			update sc_tmp.payroll_detail set nominal=(select sum(nominal) from sc_tmp.p21_detail where nodok=new.nodok and nik=new.nik and no_urut='63') 
			where nodok=new.nodok and nik=new.nik and no_urut=28;
			update sc_tmp.p21_detail set status='I' where nodok=new.nodok and nik=new.nik;
		elseif (new.status='D' and old.status='I') then
			update sc_tmp.p21_master set 
			total_pajak=(select sum(nominal) from sc_tmp.p21_detail where nodok=new.nodok and nik=new.nik and no_urut='63'),
			total_potongan=(select sum(nominal) from sc_tmp.p21_detail where nodok=new.nodok and nik=new.nik and aksi='B'),
			total_pendapatan=(select sum(nominal) from sc_tmp.p21_detail where nodok=new.nodok and nik=new.nik and aksi='A'),
			gaji_netto=(select sum(nominal) from sc_tmp.p21_detail where nodok=new.nodok and nik=new.nik and no_urut='20')
			where nodok=new.nodok and nik=new.nik;
			update sc_tmp.payroll_detail set nominal=(select sum(nominal) from sc_tmp.p21_detail where nodok=new.nodok and nik=new.nik and no_urut='63') 
			where nodok=new.nodok and nik=new.nik and no_urut=28;
		end if;
		RETURN new;
		
	ELSEIF tg_op = 'DELETE' THEN
		update sc_tmp.p21_master set 
		total_pajak=(select sum(nominal) from sc_tmp.p21_detail where nodok=old.nodok and nik=old.nik and no_urut='63'),
		total_potongan=(select sum(nominal) from sc_tmp.p21_detail where nodok=old.nodok and nik=old.nik and aksi='B'),
		total_pendapatan=(select sum(nominal) from sc_tmp.p21_detail where nodok=old.nodok and nik=old.nik and aksi='A'),
		gaji_netto=(select sum(nominal) from sc_tmp.p21_detail where nodok=old.nodok and nik=old.nik and no_urut='20')
		where nodok=old.nodok and nik=old.nik;
		RETURN new;	
	END IF;
	RETURN NEW;
END;
$$;

alter function pr_p21_detail() owner to postgres;

