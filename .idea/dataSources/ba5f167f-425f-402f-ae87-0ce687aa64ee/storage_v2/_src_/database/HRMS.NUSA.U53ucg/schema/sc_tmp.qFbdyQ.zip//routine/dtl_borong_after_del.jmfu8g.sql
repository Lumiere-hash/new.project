create function dtl_borong_after_del() returns trigger
    language plpgsql
as
$$
declare
     
     vr_nomor integer;
     vr_i integer;
     vr_new integer;
     vr_ttl integer;
     
begin
	--select * from sc_tmp.upah_borong_mst;
	--select * from sc_tmp.upah_borong_dtl;
	vr_nomor:=no_urut from sc_tmp.upah_borong_dtl where no_urut=old.no_urut and nik=old.nik and nodok=old.nodok; 	
	vr_ttl:=count(no_urut) from sc_tmp.upah_borong_dtl where nik=old.nik and nodok=old.nodok; 	
	--select * from sc_tmp.upah_borong_dtl where no_urut=no_urut+1; 
	--if (vr_nomor=1) then		
		update sc_tmp.upah_borong_dtl set no_urut=no_urut-1 where nik=old.nik and nodok=old.nodok;		 
	--end if;
return new;

end;
$$;

alter function dtl_borong_after_del() owner to postgres;

