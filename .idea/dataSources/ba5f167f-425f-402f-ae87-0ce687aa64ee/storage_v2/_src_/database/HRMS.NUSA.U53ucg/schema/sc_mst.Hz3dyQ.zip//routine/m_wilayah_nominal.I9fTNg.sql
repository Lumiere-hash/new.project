create function m_wilayah_nominal() returns trigger
    language plpgsql
as
$$
declare
     /*
     CREATE	: FIKY ASHARIZA
     CASE	: TRIGGER PENOMORAN SUB
     */
   	vr_nomor character(20);
	vr_lastdoc numeric; 
begin
			vr_lastdoc:=case 
			when max((right(trim(kdwilayahnominal),4))) is null or max((right(trim(kdwilayahnominal),4)))='' then '0'
			else max((right(trim(kdwilayahnominal),4))) end lastdoc
			from sc_mst.m_wilayah_nominal
			where kdwilayah=new.kdwilayah;
			--select * from sc_mst.nomor
			if not exists(select * from sc_mst.nomor where dokumen='M_WIL_NOM') THEN
				INSERT INTO SC_MST.NOMOR 
				(dokumen,part,count3,prefix,sufix,docno,modul,periode,cekclose)
				values
				('M_WIL_NOM','',4,'','',0,'I.P.I.2','201901','F');
			END IF;
			update sc_mst.nomor set docno=vr_lastdoc where dokumen='M_WIL_NOM';
				
			delete from sc_mst.penomoran where userid=new.inputby and dokumen='M_WIL_NOM';	
			insert into sc_mst.penomoran 
			(userid,dokumen,nomor,errorid,partid,counterid,xno)
			values(new.inputby,'M_WIL_NOM',' ',0,' ',1,0);

			vr_nomor:=trim(coalesce(nomor,'')) from sc_mst.penomoran where userid=new.inputby and dokumen='M_WIL_NOM';

			update sc_mst.m_wilayah_nominal set kdwilayahnominal=kdwilayah||'.'||vr_nomor
			where kdwilayahnominal=new.kdwilayahnominal and inputby=new.inputby and inputdate=new.inputdate;
			

return new;

end;
$$;

alter function m_wilayah_nominal() owner to postgres;

