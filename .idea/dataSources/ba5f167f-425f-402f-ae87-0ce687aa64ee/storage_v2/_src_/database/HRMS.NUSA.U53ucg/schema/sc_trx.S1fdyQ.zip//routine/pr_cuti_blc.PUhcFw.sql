create function pr_cuti_blc() returns trigger
    language plpgsql
as
$$
DECLARE 
	--author by fiky: 04/04/2016
	--update by fiky: 11/04/2016
    vr_sisacuti integer :=0;
    vr_balance integer :=0; 
    vr_ceknik character(12);   
BEGIN		
	IF tg_op = 'INSERT' THEN	
		vr_sisacuti:= coalesce(sisacuti,0) from sc_trx.cuti_blc a,
		(select a.nik,a.tanggal,a.no_dokumen,max(a.doctype) as doctype from sc_trx.cuti_blc a,
		(select a.nik,a.tanggal,max(a.no_dokumen) as no_dokumen from sc_trx.cuti_blc a,
		(select nik,max(tanggal) as tanggal from sc_trx.cuti_blc where nik=new.nik and tanggal<new.tanggal
		group by nik) as b
		where a.nik=b.nik and a.tanggal=b.tanggal
		group by a.nik,a.tanggal) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen
		group by a.nik,a.tanggal,a.no_dokumen) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen and a.doctype=b.doctype;

	

		update sc_trx.cuti_blc set sisacuti=(coalesce(vr_sisacuti,0)+coalesce(new.in_cuti,0)-coalesce(new.out_cuti,0))
		where nik=new.nik and tanggal=new.tanggal and no_dokumen=new.no_dokumen and doctype=new.doctype;

		update sc_trx.cuti_blc a set sisacuti=b.balance
		from (select *,sum("in_cuti"-"out_cuti") over(partition by nik order by nik,tanggal,doctype,no_dokumen) as balance
		from sc_trx.cuti_blc) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen  and a.nik=new.nik and a.tanggal>=new.tanggal and a.doctype=b.doctype;		

		/*update ke sisa cuti ke master karyawan*/
	update sc_mst.karyawan x set sisacuti=coalesce(a.sisacuti,0) from sc_trx.cuti_blc a,
		(select a.nik,a.tanggal,a.no_dokumen,max(a.doctype) as doctype from sc_trx.cuti_blc a,
		(select a.nik,a.tanggal,max(a.no_dokumen) as no_dokumen from sc_trx.cuti_blc a,
		(select nik,max(tanggal) as tanggal from sc_trx.cuti_blc where nik=new.nik 
		group by nik
		) as b
		where a.nik=b.nik and a.tanggal=b.tanggal
		group by a.nik,a.tanggal) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen
		group by a.nik,a.tanggal,a.no_dokumen ) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen and a.doctype=b.doctype and a.nik=x.nik;
	


		RETURN new;
	ELSEIF tg_op = 'DELETE' THEN
		update sc_trx.cuti_blc a set sisacuti=b.balance
		from (select *,sum("in_cuti"-"out_cuti") over(partition by nik order by nik,tanggal,doctype,no_dokumen) as balance
		from sc_trx.cuti_blc) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen and a.nik=old.nik and a.tanggal>=old.tanggal and a.doctype=b.doctype ;	

			/*update ke sisa cuti ke master karyawan*/
		update sc_mst.karyawan x set sisacuti=coalesce(a.sisacuti,0) from sc_trx.cuti_blc a,
		(select a.nik,a.tanggal,a.no_dokumen,max(a.doctype) as doctype from sc_trx.cuti_blc a,
		(select a.nik,a.tanggal,max(a.no_dokumen) as no_dokumen from sc_trx.cuti_blc a,
		(select nik,max(tanggal) as tanggal from sc_trx.cuti_blc where nik=old.nik 
		group by nik) as b
		where a.nik=b.nik and a.tanggal=b.tanggal
		group by a.nik,a.tanggal) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen
		group by a.nik,a.tanggal,a.no_dokumen) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen and a.doctype=b.doctype and a.nik=x.nik;

		
		RETURN new;	
	END IF;
	
END;
$$;

alter function pr_cuti_blc() owner to postgres;

