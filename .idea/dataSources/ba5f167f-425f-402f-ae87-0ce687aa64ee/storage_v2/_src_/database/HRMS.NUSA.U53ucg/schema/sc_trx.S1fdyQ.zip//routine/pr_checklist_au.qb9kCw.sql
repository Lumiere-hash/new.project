create function pr_checklist_au() returns trigger
    language plpgsql
as
$$
DECLARE
    -- Created By ARBI : 08/11/2021
BEGIN
     IF(old.status = 'P' AND new.status = 'E') THEN
        INSERT INTO sc_tmp.checklist
        SELECT *
        FROM sc_trx.checklist
        WHERE id_checklist = new.id_checklist;

        INSERT INTO sc_tmp.checklist_user
        SELECT *
        FROM sc_trx.checklist_user
        WHERE id_checklist = new.id_checklist;

        INSERT INTO sc_tmp.checklist_parameter
        SELECT *
        FROM sc_trx.checklist_parameter
        WHERE id_checklist = new.id_checklist;

        INSERT INTO sc_tmp.checklist_tanggal
        SELECT *
        FROM sc_trx.checklist_tanggal
        WHERE id_checklist = new.id_checklist;

        INSERT INTO sc_tmp.checklist_realisasi
        SELECT *
        FROM sc_trx.checklist_realisasi
        WHERE id_checklist = new.id_checklist;
    END IF;
RETURN new;
END;
$$;

alter function pr_checklist_au() owner to postgres;

