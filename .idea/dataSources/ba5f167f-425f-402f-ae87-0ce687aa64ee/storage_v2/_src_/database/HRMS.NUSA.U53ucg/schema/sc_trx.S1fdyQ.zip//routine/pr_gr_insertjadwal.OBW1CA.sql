create function pr_gr_insertjadwal(vr_bulan_akhir numeric, vr_tahun_akhir numeric, vr_kdregu character) returns SETOF void
    language plpgsql
as
$$
--author by : Fiky Ashariza 12-04-2016
--update by : --

DECLARE vr_tgl date;
DECLARE vr_tglrev date;
DECLARE vr_cek_jadwal bigint;
DECLARE vr_hari_libur bigint;

BEGIN

		
 FOR vr_tgl in select x.tgl from 
				(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
				union all
				select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
				) as x
				where x.tahun=vr_tahun_akhir and x.bulan=vr_bulan_akhir and x.kdregu=vr_kdregu


	LOOP	
		--vr_tglrev:=x.tgl_rev from 
		FOR vr_tglrev in select x.tgl_rev from 
				(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
				union all
				select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
				union all
				select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
				) as x
				where x.tgl=vr_tgl and kdregu=vr_kdregu and x.tgl_rev is not null --and x.bulan=vr_bulan_akhir and x.tahun=vr__akhir
					
				LOOP
				vr_cek_jadwal:=count(*) from sc_trx.jadwalkerja where tgl=vr_tgl and kdregu=vr_kdregu;
				vr_hari_libur:=count(tgl_libur) from sc_mst.libur where tgl_libur=vr_tgl; 
				if( vr_cek_jadwal=0 and vr_hari_libur=0 and vr_tgl is not null) then
					insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)
					select kdregu,kodejamkerja,inputdate,inputby,vr_tgl from sc_trx.jadwalkerja where tgl=vr_tglrev and kdregu=vr_kdregu;
				end if;

				RETURN NEXT vr_tglrev;
				END LOOP;				
	
	RETURN NEXT vr_tgl;
		
END LOOP;
		
		
	RETURN;
	

	
END;
$$;

alter function pr_gr_insertjadwal(numeric, numeric, char) owner to postgres;

