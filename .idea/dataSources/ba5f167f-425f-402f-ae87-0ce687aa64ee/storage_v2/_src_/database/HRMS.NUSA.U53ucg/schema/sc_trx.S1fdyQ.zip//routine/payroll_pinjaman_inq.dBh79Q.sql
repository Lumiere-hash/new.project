create function payroll_pinjaman_inq() returns trigger
    language plpgsql
as
$$
declare
/*
	Created by PhpStorm.
	User: FIKY-PC
	Date: 5/4/19 10:58 AM
	Last Modified: 5/2/19 3:45 PM.
	Developed By: Fiky Ashariza Powered By PhpStorm
	Copyright© 2019 .All rights reserved.
 
 */
     vr_pinjaman character(25);
     vr_nomor char(12); 
     vr_cekprefix char(4);
     vr_nowprefix char(4);
     vr_sld numeric(18,2);

begin
	IF tg_op = 'INSERT' THEN	
		
		/* TESTING ENVIROMENT
	
			select * from sc_trx.payroll_pinjaman_mst 
			select * from sc_trx.payroll_pinjaman_inq order by nik,docno,tgl,doctype,docref
			delete from sc_trx.payroll_pinjaman_inq where tgl='2019-05-07 14:05:16';
			
		insert into sc_trx.payroll_pinjaman_inq
		(nik,docno,tgl,docref,doctype,in_sld,out_sld,sld,status)
		(select nik,docno,to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp,'px' as docref,'OUT' as doctype,0,240000,0,'F' from sc_trx.payroll_pinjaman_mst where docno='PKRD19050007');
		*/
		update sc_trx.payroll_pinjaman_inq a set sld=b.cocoldonkbang
		from (select *,sum("in_sld"-"out_sld") over(partition by nik,docno order by nik,docno,tgl,doctype,docref) as cocoldonkbang
		from sc_trx.payroll_pinjaman_inq) b
		where a.nik=b.nik and a.docno=b.docno and a.tgl=b.tgl and a.doctype=b.doctype and a.docref=b.docref
		and a.nik=new.nik and a.tgl>=new.tgl and a.docno=new.docno;	

		select coalesce(a.sld,0) into vr_sld from sc_trx.payroll_pinjaman_inq a,	
		(select a.nik,a.docno,a.tgl,a.doctype, max(a.docref) as docref from sc_trx.payroll_pinjaman_inq a,	
		(select a.nik,a.docno,a.tgl,max(a.doctype) as doctype from sc_trx.payroll_pinjaman_inq a,
		(select nik,docno,max(tgl) as tgl from sc_trx.payroll_pinjaman_inq where nik=new.nik  and docno=new.docno
		group by nik,docno) as b where a.nik=b.nik and a.docno=b.docno and a.tgl=b.tgl
		group by a.nik,a.docno,a.tgl) as b where a.nik=b.nik and a.docno=b.docno and a.tgl=b.tgl and a.doctype=b.doctype
		group by a.nik,a.docno,a.tgl,a.doctype) as b where a.nik=b.nik and a.docno=b.docno and a.tgl=b.tgl and a.doctype=b.doctype and a.docref=b.docref;
		


		update sc_trx.payroll_pinjaman_inq a set sld=b.cocoldonkbang
		from (select *,sum("in_sld"-"out_sld") over(partition by nik,docno order by nik,docno,tgl,doctype,docref) as cocoldonkbang
		from sc_trx.payroll_pinjaman_inq) b
		where a.nik=b.nik and a.docno=b.docno and a.tgl=b.tgl and a.doctype=b.doctype and a.docref=b.docref
		and a.nik=new.nik and a.tgl>=new.tgl and a.docno=new.docno;
			--select * from  sc_trx.payroll_pinjaman_inq;
			--select * from  sc_trx.payroll_pinjaman_mst;
		if (vr_sld<=0 and new.docref!='SALDO_AWAL') then
			update sc_trx.payroll_pinjaman_mst set sisa=0 ,status='U' where docno=new.docno and nik=nik;
		elseif (vr_sld>0 and new.docref!='SALDO_AWAL') then
			update sc_trx.payroll_pinjaman_mst set sisa=vr_sld,status='P' where docno=new.docno and nik=nik;
		end if;
		RETURN new;
	ELSEIF tg_op = 'DELETE' THEN
update sc_trx.payroll_pinjaman_inq a set sld=b.cocoldonkbang
		from (select *,sum("in_sld"-"out_sld") over(partition by nik,docno order by nik,docno,tgl,doctype,docref) as cocoldonkbang
		from sc_trx.payroll_pinjaman_inq) b
		where a.nik=b.nik and a.docno=b.docno and a.tgl=b.tgl and a.doctype=b.doctype and a.docref=b.docref
		and a.nik=old.nik and a.tgl>=old.tgl and a.docno=old.docno;	

		select coalesce(a.sld,0) into vr_sld from sc_trx.payroll_pinjaman_inq a,	
		(select a.nik,a.docno,a.tgl,a.doctype, max(a.docref) as docref from sc_trx.payroll_pinjaman_inq a,	
		(select a.nik,a.docno,a.tgl,max(a.doctype) as doctype from sc_trx.payroll_pinjaman_inq a,
		(select nik,docno,max(tgl) as tgl from sc_trx.payroll_pinjaman_inq where nik=old.nik  and docno=old.docno
		group by nik,docno) as b where a.nik=b.nik and a.docno=b.docno and a.tgl=b.tgl
		group by a.nik,a.docno,a.tgl) as b where a.nik=b.nik and a.docno=b.docno and a.tgl=b.tgl and a.doctype=b.doctype
		group by a.nik,a.docno,a.tgl,a.doctype) as b where a.nik=b.nik and a.docno=b.docno and a.tgl=b.tgl and a.doctype=b.doctype and a.docref=b.docref;
		
	

		update sc_trx.payroll_pinjaman_inq a set sld=b.cocoldonkbang
		from (select *,sum("in_sld"-"out_sld") over(partition by nik,docno order by nik,docno,tgl,doctype,docref) as cocoldonkbang
		from sc_trx.payroll_pinjaman_inq) b
		where a.nik=b.nik and a.docno=b.docno and a.tgl=b.tgl and a.doctype=b.doctype and a.docref=b.docref
		and a.nik=old.nik and a.tgl>=old.tgl and a.docno=old.docno;

	
		RETURN old;	
	END IF;
	
			
return new;

end;
$$;

alter function payroll_pinjaman_inq() owner to postgres;

