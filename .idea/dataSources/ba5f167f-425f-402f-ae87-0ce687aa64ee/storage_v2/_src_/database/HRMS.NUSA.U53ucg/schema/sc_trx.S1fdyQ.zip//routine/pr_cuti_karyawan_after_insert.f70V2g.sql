create function pr_cuti_karyawan_after_insert() returns trigger
    language plpgsql
as
$$
declare


begin

update sc_trx.cuti_karyawan set status='A' where new.status='I' and nodok=new.nodok;

return new;

end;
$$;

alter function pr_cuti_karyawan_after_insert() owner to postgres;

