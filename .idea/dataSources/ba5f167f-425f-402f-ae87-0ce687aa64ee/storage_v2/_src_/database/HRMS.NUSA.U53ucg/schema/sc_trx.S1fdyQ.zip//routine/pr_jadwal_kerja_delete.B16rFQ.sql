create function pr_jadwal_kerja_delete() returns trigger
    language plpgsql
as
$$
DECLARE

BEGIN
	DELETE FROM sc_trx.dtljadwalkerja
	WHERE kdregu = old.kdregu AND tgl = old.tgl;

    RETURN new;
END;
$$;

alter function pr_jadwal_kerja_delete() owner to postgres;

