create function pr_lembur_after_insert() returns trigger
    language plpgsql
as
$$
declare
     vr_durasi integer;
     vr_jamselesai timestamp;
     vr_jammulai timestamp;
     vr_istirahat integer;
     vr_totaldurasi integer;
vr_kdlembur character(25);

begin

update sc_trx.lembur set status='A' where new.status='I' and nodok=new.nodok;
	vr_kdlembur:=trim(nodok) from sc_trx.lembur where nodok=new.nodok;

				--Lembur SMS	
insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
select telepon,sms,pengirim from 
(select c.nohp1 as telepon,'No. Lembur: '||a.nodok||' 
Nama: '||b.nmlengkap||'
Tgl: '||to_char(tgl_kerja,'dd-mm-yyyy')||'
Jam Awal: '||to_char(tgl_jam_mulai,'HH24:MI')||'
Jam Akhir: '||to_char(tgl_jam_selesai,'HH24:MI')||'
Conf: Y/N
Ket: '||coalesce(keterangan,'') as sms,
'OSIN' as pengirim
from sc_trx.lembur a
left outer join sc_mst.karyawan b on a.nik=b.nik
left outer join sc_mst.karyawan c on c.nik=b.nik_atasan
where nodok=new.nodok
) as t1 where telepon is not null and sms is not null and pengirim is not null;
	
	vr_jammulai:=tgl_jam_mulai from sc_trx.lembur where nodok=new.nodok;
	vr_jamselesai:=tgl_jam_selesai from sc_trx.lembur where nodok=new.nodok;
	vr_istirahat:=durasi_istirahat from sc_trx.lembur where nodok=new.nodok;
	
	if (vr_jamselesai>vr_jammulai) then 
		
		--vr_durasi:=extract(epoch from cast(to_char(cast(vr_jamselesai as timestamp) - cast(vr_jammulai as timestamp),'HH24:mi')as time)::interval)/60 as durasi;
		vr_durasi:=extract(epoch from cast(to_char(vr_jamselesai-vr_jammulai,'HH24:MI')as time)::interval)/60 as durasi;
		--insert into dumy(jumlah) values (vr_durasi);
		vr_totaldurasi=vr_durasi-vr_istirahat;
		update sc_trx.lembur set durasi=vr_totaldurasi where nodok=new.nodok;
	end if;
return new;


end;
$$;

alter function pr_lembur_after_insert() owner to postgres;

