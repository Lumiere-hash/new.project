create function pr_cutibersama_after_update() returns trigger
    language plpgsql
as
$$
declare
--@author : Fiky Ashariza
--@update by : Fiky Ashariza
--@update date : 10-06-2016  
vr_tgl_awal character(25);
vr_tgl_akhir character(25);
vr_hpdireksi character(25);  
vr_nmdireksi character(25);  
vr_jumlahcuti character(10); 
begin



	--select * from sc_trx.cutibersama
	IF (tg_op = 'INSERT') THEN
		select to_char(tgl_awal,'dd-mm-yyyy') as tgl_awal, to_char(tgl_akhir,'dd-mm-yyyy') as tgl_akhir,cast(jumlahcuti as character) into vr_tgl_awal,vr_tgl_akhir,vr_jumlahcuti from sc_trx.cutibersama where nodok=new.nodok;
		select trim(nohp1)as telepon,trim(nmlengkap) as nama into vr_hpdireksi,vr_nmdireksi from sc_mst.karyawan where bag_dept='DI' and subbag_dept='DR' and jabatan='D1';
	
				
		insert into sc_tmp.cuti_blc
		select nik,cast(to_char(now(),'dd-mm-yyyy HH24:MM:SS')as timestamp) as tanggal,trim(new.nodok) as no_dokumen,0 as in_cuti,new.jumlahcuti as out_cuti,0 as sisacuti,'OUT' as doctype,'F' as status
		from sc_mst.karyawan where tglkeluarkerja is null;

--CUTI BERSAMA KARYAWAN	
/*
insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
select vr_hpdireksi as nohp,
'No. CTBR CUTI BERSAMA: '||nodok||
' Jml cuti: '||jumlahcuti||' hari
tgl: '||to_char(tgl_awal,'DD-MM-YYYY')||' sd '||to_char(tgl_akhir,'DD-MM-YYYY')||'
conf: Y/N
ket: '||keterangan as isisms
,vr_nmdireksi from sc_trx.cutibersama
where nodok=new.nodok;
*/		
	return new;
	ELSEIF (tg_op = 'UPDATE') THEN
	select to_char(tgl_awal,'dd-mm-yyyy') as tgl_awal, to_char(tgl_akhir,'dd-mm-yyyy') as tgl_akhir,cast(jumlahcuti as character) into vr_tgl_awal,vr_tgl_akhir,vr_jumlahcuti from sc_trx.cutibersama where nodok=new.nodok;
	select trim(nohp1)as telepon,trim(nmlengkap) as nama into vr_hpdireksi,vr_nmdireksi from sc_mst.karyawan where bag_dept='DI' and subbag_dept='DR' and jabatan='D1';
	
	
	if (new.status='P')and(old.status='I') then
		
		update sc_tmp.cuti_blc set tanggal=new.tgl_dok,out_cuti=new.jumlahcuti where no_dokumen=new.nodok; --UPDATE TANGGAL BARU TANPA ADA EDIT
		insert into sc_trx.cuti_blc
		select * from sc_tmp.cuti_blc where no_dokumen=new.nodok and status='F';
/*
insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
select a.nohp1 as nohp,				
'CUTI BERSAMA '||trim(coalesce(c.keterangan,''))||' TGL: '||vr_tgl_awal||' S/D '||vr_tgl_akhir||'
Potong CUTI: '||vr_jumlahcuti||' Hari' as isisms
,'HRD'
from sc_mst.karyawan a left outer join
sc_tmp.cuti_blc b on a.nik=b.nik left outer join
sc_trx.cutibersama c on b.no_dokumen=c.nodok 
where a.tglkeluarkerja is null and b.no_dokumen=new.nodok and b.status='F'; 
*/

elseif (new.status='C')and(old.status='I') then
		delete from sc_tmp.cuti_blc where no_dokumen=new.nodok; --DELETE DARI TEMPORARY PEMBATALAN
		delete from sc_trx.cuti_blc where no_dokumen=new.nodok; --DELETE DARI TEMPORARY PEMBATALAN
/*		
insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
select vr_hpdireksi as nohp,				
'CUTI BERSAMA: '||nodok||
' Jml cuti: '||jumlahcuti||' hari
tgl: '||to_char(tgl_awal,'DD-MM-YYYY')||' S/D '||to_char(tgl_akhir,'DD-MM-YYYY')||'
DIBATALKAN/DITOLAK 
ket: '||keterangan as isisms
,vr_nmdireksi from sc_trx.cutibersama
where nodok=new.nodok;
*/		
	elseif (new.status='C')and(old.status='P') then	 
		delete from sc_tmp.cuti_blc where no_dokumen=new.nodok; --DELETE DARI TEMPORARY PEMBATALAN
		delete from sc_trx.cuti_blc where no_dokumen=new.nodok; --DELETE DARI TEMPORARY	PEMBATALAN
	end if;

	perform sc_trx.pr_rekap_cutiblcall();

	return new;
	ELSEIF (tg_op = 'DELETE') THEN
		delete from sc_tmp.cuti_blc where no_dokumen=old.nodok;
		delete from sc_trx.cuti_blc where no_dokumen=old.nodok;
	
		
	perform sc_trx.pr_rekap_cutiblcall();
	return old;
	END IF;
	return null;
end;

$$;

alter function pr_cutibersama_after_update() owner to postgres;

