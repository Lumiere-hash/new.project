create function tr_trx_stgblco() returns trigger
    language plpgsql
as
$$
DECLARE 
	--author by fiky: 12/08/2017
	--update by fiky: 12/08/2017
    vr_qtysisa numeric;
    vr_docno character(50);
    vr_balance numeric; 
    vr_ceknik character(12);   
BEGIN		
	IF tg_op = 'INSERT' THEN	
		--select * from sc_trx.stgblco order by branch,loccode,stockcode,trxdate,doctype,docno,docref;
		update sc_trx.stgblco a set qty_sld=b.balance
		from (select *,sum("qty_in"-"qty_out") over(partition by branch,loccode,kdgroup,kdsubgroup,stockcode order by branch,loccode,kdgroup,kdsubgroup,stockcode,trxdate,doctype,docno,docref) as balance
		from sc_trx.stgblco) b
		where a.branch=b.branch and a.loccode=b.loccode and a.kdgroup=b.kdgroup and a.kdsubgroup=b.kdsubgroup and a.stockcode=b.stockcode and a.trxdate=b.trxdate and a.doctype=b.doctype and 
		a.docno=b.docno and a.docref=b.docref 
		and a.branch=new.branch and a.loccode=new.loccode and a.kdgroup=new.kdgroup and a.kdsubgroup=new.kdsubgroup and a.stockcode=new.stockcode;
		
		select coalesce(a.qty_sld,0) as qty_sld,trim(a.docno) as docno into vr_qtysisa,vr_docno from sc_trx.stgblco a,
		(select a.branch,a.loccode,a.kdgroup,a.kdsubgroup,a.stockcode,a.trxdate,a.doctype,a.docno,max(a.docref) as docref from sc_trx.stgblco a,
		(select a.branch,a.loccode,a.kdgroup,a.kdsubgroup,a.stockcode,a.trxdate,a.doctype,max(a.docno) as docno from sc_trx.stgblco a,
		(select a.branch,a.loccode,a.kdgroup,a.kdsubgroup,a.stockcode,a.trxdate,max(a.doctype) as doctype from sc_trx.stgblco a,
		(select branch,loccode,kdgroup,kdsubgroup,stockcode,max(trxdate) as trxdate from sc_trx.stgblco
		--where branch='SBYNSA' and loccode='SBYMRG' and stockcode='PEN000002' 
		where branch=new.branch and loccode=new.loccode and stockcode=new.stockcode
		group by branch,loccode,kdgroup,kdsubgroup,stockcode) as b
		where a.branch=b.branch and a.loccode=b.loccode and a.kdgroup=b.kdgroup and a.kdsubgroup=b.kdsubgroup and a.stockcode=b.stockcode and a.trxdate=b.trxdate
		group by a.branch,a.loccode,a.kdgroup,a.kdsubgroup,a.stockcode,a.trxdate) as  b
		where a.branch=b.branch and a.loccode=b.loccode  and a.kdgroup=b.kdgroup and a.kdsubgroup=b.kdsubgroup and a.stockcode=b.stockcode and a.trxdate=b.trxdate and a.doctype=b.doctype 
		group by a.branch,a.loccode,a.kdgroup,a.kdsubgroup,a.stockcode,a.trxdate,a.doctype) as b
		where a.branch=b.branch and a.loccode=b.loccode and a.kdgroup=b.kdgroup and a.kdsubgroup=b.kdsubgroup and a.stockcode=b.stockcode and a.trxdate=b.trxdate and a.doctype=b.doctype and a.docno=b.docno
		group by a.branch,a.loccode,a.kdgroup,a.kdsubgroup,a.stockcode,a.trxdate,a.doctype,a.docno) as b
		where a.branch=b.branch and a.loccode=b.loccode and a.kdgroup=b.kdgroup and a.kdsubgroup=b.kdsubgroup and a.stockcode=b.stockcode and a.trxdate=b.trxdate and a.doctype=b.doctype and a.docno=b.docno and a.docref=b.docref
		group by a.branch,a.loccode,a.kdgroup,a.kdsubgroup,a.stockcode,a.trxdate,a.doctype,a.docno,a.docref;
		
		--select * from sc_mst.stkgdw
		--select * from sc_trx.stgblco
		---update sc_mst.stkgdw set onhand=vr_qtysisa,docno=vr_docno,lastdate=new.trxdate where branch=new.branch and loccode=new.loccode and stockcode=new.stockcode ;
		--alter table sc_mst.stkgdw alter column lastdate type timestamp without time zone using lastdate::timestamp without time zone;

		RETURN new;
	ELSEIF tg_op = 'DELETE' THEN
		update sc_trx.stgblco a set qty_sld=b.balance
		from (select *,sum("qty_in"-"qty_out") over(partition by branch,loccode,kdgroup,kdsubgroup,stockcode order by branch,loccode,kdgroup,kdsubgroup,stockcode,trxdate,doctype,docno,docref) as balance
		from sc_trx.stgblco) b
		where a.branch=b.branch and a.loccode=b.loccode and a.kdgroup=b.kdgroup and a.kdsubgroup=b.kdsubgroup and a.stockcode=b.stockcode and a.trxdate=b.trxdate and a.doctype=b.doctype and 
		a.docno=b.docno and a.docref=b.docref 
		and a.branch=old.branch and a.loccode=old.loccode and a.kdgroup=old.kdgroup and a.kdsubgroup=old.kdsubgroup and a.stockcode=old.stockcode;
		
		select coalesce(a.qty_sld,0) as qty_sld,trim(a.docno) as docno into vr_qtysisa,vr_docno from sc_trx.stgblco a,
		(select a.branch,a.loccode,a.kdgroup,a.kdsubgroup,a.stockcode,a.trxdate,a.doctype,a.docno,max(a.docref) as docref from sc_trx.stgblco a,
		(select a.branch,a.loccode,a.kdgroup,a.kdsubgroup,a.stockcode,a.trxdate,a.doctype,max(a.docno) as docno from sc_trx.stgblco a,
		(select a.branch,a.loccode,a.kdgroup,a.kdsubgroup,a.stockcode,a.trxdate,max(a.doctype) as doctype from sc_trx.stgblco a,
		(select branch,loccode,kdgroup,kdsubgroup,stockcode,max(trxdate) as trxdate from sc_trx.stgblco
		--where branch='SBYNSA' and loccode='SBYMRG' and stockcode='PEN000002' 
		where branch=old.branch and loccode=old.loccode and stockcode=old.stockcode
		group by branch,loccode,kdgroup,kdsubgroup,stockcode) as b
		where a.branch=b.branch and a.loccode=b.loccode and a.kdgroup=b.kdgroup and a.kdsubgroup=b.kdsubgroup and a.stockcode=b.stockcode and a.trxdate=b.trxdate
		group by a.branch,a.loccode,a.kdgroup,a.kdsubgroup,a.stockcode,a.trxdate) as  b
		where a.branch=b.branch and a.loccode=b.loccode  and a.kdgroup=b.kdgroup and a.kdsubgroup=b.kdsubgroup and a.stockcode=b.stockcode and a.trxdate=b.trxdate and a.doctype=b.doctype 
		group by a.branch,a.loccode,a.kdgroup,a.kdsubgroup,a.stockcode,a.trxdate,a.doctype) as b
		where a.branch=b.branch and a.loccode=b.loccode and a.kdgroup=b.kdgroup and a.kdsubgroup=b.kdsubgroup and a.stockcode=b.stockcode and a.trxdate=b.trxdate and a.doctype=b.doctype and a.docno=b.docno
		group by a.branch,a.loccode,a.kdgroup,a.kdsubgroup,a.stockcode,a.trxdate,a.doctype,a.docno) as b
		where a.branch=b.branch and a.loccode=b.loccode and a.kdgroup=b.kdgroup and a.kdsubgroup=b.kdsubgroup and a.stockcode=b.stockcode and a.trxdate=b.trxdate and a.doctype=b.doctype and a.docno=b.docno and a.docref=b.docref
		group by a.branch,a.loccode,a.kdgroup,a.kdsubgroup,a.stockcode,a.trxdate,a.doctype,a.docno,a.docref;
		

		--select * from sc_mst.stkgdw
		----update sc_mst.stkgdw set onhand=vr_qtysisa,docno=vr_docno,lastdate=old.trxdate where branch=old.branch and loccode=old.loccode and stockcode=old.stockcode ;
		
		RETURN old;	
	END IF;
	
END;
$$;

alter function tr_trx_stgblco() owner to postgres;

