create function pr_cuti_karyawan_after_update() returns trigger
    language plpgsql
as
$$
declare

vr_status_ptg character(3);
vr_sisa numeric;
vr_nikrows character(12);
vr_tgloff date;
vr_tglmulai date;
vr_tglselesai date;
--@update by : Fiky Ashariza
--@update date : 30-01-2020   
--@revision : Penambahan notifikasi approval mobile 
 
begin
PERFORM sc_trx.pr_rekap_cutiblcall();

vr_status_ptg:=coalesce(status_ptg,'A1') from sc_trx.cuti_karyawan where nodok=new.nodok;
vr_sisa:=coalesce(a.sisacuti,0) from sc_trx.cuti_lalu a,
			(select a.nik,a.tanggal,a.no_dokumen,max(a.doctype) as doctype from sc_trx.cuti_lalu a,
			(select a.nik,a.tanggal,max(a.no_dokumen) as no_dokumen from sc_trx.cuti_lalu a,
			(select nik,max(tanggal) as tanggal from sc_trx.cuti_lalu  
			group by nik
			) as b
			where a.nik=b.nik and a.tanggal=b.tanggal
			group by a.nik,a.tanggal) b
			where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen
			group by a.nik,a.tanggal,a.no_dokumen ) b
			where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen and a.doctype=b.doctype and a.nik=new.nik;
			
vr_nikrows:=count(trim(coalesce(nik,'')))from sc_mst.karyawan where tglmasukkerja<=cast(to_char(now()-interval '1 year','yyyy-mm-dd')as date)
	and (to_char(tglmasukkerja,'mm-dd') between to_char(now()-interval '2 months','mm-dd')and to_char(now(),'mm-dd')) and nik=new.nik;			

vr_tgloff:=cast(replace(to_char(tglmasukkerja+interval '2 months','yyyy-mm-dd'),left(to_char(tglmasukkerja+interval '2 months','yyyy-mm-dd'),4),to_char(now(),'yyyy'))as date)as tgloff from sc_mst.karyawan where tglmasukkerja<=cast(to_char(now()-interval '1 year','yyyy-mm-dd')as date)
	and nik=new.nik;

vr_tglmulai:=tgl_mulai from sc_trx.cuti_karyawan where nik=new.nik and nodok=new.nodok;
vr_tglselesai:=tgl_selesai from sc_trx.cuti_karyawan where nik=new.nik and nodok=new.nodok;
	
 
  if (new.status='P')and(old.status='A') then

	update sc_trx.approvals_system set status='U',asstatus='P' where docno = new.nodok and status!='U';

	if exists (select * from sc_trx.cuti_karyawan where nodok=new.nodok and status='P') then 

	 
			INSERT INTO sc_trx.cuti_blc(nik,tanggal,no_dokumen,in_cuti,out_cuti,sisacuti,doctype,status) 
			select nik,vr_tglselesai,new.nodok,jumlah_cuti, jumlah_cuti,0,'DNS','P'  
			from sc_trx.cuti_karyawan where nodok=new.nodok and new.tpcuti='C' ;

			INSERT INTO sc_trx.cuti_blc(nik,tanggal,no_dokumen,in_cuti,out_cuti,sisacuti,doctype,status) 
			select nik,vr_tglselesai,new.nodok,jumlah_cuti, jumlah_cuti,0,'IJKHS','P'  
			from sc_trx.cuti_karyawan where nodok=new.nodok and new.tpcuti='B' ;

	/*---SELF SMS----
	insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
	select b.nohp1,			
	'Sdr/i '||coalesce(b.nmlengkap,'')||' Cuti Type '||
case 
when coalesce(a.status_ptg,'A1')='A1' then 'POTONG CUTI '
when coalesce(a.status_ptg,'A1')='A2' then 'POTONG GAJI '
end 
||'dengan no. '||coalesce(a.nodok,'')||' Di Setujui,Tgl: '||to_char(tgl_mulai,'dd-mm-yyyy')||' sd '||to_char(tgl_selesai,'dd-mm-yyyy')
	,nmlengkap
	from sc_trx.cuti_karyawan a
	left outer join sc_mst.karyawan b on a.nik=b.nik
	where a.nodok=new.nodok and a.status='P';*/
	
	/*---SMS KE HRD----	
	insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
	select telepon,'No Cuti Type '||
case 
when coalesce(status_ptg,'A1')='A1' then 'POTONG CUTI '
when coalesce(status_ptg,'A1')='A2' then 'POTONG GAJI '
end 
||' :'||coalesce(nodok,'')||' '||coalesce(nmlengkap,'')||' tgl: '||to_char(tgl_mulai,'dd-mm-yyyy')||' sd '||to_char(tgl_selesai,'dd-mm-yyyy')||' Telah Di setujui','OSIN'  from
	(select t0.*,trim(t3.nohp1) as telepon,t1.nodok,t1.nik,t1.nmlengkap,t1.sisacuti,t1.tgl_mulai,t1.tgl_selesai,t1.nik as nikcuti,t1.status_ptg from sc_mst.notif_sms t0
	left outer join (select	case b.kdcabang	when 'SBYMRG' then 'Y'	end as kanwil_sby,
				case b.kdcabang	when 'SMGDMK' then 'Y'	end as kanwil_dmk,
				case b.kdcabang	when 'SMGCND' then 'Y'	end as kanwil_smg,
				case b.kdcabang	when 'JKTKPK' then 'Y'	end as kanwil_jkt,
				a.*,b.nmlengkap,b.sisacuti from sc_trx.cuti_karyawan a
			left outer join sc_mst.karyawan b on a.nik=b.nik
			--where nodok=new.nodok 
			) as t1
			on t0.kanwil_sby=t1.kanwil_sby or
			t0.kanwil_smg=t1.kanwil_smg or
			t0.kanwil_dmk=t1.kanwil_dmk or
			t0.kanwil_jkt=t1.kanwil_jkt
	left outer join sc_mst.karyawan t3 on t0.nik=t3.nik		
	where cuti='Y') as t2
	where telepon is not null and nodok=new.nodok;
*/
	/* SMS KE ATASAN 1&2 
	insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
	select telepon,textdecoded,nmlengkap from 
	(select c.nohp1 as telepon,			
	'Sdr/i '||coalesce(a.nmlengkap,'')||' Cuti Type '||
case 
when coalesce(b.status_ptg,'A1')='A1' then 'POTONG CUTI '
when coalesce(b.status_ptg,'A1')='A2' then 'POTONG GAJI '
end 
||'dengan no. '||coalesce(b.nodok,'')||' Di Setujui,TGL Cuti:'||to_char(b.tgl_mulai,'dd-mm-yyyy')||'s/d TGL:'||to_char(b.tgl_selesai,'dd-mm-yyyy') as textdecoded
	,a.nmlengkap,a.nik,b.nodok
	from sc_mst.karyawan a  
	left outer join  sc_trx.cuti_karyawan b on a.nik=b.nik
	left outer join  sc_mst.karyawan c on a.nik_atasan=c.nik
	left outer join  sc_mst.karyawan d on a.nik_atasan2=d.nik
	union all
	select d.nohp1,			
	'Sdr/i '||coalesce(a.nmlengkap,'')||' Cuti dengan no. '||coalesce(b.nodok,'')||' Di Setujui,TGL Cuti:'||to_char(b.tgl_mulai,'dd-mm-yyyy')||'s/d TGL:'||to_char(b.tgl_selesai,'dd-mm-yyyy') as textdecoded
	,a.nmlengkap,a.nik,b.nodok
	from sc_mst.karyawan a  
	left outer join  sc_trx.cuti_karyawan b on a.nik=b.nik
	left outer join  sc_mst.karyawan c on a.nik_atasan=c.nik
	left outer join  sc_mst.karyawan d on a.nik_atasan2=d.nik) as x
	where nik=new.nik and nodok=new.nodok and telepon is not null;
	*/

	/*SMS Ke Karyawan Pelimpahan
	insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
	select c.nohp1,			
	'Sdr/i '||coalesce(c.nmlengkap,'')||' Cuti '||coalesce(b.nmlengkap,'')||' Di Setujui dan Pekerjaan Dilimpahkan Ke Sdr/i,TGL'||to_char(a.tgl_mulai,'dd-mm-yyyy')||' s/d TGL:'||to_char(a.tgl_selesai,'dd-mm-yyyy'),c.nmlengkap
	from sc_trx.cuti_karyawan a  
	left outer join  sc_mst.karyawan b on a.nik=b.nik
	left outer join  sc_mst.karyawan c on a.pelimpahan=c.nik
	where a.nik=new.nik and a.nodok=new.nodok and c.nohp1 is not null;
	*/
			
	if(vr_status_ptg='A1' and new.tpcuti='A') then	--potong cuti

	INSERT INTO sc_trx.cuti_blc(nik,tanggal,no_dokumen,in_cuti,out_cuti,sisacuti,doctype,status) 
	select nik,vr_tglselesai,new.nodok,0, jumlah_cuti,0,'OUT','P'  
	from sc_trx.cuti_karyawan where new.status='P' and nodok=new.nodok and tpcuti='A';
		if(vr_sisa>0 and vr_nikrows>='1' and (vr_tgloff>=vr_tglmulai or vr_tgloff>=vr_tglselesai))then
			INSERT INTO sc_trx.cuti_lalu(nik,tanggal,no_dokumen,in_cuti,out_cuti,sisacuti,doctype,status) 
			select nik,vr_tglselesai,new.nodok,0, jumlah_cuti,0,'OUT','P'  
			from sc_trx.cuti_karyawan where new.status='P' and nodok=new.nodok and new.tpcuti='A';
		end if;	
		

	
	end if;
	else if(vr_status_ptg='A2'  and new.tpcuti='A') then --potong gaji

	INSERT INTO sc_trx.cuti_blc(nik,tanggal,no_dokumen,in_cuti,out_cuti,sisacuti,doctype,status) 
	select nik,vr_tglselesai,new.nodok,jumlah_cuti, jumlah_cuti,0,'PTG','P'  
	from sc_trx.cuti_karyawan where new.status='P' and nodok=new.nodok and new.tpcuti='A';
	
	end if;
		--if(new.tpcuti='B' or new.tpcuti='C') and new.status='P' then
			
		--end if;
	PERFORM sc_trx.pr_rekap_cutiblcall();

	end if;
	
end if;
if(new.status='C') and (old.status='P') then
	/* CALLBACK APPROVAL*/
	update sc_trx.approvals_system set status='C',asstatus='C' where docno = new.nodok;
	/*---SELF SMS----
	insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
	select b.nohp1,			
	'Sdr/i '||coalesce(b.nmlengkap,'')||' Cuti dengan no. '||coalesce(a.nodok,'')||' Di Batalkan,Tgl: '||to_char(tgl_mulai,'dd-mm-yyyy')||' sd '||to_char(tgl_selesai,'dd-mm-yyyy')
	,nmlengkap
	from sc_trx.cuti_karyawan a
	left outer join sc_mst.karyawan b on a.nik=b.nik
	where a.status='C' and a.nodok=new.nodok;
	
*/
	/*---SMS KE HRD----	
	insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
	select telepon,'No Cuti :'||coalesce(nodok,'')||' '||coalesce(nmlengkap,'')||' tgl: '||to_char(tgl_mulai,'dd-mm-yyyy')||' sd '||to_char(tgl_selesai,'dd-mm-yyyy')||' DIBATALKAN','OSIN'  from
	(select t0.*,trim(t3.nohp1) as telepon,t1.nodok,t1.nik,t1.nmlengkap,t1.sisacuti,t1.tgl_mulai,t1.tgl_selesai,t1.nik as nikcuti from sc_mst.notif_sms t0
	left outer join (select	case b.kdcabang	when 'SBYMRG' then 'Y'	end as kanwil_sby,
				case b.kdcabang	when 'SMGDMK' then 'Y'	end as kanwil_dmk,
				case b.kdcabang	when 'SMGCND' then 'Y'	end as kanwil_smg,
				case b.kdcabang	when 'JKTKPK' then 'Y'	end as kanwil_jkt,
				a.*,b.nmlengkap,b.sisacuti from sc_trx.cuti_karyawan a
			left outer join sc_mst.karyawan b on a.nik=b.nik
			--where nodok=new.nodok 
			) as t1
			on t0.kanwil_sby=t1.kanwil_sby or
			t0.kanwil_smg=t1.kanwil_smg or
			t0.kanwil_dmk=t1.kanwil_dmk or
			t0.kanwil_jkt=t1.kanwil_jkt
	left outer join sc_mst.karyawan t3 on t0.nik=t3.nik		
	where cuti='Y') as t2
	where telepon is not null and nodok=new.nodok;
	*/

	/* SMS KE ATASAN 1&2 
	insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
	select telepon,textdecoded,nmlengkap from 
	(select c.nohp1 as telepon,			
	'Sdr/i '||coalesce(a.nmlengkap,'')||' Cuti dengan no. '||coalesce(b.nodok,'')||' TGL Cuti:'||to_char(b.tgl_mulai,'dd-mm-yyyy')||'s/d TGL:'||to_char(b.tgl_selesai,'dd-mm-yyyy')||'DIBATALKAN' as textdecoded
	,a.nmlengkap,a.nik,b.nodok
	from sc_mst.karyawan a  
	left outer join  sc_trx.cuti_karyawan b on a.nik=b.nik
	left outer join  sc_mst.karyawan c on a.nik_atasan=c.nik
	left outer join  sc_mst.karyawan d on a.nik_atasan2=d.nik
	union all
	select d.nohp1,			
	'Sdr/i '||coalesce(a.nmlengkap,'')||' Cuti dengan no. '||coalesce(b.nodok,'')||' TGL Cuti:'||to_char(b.tgl_mulai,'dd-mm-yyyy')||'s/d TGL:'||to_char(b.tgl_selesai,'dd-mm-yyyy')||'DIBATALKAN' as textdecoded
	,a.nmlengkap,a.nik,b.nodok
	from sc_mst.karyawan a  
	left outer join  sc_trx.cuti_karyawan b on a.nik=b.nik
	left outer join  sc_mst.karyawan c on a.nik_atasan=c.nik
	left outer join  sc_mst.karyawan d on a.nik_atasan2=d.nik) as x
	where nik=new.nik and nodok=new.nodok and telepon is not null;
	*/

	/*SMS Ke Karyawan Pelimpahan
	insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
	select c.nohp1,			
	'Sdr/i '||coalesce(c.nmlengkap,'')||' Cuti '||coalesce(b.nmlengkap,'')||',TGL'||to_char(a.tgl_mulai,'dd-mm-yyyy')||' s/d TGL:'||to_char(a.tgl_selesai,'dd-mm-yyyy')||'DIBATALKAN',c.nmlengkap
	from sc_trx.cuti_karyawan a  
	left outer join  sc_mst.karyawan b on a.nik=b.nik
	left outer join  sc_mst.karyawan c on a.pelimpahan=c.nik
	where a.nik=new.nik and a.nodok=new.nodok and c.nohp1 is not null;

	*/

	if(old.status_ptg='A1' and new.tpcuti='A') then --potong cuti

		INSERT INTO sc_trx.cuti_blc(nik,tanggal,no_dokumen,in_cuti,out_cuti,sisacuti,doctype,status) 
		select nik,cast(to_char(now(),'yyyy-mm-dd hh24:mi:ss') as timestamp),new.nodok,jumlah_cuti,0,0,'IN','C'  
		from sc_trx.cuti_karyawan where status='C' and nodok=new.nodok and new.tpcuti='A';
			if(vr_sisa>0)then
				delete from sc_trx.cuti_lalu where no_dokumen=new.nodok;
			end if;	
			
			
	end if;
	else if(old.status_ptg='A2' and new.tpcuti='A') then --potong gaji
	
		INSERT INTO sc_trx.cuti_blc(nik,tanggal,no_dokumen,in_cuti,out_cuti,sisacuti,doctype,status) 
		select nik, cast(to_char(now(),'yyyy-mm-dd hh24:mi:ss') as timestamp),new.nodok,jumlah_cuti,jumlah_cuti,0,'PTG','C'  
		from sc_trx.cuti_karyawan where status='C' and nodok=new.nodok and new.tpcuti='A';

	
	end if;

	
	if (new.status='A') and (old.status='I') then
	perform sc_trx.pr_capture_approvals_system();
	/* SMS NOTIF UNTUK APPROVAL
	insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
select nohp,left(isisms,160),nmlengkap from (
select trim(both '_' from c.nohp1) as nohp,'No. Cuti: '||coalesce(nodok,'')||'
Nama: '||coalesce(b.nmlengkap,'')||'
Jml cuti: '||coalesce(jumlah_cuti,0)||' hari 
tgl: '||to_char(tgl_mulai,'dd-mm-yyyy')||' sd '||to_char(tgl_selesai,'dd-mm-yyyy')||'
conf: Y/N 
ket: '||a.keterangan as isisms
,b.nmlengkap
			from sc_trx.cuti_karyawan a
			left outer join  sc_mst.karyawan b on a.nik=b.nik
			left outer join  sc_mst.karyawan c on c.nik=b.nik_atasan
			where a.nodok=new.nodok
			) as t1;
			 */
	elseif 	(new.status='M') and (old.status='A') then	
	/* SMS NOTIF UNTUK APPROVAL
		insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
select nohp,left(isisms,160),nmlengkap from (
select trim(both '_' from c.nohp1) as nohp,'No. Cuti: '||coalesce(nodok,'')||'
Nama: '||coalesce(b.nmlengkap,'')||'
Jml cuti: '||coalesce(jumlah_cuti,0)||' hari 
tgl: '||to_char(tgl_mulai,'dd-mm-yyyy')||' sd '||to_char(tgl_selesai,'dd-mm-yyyy')||'
conf: Y/N 
ket: '||a.keterangan as isisms
,b.nmlengkap
			from sc_trx.cuti_karyawan a
			left outer join  sc_mst.karyawan b on a.nik=b.nik
			left outer join  sc_mst.karyawan c on c.nik=b.nik_atasan
			where a.nodok=new.nodok
			) as t1;
			*/	
		update sc_trx.cuti_karyawan set status=old.status where nodok=new.nodok;	
	end if;	

PERFORM sc_trx.pr_rekap_cutiblcall();
end if;	
if (new.status IN ('C','D') and old.status NOT IN ('C','D')) then

update sc_trx.approvals_system set status='C',asstatus='C' where docno = new.nodok and status!='C';

elseif(new.status IN ('P') and old.status NOT IN ('P')) THEN

update sc_trx.approvals_system set status='U',asstatus='P' where docno = new.nodok and status!='U';

end if;
	
return new;

end;
$$;

alter function pr_cuti_karyawan_after_update() owner to postgres;

