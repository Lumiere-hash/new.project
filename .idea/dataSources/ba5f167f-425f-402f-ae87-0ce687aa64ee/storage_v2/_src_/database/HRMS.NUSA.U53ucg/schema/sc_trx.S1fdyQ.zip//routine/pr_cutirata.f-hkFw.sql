create function pr_cutirata() returns SETOF void
    language plpgsql
as
$$
    --create by Fiky Ashariza : 08-04-2016
--update by Fiky Ashariza : 20-07-2016
--cutirata ulang tahun -5 KABISAT

DECLARE vr_ceknik char(12);
DECLARE	vr_cekpkblc integer;
DECLARE vr_cekpklalu integer;
DECLARE vr_cutilalu2month char(12);
DECLARE vr_sisarate numeric;

BEGIN

--rebalance sebelum insert
perform sc_trx.pr_rekap_cutiblcall();


--cek cuti rata ulang tahun karyawan hingga minus -5 hari dari hari h ultah antisipasi kabisat
FOR vr_ceknik in select trim(coalesce(nik,'')) from sc_mst.karyawan where tglmasukkerja<=cast(to_char(now()-interval '1 year','yyyy-mm-dd')as date)
and (to_char(tglmasukkerja,'mm-dd') between to_char(now(),'mm-dd') and to_char(now()+interval '5 days','mm-dd') )

--FOR vr_ceknik in select trim(coalesce(nik,'')) from sc_mst.karyawan where tglmasukkerja<=cast(to_char(cast('2017-01-01' as date)-interval '1 year','yyyy-mm-dd')as date)
--and (to_char(tglmasukkerja,'mm-dd') between to_char(cast('2017-01-01' as date),'mm-dd') and to_char(cast('2017-01-01' as date)+interval '5 days','mm-dd') ) and nik is not null
	
	
	LOOP
		vr_sisarate:=sisacuti from sc_mst.karyawan where nik=vr_ceknik;

		if(to_char(now(),'yyyy')>'2017') then
			PERFORM sc_trx.pr_hanguscuti_nik(vr_ceknik); ---hangus cuti dulu baru insert nanti untuk ultah 2018
		end if;
		vr_cekpkblc:=count(*) from sc_trx.cuti_blc where nik=vr_ceknik and status='Cuti '||to_char(now(),'YYYY') and no_dokumen=vr_ceknik and doctype='IN';  
		--vr_cekpkblc:=
		--select * from sc_trx.cuti_blc where nik='00121501' and status='Cuti '||to_char(now(),'YYYY') and no_dokumen='00121501' and doctype='IN';  

		vr_sisarate:=sisacuti from sc_mst.karyawan where nik=vr_ceknik;
		IF vr_cekpkblc=0 THEN

			if((select count(nik) from sc_his.cuti_blc where nik=vr_ceknik)>0 and (select to_char(now(),'yyyy')='2017')) then --penambahan prorate hanya 1th normalisasi 2018
				insert into sc_trx.cuti_blc --penambahan cuti + prorate(tahun2018)
			    select vr_ceknik as nik,cast(to_char(now(),'YYYY-MM-DD 00:06:06')as timestamp) as tanggal,
			    vr_ceknik as no_dokumen,((select in_cuti from sc_his.cuti_blc where nik=vr_ceknik)) as in_cuti,0 as out_cuti, 0 as sisacuti,'IN' as doctype, 'Cuti '||to_char(now(),'YYYY') as status from sc_mst.karyawan 
			    where nik=vr_ceknik;
			    
			else
			    
				insert into sc_trx.cuti_blc --penambahan cuti ultah normal
			    select vr_ceknik as nik,cast(to_char(now(),'YYYY-MM-DD 00:06:06')as timestamp) as tanggal,
			    vr_ceknik as no_dokumen,12 as in_cuti,0 as out_cuti, 0 as sisacuti,'IN' as doctype, 'Cuti '||to_char(now(),'YYYY') as status from sc_mst.karyawan 
			    where nik=vr_ceknik;	    
			end if;
		    
		END IF;
	
	RETURN NEXT vr_ceknik;
	END LOOP;
	perform sc_trx.pr_rekap_cutiblcall(); --hitung ulang

	--cek hangus cuti kondisi khusus karyawan -5 days antisipasi kabisat
	FOR vr_cutilalu2month in select trim(coalesce(nik,''))
					from sc_mst.karyawan where tglmasukkerja<=cast(to_char(now()-interval '1 year','yyyy-mm-dd')as date)
					and to_char(tglmasukkerja,'mm-dd') between  to_char(((now()-interval '2 months')-interval '5 days'),'mm-dd') 
					and to_char(now()-interval '2 months','mm-dd') 

	LOOP
	PERFORM sc_trx.pr_hanguscutilalu_nik(trim(coalesce(vr_cutilalu2month,''))); --hangus cuti lalu setelah 2 bulan 
	RETURN NEXT vr_cutilalu2month;
	END LOOP;

	perform sc_trx.pr_rekap_cutiblcall(); --hitung ulang
	RETURN;
	

	
END;
$$;

alter function pr_cutirata() owner to postgres;

