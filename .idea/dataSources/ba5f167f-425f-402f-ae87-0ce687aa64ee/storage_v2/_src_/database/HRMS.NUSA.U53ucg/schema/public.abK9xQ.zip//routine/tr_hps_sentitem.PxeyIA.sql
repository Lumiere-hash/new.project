create function tr_hps_sentitem() returns trigger
    language plpgsql
as
$$
BEGIN  

	update sc_log.trash_outbox set no_penerima=t1."DestinationNumber", isi_sms=t1."TextDecoded", tanggal_kirim=t1."SendingDateTime" from
	(select "DestinationNumber", "TextDecoded", "SendingDateTime" from sentitems where "ID"=NEW.id) as t1			
	where id=NEW.id;

	delete from sentitems where "ID" = NEW.id; 
	
	RETURN NEW;  

END;

$$;

alter function tr_hps_sentitem() owner to postgres;

