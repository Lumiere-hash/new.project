create function tr_mapping_satuan_brg() returns trigger
    language plpgsql
as
$$
DECLARE 
	--author by fiky: 21/08/2017
	--update by fiky: 21/08/2017
    vr_sisacuti integer :=0;
    vr_balance integer :=0; 
    vr_ceknik character(12);   
BEGIN		
	IF tg_op = 'INSERT' THEN
		
		RETURN new;
	ELSEIF tg_op = 'UPDATE' THEN
		/*
		IF (new.status='P' and old.status='A') THEN
			--select * from sc_mst.stkgdw
			--SELECT * FROM SC_TRX.PO_ORDER;
			--SELECT * FROM SC_TRX.STGBLCBR ORDER BY BRANCH,LOCCODE,STOCKCODE,TRXDATE,DOCTYPE,DOCNO,DOCREF;
			insert into sc_trx.stgblcbr (branch,loccode,stockcode,trxdate,doctype,docno,docref,qty_in,qty_out,qty_sld,hist,ctype)
			(select branch,loccode,stockcode,to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp as trxdate,'BBM',nodok as docno,'' as docref,
			qtypo as qty_in,0 as qty_out,0 as qty_sld,null as hist,null as ctype from sc_trx.PO_ORDER where nodok=new.nodok);
		ELSEIF (new.status='C' and old.status='P') THEN
			delete from sc_trx.stgblcbr where docno=new.nodok and doctype='BBM';
		
		END IF; */
		RETURN NEW;
	ELSEIF tg_op = 'DELETE' THEN
			IF EXISTS(select * from sc_trx.po_dtlref where kdgroup=old.kdgroup and kdsubgroup=old.kdsubgroup and stockcode=old.stockcode and satkecil=old.satkecil
			and satminta=old.satbesar limit 1) THEN
				insert into sc_mst.mapping_satuan_brg 
				(branch,satkecil,satbesar,qty,keterangan,inputdate,inputby,updatedate,updateby,kdgroup,kdsubgroup,stockcode)
				values
				(old.branch,old.satkecil,old.satbesar,old.qty,old.keterangan,old.inputdate,old.inputby,old.updatedate,old.updateby,old.kdgroup,old.kdsubgroup,old.stockcode);

				delete from sc_mst.trxerror where userid='MP' and modul='MSTMAPSTOCK';
				insert into sc_mst.trxerror
				(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
				('MP',1,'MP','','MSTMAPSTOCK');

				RAISE NOTICE 'EITSS MAPING SUDAH DIJALANKAN DI PO/SPPB DILARANG HAPUS(%)', old.satkecil||'-'||old.satbesar;
			ELSEIF(select * from sc_trx.sppb_dtl where kdgroup=old.kdgroup and kdsubgroup=old.kdsubgroup and stockcode=old.stockcode and satkecil=old.satkecil
			and satminta=old.satbesar limit 1) THEN
				insert into sc_mst.mapping_satuan_brg 
				(branch,satkecil,satbesar,qty,keterangan,inputdate,inputby,updatedate,updateby,kdgroup,kdsubgroup,stockcode)
				values
				(old.branch,old.satkecil,old.satbesar,old.qty,old.keterangan,old.inputdate,old.inputby,old.updatedate,old.updateby,old.kdgroup,old.kdsubgroup,old.stockcode);

				delete from sc_mst.trxerror where userid='MP' and modul='MSTMAPSTOCK';
				insert into sc_mst.trxerror
				(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
				('MP',1,'MP','','MSTMAPSTOCK');

				RAISE NOTICE 'EITSS MAPING SUDAH DIJALANKAN DI PO/SPPB DILARANG HAPUS(%)', old.satkecil||'-'||old.satbesar;
			END IF;

				delete from sc_mst.trxerror where userid='MP' and modul='MSTMAPSTOCK';
				insert into sc_mst.trxerror
				(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
				('MP',0,'MP','','MSTMAPSTOCK');
				
		RETURN old;	
	END IF;
	
END;
$$;

alter function tr_mapping_satuan_brg() owner to postgres;

