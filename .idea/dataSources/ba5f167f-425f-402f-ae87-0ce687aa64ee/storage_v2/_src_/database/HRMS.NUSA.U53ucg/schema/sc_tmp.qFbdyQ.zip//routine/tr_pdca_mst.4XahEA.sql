create function tr_pdca_mst() returns trigger
    language plpgsql
as
$$
declare
--created by Fiky ::18/07/2017
--Update by Fiky ::12/05/2018
--Penambahan Realisasidate&by
     vr_nomor char(12); 
     vr_cekprefix char(4);
     vr_nowprefix char(4);
begin    

	IF TG_OP ='INSERT' THEN 

	RETURN NEW;
	ELSEIF TG_OP ='UPDATE' THEN
			/* NO RESOURCE UPDATE */
		if (new.status='' and old.status IN ('I','E','A','R','O')) then
		
			if exists(select * from sc_tmp.pdca_mst where docdate is not null and docno=new.docno) then

				if ((select sum(coalesce(percentage,0)) from sc_tmp.pdca_dtl where docno=new.docno and status not in ('C','D'))>0::numeric) then
					update sc_tmp.pdca_mst set 
					planperiod=to_char(docdate,'yyyymm'),
					avgvalue=round(coalesce(ttlpercent,0)/coalesce(ttlplan,0),2),
					status=old.status where docno=new.docno;

					update sc_tmp.pdca_dtl set docdate=new.docdate where docno=new.docno;
				else
					update sc_tmp.pdca_mst set 
					planperiod=to_char(docdate,'yyyymm'),
					status=old.status where docno=new.docno;
					update sc_tmp.pdca_dtl set docdate=new.docdate where docno=new.docno;
				end if;
			end if;
			
		elseif (new.status='F' and old.status='I') then
			vr_nomor:='PDCA'||to_char(new.docdate,'YYYYMM');
		
			insert into sc_his.pdca_mst
			(branch,nik,docno,docdate,docref,doctype,docpage,revision,tglawal,tglakhir,global_desc,planperiod,ttlpercent,ttlplan,avgvalue,inputdate,
			inputby,updatedate,updateby,canceldate,cancelby,approvdate,approvby,realisasidate,realisasiby,status)
			(select branch,nik,vr_nomor,docdate,docref,doctype,docpage,revision,tglawal,tglakhir,global_desc,planperiod,ttlpercent,ttlplan,avgvalue,inputdate,
			inputby,updatedate,updateby,canceldate,cancelby,approvdate,approvby,realisasidate,realisasiby,'A' as status from sc_tmp.pdca_mst where docno=new.docno);

			insert into sc_his.pdca_dtl
			(nik,docno,nomor,doctype,docref,docdate,docpage,revision,planperiod,descplan,idbu,qtytime,do_c,percentage,remark,
			inputdate,inputby,updatedate,updateby,canceldate,cancelby,approvdate,approvby,realisasidate,realisasiby,status)
			(select nik,vr_nomor,nomor,doctype,docref,docdate,docpage,revision,planperiod,descplan,idbu,qtytime,do_c,percentage,remark,
			inputdate,inputby,updatedate,updateby,canceldate,cancelby,approvdate,approvby,realisasidate,realisasiby,'A' as status from sc_tmp.pdca_dtl where docno=new.docno);

			delete from sc_tmp.pdca_mst where docno=new.docno;
			delete from sc_tmp.pdca_dtl where docno=new.docno;
		elseif (new.status='F' and old.status='E') then
			vr_nomor:='PDCA'||to_char(new.docdate,'YYYYMM');

			delete from sc_his.pdca_mst where nik=new.nik and docdate=new.docdate and doctype=new.doctype;
			delete from sc_his.pdca_dtl where nik=new.nik and docdate=new.docdate and doctype=new.doctype;
		
			insert into sc_his.pdca_mst
			(branch,nik,docno,docdate,docref,doctype,docpage,revision,tglawal,tglakhir,global_desc,planperiod,ttlpercent,ttlplan,avgvalue,inputdate,
			inputby,updatedate,updateby,canceldate,cancelby,approvdate,approvby,realisasidate,realisasiby,status)
			(select branch,nik,vr_nomor,docdate,docref,doctype,docpage,revision,tglawal,tglakhir,global_desc,planperiod,ttlpercent,ttlplan,avgvalue,inputdate,
			inputby,updatedate,updateby,canceldate,cancelby,approvdate,approvby,realisasidate,realisasiby,'A' as status from sc_tmp.pdca_mst where docno=new.docno);

			insert into sc_his.pdca_dtl
			(nik,docno,nomor,doctype,docref,docdate,docpage,revision,planperiod,descplan,idbu,qtytime,do_c,percentage,remark,
			inputdate,inputby,updatedate,updateby,canceldate,cancelby,approvdate,approvby,realisasidate,realisasiby,status)
			(select nik,vr_nomor,nomor,doctype,docref,docdate,docpage,revision,planperiod,descplan,idbu,qtytime,do_c,percentage,remark,
			inputdate,inputby,updatedate,updateby,canceldate,cancelby,approvdate,approvby,realisasidate,realisasiby,'A' as status from sc_tmp.pdca_dtl where docno=new.docno);

			delete from sc_tmp.pdca_mst where docno=new.docno;
			delete from sc_tmp.pdca_dtl where docno=new.docno;
		elseif (new.status='F' and old.status='R') then
			vr_nomor:='PDCA'||to_char(new.docdate,'YYYYMM');

			delete from sc_his.pdca_mst where nik=new.nik and docdate=new.docdate and doctype=new.doctype;
			delete from sc_his.pdca_dtl where nik=new.nik and docdate=new.docdate and doctype=new.doctype;
		
			insert into sc_his.pdca_mst
			(branch,nik,docno,docdate,docref,doctype,docpage,revision,tglawal,tglakhir,global_desc,planperiod,ttlpercent,ttlplan,avgvalue,inputdate,
			inputby,updatedate,updateby,canceldate,cancelby,approvdate,approvby,realisasidate,realisasiby,status)
			(select branch,nik,vr_nomor,docdate,docref,doctype,docpage,revision,tglawal,tglakhir,global_desc,planperiod,ttlpercent,ttlplan,avgvalue,inputdate,
			inputby,updatedate,updateby,canceldate,cancelby,approvdate,approvby,realisasidate,realisasiby,'R' as status from sc_tmp.pdca_mst where docno=new.docno);

			insert into sc_his.pdca_dtl
			(nik,docno,nomor,doctype,docref,docdate,docpage,revision,planperiod,descplan,idbu,qtytime,do_c,percentage,remark,
			inputdate,inputby,updatedate,updateby,canceldate,cancelby,approvdate,approvby,realisasidate,realisasiby,status)
			(select nik,vr_nomor,nomor,doctype,docref,docdate,docpage,revision,planperiod,descplan,idbu,qtytime,do_c,percentage,remark,
			inputdate,inputby,updatedate,updateby,canceldate,cancelby,approvdate,approvby,realisasidate,realisasiby,status from sc_tmp.pdca_dtl where docno=new.docno);

			delete from sc_tmp.pdca_mst where docno=new.docno;
			delete from sc_tmp.pdca_dtl where docno=new.docno;	
		elseif (new.status='F' and old.status='O') then
			vr_nomor:='PDCA'||to_char(new.docdate,'YYYYMM');

			delete from sc_his.pdca_mst where nik=new.nik and docdate=new.docdate and doctype=new.doctype;
			delete from sc_his.pdca_dtl where nik=new.nik and docdate=new.docdate and doctype=new.doctype;
		
			insert into sc_his.pdca_mst
			(branch,nik,docno,docdate,docref,doctype,docpage,revision,tglawal,tglakhir,global_desc,planperiod,ttlpercent,ttlplan,avgvalue,inputdate,
			inputby,updatedate,updateby,canceldate,cancelby,approvdate,approvby,realisasidate,realisasiby,status)
			(select branch,nik,vr_nomor,docdate,docref,doctype,docpage,revision,tglawal,tglakhir,global_desc,planperiod,ttlpercent,ttlplan,avgvalue,inputdate,
			inputby,updatedate,updateby,canceldate,cancelby,approvdate,approvby,realisasidate,realisasiby,'P' as status from sc_tmp.pdca_mst where docno=new.docno);

			insert into sc_his.pdca_dtl
			(nik,docno,nomor,doctype,docref,docdate,docpage,revision,planperiod,descplan,idbu,qtytime,do_c,percentage,remark,
			inputdate,inputby,updatedate,updateby,canceldate,cancelby,approvdate,approvby,realisasidate,realisasiby,status)
			(select nik,vr_nomor,nomor,doctype,docref,docdate,docpage,revision,planperiod,descplan,idbu,qtytime,do_c,percentage,remark,
			inputdate,inputby,updatedate,updateby,canceldate,cancelby,approvdate,approvby,realisasidate,realisasiby,case when status='O' then 'P' else status end from sc_tmp.pdca_dtl where docno=new.docno);

			delete from sc_tmp.pdca_mst where docno=new.docno;
			delete from sc_tmp.pdca_dtl where docno=new.docno;
		end if;
	
			
	RETURN NEW;
	END IF;
    
    
    return new;
        
end;
$$;

alter function tr_pdca_mst() owner to postgres;

