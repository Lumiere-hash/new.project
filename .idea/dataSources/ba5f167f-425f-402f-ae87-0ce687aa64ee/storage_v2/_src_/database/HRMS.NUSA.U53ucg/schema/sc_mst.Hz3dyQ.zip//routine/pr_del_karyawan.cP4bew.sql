create function pr_del_karyawan() returns trigger
    language plpgsql
as
$$
DECLARE

BEGIN
	--vr_status:=trim(status) from sc_mst.karyawan where nik=new.nik for update;
	if (new.status='D') and (old.status='' or old.status is NULL) then
		insert into sc_his.karyawan_del (branch,nik,nmlengkap,callname,jk,neglahir,provlahir,kotalahir,tgllahir,kd_agama,stswn,stsfisik,ketfisik,noktp,ktp_seumurhdp,ktpdikeluarkan,
		tgldikeluarkan,status_pernikahan,gol_darah,negktp,provktp,kotaktp,kecktp,kelktp,alamatktp,negtinggal,provtinggal,kotatinggal,kectinggal,keltinggal,alamattinggal,nohp1,nohp2,
		npwp,tglnpwp,bag_dept,subbag_dept,jabatan,lvl_jabatan,grade_golongan,nik_atasan,nik_atasan2,status_ptkp,besaranptkp,tglmasukkerja,tglkeluarkerja,masakerja,statuskepegawaian,
		kdcabang,branchaktif,grouppenggajian,gajipokok,gajibpjs,namabank,namapemilikrekening,norek,tjshift,idabsen,email,bolehcuti,sisacuti,inputdate,inputby,updatedate,updateby,image,
		idmesin,cardnumber,status,tgl_ktp,costcenter,tj_tetap,gajitetap,gajinaker,tjlembur,tjborong,nokk,tgl_delete,delete_by,kdwilayahnominal,kdlvlgp,pinjaman,kdgradejabatan,deviceid)
        select branch,nik,nmlengkap,callname,jk,neglahir,provlahir,kotalahir,tgllahir,kd_agama,stswn,stsfisik,ketfisik,noktp,ktp_seumurhdp,ktpdikeluarkan,
		tgldikeluarkan,status_pernikahan,gol_darah,negktp,provktp,kotaktp,kecktp,kelktp,alamatktp,negtinggal,provtinggal,kotatinggal,kectinggal,keltinggal,alamattinggal,nohp1,nohp2,
		npwp,tglnpwp,bag_dept,subbag_dept,jabatan,lvl_jabatan,grade_golongan,nik_atasan,nik_atasan2,status_ptkp,besaranptkp,tglmasukkerja,tglkeluarkerja,masakerja,statuskepegawaian,
		kdcabang,branchaktif,grouppenggajian,gajipokok,gajibpjs,namabank,namapemilikrekening,norek,tjshift,idabsen,email,bolehcuti,sisacuti,inputdate,inputby,updatedate,updateby,image,
		idmesin,cardnumber,status,tgl_ktp,costcenter,tj_tetap,gajitetap,gajinaker,tjlembur,tjborong,nokk,to_timestamp(to_char(now(),'yyyy-mm-dd HH:MI:SS'),'yyyy-mm-dd HH:MI:SS'),updateby,kdwilayahnominal,kdlvlgp,pinjaman,kdgradejabatan,deviceid
        from sc_mst.karyawan
        where nik=new.nik;

        delete from sc_mst.karyawan where nik=new.nik;
        delete from sc_trx.riwayat_keluarga where nik=new.nik;
        delete from sc_trx.riwayat_pengalaman where nik=new.nik;
        delete from sc_trx.riwayat_pendidikan where nik=new.nik;
        delete from sc_trx.bpjs_karyawan where nik=new.nik;
        delete from sc_trx.riwayat_kesehatan where nik=new.nik;
	end if;
	RETURN new;

END;
$$;

alter function pr_del_karyawan() owner to postgres;

