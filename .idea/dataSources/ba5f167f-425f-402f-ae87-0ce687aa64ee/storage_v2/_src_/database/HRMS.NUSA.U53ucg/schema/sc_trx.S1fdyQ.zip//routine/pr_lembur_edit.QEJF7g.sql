create function pr_lembur_edit() returns trigger
    language plpgsql
as
$$
declare
 /* 
 author : gilrandy
 created:
 updated by: fiky
 case update:	ganti timestamp lembur
 
 */    
     vr_durasi integer;
     vr_jamselesai timestamp without time zone;
     vr_jammulai timestamp without time zone;
     vr_istirahat integer;
     vr_totaldurasi integer;
     
begin
		IF (new.status='U' and old.status='A') THEN
			vr_jammulai:=tgl_jam_mulai from sc_trx.lembur where nodok=new.nodok;
			vr_jamselesai:=tgl_jam_selesai from sc_trx.lembur where nodok=new.nodok;
			vr_istirahat:=durasi_istirahat from sc_trx.lembur where nodok=new.nodok;
			
			--vr_durasi:=extract(epoch from cast(to_char(cast(vr_jamselesai as time) - cast(vr_jammulai as time),'HH24:mi')as time)::interval)/60 as durasi;
			vr_durasi:=extract(epoch from cast(to_char(vr_jamselesai-vr_jammulai,'HH24:MI')as time)::interval)/60 as durasi;
			--insert into dumy(jumlah) values (vr_durasi);
			vr_totaldurasi=vr_durasi-vr_istirahat;
			update sc_trx.lembur set durasi=vr_totaldurasi,status='A' where nodok=new.nodok;
		ELSEIF (new.status='U' and old.status='P') THEN

			vr_jammulai:=tgl_jam_mulai from sc_trx.lembur where nodok=new.nodok;
			vr_jamselesai:=tgl_jam_selesai from sc_trx.lembur where nodok=new.nodok;
			vr_istirahat:=durasi_istirahat from sc_trx.lembur where nodok=new.nodok;
			
			--vr_durasi:=extract(epoch from cast(to_char(cast(vr_jamselesai as timestamp) - cast(vr_jammulai as timestamp),'HH24:mi')as time)::interval)/60 as durasi;
			vr_durasi:=extract(epoch from cast(to_char(vr_jamselesai-vr_jammulai,'HH24:MI')as time)::interval)/60 as durasi;

			--insert into dumy(jumlah) values (vr_durasi);
			vr_totaldurasi=vr_durasi-vr_istirahat;
			update sc_trx.lembur set durasi=vr_totaldurasi,status='P' where nodok=new.nodok;

		END IF;
return new;

end;
$$;

alter function pr_lembur_edit() owner to postgres;

