create function pr_penambahan_cuti12() returns SETOF void
    language plpgsql
as
$$
    --author by : Fiky Ashariza 12-01-2016
--update by : --
--idbu	    : NUSA
--update by : Unknown 12-04-2016
--prosedur kedua penambahan cuti awal tahun (2)

DECLARE vr_sisacuti integer;
DECLARE vr_nik character(12);
DECLARE vr_cek_prorate integer;
DECLARE vr_cuti_prorate integer;
DECLARE vr_dokumen character(12);

BEGIN
		update sc_trx.cuti_blc a set sisacuti=b.balance
		from (select *,sum("in_cuti"-"out_cuti") over(partition by nik order by nik,tanggal,no_dokumen,doctype) as balance
		from sc_trx.cuti_blc) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen and a.doctype=b.doctype;

		delete from sc_his.cuti_blc;
		insert into sc_his.cuti_blc (nik,tanggal,no_dokumen,in_cuti,out_cuti,sisacuti,doctype,status)
		select nik,tglmasukkerja,'PRORATE',
		case when to_char(tglmasukkerja,'dd')<='15' then  cast(to_char(tglmasukkerja,'mm') as numeric)-1
		when to_char(tglmasukkerja,'dd')>'15' then  cast(to_char(tglmasukkerja,'mm') as numeric)
		end as prorate,0,0,'PRORATE','I' 
		from sc_mst.karyawan 
		where tglmasukkerja between cast(to_char(now()-interval '2 year','yyyy')||'-01-01' as date) and cast(to_char(now()-interval '1 year','yyyy')||'-01-01' as date) and statuskepegawaian<>'KO';	

		
		
vr_dokumen:='CA'||to_char(now(),'yyyy'); 
--vr_dokumen:='CA'||'2018'; 
FOR vr_nik in select trim(coalesce(nik,'')) from sc_mst.karyawan where tglmasukkerja<=cast(to_char(now()-interval '1 year','yyyy-mm-dd')as date) and tglkeluarkerja is null
	--select trim(coalesce(nik,'')),statuskepegawaian from sc_mst.karyawan where tglmasukkerja<=cast(to_char(now()-interval '1 year','yyyy-mm-dd')as date) and tglkeluarkerja is null;

	LOOP	
	vr_cek_prorate:=count(*) from sc_mst.karyawan where 
	---tglmasukkerja between cast(to_char(now()-interval '1 year','yyyy')||'-01-01' as date) and cast(to_char(now(),'yyyy')||'-01-01' as date) and nik=vr_nik;
	tglmasukkerja between cast(to_char(now()-interval '2 year','yyyy')||'-01-01' as date) and cast(to_char(now()-interval '1 year','yyyy')||'-01-01' as date) and nik=vr_nik;
	
	vr_cuti_prorate:=coalesce(in_cuti,0) from sc_his.cuti_blc where nik=vr_nik and doctype='PRORATE' and status='F';	
		if not exists (select * from sc_trx.cuti_blc where nik=vr_nik and status=vr_dokumen and no_dokumen=vr_dokumen) then 
			IF (vr_cek_prorate>0) THEN --input cuti untuk karyawan prorate
			
				insert into sc_trx.cuti_blc (nik,tanggal,no_dokumen,in_cuti,out_cuti,sisacuti,doctype,status)
				--values (vr_nik,cast(to_char(now(),'2018-01-01 00:05:05')as timestamp),vr_dokumen,case when vr_cuti_prorate is null then 0 else vr_cuti_prorate end,0,0,'IN',vr_dokumen);
				values (vr_nik,cast(to_char(now(),to_char(now(),'yyyy')||'-01-01 00:05:05')as timestamp),vr_dokumen,12,0,0,'IN',vr_dokumen);
				/*
				insert into sc_trx.cuti_blc (nik,tanggal,no_dokumen,in_cuti,out_cuti,sisacuti,doctype,status)
				values (vr_nik,cast(to_char(now(),'2018-01-01 00:05:05')as timestamp),vr_dokumen,0,0,0,'IN',vr_dokumen);
				*/

			ELSE 
				insert into sc_trx.cuti_blc (nik,tanggal,no_dokumen,in_cuti,out_cuti,sisacuti,doctype,status)
				values (vr_nik,cast(to_char(now(),to_char(now(),'yyyy')||'-01-01 00:05:05')as timestamp),vr_dokumen,12,0,0,'IN',vr_dokumen);
			END IF;
			
		end if;	
	RETURN NEXT vr_nik;
	END LOOP;

	update sc_mst.karyawan set sisacuti=0 where sisacuti is null; --set 0 untuk karyawan yang belum pernah cuti
	update sc_mst.nomor set prefix='CT'||to_char(now(),'yy') where dokumen='CUTI-KARYAWAN';

	PERFORM sc_trx.pr_rekap_cutiblcall();
RETURN;

	
END;
$$;

alter function pr_penambahan_cuti12() owner to postgres;

