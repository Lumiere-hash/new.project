create function pr_ambil_jp_kar(id character, nomor integer, userid character) returns numeric
    language plpgsql
as
$$
DECLARE 
vr_duit numeric(18,2):=0;
vr_perusahaan numeric(18,2):=0;
vr_karyawan numeric(18,2):=0;
vr_potong numeric(18,2):=0;
vr_tgl char(6);
vr_idbpjs char(20);
BEGIN		
	select besaranperusahaan,besarankaryawan into vr_perusahaan,vr_karyawan from sc_mst.komponen_bpjs where kode_bpjs='BPJSTK' and kodekomponen='JP';
	select coalesce(sum(gajinaker),0) into vr_duit from sc_mst.karyawan where nik=id;
	select to_char(periode_akhir,'YYYYMM') into vr_tgl from sc_tmp.payroll_rekap where nodok=userid;
	select id_bpjs into vr_idbpjs from sc_trx.bpjs_karyawan
	where nik=id and to_char(tgl_berlaku,'YYYYMM')<=vr_tgl and kode_bpjs='BPJSTK';	

	if (vr_idbpjs is not null) then
	vr_potong=(vr_karyawan/100.00) * vr_duit;
	else vr_potong=0;
	end if;
	delete from sc_tmp.payroll_detail where nodok=userid and nik=id and no_urut=nomor;

	insert into sc_tmp.payroll_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
	select userid as nodok,id as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_potong as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by from sc_mst.detail_formula
	where no_urut=nomor and kdrumus='PR';
	
	RETURN vr_potong;	
END;
$$;

alter function pr_ambil_jp_kar(char, integer, char) owner to postgres;

