create function jadwalkerja_after() returns trigger
    language plpgsql
as
$$
begin


if (new.status='F') then


	INSERT INTO sc_trx.jadwalkerja(kdregu,kodejamkerja,inputdate,inputby,id,tgl) 
	select kdregu,kodejamkerja,inputdate,inputby,id,tgl  from sc_im.jadwalkerja where status='F';

	delete from sc_im.jadwalkerja;
	
end if;
return new;

end;
$$;

alter function jadwalkerja_after() owner to postgres;

