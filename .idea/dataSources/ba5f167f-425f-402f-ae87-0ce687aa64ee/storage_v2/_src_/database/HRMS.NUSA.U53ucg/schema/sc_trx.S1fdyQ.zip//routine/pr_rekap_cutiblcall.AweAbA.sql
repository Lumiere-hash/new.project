create function pr_rekap_cutiblcall() returns void
    language plpgsql
as
$$
--author by : Fiky Ashariza 11-04-2016
--update by : - -
BEGIN	


	update sc_trx.cuti_blc a set sisacuti=b.balance
		from (select *,sum("in_cuti"-"out_cuti") over(partition by nik order by nik,tanggal,no_dokumen,doctype) as balance
		from sc_trx.cuti_blc) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen and a.doctype=b.doctype;

	update sc_mst.karyawan x set sisacuti=coalesce(a.sisacuti,0) from sc_trx.cuti_blc a,
		(select a.nik,a.tanggal,a.no_dokumen,max(a.doctype) as doctype from sc_trx.cuti_blc a,
		(select a.nik,a.tanggal,max(a.no_dokumen) as no_dokumen from sc_trx.cuti_blc a,
		(select nik,max(tanggal) as tanggal from sc_trx.cuti_blc  
		group by nik
		) as b
		where a.nik=b.nik and a.tanggal=b.tanggal
		group by a.nik,a.tanggal) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen
		group by a.nik,a.tanggal,a.no_dokumen ) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen and a.doctype=b.doctype and a.nik=x.nik;

	RETURN;	
END;
$$;

alter function pr_rekap_cutiblcall() owner to postgres;

