create function tr_regu_opr() returns trigger
    language plpgsql
as
$$
declare
     /*
	author 	: Fiky Ashariza
	update 	: Fiky Ashariza
	link	: triger master karyawan
	case	: Penambahan trigger regu operator dan bloking
     */
begin
	IF TG_OP ='INSERT' THEN
		delete from sc_trx.dtljadwalkerja
		where nik=new.nik and to_char(tgl,'YYYY-mm-dd')::date>=new.tglefektif and updatedate is null;
		
		insert into sc_trx.dtljadwalkerja (nik,tgl,kdjamkerja,kdregu,inputdate,inputby)
		(select new.nik as nik,tgl,kodejamkerja,kdregu,new.input_date as input_date,new.input_by as inputby from sc_trx.jadwalkerja 
		where kdregu=new.kdregu
		and to_char(tgl,'YYYY-mm-dd')::date>=new.tglefektif
		order by tgl);

	RETURN NEW;
	ELSEIF	TG_OP ='UPDATE' THEN
		delete from sc_trx.dtljadwalkerja
		where nik=new.nik and to_char(tgl,'YYYY-mm-dd')::date>=new.tglefektif and updatedate is null;
		
		insert into sc_trx.dtljadwalkerja (nik,tgl,kdjamkerja,kdregu,inputdate,inputby)
		(select new.nik as nik,tgl,kodejamkerja,kdregu,new.update_date as inputdate,new.update_by as inputby from sc_trx.jadwalkerja 
		where kdregu=new.kdregu
		and to_char(tgl,'YYYY-mm-dd')::date>=new.tglefektif and to_char(tgl,'YYYY-mm-dd')::date not in (select tgl from sc_trx.dtljadwalkerja where 
		 to_char(tgl,'YYYY-mm-dd')::date>=new.tglefektif and updatedate is not null and nik=new.nik)
		order by tgl);
	RETURN NEW;
	ELSEIF TG_OP ='DELETE' THEN
		delete from sc_trx.dtljadwalkerja
		where nik=old.nik and to_char(tgl,'YYYY-mm-dd')::date>=old.tglefektif;

	RETURN OLD;
	END IF;


return new;

end;
$$;

alter function tr_regu_opr() owner to postgres;

