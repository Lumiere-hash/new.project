create function tr_asnkendaraan_mst() returns trigger
    language plpgsql
as
$$
declare
--created by Fiky ::18/05/2018
     vr_nomor char(12); 
     vr_lastdoc numeric; 
     vr_cekprefix char(4);
     vr_nowprefix char(4);
begin    

	IF TG_OP ='INSERT' THEN 

	RETURN NEW;
	ELSEIF TG_OP ='UPDATE' THEN
			
			/* NO RESOURCE UPDATE 
			select * from sc_mst.nomor	
			select * from sc_his.asnkendaraan_mst
			*/
		if (new.status='E' and old.status='A') then

			insert into sc_tmp.asnkendaraan_mst
			(docno,docdate,docref,kdgroup,kdsubgroup,stockcode,kdsubasuransi,old_kdsubasuransi,expasuransi,old_expasuransi,
			ttlvalue,description,status,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,docnotmp)
			(select NEW.UPDATEBY,docdate,docref,kdgroup,kdsubgroup,stockcode,kdsubasuransi,old_kdsubasuransi,expasuransi,old_expasuransi,
			ttlvalue,description,'E' as status,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,NEW.DOCNO AS docnotmp from sc_his.asnkendaraan_mst where docno=new.docno);

		elseif (new.status='A1' and old.status='A') then
		
			insert into sc_tmp.asnkendaraan_mst
			(docno,docdate,docref,kdgroup,kdsubgroup,stockcode,kdsubasuransi,old_kdsubasuransi,expasuransi,old_expasuransi,
			ttlvalue,description,status,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,docnotmp)
			(select NEW.APPROVALBY,docdate,docref,kdgroup,kdsubgroup,stockcode,kdsubasuransi,old_kdsubasuransi,expasuransi,old_expasuransi,
			ttlvalue,description,'A' as status,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,NEW.DOCNO AS docnotmp from sc_his.asnkendaraan_mst where docno=new.docno);
			
		elseif (new.status='C' and old.status='A') then
			insert into sc_tmp.asnkendaraan_mst
			(docno,docdate,docref,kdgroup,kdsubgroup,stockcode,kdsubasuransi,old_kdsubasuransi,expasuransi,old_expasuransi,
			ttlvalue,description,status,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,docnotmp)
			(select NEW.UPDATEBY,docdate,docref,kdgroup,kdsubgroup,stockcode,kdsubasuransi,old_kdsubasuransi,expasuransi,old_expasuransi,
			ttlvalue,description,'C' as status,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,NEW.DOCNO AS docnotmp from sc_his.asnkendaraan_mst where docno=new.docno);
		end if;
	
			
	RETURN NEW;
	END IF;
    
    
    return new;
        
end;
$$;

alter function tr_asnkendaraan_mst() owner to postgres;

