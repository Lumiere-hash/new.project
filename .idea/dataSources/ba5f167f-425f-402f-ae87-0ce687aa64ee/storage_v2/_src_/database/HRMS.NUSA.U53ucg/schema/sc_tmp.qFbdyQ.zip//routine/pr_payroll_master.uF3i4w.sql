create function pr_payroll_master() returns trigger
    language plpgsql
as
$$
BEGIN
		
	IF (tg_op = 'UPDATE') THEN	---(tg_op = 'INSERT') or triger ubah update
		if (new.status='H' and old.status='I') then --H untuk hitung ulang
			update sc_tmp.payroll_master set 
			total_pendapatan=(select sum(nominal) from sc_tmp.payroll_detail where nodok=new.nodok and nik=new.nik and aksi='A'),
			total_potongan=(select sum(nominal) from sc_tmp.payroll_detail where nodok=new.nodok and nik=new.nik and aksi='B'),
			total_deposit=(select sum(nominal) from sc_tmp.payroll_detail where nodok=new.nodok and nik=new.nik and aksi='C'),
			total_upah=(select sum(nominal) from sc_tmp.payroll_detail where nodok=new.nodok and nik=new.nik and aksi='A')
				   -(select sum(nominal) from sc_tmp.payroll_detail where nodok=new.nodok and nik=new.nik and aksi='B')
				   +(select sum(nominal) from sc_tmp.payroll_detail where nodok=new.nodok and nik=new.nik and aksi='C')
			where nodok=new.nodok and nik=new.nik;	
			
			update sc_tmp.payroll_rekap set 
			total_pendapatan=(select sum(total_pendapatan) from sc_tmp.payroll_master where nodok=new.nodok and kddept=new.kddept),
			total_potongan=(select sum(total_potongan) from sc_tmp.payroll_master where nodok=new.nodok and kddept=new.kddept),
			total_deposit=(select sum(total_deposit) from sc_tmp.payroll_master where nodok=new.nodok and kddept=new.kddept),
			total_upah=(select sum(total_pendapatan) from sc_tmp.payroll_master where  nodok=new.nodok and kddept=new.kddept)
				   -(select sum(total_potongan) from sc_tmp.payroll_master where  nodok=new.nodok and kddept=new.kddept)
				   +(select sum(total_deposit) from sc_tmp.payroll_master where  nodok=new.nodok and kddept=new.kddept)
			where nodok=new.nodok and kddept=new.kddept;
			update sc_tmp.payroll_master set status='I' where nodok=new.nodok and nik=new.nik;	
			
		elseif (new.status='D' and old.status='I') then
			update sc_tmp.payroll_rekap set 
			total_pendapatan=(select sum(total_pendapatan) from sc_tmp.payroll_master where nodok=old.nodok and kddept=old.kddept),
			total_potongan=(select sum(total_potongan) from sc_tmp.payroll_master where nodok=old.nodok and kddept=old.kddept),
			total_deposit=(select sum(total_deposit) from sc_tmp.payroll_master where nodok=old.nodok and kddept=old.kddept),
			total_upah=(select sum(total_pendapatan) from sc_tmp.payroll_master where  nodok=old.nodok and kddept=old.kddept)
				   -(select sum(total_potongan) from sc_tmp.payroll_master where  nodok=old.nodok and kddept=old.kddept)
				   +(select sum(total_deposit) from sc_tmp.payroll_master where  nodok=old.nodok and kddept=old.kddept)
			where nodok=old.nodok and kddept=old.kddept;	
		end if;
		RETURN new;	
		
		
	ELSEIF tg_op = 'DELETE' THEN
		update sc_tmp.payroll_rekap set 
		total_pendapatan=(select sum(total_pendapatan) from sc_tmp.payroll_master where nodok=old.nodok and kddept=old.kddept),
		total_potongan=(select sum(total_potongan) from sc_tmp.payroll_master where nodok=old.nodok and kddept=old.kddept),
		total_deposit=(select sum(total_deposit) from sc_tmp.payroll_master where nodok=old.nodok and kddept=old.kddept),
		total_upah=(select sum(total_pendapatan) from sc_tmp.payroll_master where  nodok=old.nodok and kddept=old.kddept)
			   -(select sum(total_potongan) from sc_tmp.payroll_master where  nodok=old.nodok and kddept=old.kddept)
			   +(select sum(total_deposit) from sc_tmp.payroll_master where  nodok=old.nodok and kddept=old.kddept)
		where nodok=old.nodok and kddept=old.kddept;	
		RETURN new;	
	END IF;
	RETURN NEW;
END;

$$;

alter function pr_payroll_master() owner to postgres;

