create view stbbm_mst_view
            (branch, nodok, nodokref, loccode, nodokopr, nodokdate, nodoktype, disc1, disc2, disc3, disc4, exppn,
             ttlbrutto, ttldiskon, ttldpp, ttlppn, ttlnetto, pkp, keterangan, inputdate, inputby, updatedate, updateby,
             approvaldate, approvalby, nodoktmp, status, nmstatus)
as
SELECT a.branch,
       a.nodok,
       a.nodokref,
       a.loccode,
       a.nodokopr,
       a.nodokdate,
       a.nodoktype,
       a.disc1,
       a.disc2,
       a.disc3,
       a.disc4,
       a.exppn,
       a.ttlbrutto,
       a.ttldiskon,
       a.ttldpp,
       a.ttlppn,
       a.ttlnetto,
       a.pkp,
       a.keterangan,
       a.inputdate,
       a.inputby,
       a.updatedate,
       a.updateby,
       a.approvaldate,
       a.approvalby,
       a.nodoktmp,
       a.status,
       b.uraian AS nmstatus
FROM sc_trx.stbbm_mst a
         LEFT JOIN sc_mst.trxtype b ON a.status = b.kdtrx AND b.jenistrx::text = 'STBBM'::text
ORDER BY a.nodok DESC;

alter table stbbm_mst_view
    owner to postgres;

