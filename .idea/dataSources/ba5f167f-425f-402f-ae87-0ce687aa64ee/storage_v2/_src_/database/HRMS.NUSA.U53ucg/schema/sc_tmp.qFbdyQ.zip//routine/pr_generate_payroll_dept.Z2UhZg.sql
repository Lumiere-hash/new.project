create function pr_generate_payroll_dept(vr_nodok character, vr_pkeluar character, vr_tglawalfix date, vr_tglakhirfix date, vr_gp character, vr_kddept character) returns timestamp without time zone
    language plpgsql
as
$$
DECLARE
    vr_nik char(12);
    vr_tglkeluarkerja date;
    vr_urut integer;
    vr_keluarkerja char(12);
    
    
    
BEGIN
	vr_keluarkerja:=to_char(vr_tglakhirfix,'YYYYMM');
 /* 
    FOR vr_nik IN select a.nik,a.tglkeluarkerja from sc_mst.karyawan a
		left outer join sc_mst.departmen b on a.bag_dept=b.kddept
		where a.grouppenggajian=vr_gp and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO'
		
    LOOP
	    select tglkeluarkerja into vr_tglkeluarkerja from sc_mst.karyawan where nik=vr_nik;
	    insert into sc_tmp.payroll_master(nodok,nik,periode_mulai,periode_akhir,tglkeluarkerja,kddept) values (vr_nodok,vr_nik,tglawalfix,tglakhirfix,vr_tglkeluarkerja,vr_kddept);
*/
		delete from sc_tmp.payroll_rekap where nodok=vr_nodok and kddept=vr_kddept;
		delete from sc_tmp.payroll_master where nodok=vr_nodok and kddept=vr_kddept;
		delete from sc_tmp.payroll_detail where (no_urut in (1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30)) 
		and nodok=vr_nodok and nik in
		(select trim(nik) from sc_mst.karyawan where bag_dept=vr_kddept and statuskepegawaian<>'KO');

		/* INIT TO PAYROLL REKAP */
		INSERT INTO sc_tmp.payroll_rekap (nodok,input_by,input_date,status,periode_mulai,periode_akhir, kddept)
		 VALUES 
		(vr_nodok, vr_nodok, to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp, 'I', vr_tglawalfix, vr_tglakhirfix, vr_kddept);
		/* INIT TO PAYROLL MASTER */
		insert into sc_tmp.payroll_master(nodok,nik,periode_mulai,periode_akhir,tglkeluarkerja,kddept,status)
			select vr_nodok as nodok,a.nik,vr_tglawalfix as periode_mulai,vr_tglakhirfix as periode_akhir,a.tglkeluarkerja,a.bag_dept as kddept,'I' as status from 
			(select a.*,b.* from sc_mst.karyawan a
						left outer join sc_mst.departmen b on a.bag_dept=b.kddept
						where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end)  and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO') a 
			order by a.nik;
		
		   --  perform sc_trx.pr_ambil_gp(vr_nik,1,nodok,vr_kddept);
		insert into sc_tmp.payroll_detail(
			nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
			approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
		select vr_nodok as nodok,a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,
				case 
				when count(d.*)>=25  then e.gajipokok::numeric(18,2) 
				when count(d.*)<25 and to_char(a.tglmasukkerja,'yyyymm')=to_char(c.periode_akhir,'YYYYMM') then ((e.gajipokok::numeric(18,2)/25)*count(d.*))::numeric(18,2) 
				when count(d.*)<25 and to_char(a.tglmasukkerja,'yyyymm')<to_char(c.periode_akhir,'YYYYMM') then e.gajipokok::numeric(18,2) 
				else ((e.gajipokok::numeric(18,2)/25)*count(d.*))::numeric(18,2) end as nominal ,to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as input_date,null as approval_date,vr_nodok as input_by,
			null as approval_by,null as delete_by,null as cancel_by,b.update_date,null as delete_date,null as cancel_date,b.update_by from 
			(select a.nik,a.tglkeluarkerja,a.tglmasukkerja,b.* from sc_mst.karyawan a
					left outer join sc_mst.departmen b on a.bag_dept=b.kddept
					where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end)  and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO') a 
			left outer join sc_mst.detail_formula b on no_urut=1 and kdrumus='PR'
			left outer join sc_tmp.payroll_rekap c on c.nodok=vr_nodok and c.kddept=vr_kddept
			left outer join sc_trx.dtljadwalkerja d on d.nik=a.nik and to_char(c.periode_akhir,'YYYYMM')=to_char(d.tgl,'YYYYMM')
			left outer join sc_mst.karyawan e on e.nik=a.nik 
			group by a.nik,a.tglmasukkerja,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,keterangan,e.gajipokok,b.update_date,b.update_by,c.periode_akhir
			order by a.tglmasukkerja;

		     --perform sc_trx.pr_ambil_gajibpjs(vr_nik,2,nodok);
		insert into sc_tmp.payroll_detail(
			nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
			approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
		select vr_nodok as nodok,a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,coalesce(gajibpjs,0) as nominal,to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as input_date,null as approval_date,vr_nodok as input_by,
			null as approval_by,null as delete_by,null as cancel_by,null as update_date,null as delete_date,null as cancel_date,'' as update_by from
			(select a.*,b.* from sc_mst.karyawan a
					left outer join sc_mst.departmen b on a.bag_dept=b.kddept
					where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end)  and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO') a 
			left outer join sc_mst.detail_formula b on b.no_urut=2 and b.kdrumus='PR';
			 
		     --perform sc_trx.pr_ambil_gajinaker(vr_nik,3,nodok);
		insert into sc_tmp.payroll_detail(
			nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
			approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
		select vr_nodok as nodok,a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,coalesce(gajinaker,0) as nominal,
			to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as input_date,null as approval_date,vr_nodok as input_by,null as approval_by,null as delete_by,null as cancel_by,null as update_date,null as delete_date,null as cancel_date,'' as update_by from 
			(select a.*,b.* from sc_mst.karyawan a
					left outer join sc_mst.departmen b on a.bag_dept=b.kddept
					where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end)  and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO') a 
			left outer join sc_mst.detail_formula b on b.no_urut=3 and b.kdrumus='PR';
			
		     --perform sc_trx.pr_potongan_absen(vr_nik,4,nodok);
		insert into sc_tmp.payroll_detail(
			nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
			approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
		select vr_nodok as nodok,a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,b.keterangan,sum(coalesce(cuti_nominal,0))as nominal,
			to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as input_date,null as approval_date,vr_nodok as input_by,null as approval_by,null as delete_by,null as cancel_by,null as update_date,null as delete_date,null as cancel_date,'' as update_by from 
			(select a.*,b.* from sc_mst.karyawan a
					left outer join sc_mst.departmen b on a.bag_dept=b.kddept
					where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end)  and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO') a 
			left outer join sc_mst.detail_formula b on b.no_urut=4 and b.kdrumus='PR'
			left outer join sc_tmp.payroll_rekap c on c.nodok=vr_nodok and c.kddept=vr_kddept
			left outer join sc_tmp.cek_absen d on a.nik=d.nik and d.tgl_kerja between c.periode_mulai and c.periode_akhir
			group by a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,b.keterangan,b.update_date,b.update_by,c.periode_akhir;
	
		     --perform sc_trx.pr_input_global(vr_nik,5,nodok);
		insert into sc_tmp.payroll_detail(
			nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
			approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
		select vr_nodok as nodok,a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,coalesce(0,0)as nominal,
			to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as input_date,null as approval_date,vr_nodok as input_by,null as approval_by,null as delete_by,null as cancel_by,null as update_date,null as delete_date,null as cancel_date,'' as update_by from 
			(select a.*,b.* from sc_mst.karyawan a
					left outer join sc_mst.departmen b on a.bag_dept=b.kddept
					where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end)  and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO') a 
			left outer join sc_mst.detail_formula b on no_urut=5 and kdrumus='PR';
			
		     --perform sc_trx.pr_upah_borong(vr_nik,6,nodok);
		insert into sc_tmp.payroll_detail(
			nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
			approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
		select vr_nodok as nodok,a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,b.keterangan,coalesce(sum(c.total_upah),0)as nominal,
			to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as input_date,null as approval_date,vr_nodok as input_by,null as approval_by,null as delete_by,null as cancel_by,null as update_date,null as delete_date,null as cancel_date,'' as update_by from 
		(select a.*,b.* from sc_mst.karyawan a
					left outer join sc_mst.departmen b on a.bag_dept=b.kddept
					where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end)  and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO') a
			left outer join sc_mst.detail_formula b on no_urut=6 and kdrumus='PR'
			left outer join sc_tmp.cek_borong c on a.nik=c.nik
			group by a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,b.keterangan,b.update_date,b.update_by;
			
		     --perform sc_trx.pr_ambil_tj(vr_nik,7,nodok);
		insert into sc_tmp.payroll_detail(
			nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
			approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
		select vr_nodok as nodok,a.nik,b.no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,b.keterangan,coalesce(sum(c.nominal),0)as nominal,
			to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as input_date,null as approval_date,vr_nodok as input_by,null as approval_by,null as delete_by,null as cancel_by,null as update_date,null as delete_date,null as cancel_date,'' as update_by from 
		(select a.*,b.* from sc_mst.karyawan a
					left outer join sc_mst.departmen b on a.bag_dept=b.kddept
					where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end)  and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO') a
			left outer join sc_mst.detail_formula b on b.no_urut=7 and b.kdrumus='PR'
			left outer join sc_mst.dtlgaji_karyawan c on a.nik=c.nik and c.no_urut=7 and c.keterangan='TUNJANGAN JABATAN'
			group by a.nik,b.no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,b.keterangan,b.update_date,b.update_by;
			
		     --perform sc_trx.pr_ambil_tm(vr_nik,8,nodok);
		insert into sc_tmp.payroll_detail(
			nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
			approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
		select vr_nodok as nodok,a.nik,b.no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,b.keterangan,coalesce(sum(c.nominal),0)as nominal,
			to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as input_date,null as approval_date,vr_nodok as input_by,null as approval_by,null as delete_by,null as cancel_by,null as update_date,null as delete_date,null as cancel_date,'' as update_by from 
		(select a.*,b.* from sc_mst.karyawan a
					left outer join sc_mst.departmen b on a.bag_dept=b.kddept
					where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end)  and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO') a
			left outer join sc_mst.detail_formula b on b.no_urut=8 and b.kdrumus='PR'
			left outer join sc_mst.dtlgaji_karyawan c on a.nik=c.nik and c.no_urut=8 and c.keterangan='TUNJANGAN MASA KERJA'
			group by a.nik,b.no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,b.keterangan,b.update_date,b.update_by;
			
		     --perform sc_trx.pr_ambil_tp(vr_nik,9,nodok);
		insert into sc_tmp.payroll_detail(
			nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
			approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
		select vr_nodok as nodok,a.nik,b.no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,b.keterangan,coalesce(sum(c.nominal),0)as nominal,
			to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as input_date,null as approval_date,vr_nodok as input_by,null as approval_by,null as delete_by,null as cancel_by,null as update_date,null as delete_date,null as cancel_date,'' as update_by from 
		(select a.*,b.* from sc_mst.karyawan a
					left outer join sc_mst.departmen b on a.bag_dept=b.kddept
					where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end)  and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO') a
			left outer join sc_mst.detail_formula b on b.no_urut=9 and b.kdrumus='PR'
			left outer join sc_mst.dtlgaji_karyawan c on a.nik=c.nik and c.no_urut=9 and c.keterangan='TUNJANGAN PRESTASI'
			group by a.nik,b.no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,b.keterangan,b.update_date,b.update_by;
			
		     --perform sc_trx.pr_tunjangan_shift(vr_nik,10,nodok);
		insert into sc_tmp.payroll_detail(
			nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
			approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
		select vr_nodok as nodok,a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,b.keterangan,sum(coalesce(d.nominal,0))as nominal,
			to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as input_date,null as approval_date,vr_nodok as input_by,null as approval_by,null as delete_by,null as cancel_by,null as update_date,null as delete_date,null as cancel_date,'' as update_by from 
			(select a.*,b.* from sc_mst.karyawan a
					left outer join sc_mst.departmen b on a.bag_dept=b.kddept
					where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end)  and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO') a 
			left outer join sc_mst.detail_formula b on b.no_urut=10 and b.kdrumus='PR'
			left outer join sc_tmp.payroll_rekap c on c.nodok=vr_nodok and c.kddept=vr_kddept
			left outer join sc_tmp.cek_shift d on a.nik=d.nik and d.tgl_kerja between c.periode_mulai and c.periode_akhir
			group by a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,b.keterangan,b.update_date,b.update_by;
			
		     --perform sc_trx.pr_tunjangan_lembur(vr_nik,11,nodok);
		insert into sc_tmp.payroll_detail(
			nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
			approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
		select vr_nodok as nodok,a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,b.keterangan,sum(coalesce(d.nominal,0))as nominal,
			to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as input_date,null as approval_date,vr_nodok as input_by,null as approval_by,null as delete_by,null as cancel_by,null as update_date,null as delete_date,null as cancel_date,'' as update_by from 
			(select a.*,b.* from sc_mst.karyawan a
					left outer join sc_mst.departmen b on a.bag_dept=b.kddept
					where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end)  and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO') a 
			left outer join sc_mst.detail_formula b on b.no_urut=11 and b.kdrumus='PR'
			left outer join sc_tmp.payroll_rekap c on c.nodok=vr_nodok and c.kddept=vr_kddept
			left outer join sc_tmp.cek_lembur d on a.nik=d.nik and d.tgl_kerja between c.periode_mulai and c.periode_akhir
			group by a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,b.keterangan,b.update_date,b.update_by;
			
		     --perform sc_trx.pr_input_global(vr_nik,12,nodok);
		insert into sc_tmp.payroll_detail(
			nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
			approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
		select vr_nodok as nodok,a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,coalesce(0,0)as nominal,
			to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as input_date,null as approval_date,vr_nodok as input_by,null as approval_by,null as delete_by,null as cancel_by,null as update_date,null as delete_date,null as cancel_date,'' as update_by from 
			(select a.*,b.* from sc_mst.karyawan a
					left outer join sc_mst.departmen b on a.bag_dept=b.kddept
					where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end)  and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO') a 
			left outer join sc_mst.detail_formula b on no_urut=12 and kdrumus='PR';
			
		     --perform sc_trx.pr_input_global(vr_nik,13,nodok);
		insert into sc_tmp.payroll_detail(
			nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
			approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
		select vr_nodok as nodok,a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,coalesce(0,0)as nominal,
			to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as input_date,null as approval_date,vr_nodok as input_by,null as approval_by,null as delete_by,null as cancel_by,null as update_date,null as delete_date,null as cancel_date,'' as update_by from 
			(select a.*,b.* from sc_mst.karyawan a
					left outer join sc_mst.departmen b on a.bag_dept=b.kddept
					where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end)  and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO') a 
			left outer join sc_mst.detail_formula b on no_urut=13 and kdrumus='PR';
			
		     --perform sc_trx.pr_input_global(vr_nik,14,nodok);
		insert into sc_tmp.payroll_detail(
			nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
			approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
		select vr_nodok as nodok,a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,coalesce(0,0)as nominal,
			to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as input_date,null as approval_date,vr_nodok as input_by,null as approval_by,null as delete_by,null as cancel_by,null as update_date,null as delete_date,null as cancel_date,'' as update_by from 
			(select a.*,b.* from sc_mst.karyawan a
					left outer join sc_mst.departmen b on a.bag_dept=b.kddept
					where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end)  and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO') a 
			left outer join sc_mst.detail_formula b on no_urut=14 and kdrumus='PR';
			
		     --perform sc_trx.pr_input_global(vr_nik,15,nodok);
		insert into sc_tmp.payroll_detail(
			nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
			approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
		select vr_nodok as nodok,a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,coalesce(0,0)as nominal,
			to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as input_date,null as approval_date,vr_nodok as input_by,null as approval_by,null as delete_by,null as cancel_by,null as update_date,null as delete_date,null as cancel_date,'' as update_by from 
			(select a.*,b.* from sc_mst.karyawan a
					left outer join sc_mst.departmen b on a.bag_dept=b.kddept
					where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end)  and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO') a 
			left outer join sc_mst.detail_formula b on no_urut=15 and kdrumus='PR';
			
		     --perform sc_trx.pr_ambil_jkk_per(vr_nik,16,nodok);
		insert into sc_tmp.payroll_detail(
			nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
			approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
		select vr_nodok as nodok,a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,b.keterangan,case 
				when max(e.id_bpjs) is not null  then ((d.besaranperusahaan/100)*(coalesce(a.gajinaker,0))::numeric(18,2))::numeric(18,2)
				else 0::numeric(18,2) end as nominal ,
			to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as input_date,null as approval_date,vr_nodok as input_by,null as approval_by,null as delete_by,null as cancel_by,null as update_date,null as delete_date,null as cancel_date,'' as update_by from 
			(select a.*,b.* from sc_mst.karyawan a
					left outer join sc_mst.departmen b on a.bag_dept=b.kddept
					where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end)  and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO') a 
			left outer join sc_mst.detail_formula b on no_urut=16 and kdrumus='PR'
			left outer join sc_tmp.payroll_rekap c on c.nodok=vr_nodok and c.kddept=vr_kddept
			left outer join sc_mst.komponen_bpjs d on d.kode_bpjs='BPJSTK' and d.kodekomponen='JKK'	
			left outer join (select * from sc_trx.bpjs_karyawan) e on a.nik=e.nik and e.kode_bpjs='BPJSTK' and to_char(e.tgl_berlaku,'YYYYMM')<=to_char(c.periode_akhir,'YYYYMM')
		group by a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,b.keterangan,b.update_date,b.update_by,d.besaranperusahaan,a.gajinaker ;     

		     --perform sc_trx.pr_ambil_jkm_per(vr_nik,17,nodok);
		insert into sc_tmp.payroll_detail(
			nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
			approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
		select vr_nodok as nodok,a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,b.keterangan,case 
				when max(e.id_bpjs) is not null  then ((d.besaranperusahaan/100)*(coalesce(a.gajinaker,0))::numeric(18,2))::numeric(18,2)
				else 0::numeric(18,2) end as nominal ,
			to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as input_date,null as approval_date,vr_nodok as input_by,null as approval_by,null as delete_by,null as cancel_by,null as update_date,null as delete_date,null as cancel_date,'' as update_by from 
			(select a.*,b.* from sc_mst.karyawan a
					left outer join sc_mst.departmen b on a.bag_dept=b.kddept
					where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end)  and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO') a 
			left outer join sc_mst.detail_formula b on no_urut=17 and kdrumus='PR'
			left outer join sc_tmp.payroll_rekap c on c.nodok=vr_nodok and c.kddept=vr_kddept
			left outer join sc_mst.komponen_bpjs d on d.kode_bpjs='BPJSTK' and d.kodekomponen='JKM'	
			left outer join (select * from sc_trx.bpjs_karyawan) e on a.nik=e.nik and e.kode_bpjs='BPJSTK' and to_char(e.tgl_berlaku,'YYYYMM')<=to_char(c.periode_akhir,'YYYYMM')
		group by a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,b.keterangan,b.update_date,b.update_by,d.besaranperusahaan,a.gajinaker ;     

		     --perform sc_trx.pr_ambil_jht_per(vr_nik,18,nodok);
		insert into sc_tmp.payroll_detail(
			nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
			approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
		select vr_nodok as nodok,a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,b.keterangan,case 
				when max(e.id_bpjs) is not null  then ((d.besaranperusahaan/100)*(coalesce(a.gajinaker,0))::numeric(18,2))::numeric(18,2)
				else 0::numeric(18,2) end as nominal ,
			to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as input_date,null as approval_date,vr_nodok as input_by,null as approval_by,null as delete_by,null as cancel_by,null as update_date,null as delete_date,null as cancel_date,'' as update_by from 
			(select a.*,b.* from sc_mst.karyawan a
					left outer join sc_mst.departmen b on a.bag_dept=b.kddept
					where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end)  and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO') a 
			left outer join sc_mst.detail_formula b on no_urut=18 and kdrumus='PR'
			left outer join sc_tmp.payroll_rekap c on c.nodok=vr_nodok and c.kddept=vr_kddept
			left outer join sc_mst.komponen_bpjs d on d.kode_bpjs='BPJSTK' and d.kodekomponen='JHT'	
			left outer join (select * from sc_trx.bpjs_karyawan) e on a.nik=e.nik and e.kode_bpjs='BPJSTK' and to_char(e.tgl_berlaku,'YYYYMM')<=to_char(c.periode_akhir,'YYYYMM')
		group by a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,b.keterangan,b.update_date,b.update_by,d.besaranperusahaan,a.gajinaker ;          
		     
		     --perform sc_trx.pr_ambil_bpjs_per(vr_nik,19,nodok);
		insert into sc_tmp.payroll_detail(
			nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
			approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
		select vr_nodok as nodok,a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,b.keterangan,case 
				when max(e.id_bpjs) is not null  then ((d.besaranperusahaan/100)*(coalesce(a.gajibpjs,0))::numeric(18,2))::numeric(18,2)
				else 0::numeric(18,2) end as nominal ,
			to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as input_date,null as approval_date,vr_nodok as input_by,null as approval_by,null as delete_by,null as cancel_by,null as update_date,null as delete_date,null as cancel_date,'' as update_by from 
			(select a.*,b.* from sc_mst.karyawan a
					left outer join sc_mst.departmen b on a.bag_dept=b.kddept
					where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end)  and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO') a 
			left outer join sc_mst.detail_formula b on no_urut=19 and kdrumus='PR'
			left outer join sc_tmp.payroll_rekap c on c.nodok=vr_nodok and c.kddept=vr_kddept
			left outer join sc_mst.komponen_bpjs d on d.kode_bpjs='BPJSKES' and d.kodekomponen='BPJSKES'	
			left outer join (select * from sc_trx.bpjs_karyawan) e on a.nik=e.nik and e.kode_bpjs='BPJSKES' and to_char(e.tgl_berlaku,'YYYYMM')<=to_char(c.periode_akhir,'YYYYMM')
		group by a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,b.keterangan,b.update_date,b.update_by,d.besaranperusahaan,a.gajibpjs ;               

		     --perform sc_trx.pr_ambil_jp_per(vr_nik,20,nodok);
		insert into sc_tmp.payroll_detail(
			nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
			approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
		select vr_nodok as nodok,a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,b.keterangan,case 
				when max(e.id_bpjs) is not null  then ((d.besaranperusahaan/100)*(coalesce(a.gajinaker,0))::numeric(18,2))::numeric(18,2)
				else 0::numeric(18,2) end as nominal ,
			to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as input_date,null as approval_date,vr_nodok as input_by,null as approval_by,null as delete_by,null as cancel_by,null as update_date,null as delete_date,null as cancel_date,'' as update_by from 
			(select a.*,b.* from sc_mst.karyawan a
					left outer join sc_mst.departmen b on a.bag_dept=b.kddept
					where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end)  and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO') a 
			left outer join sc_mst.detail_formula b on no_urut=20 and kdrumus='PR'
			left outer join sc_tmp.payroll_rekap c on c.nodok=vr_nodok and c.kddept=vr_kddept
			left outer join sc_mst.komponen_bpjs d on d.kode_bpjs='BPJSTK' and d.kodekomponen='JP'	
			left outer join (select * from sc_trx.bpjs_karyawan) e on a.nik=e.nik and e.kode_bpjs='BPJSTK' and to_char(e.tgl_berlaku,'YYYYMM')<=to_char(c.periode_akhir,'YYYYMM')
		group by a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,b.keterangan,b.update_date,b.update_by,d.besaranperusahaan,a.gajinaker ;               

		     --perform sc_trx.pr_ambil_jht_kar(vr_nik,21,nodok);
		insert into sc_tmp.payroll_detail(
			nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
			approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
		select vr_nodok as nodok,a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,b.keterangan,case 
				when max(e.id_bpjs) is not null  then ((d.besarankaryawan/100)*(coalesce(a.gajinaker,0))::numeric(18,2))::numeric(18,2)
				else 0::numeric(18,2) end as nominal ,
			to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as input_date,null as approval_date,vr_nodok as input_by,null as approval_by,null as delete_by,null as cancel_by,null as update_date,null as delete_date,null as cancel_date,'' as update_by from 
			(select a.*,b.* from sc_mst.karyawan a
					left outer join sc_mst.departmen b on a.bag_dept=b.kddept
					where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end)  and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO') a 
			left outer join sc_mst.detail_formula b on no_urut=21 and kdrumus='PR'
			left outer join sc_tmp.payroll_rekap c on c.nodok=vr_nodok and c.kddept=vr_kddept
			left outer join sc_mst.komponen_bpjs d on d.kode_bpjs='BPJSTK' and d.kodekomponen='JHT'	
			left outer join (select * from sc_trx.bpjs_karyawan) e on a.nik=e.nik and e.kode_bpjs='BPJSTK' and to_char(e.tgl_berlaku,'YYYYMM')<=to_char(c.periode_akhir,'YYYYMM')
		group by a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,b.keterangan,b.update_date,b.update_by,d.besarankaryawan,a.gajinaker ;               
    
		     
		     --perform sc_trx.pr_ambil_bpjs_kar(vr_nik,22,nodok);
		insert into sc_tmp.payroll_detail(
			nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
			approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
		select vr_nodok as nodok,a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,b.keterangan,case 
				when max(e.id_bpjs) is not null  then ((d.besarankaryawan/100)*(coalesce(a.gajibpjs,0))::numeric(18,2))::numeric(18,2)
				else 0::numeric(18,2) end as nominal ,
			to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as input_date,null as approval_date,vr_nodok as input_by,null as approval_by,null as delete_by,null as cancel_by,null as update_date,null as delete_date,null as cancel_date,'' as update_by from 
			(select a.*,b.* from sc_mst.karyawan a
					left outer join sc_mst.departmen b on a.bag_dept=b.kddept
					where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end)  and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO') a 
			left outer join sc_mst.detail_formula b on no_urut=22 and kdrumus='PR'
			left outer join sc_tmp.payroll_rekap c on c.nodok=vr_nodok and c.kddept=vr_kddept
			left outer join sc_mst.komponen_bpjs d on d.kode_bpjs='BPJSKES' and d.kodekomponen='BPJSKES'	
			left outer join (select * from sc_trx.bpjs_karyawan) e on a.nik=e.nik and e.kode_bpjs='BPJSKES' and to_char(e.tgl_berlaku,'YYYYMM')<=to_char(c.periode_akhir,'YYYYMM')
		group by a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,b.keterangan,b.update_date,b.update_by,d.besarankaryawan,a.gajibpjs ;               
		     
		     --perform sc_trx.pr_ambil_jp_kar(vr_nik,23,nodok);
		insert into sc_tmp.payroll_detail(
			nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
			approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
		select vr_nodok as nodok,a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,b.keterangan,case 
				when max(e.id_bpjs) is not null  then ((d.besarankaryawan/100)*(coalesce(a.gajinaker,0))::numeric(18,2))::numeric(18,2)
				else 0::numeric(18,2) end as nominal ,
			to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as input_date,null as approval_date,vr_nodok as input_by,null as approval_by,null as delete_by,null as cancel_by,null as update_date,null as delete_date,null as cancel_date,'' as update_by from 
			(select a.*,b.* from sc_mst.karyawan a
					left outer join sc_mst.departmen b on a.bag_dept=b.kddept
					where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end)  and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO') a 
			left outer join sc_mst.detail_formula b on no_urut=23 and kdrumus='PR'
			left outer join sc_tmp.payroll_rekap c on c.nodok=vr_nodok and c.kddept=vr_kddept
			left outer join sc_mst.komponen_bpjs d on d.kode_bpjs='BPJSTK' and d.kodekomponen='JP'	
			left outer join (select * from sc_trx.bpjs_karyawan) e on a.nik=e.nik and e.kode_bpjs='BPJSTK' and to_char(e.tgl_berlaku,'YYYYMM')<=to_char(c.periode_akhir,'YYYYMM')
		group by a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,b.keterangan,b.update_date,b.update_by,d.besarankaryawan,a.gajinaker ;               

		     --perform sc_trx.pr_input_global(vr_nik,24,nodok);
		insert into sc_tmp.payroll_detail(
			nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
			approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
		select vr_nodok as nodok,a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,coalesce(0,0)as nominal,
			to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as input_date,null as approval_date,vr_nodok as input_by,null as approval_by,null as delete_by,null as cancel_by,null as update_date,null as delete_date,null as cancel_date,'' as update_by from 
			(select a.*,b.* from sc_mst.karyawan a
					left outer join sc_mst.departmen b on a.bag_dept=b.kddept
					where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end)  and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO') a 
			left outer join sc_mst.detail_formula b on no_urut=24 and kdrumus='PR';
			
		     --perform sc_trx.pr_input_global(vr_nik,25,nodok);
		insert into sc_tmp.payroll_detail(
			nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
			approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
		select vr_nodok as nodok,a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,coalesce(0,0)as nominal,
			to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as input_date,null as approval_date,vr_nodok as input_by,null as approval_by,null as delete_by,null as cancel_by,null as update_date,null as delete_date,null as cancel_date,'' as update_by from 
			(select a.*,b.* from sc_mst.karyawan a
					left outer join sc_mst.departmen b on a.bag_dept=b.kddept
					where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end)  and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO') a 
			left outer join sc_mst.detail_formula b on no_urut=25 and kdrumus='PR';
			
		     --perform sc_trx.pr_input_global(vr_nik,26,nodok);
		     --select * from sc_mst.detail_formula where no_urut='26'
		     --select nik,round(sum(npotong)) as npotong from (select nik,case when sisa <= npotong and sisa>0 then sisa else npotong end as npotong from sc_trx.payroll_pinjaman_mst where status in ('P','F') and nik='0318.307') as x group by nik;
		insert into sc_tmp.payroll_detail(
			nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
			approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
		select vr_nodok as nodok,a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,coalesce(npotong,0)as nominal,
			to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as input_date,null as approval_date,vr_nodok as input_by,null as approval_by,null as delete_by,null as cancel_by,null as update_date,null as delete_date,null as cancel_date,'' as update_by from 
			(select a.*,b.*,c.npotong from sc_mst.karyawan a
					left outer join sc_mst.departmen b on a.bag_dept=b.kddept
					left outer join (select nik,round(sum(out_sld)) as npotong from sc_trx.payroll_pinjaman_inq where docref=vr_nodok and doctype='OUT' group by nik) c on a.nik=c.nik
					where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end) and a.statuskepegawaian<>'KO') a 
			left outer join sc_mst.detail_formula b on no_urut=26 and kdrumus='PR';
			
		     --perform sc_trx.pr_ambil_pph21(vr_nik,28,nodok);
		insert into sc_tmp.payroll_detail(
			nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
			approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
		select vr_nodok as nodok,a.nik,b.no_urut,b.tipe,b.aksi_tipe,b.aksi,b.taxable,b.tetap,b.deductible,b.regular,b.cash,'I' as status,b.keterangan,sum(coalesce(nominal,0))as nominal,
			to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as input_date,null as approval_date,'66666' as input_by,null as approval_by,null as delete_by,null as cancel_by,null as update_date,null as delete_date,null as cancel_date,'' as update_by from 
			(select a.*,b.* from sc_mst.karyawan a
					left outer join sc_mst.departmen b on a.bag_dept=b.kddept
					where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end)  and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO') a 
			left outer join sc_mst.detail_formula b on b.no_urut=28 and b.kdrumus='PR'
			left outer join sc_tmp.payroll_rekap c on c.nodok=vr_nodok and c.kddept=vr_kddept
			left outer join sc_tmp.p21_detail d on d.nik=a.nik and d.no_urut=63 and d.keterangan='TOTAL PPH 21'
			group by a.nik,b.no_urut,b.tipe,b.aksi_tipe,b.aksi,b.taxable,b.tetap,b.deductible,b.regular,b.cash,b.keterangan,b.update_date,b.update_by,c.periode_akhir;

		     --perform sc_trx.pr_input_global(vr_nik,29,nodok);
		insert into sc_tmp.payroll_detail(
			nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
			approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
		select vr_nodok as nodok,a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,coalesce(0,0)as nominal,
			to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as input_date,null as approval_date,vr_nodok as input_by,null as approval_by,null as delete_by,null as cancel_by,null as update_date,null as delete_date,null as cancel_date,'' as update_by from 
			(select a.*,b.* from sc_mst.karyawan a
					left outer join sc_mst.departmen b on a.bag_dept=b.kddept
					where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end)  and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO') a 
			left outer join sc_mst.detail_formula b on no_urut=29 and kdrumus='PR';
			
		     --perform sc_trx.pr_input_global(vr_nik,30,nodok);
		insert into sc_tmp.payroll_detail(
			nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
			approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
		select vr_nodok as nodok,a.nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,coalesce(0,0)as nominal,
			to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as input_date,null as approval_date,vr_nodok as input_by,null as approval_by,null as delete_by,null as cancel_by,null as update_date,null as delete_date,null as cancel_date,'' as update_by from 
			(select a.*,b.* from sc_mst.karyawan a
					left outer join sc_mst.departmen b on a.bag_dept=b.kddept
					where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end)  and a.bag_dept=vr_kddept and a.statuskepegawaian<>'KO') a 
			left outer join sc_mst.detail_formula b on no_urut=30 and kdrumus='PR';
		     

	    
	    
 --   END LOOP;
	--update sc_tmp.payroll_detail set status='H' where nodok=vr_nodok and nik in (select trim(nik) from sc_mst.karyawan where grouppenggajian=vr_gp and bag_dept=vr_kddept and statuskepegawaian<>'KO');
	update sc_tmp.payroll_master set status='H' where nodok=vr_nodok and kddept=vr_kddept;
	update sc_mst.trxerror set errorcode='0' where userid=trim(vr_nodok) and modul='PAYROLL_GEN';
    RETURN vr_tglkeluarkerja;
END;
$$;

alter function pr_generate_payroll_dept(char, char, date, date, char, char) owner to postgres;

