create function update_template_jadwal() returns trigger
    language plpgsql
as
$$
declare vr_status character(10);
vr_cek bigint;
vr_mst_regu_eosf_val character(10);
vr_mst_regu_eosf_index character(10);
vr_eor_val character(10);   
begin


if (new.status='F')and(old.status is null or old.status='') then 


	delete from sc_mst.template_jadwal WHERE kdregu=new.kdregu and bulan=new.bulan and tahun=new.tahun and kd_opt=new.kd_opt;
	--VR_CEK:=COUNT(*) FROM SC_mst.template_jadwal WHERE kdregu=new.kdregu and bulan=new.bulan and tahun=new.tahun and kd_opt=new.kd_opt;
	--IF VR_CEK=0 THEN

	vr_mst_regu_eosf_val:=trim(eosf_val) from sc_mst.regu where kdregu=new.kdregu and kd_opt=new.kd_opt;	--value shift	
	vr_mst_regu_eosf_index:=trim(eosf_index) from sc_mst.regu where kdregu=new.kdregu and kd_opt=new.kd_opt; --value index
	vr_eor_val:=trim(eor_val) from sc_mst.regu where kdregu=new.kdregu and kd_opt=new.kd_opt; --value ritme
	
		INSERT INTO sc_mst.template_jadwal (tahun,bulan,kdregu,kd_opt,m01_1 ,m01_2 ,m01_3 ,m01_4 ,m01_5 ,m01_6 ,m01_7 ,m02_8 ,m02_9 ,m02_10 ,m02_11 ,m02_12 ,m02_13 ,m02_14 ,m03_15 ,m03_16 ,m03_17 ,
			m03_18 ,m03_19 ,m03_20 ,m03_21 ,m04_22 ,m04_23 ,m04_24 ,m04_25 ,m04_26 ,m04_27 ,m04_28 ,m05_29 ,m05_30 ,m05_31 ,m05_32 ,m05_33 ,m05_34 ,m05_35 ,m01_1_rev ,m01_2_rev ,m01_3_rev ,m01_4_rev ,m01_5_rev ,m01_6_rev ,m01_7_rev ,
			m02_8_rev ,m02_9_rev ,m02_10_rev ,m02_11_rev ,m02_12_rev ,m02_13_rev ,m02_14_rev ,m03_15_rev ,m03_16_rev ,m03_17_rev ,m03_18_rev ,m03_19_rev ,m03_20_rev ,m03_21_rev ,m04_22_rev ,m04_23_rev ,m04_24_rev ,m04_25_rev ,m04_26_rev ,
			m04_27_rev ,m04_28_rev ,m05_29_rev ,m05_30_rev ,m05_31_rev , m05_32_rev ,m05_33_rev ,m05_34_rev ,m05_35_rev ,eosf_index ,eosf_val ,eor_val ,status,eosf_index_end ,eosf_val_end ,eor_val_end ) 
		select tahun,bulan,kdregu,kd_opt,m01_1 ,m01_2 ,m01_3 ,m01_4 ,m01_5 ,m01_6 ,m01_7 ,m02_8 ,m02_9 ,m02_10 ,m02_11 ,m02_12 ,m02_13 ,m02_14 ,m03_15 ,m03_16 ,m03_17 ,
			m03_18 ,m03_19 ,m03_20 ,m03_21 ,m04_22 ,m04_23 ,m04_24 ,m04_25 ,m04_26 ,m04_27 ,m04_28 ,m05_29 ,m05_30 ,m05_31 ,m05_32 ,m05_33 ,m05_34 ,m05_35 ,m01_1_rev ,m01_2_rev ,m01_3_rev ,m01_4_rev ,m01_5_rev ,m01_6_rev ,m01_7_rev ,
			m02_8_rev ,m02_9_rev ,m02_10_rev ,m02_11_rev ,m02_12_rev ,m02_13_rev ,m02_14_rev ,m03_15_rev ,m03_16_rev ,m03_17_rev ,m03_18_rev ,m03_19_rev ,m03_20_rev ,m03_21_rev ,m04_22_rev ,m04_23_rev ,m04_24_rev ,m04_25_rev ,m04_26_rev ,
			m04_27_rev ,m04_28_rev ,m05_29_rev ,m05_30_rev ,m05_31_rev , m05_32_rev ,m05_33_rev ,m05_34_rev ,m05_35_rev ,vr_mst_regu_eosf_index ,vr_mst_regu_eosf_val ,vr_eor_val ,status,eosf_index ,eosf_val ,eor_val 
		FROM sc_tmp.template_jadwal WHERE kdregu=new.kdregu and bulan=new.bulan and tahun=new.tahun and kd_opt=new.kd_opt and STATUS='F';


	
	--END IF;
		UPDATE SC_MST.REGU set --update regu setelah submit
		eosf_index=(select trim(eosf_index) FROM sc_tmp.template_jadwal WHERE kdregu=new.kdregu and bulan=new.bulan and tahun=new.tahun ),
		eosf_val=(select trim(eosf_val) FROM sc_tmp.template_jadwal WHERE kdregu=new.kdregu and bulan=new.bulan and tahun=new.tahun  ),
		eor_val=(select trim(eor_val) FROM sc_tmp.template_jadwal WHERE kdregu=new.kdregu and bulan=new.bulan and tahun=new.tahun )
		WHERE kdregu=new.kdregu AND kd_opt=new.kd_opt;

	
	DELETE FROM sc_tmp.template_jadwal WHERE STATUS='F' AND kdregu=new.kdregu and bulan=new.bulan and tahun=new.tahun;

end if;
return new;

end;
$$;

alter function update_template_jadwal() owner to postgres;

