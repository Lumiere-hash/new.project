create function pr_pph15_21(id character, nomor integer, userid character) returns numeric
    language plpgsql
as
$$
DECLARE 

vr_pkp numeric(18,2):=0;
vr_pembulatan numeric(18,2):=0;
vr_pph15 numeric(18,2):=0;
BEGIN		

	--select besaranptkp into vr_duit from sc_mst.karyawan where nik=id;

	select round(nominal,-3) into vr_pembulatan from sc_tmp.p21_detail where nik=id  and no_urut='28' and keterangan='PKP';	

	if vr_pembulatan-50000000>0 then
		vr_pph15=vr_pembulatan*15/100.00;
	else vr_pph15=0;
	end if;
		
	
	delete from sc_tmp.p21_detail where nodok=userid and nik=id and no_urut=nomor;

	insert into sc_tmp.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
	select userid as nodok,id as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_pph15 as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by from sc_mst.detail_formula
	where no_urut=nomor and kdrumus='P21';

	--insert into dumy(nominal) values (vr_pph5);
	
	RETURN vr_pph15;	
END;
$$;

alter function pr_pph15_21(char, integer, char) owner to postgres;

