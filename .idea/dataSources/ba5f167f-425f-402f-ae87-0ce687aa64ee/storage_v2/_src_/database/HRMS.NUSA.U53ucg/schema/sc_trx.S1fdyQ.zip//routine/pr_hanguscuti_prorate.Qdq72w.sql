create function pr_hanguscuti_prorate() returns SETOF void
    language plpgsql
as
$$
--author by : Fiky Ashariza 12-04-2016
--update by : --
--idbu	    : NUSA
--update by : Unknown 12-04-2016
--prosedur ketiga penambahan cuti awal maret (3)


DECLARE vr_sisacuti integer;
DECLARE vr_nik character(12);
DECLARE vr_dokumen character(12);
DECLARE vr_sisaup12 integer;

BEGIN
/* HITUNG ULANG CUTI BALANCE */
/*tabel bantuan cuti prorata insert ke cuti ultah*/
update sc_trx.cuti_blc a set sisacuti=b.balance
from (select *,sum("in_cuti"-"out_cuti") over(partition by nik order by nik,tanggal,no_dokumen,doctype) as balance
from sc_trx.cuti_blc) b
where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen and a.doctype=b.doctype;

FOR vr_nik,vr_sisaup12 in select trim(nik),sisacuti from sc_mst.karyawan where coalesce(statuskepegawaian,'')<>'KO' and sisacuti>12


	LOOP	

	insert into sc_trx.cuti_blc (nik,tanggal,no_dokumen,in_cuti,out_cuti,sisacuti,doctype,status)
	values (vr_nik,cast(to_char(now(),'yyyy-mm-dd 01:01:01')as timestamp),'HGSPRT',0,(vr_sisaup12-12),0,'HGS','HANGUS'); --insert untuk penghangusan cuti
	
	RETURN NEXT vr_nik;
	END LOOP;

	update sc_mst.karyawan set sisacuti=0 where sisacuti is null; --set 0 untuk karyawan yang belum pernah cuti
	
	
RETURN;
	

	
END;
$$;

alter function pr_hanguscuti_prorate() owner to postgres;

