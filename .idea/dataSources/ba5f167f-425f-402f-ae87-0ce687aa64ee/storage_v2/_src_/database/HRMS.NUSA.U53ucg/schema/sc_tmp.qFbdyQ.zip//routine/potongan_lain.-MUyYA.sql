create function potongan_lain() returns timestamp without time zone
    language plpgsql
as
$$
DECLARE
    vr_tgl timestamp without time zone;	
    vr_nik char(12);
    vr_nodok char(16);
   vr_upah numeric(18,2);
   vr_duit numeric(18,2);
   vr_ptg numeric(18,2);
   vr_gaji numeric(18,2);
   vr_pendapatan numeric(18,2);
   vr_totalupah numeric(18,2);
   vr_totalpendapatan numeric(18,2);
    
    
    
BEGIN
	--vr_keluarkerja:=to_char(tglakhirfix,'YYYYMM');
      --FOR listNik IN select distinct nik from sc_trx.dtljadwalkerja where to_char(tgl,'YYYYMM')=$1 and case when xnik<>'' then nik=xnik else nik<>'' end order by nik
    FOR vr_nik IN select nik from sc_tmp.payroll_master
			order by nik
			

			
		
    LOOP
	    
	
	    --FOR vr_urut IN select no_urut from sc_mst.detail_formula where kdrumus='PR' order by no_urut asc 
	    --LOOP
		
		     --insert into dumy(nik) values (vr_nik);

		  
			select coalesce(nominal,0) into vr_upah from sc_tmp.payroll_detail
			where nik=vr_nik and no_urut=25;

			select coalesce(nominal,0) into vr_gaji from sc_tmp.payroll_detail
			where nik=vr_nik and no_urut=29;

			vr_duit=vr_upah+vr_gaji;

			update sc_tmp.payroll_detail set nominal=0 
			where nik=vr_nik and no_urut=25;

			
			update sc_tmp.payroll_detail set nominal=vr_duit 
			where nik=vr_nik and no_urut=29; 
		
	    
    END LOOP;
    
    RETURN vr_tgl;
END;
$$;

alter function potongan_lain() owner to postgres;

