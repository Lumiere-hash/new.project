create view v_anajab_mst_jabatan
            (nmjabatan, nmdept, nmsubdept, nmlvljabatan, alljabatan, docdate1, docno, docdate, docref, kddept,
             kdsubdept, kdjabatan, kdlvljabatan, file_dir, file_name, file_patch, description, status, inputdate,
             inputby, updatedate, updateby, approvaldate, approvalby, docnotmp, nmstatus)
as
SELECT a.nmjabatan,
       b.nmdept,
       c.nmsubdept,
       e.nmlvljabatan,
       (((COALESCE(b.nmdept, ''::character varying)::text || ' - '::text) ||
         COALESCE(c.nmsubdept, ''::character varying)::text) || ' - '::text) ||
       COALESCE(a.nmjabatan, ''::character varying)::text               AS alljabatan,
       to_char(f.docdate::timestamp with time zone, 'dd-mm-yyyy'::text) AS docdate1,
       f.docno,
       f.docdate,
       f.docref,
       f.kddept,
       f.kdsubdept,
       f.kdjabatan,
       f.kdlvljabatan,
       f.file_dir,
       f.file_name,
       f.file_patch,
       f.description,
       f.status,
       f.inputdate,
       f.inputby,
       f.updatedate,
       f.updateby,
       f.approvaldate,
       f.approvalby,
       f.docnotmp,
       CASE
           WHEN COALESCE(f.file_name, ''::text) = ''::text THEN 'BELUM TERUPLOAD'::text
           ELSE 'SUDAH TERUPLOAD'::text
           END                                                          AS nmstatus
FROM sc_mst.jabatan a
         LEFT JOIN sc_mst.departmen b ON a.kddept = b.kddept
         LEFT JOIN sc_mst.subdepartmen c ON a.kddept = c.kddept AND a.kdsubdept = c.kdsubdept
         LEFT JOIN sc_mst.lvljabatan e ON a.kdlvl = e.kdlvl
         LEFT JOIN sc_his.anajab_mst f
                   ON f.kddept = a.kddept AND a.kdsubdept = f.kdsubdept AND a.kdjabatan = f.kdjabatan;

alter table v_anajab_mst_jabatan
    owner to postgres;

