create function pr_p1721_detail() returns trigger
    language plpgsql
as
$$
DECLARE
vr_tahun character(20);
vr_kddept character(20);
  
    vr_subtotalbruto numeric;
    vr_totalpajak numeric;
    vr_totalpendapatan numeric;
    vr_totalpotongan numeric;
    vr_subtotalpengurang numeric;
    vr_penghasilan_netto numeric;
    vr_netto_untukpph21 numeric;
    vr_netto_masa_lalu numeric;
    vr_pkp numeric; vr_ptkp numeric; vr_pkp_net numeric;
    vr_pphsetahun numeric;
    vr_pphsetahun_masa_lalu numeric;
    vr_pph_terutang numeric;

BEGIN
		

	IF (tg_op = 'UPDATE') THEN	
		vr_kddept:=trim(bag_dept) from sc_mst.karyawan where nik=new.nik;

		update sc_tmp.p1721_rekap set
		total_pajak=(select coalesce(sum(nominal),0) from sc_tmp.p1721_detail  where no_urut=17 and grouppenggajian=new.grouppenggajian and kddept=vr_kddept),
		total_potongan=(select coalesce(sum(nominal),0) from sc_tmp.p1721_detail  where no_urut=11 and grouppenggajian=new.grouppenggajian and kddept=vr_kddept),
		total_pendapatan=(select coalesce(sum(nominal),0) from sc_tmp.p1721_detail  where no_urut=12 and grouppenggajian=new.grouppenggajian and kddept=vr_kddept)
		where nodok=new.nodok;
		
			vr_subtotalbruto:=coalesce(sum(nominal),0) from sc_tmp.p1721_detail where nik=new.nik and (no_urut in (1,2,3,4,5,6,7)); --subtotal bruto
			update sc_tmp.p1721_detail set nominal=vr_subtotalbruto where nik=new.nik and no_urut=8;			

			vr_subtotalpengurang:=coalesce(sum(nominal),0) from sc_tmp.p1721_detail where nik=new.nik and (no_urut in (9,10)); --subtotal pengurang
			update sc_tmp.p1721_detail set nominal=vr_subtotalpengurang where nik=new.nik and no_urut=11;			
			
			vr_penghasilan_netto:=vr_subtotalbruto-vr_subtotalpengurang;--subtotal penghasilan nettto 
			update sc_tmp.p1721_detail set nominal=vr_penghasilan_netto where nik=new.nik and no_urut=12;		
			
			vr_netto_masa_lalu:=coalesce(sum(nominal),0) from sc_tmp.p1721_detail where nik=new.nik and (no_urut in (13));
			vr_netto_untukpph21:=vr_penghasilan_netto+vr_netto_masa_lalu;      --subtotal penghasilan nettto untuk perhitungan pph netto + netto sebelumnya
			update sc_tmp.p1721_detail set nominal=vr_netto_untukpph21 where nik=new.nik and no_urut=14;	

			vr_netto_masa_lalu:=coalesce(sum(nominal),0) from sc_tmp.p1721_detail where nik=new.nik and (no_urut in (13));
			vr_netto_untukpph21:=vr_penghasilan_netto+vr_netto_masa_lalu;      --subtotal penghasilan nettto untuk perhitungan pph netto + netto sebelumnya
			update sc_tmp.p1721_detail set nominal=vr_netto_untukpph21 where nik=new.nik and no_urut=14;	
		
			vr_ptkp:=coalesce(sum(nominal),0) from sc_tmp.p1721_detail where nik=new.nik and (no_urut in (15));
			vr_pkp:=vr_netto_untukpph21-vr_ptkp;      --penghasilan kena pajak pertahun

			if vr_pkp<vr_ptkp then 
				vr_pkp_net=0; 
			else vr_pkp_net=trunc(vr_pkp,-3);
			end if;
			update sc_tmp.p1721_detail set nominal=vr_pkp_net where nik=new.nik and no_urut=16;	


			--perhitungan pph21 atas penghasilan kena pajak setahun versi 2
/*			if (vr_pkp_net<=50000000) then 
				vr_pphsetahun=vr_pkp_net*5/100.00;
			elseif (vr_pkp_net<=250000000) then
				vr_pphsetahun=(vr_pkp_net-50000000)*15/100.00+2500000;
			elseif (vr_pkp_net<=500000000) then
				vr_pphsetahun=(vr_pkp_net-250000000)*25/100.00+32500000;
			else vr_pphsetahun=(vr_pkp_net-500000000)*30/100.00+95000000;
			end if;
*/			
			select sum(nominal) as pph21_y into vr_pphsetahun from sc_trx.p21_detail where nik=new.nik and no_urut='63' and nodok like '%'||vr_tahun||'%';  --RUMUS VERSI 1 SUMMARY TOTAL PPH21/BULAN
			update sc_tmp.p1721_detail set nominal=vr_pphsetahun where nik=new.nik and no_urut=17;	
			
			vr_pphsetahun_masa_lalu:=coalesce(sum(nominal),0) from sc_tmp.p1721_detail where nik=new.nik and (no_urut in (18));
			vr_pph_terutang:=vr_pphsetahun-vr_pphsetahun_masa_lalu;      --penghasilan kena pajak pertahun
			update sc_tmp.p1721_detail set nominal=vr_pph_terutang where nik=new.nik and no_urut=19;	--terutang	
			update sc_tmp.p1721_detail set nominal=vr_pph_terutang where nik=new.nik and no_urut=20;	--pph21 yang telah dipotong lunas	



		RETURN new;	
	ELSEIF tg_op = 'DELETE' THEN
		
		update sc_tmp.p1721_rekap set
		total_pajak=(select coalesce(sum(nominal),0) from sc_tmp.p1721_detail  where no_urut=17 and grouppenggajian=new.grouppenggajian and kddept=vr_kddept),
		total_potongan=(select coalesce(sum(nominal),0) from sc_tmp.p1721_detail  where no_urut=11 and grouppenggajian=new.grouppenggajian and kddept=vr_kddept),
		total_pendapatan=(select coalesce(sum(nominal),0) from sc_tmp.p1721_detail  where no_urut=12 and grouppenggajian=new.grouppenggajian and kddept=vr_kddept)
		where nodok=old.nodok;

		RETURN old;	
	END IF;
	
END;
$$;

alter function pr_p1721_detail() owner to postgres;

