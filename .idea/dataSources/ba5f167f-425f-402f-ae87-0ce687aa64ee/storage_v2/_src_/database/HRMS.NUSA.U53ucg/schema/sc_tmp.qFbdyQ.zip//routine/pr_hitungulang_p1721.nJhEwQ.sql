create function pr_hitungulang_p1721(vr_tahun character, vr_kddept character, vr_nodok character, vr_gp character) returns timestamp without time zone
    language plpgsql
as
$$
DECLARE
	
    vr_nik char(12);
    vr_tglkeluarkerja character(20);
    vr_periode_awal integer;
    vr_periode_akhir integer;
    vr_doktemp character(20);
    vr_doktemp2 character(20);
    vr_urut integer;
    vr_subtotalbruto numeric;
    vr_subtotalpengurang numeric;
    vr_penghasilan_netto numeric;
    vr_netto_untukpph21 numeric;
    vr_netto_masa_lalu numeric;
    vr_pkp numeric; vr_ptkp numeric; vr_pkp_net numeric;
    vr_pphsetahun numeric;
    vr_pphsetahun_masa_lalu numeric;
    vr_pph_terutang numeric;

    
    vr_tglmasukkerja character(20);
    vr_return timestamp without time zone;
    
    
    
BEGIN
		
	delete from sc_tmp.p1721_rekap where kddept=vr_kddept and grouppenggajian=vr_gp ;

	insert into sc_tmp.p1721_rekap
	(select  vr_nodok as nodok,cast(to_char(now(),vr_tahun||'-'||'12'||'-'||'01')as date) as tgl_dok,sum(total_pajak)as total_pajak,sum(total_pendapatan)as total_pendapatan,sum(total_potongan)as total_potongan,cast(to_char(now(),'yyyy-mm-dd HH24:MI:SS')as timestamp) as input_date,null as approval_date,'666666' as input_by,'' as approval_by,'' as delete_by,'' as cancel_by,null as update_date,
	null as delete_date,null as cancel_date,'' as update_by,'I' as status,1 as periode_mulai,12 as periode_akhir,vr_kddept as kddept,b.grouppenggajian from sc_trx.p21_master a 
	left outer join sc_mst.karyawan b on a.nik=b.nik
	where a.nodok like '%'||vr_tahun||'%' and a.nodok like '%'||vr_kddept||'%' and b.grouppenggajian=vr_gp
	group by b.grouppenggajian);


	
    FOR vr_nik in select nik from sc_mst.karyawan where (nik in (select nik from sc_trx.p21_detail where nodok like '%'||vr_tahun||'%')) and grouppenggajian=vr_gp and bag_dept=vr_kddept
    LOOP
			vr_subtotalbruto:=coalesce(sum(nominal),0) from sc_tmp.p1721_detail where nik=vr_nik and (no_urut in (1,2,3,4,5,6,7)); --subtotal bruto
			update sc_tmp.p1721_detail set nominal=vr_subtotalbruto where nik=vr_nik and no_urut=8;			

			vr_subtotalpengurang:=coalesce(sum(nominal),0) from sc_tmp.p1721_detail where nik=vr_nik and (no_urut in (9,10)); --subtotal pengurang
			update sc_tmp.p1721_detail set nominal=vr_subtotalpengurang where nik=vr_nik and no_urut=11;			
			
			vr_penghasilan_netto:=vr_subtotalbruto-vr_subtotalpengurang;--subtotal penghasilan nettto 
			update sc_tmp.p1721_detail set nominal=vr_penghasilan_netto where nik=vr_nik and no_urut=12;		
			
			vr_netto_masa_lalu:=coalesce(sum(nominal),0) from sc_tmp.p1721_detail where nik=vr_nik and (no_urut in (13));
			vr_netto_untukpph21:=vr_penghasilan_netto+vr_netto_masa_lalu;      --subtotal penghasilan nettto untuk perhitungan pph netto + netto sebelumnya
			update sc_tmp.p1721_detail set nominal=vr_netto_untukpph21 where nik=vr_nik and no_urut=14;	

			vr_netto_masa_lalu:=coalesce(sum(nominal),0) from sc_tmp.p1721_detail where nik=vr_nik and (no_urut in (13));
			vr_netto_untukpph21:=vr_penghasilan_netto+vr_netto_masa_lalu;      --subtotal penghasilan nettto untuk perhitungan pph netto + netto sebelumnya
			update sc_tmp.p1721_detail set nominal=vr_netto_untukpph21 where nik=vr_nik and no_urut=14;	
		
			vr_ptkp:=coalesce(sum(nominal),0) from sc_tmp.p1721_detail where nik=vr_nik and (no_urut in (15));
			vr_pkp:=vr_netto_untukpph21-vr_ptkp;      --penghasilan kena pajak pertahun

			if vr_pkp<vr_ptkp then 
				vr_pkp_net=0; 
			else vr_pkp_net=trunc(vr_pkp,-3);
			end if;
			update sc_tmp.p1721_detail set nominal=vr_pkp_net where nik=vr_nik and no_urut=16;	


			--perhitungan pph21 atas penghasilan kena pajak setahun versi 2
/*			if (vr_pkp_net<=50000000) then 
				vr_pphsetahun=vr_pkp_net*5/100.00;
			elseif (vr_pkp_net<=250000000) then
				vr_pphsetahun=(vr_pkp_net-50000000)*15/100.00+2500000;
			elseif (vr_pkp_net<=500000000) then
				vr_pphsetahun=(vr_pkp_net-250000000)*25/100.00+32500000;
			else vr_pphsetahun=(vr_pkp_net-500000000)*30/100.00+95000000;
			end if;
*/			
			select sum(nominal) as pph21_y into vr_pphsetahun from sc_trx.p21_detail where nik=vr_nik and no_urut='63' and nodok like '%'||vr_tahun||'%';  --RUMUS VERSI 1 SUMMARY TOTAL PPH21/BULAN
			update sc_tmp.p1721_detail set nominal=vr_pphsetahun where nik=vr_nik and no_urut=17;	
			
			vr_pphsetahun_masa_lalu:=coalesce(sum(nominal),0) from sc_tmp.p1721_detail where nik=vr_nik and (no_urut in (18));
			vr_pph_terutang:=vr_pphsetahun-vr_pphsetahun_masa_lalu;      --penghasilan kena pajak pertahun
			update sc_tmp.p1721_detail set nominal=vr_pph_terutang where nik=vr_nik and no_urut=19;	--terutang	
			update sc_tmp.p1721_detail set nominal=vr_pph_terutang where nik=vr_nik and no_urut=20;	--pph21 yang telah dipotong lunas	


    END LOOP;
/*
select * from sc_tmp.p1721_rekap
select * from sc_tmp.p1721_master

select sum(nominal) from sc_trx.p21_detail where no_urut=25 and nik in (select nik from sc_mst.karyawan where grouppenggajian='P1' and bag_dept='PRD');
select sum(total_pajak),sum(total_pendapatan),sum(total_potongan) from sc_trx.p21_master where nik in (select nik from sc_mst.karyawan where grouppenggajian='P1' and bag_dept='PRD')  and nodok like '%2016%'
select * from sc_mst.karyawan
select * from sc_tmp.p1721_detail a left outer join sc_mst.karyawan b on a.nik=b.nik where no_urut=8;
update sc_tmp.p1721_rekap where to_char(tgl_dok,'yyyy')=vr_tahun

truncate sc_tmp.p1721_detail
*/	    
    RETURN vr_return;
END;
$$;

alter function pr_hitungulang_p1721(char, char, char, char) owner to postgres;

