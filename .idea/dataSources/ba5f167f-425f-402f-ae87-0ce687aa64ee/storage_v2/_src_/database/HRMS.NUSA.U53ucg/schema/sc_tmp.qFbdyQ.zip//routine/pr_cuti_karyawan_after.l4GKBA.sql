create function pr_cuti_karyawan_after() returns trigger
    language plpgsql
as
$$
declare
     
     vr_nomor char(30);
     
begin
/*
	Update 30/01/2020 Penambahan notifikasi approval mobile 
*/
--vr_status:=trim(coalesce(status,'')) from sc_tmp.cuti where branch=new.branch and kddokumen=new.kddokumen for update;
--vr_nomor

delete from sc_mst.penomoran where userid=new.nodok; 
insert into sc_mst.penomoran 
        (userid,dokumen,nomor,errorid,partid,counterid,xno)
        values(new.nodok,'CUTI-KARYAWAN',' ',0,' ',1,0);

vr_nomor:=trim(coalesce(nomor,'')) from sc_mst.penomoran where userid=new.nodok;
 if (trim(vr_nomor)!='') or (not vr_nomor is null) then
	INSERT INTO sc_trx.cuti_karyawan(
		nodok,nik,kddept,kdsubdept,kdlvljabatan,kdjabatan,tgl_dok,tpcuti,tgl_mulai,tgl_selesai,kdijin_khusus,
		jumlah_cuti,keterangan,input_by,update_by,nmatasan,pelimpahan,alamat,
		input_date,update_date,status,approval_date,approval_by,delete_by,delete_date,cancel_by,cancel_date,status_ptg
	    )
	SELECT vr_nomor,nik,kddept,kdsubdept,kdlvljabatan,kdjabatan,tgl_dok,tpcuti,tgl_mulai,tgl_selesai,kdijin_khusus,
		jumlah_cuti,keterangan,input_by,update_by,nmatasan,pelimpahan,alamat,
		input_date,update_date,'I' as status,approval_date,approval_by,delete_by,delete_date,cancel_by,cancel_date,status_ptg

	from sc_tmp.cuti_karyawan where nodok=new.nodok and nik=new.nik;
	
	delete from sc_mst.trxerror where modul='CUTI' and userid=new.nodok;
	insert into sc_mst.trxerror
	(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
	(new.nodok,0,vr_nomor,'','CUTI');
       
delete from sc_tmp.cuti_karyawan where nodok=new.nodok and nik=new.nik;

end if;

return new;

end;
$$;

alter function pr_cuti_karyawan_after() owner to postgres;

