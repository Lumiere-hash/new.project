create function pr_cek_inbox() returns trigger
    language plpgsql
as
$$ 
declare
/* 
CREATE BY : FIKY
UPDATE DATE 23-08-2018
UPDATE : PENAMBAHAN ITEM SMS SPPB 
*/
     vr_jns char(30);
     vr_atasan1 char(30);
     --cuti
     vr_kodecuti char(20);
     vr_hpatscuti char(20);
     vr_stscuti char(1);
     
     --lembur
     vr_kodelembur char(20);
     vr_hpatslembur char(20);
     vr_stslembur char(2);

     --ijin
     vr_kodeijin char(20);
     vr_hpatsijin char(20);
     vr_stsijin char(1);	

     --dinas karyawan
     vr_kodedinas char(20);
     vr_hpatsdinas char(20);
     vr_stsdinas char(2);
     
     --cutibersama
     vr_kodecutib char(20);
     vr_hpatscutib char(20);
     vr_stscutib char(1);

     --perawatan
     vr_kodeperawatan char(20);
     vr_hpatsperawatan char(20);
     vr_nikatsperawatan char(20);
     vr_stsperawatan char(1);

     --sppb
     vr_kodesppb char(20);
     vr_nikatssppb1 char(20);
     vr_hpatssppb1 char(20);
     vr_nikatssppb char(20);
     vr_stssppb char(1);

     
     vr_konf char(1);
     vr_tipe char(10);
     vr_nohp char(20);
BEGIN		
		vr_jns:=left(trim(upper(split_part(trim(split_part("TextDecoded", ':', 1)),'No.',2))),4) from inbox where "SenderNumber"=new."SenderNumber" and "ID"=new."ID";																
		---select left(trim(upper(split_part(trim(split_part("TextDecoded", ':', 1)),'No.',2))),4) from inbox where "SenderNumber"=new."SenderNumber" and "ID"=new."ID";																
		vr_konf:=left(trim(left(trim(split_part(upper("TextDecoded"), 'CONF:', 2)),1)),1) as jnsdokumen from inbox where "SenderNumber"=new."SenderNumber" and "ID"=new."ID";																
		--select left(trim(left(trim(split_part(upper("TextDecoded"), 'CONF:', 2)),1)),1) as jnsdokumen from inbox where "SenderNumber"=new."SenderNumber" and "ID"=new."ID";																
		vr_tipe:=case 	when "SenderNumber"  in (select nohp1 from sc_mst.karyawan) then 'INTERN'
				when "SenderNumber"  in (select distinct ownhp from sc_mst.outlet where ownhp<>'+62') then 'POIN'
				else 'UNKNOWN' end from inbox where "SenderNumber"=new."SenderNumber" and "ID"=new."ID";
											
		vr_nohp:=trim("SenderNumber") from inbox where "SenderNumber"=new."SenderNumber" and "ID"=new."ID";
		vr_atasan1:=trim(nik) from sc_mst.karyawan where nohp1=new."SenderNumber";

		--cuti
		if (vr_jns='CUTI') and (vr_jns<>'') then
			vr_kodecuti:=left(trim(coalesce(split_part(trim(split_part("TextDecoded", ':', 2)),'Nama',1))),8) from inbox where "SenderNumber"=new."SenderNumber" and "ID"=new."ID";			
			vr_hpatscuti:=trim(both '_' from c.nohp1) from sc_trx.cuti_karyawan a    --nomer hp atasan nik
					left outer join sc_mst.karyawan b on a.nik=b.nik
					left outer join sc_mst.karyawan c on b.nik_atasan=c.nik
					where a.nodok=vr_kodecuti;
			vr_stscuti:=status from sc_trx.cuti_karyawan where nodok=vr_kodecuti;

			if ((vr_hpatscuti=new."SenderNumber") or (vr_hpatscuti=replace(new."SenderNumber",'+628','08'))) then
				if (vr_stscuti='A') then
					if (vr_konf='Y') then				
						update sc_trx.cuti_karyawan set approval_date=cast(to_char(now(),'yyyy-mm-dd HH24:MI:SS') as timestamp),approval_by=vr_atasan1, status='P' where nodok=vr_kodecuti;										
					elseif (vr_konf='N') then
						update sc_trx.cuti_karyawan set cancel_date=cast(to_char(now(),'yyyy-mm-dd HH24:MI:SS') as timestamp),cancel_by=vr_atasan1 ,status='C' where nodok=vr_kodecuti;	
					else insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
						select "SenderNumber",			
						'Hapus Bagian Keterangan Cuti!'
						,'SYSTEM'
						from inbox
						where "ID"=new."ID";													
					END IF;	
					
				else 
					insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
					select "SenderNumber",			
					'Sudah Di proses!'
					,'SYSTEM'
					from inbox
					where "ID"=new."ID";
				end if;
			else insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
					select "SenderNumber",			
					'Anda Tidak Berhak Approval Cuti ini!'
					,'SYSTEM'
					from inbox
					where "ID"=new."ID";													
			end if;

		--ijin	
		else if  (vr_jns='IJIN') and vr_jns<>'' then
						
			vr_kodeijin:=trim(regexp_replace(trim(right(trim(split_part(trim("TextDecoded"), 'Nama', 1)),10)), E'[\\n\\r]+', ' ', 'g' )) from inbox where "SenderNumber"=new."SenderNumber" and "ID"=new."ID";	
			vr_hpatsijin:=distinct(trim(both '_' from c.nohp1)) from sc_trx.ijin_karyawan a    --nomer hp atasan nik
					left outer join sc_mst.karyawan b on a.nik=b.nik
					left outer join sc_mst.karyawan c on b.nik_atasan=c.nik
					where a.nodok=vr_kodeijin;
			vr_stsijin:=trim(status) from sc_trx.ijin_karyawan where nodok=vr_kodeijin;

			if (vr_hpatsijin=new."SenderNumber" or (vr_hpatsijin=replace(new."SenderNumber",'+628','08'))) then
				if (vr_stsijin='A') then
					if (vr_konf='Y') then				
						update sc_trx.ijin_karyawan set approval_date=cast(to_char(now(),'yyyy-mm-dd HH24:MI:SS') as timestamp),approval_by=vr_atasan1 ,status='P' where nodok=vr_kodeijin;										
					elseif (vr_konf='N') then
						update sc_trx.ijin_karyawan set cancel_date=cast(to_char(now(),'yyyy-mm-dd HH24:MI:SS') as timestamp),cancel_by=vr_atasan1 ,status='C' where nodok=vr_kodeijin;	
					else insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
						select "SenderNumber",			
						'Hapus Bagian Keterangan Ijin!'
						,'SYSTEM'
						from inbox
						where "ID"=new."ID";													
					END IF;	
					
				else 
					insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
					select "SenderNumber",			
					'Sudah Di proses!'
					,'SYSTEM'
					from inbox
					where "ID"=new."ID";
				end if;
			else insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
					select "SenderNumber",			
					'Anda Tidak Berhak Approval Ijin ini!'
					,'SYSTEM'
					from inbox
					where "ID"=new."ID";													
			end if;
		

		--Lembur		
		elseif  (vr_jns='LEMB') and vr_jns<>'' then
			vr_kodelembur:=left(trim(coalesce(split_part(trim(split_part("TextDecoded", ':', 2)),'Nama',1))),9) from inbox where "SenderNumber"=new."SenderNumber" and "ID"=new."ID";
			vr_hpatslembur:=distinct(trim(both '_' from c.nohp1)) from sc_trx.lembur a    --nomer hp atasan nik
					left outer join sc_mst.karyawan b on a.nik=b.nik
					left outer join sc_mst.karyawan c on b.nik_atasan=c.nik
					where a.nodok=vr_kodelembur;
			vr_stslembur:=trim(status) from sc_trx.lembur where nodok=vr_kodelembur;		
			
			if (vr_hpatslembur=new."SenderNumber"  or (vr_hpatslembur=replace(new."SenderNumber",'+628','08'))) then
				if (vr_stslembur='A') then
					if (vr_konf='Y') then															
						update sc_trx.lembur set  approval_date=cast(to_char(now(),'yyyy-mm-dd HH24:MI:SS') as timestamp),approval_by=vr_atasan1 ,status='P' where nodok=vr_kodelembur;														
					elseif (vr_konf='N') then				
						update sc_trx.lembur set  cancel_date=cast(to_char(now(),'yyyy-mm-dd HH24:MI:SS') as timestamp),cancel_by=vr_atasan1 ,status='C' where nodok=vr_kodelembur;
					else insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
						select "SenderNumber",			
						'Hapus Bagian Keterangan Lembur!'
						,'SYSTEM'
						from inbox
						where "ID"=new."ID";																									
					END IF;
				else 
					insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
					select "SenderNumber",			
					'Sudah Di proses!'
					,'SYSTEM'
					from inbox
					where "ID"=new."ID";
				end if;
			else insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
					select "SenderNumber",			
					'Anda Tidak Berhak Approval Lembur ini!'
					,'SYSTEM'
					from inbox
					where "ID"=new."ID";													
			end if;


		--Dinas karyawan	

		elseif  (vr_jns='DINA') and vr_jns<>'' then
			vr_kodedinas:=left(trim(coalesce(split_part(trim(split_part("TextDecoded", ':', 2)),'Nama',1))),8) from inbox where "SenderNumber"=new."SenderNumber" and "ID"=new."ID";
			vr_hpatsdinas:=distinct(trim(both '_' from c.nohp1)) from sc_trx.dinas a    --nomer hp atasan nik
					left outer join sc_mst.karyawan b on a.nik=b.nik
					left outer join sc_mst.karyawan c on b.nik_atasan=c.nik
					where a.nodok=vr_kodedinas;
			vr_stsdinas:=trim(status) from sc_trx.dinas where nodok=vr_kodedinas;		
			
			if (vr_hpatsdinas=new."SenderNumber" or (vr_hpatsdinas=replace(new."SenderNumber",'+628','08'))) then
				if (vr_stsdinas='A') then
					if (vr_konf='Y') then															
						update sc_trx.dinas set approval_date=cast(to_char(now(),'yyyy-mm-dd HH24:MI:SS') as timestamp),approval_by=vr_atasan1, status='P' where nodok=vr_kodedinas;														
					elseif (vr_konf='N') then				
						update sc_trx.dinas set cancel_date=cast(to_char(now(),'yyyy-mm-dd HH24:MI:SS') as timestamp),cancel_by=vr_atasan1 , status='C' where nodok=vr_kodedinas;
					else insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
						select "SenderNumber",			
						'Hapus Bagian Keterangan Dinas!'
						,'SYSTEM'
						from inbox
						where "ID"=new."ID";																									
					END IF;
				else 
					insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
					select "SenderNumber",			
					'Sudah Di proses!'
					,'SYSTEM'
					from inbox
					where "ID"=new."ID";
				end if;
			else insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
					select "SenderNumber",			
					'Anda Tidak Berhak Approval Dinas ini!'
					,'SYSTEM'
					from inbox
					where "ID"=new."ID";													
			end if;


		--cuti bersama
		elseif (vr_jns='CTBR') and (vr_jns<>'') then
			vr_kodecutib:=left(trim(coalesce(split_part(trim(split_part("TextDecoded", ':', 2)),'Nama',1))),8) from inbox where "SenderNumber"=new."SenderNumber" and "ID"=new."ID";			
			vr_stscutib:=trim(status) from sc_trx.cutibersama where nodok=vr_kodecutib;
			vr_hpatscutib:=trim(nohp1) from sc_mst.karyawan where bag_dept='DI' and subbag_dept='DR' and jabatan='D1';
			if (vr_hpatscutib=new."SenderNumber" or (vr_hpatscutib=replace(new."SenderNumber",'+628','08'))) then
				if (vr_stscutib='I') then
					if (vr_konf='Y') then				
						update sc_trx.cutibersama set status='P' where nodok=vr_kodecutib;										
					elseif (vr_konf='N') then
						update sc_trx.cutibersama set status='C' where nodok=vr_kodecutib;	
					else insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
						select "SenderNumber",			
						'Hapus Bagian Keterangan Cuti!'
						,'SYSTEM'
						from inbox
						where "ID"=new."ID";													
					END IF;					
				else 
					insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
					select "SenderNumber",			
					'Sudah Di proses!'
					,'SYSTEM'
					from inbox
					where "ID"=new."ID";
				end if;
			else insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
					select "SenderNumber",			
					'Anda Tidak Berhak Approval Cuti ini!'
					,'SYSTEM'
					from inbox
					where "ID"=new."ID";													
			end if;	
		--PERAWATAN ASSET KARYAWAN
		--SELECT left(trim(upper(split_part(trim(split_part("TextDecoded", ':', 1)),'No.',2))),4) from inbox --where "SenderNumber"=new."SenderNumber" and "ID"=new."ID";																
		--SELECT left(trim(left(trim(split_part(upper("TextDecoded"), 'CONF:', 2)),1)),1) as jnsdokumen from inbox --where "SenderNumber"=new."SenderNumber" and "ID"=new."ID";																
	
		elseif (vr_jns='PAS') and (vr_jns<>'') then
			vr_kodeperawatan:=trim(regexp_replace(split_part(split_part("TextDecoded", 'PAS:', 2),'Sdr/i',1), E'[\\n\\r]+', ' ', 'g' )) from inbox where "SenderNumber"=new."SenderNumber" and "ID"=new."ID";			
			--select left(trim(coalesce(split_part(trim(split_part("TextDecoded", ':', 2)),'Nama',1))),12) from inbox --where "SenderNumber"=new."SenderNumber" and "ID"=new."ID";			
			vr_stsperawatan:=trim(status) from sc_his.perawatanasset where nodok=vr_kodeperawatan;
			--select trim(status) from sc_his.perawatanasset where nodok='PAS18010003';
			--vr_hpatsperawatan:=trim(nohp1) from sc_mst.karyawan where bag_dept='DI' and subbag_dept='DR' and jabatan='D1';
			vr_hpatsperawatan:=coalesce(trim(hpatasanmohon),'') from (
				select a.*,a1.nmlengkap as nmnikpakai,trim(a1.nohp1) as hpnikpakai,
				a2.nmlengkap as nmnikmohon,trim(a2.nohp1) as hpnikmohon,
				a3.nik as nikatasanmohon,a3.nmlengkap as nmatasanmohon,trim(a3.nohp1) as hpatasanmohon,b1.nmbarang,b1.nopol from sc_his.perawatanasset a
				left outer join sc_mst.karyawan a1 on a1.nik=a.nikpakai
				left outer join sc_mst.karyawan a2 on a2.nik=a.nikmohon
				left outer join sc_mst.karyawan a3 on a3.nik=a2.nik_atasan
				left outer join sc_mst.mbarang b1 on b1.nodok=a.stockcode
				) as x	where nodok=vr_kodeperawatan;
			vr_nikatsperawatan:=coalesce(trim(nikatasanmohon),'') from (
				select a.*,a1.nmlengkap as nmnikpakai,trim(a1.nohp1) as hpnikpakai,
				a2.nmlengkap as nmnikmohon,trim(a2.nohp1) as hpnikmohon,
				a3.nik as nikatasanmohon,a3.nmlengkap as nmatasanmohon,trim(a3.nohp1) as hpatasanmohon,b1.nmbarang,b1.nopol from sc_his.perawatanasset a
				left outer join sc_mst.karyawan a1 on a1.nik=a.nikpakai
				left outer join sc_mst.karyawan a2 on a2.nik=a.nikmohon
				left outer join sc_mst.karyawan a3 on a3.nik=a2.nik_atasan
				left outer join sc_mst.mbarang b1 on b1.nodok=a.stockcode
				) as x	where nodok=vr_kodeperawatan;	
				
			if (vr_hpatsperawatan=new."SenderNumber" or (vr_hpatsperawatan=replace(new."SenderNumber",'+628','08'))) then
				if (vr_stsperawatan='A') then
					if (vr_konf='Y') then
						--select * from sc_his.perawatanasset
						update sc_his.perawatanasset set status='',approvaldate=to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp,approvalby=vr_nikatsperawatan where nodok=vr_kodeperawatan;										
						update sc_his.perawatanasset set status='A1',approvaldate=to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp,approvalby=vr_nikatsperawatan where nodok=vr_kodeperawatan;										
						update sc_his.perawatanasset set status='A1',approvaldate=to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp,approvalby=vr_nikatsperawatan where nodok=vr_kodeperawatan and status='A1';	
						update sc_tmp.perawatanasset set status='F',approvaldate=to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp,approvalby=vr_nikatsperawatan where nodoktmp=vr_kodeperawatan;	
 									
					elseif (vr_konf='N') then
						update sc_his.perawatanasset set status='',canceldate=to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp,cancelby=vr_nikatsperawatan where nodok=vr_kodeperawatan;										
						update sc_his.perawatanasset set status='C',canceldate=to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp,cancelby=vr_nikatsperawatan where nodok=vr_kodeperawatan;										
						update sc_tmp.perawatanasset set status='F',canceldate=to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp,cancelby=vr_nikatsperawatan where nodok=vr_kodeperawatan;										
					else insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
						select "SenderNumber",			
						'Silahkan Pilih Y/N!'
						,'SYSTEM'
						from inbox
						where "ID"=new."ID";													
					END IF;					
				else 
					insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
					select "SenderNumber",			
					'Sudah Di proses!'
					,'SYSTEM'
					from inbox
					where "ID"=new."ID";
				end if;
			/*elseif (vr_hpatsperawatan=new."SenderNumber" or (vr_hpatsperawatan=replace(new."SenderNumber",'+628','08'))) then --untuk hr
			if (vr_stsperawatan='A' or vr_stsperawatan='A1') then
				if (vr_konf='Y') then
						--select * from sc_his.perawatanasset
						update sc_his.perawatanasset set status='',approvaldate=to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp,approvalby=vr_nikatsperawatan where nodok=vr_kodeperawatan;										
						update sc_his.perawatanasset set status='P',approvaldate=to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp,approvalby=vr_nikatsperawatan where nodok=vr_kodeperawatan;										
					elseif (vr_konf='N') then
						update sc_his.perawatanasset set status='',canceldate=to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp,cancelby=vr_nikatsperawatan where nodok=vr_kodeperawatan;										
						update sc_his.perawatanasset set status='C',canceldate=to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp,cancelby=vr_nikatsperawatan where nodok=vr_kodeperawatan;										
					else insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
						select "SenderNumber",			
						'Silahkan Pilih Y/N!'
						,'SYSTEM'
						from inbox
						where "ID"=new."ID";													
					END IF;					
				else 
					insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
					select "SenderNumber",			
					'Sudah Di proses!'
					,'SYSTEM'
					from inbox
					where "ID"=new."ID";
				end if;*/
			else insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
					select "SenderNumber",			
					'Silahkan Pilih Y/N!'
					,'SYSTEM'
					from inbox
					where "ID"=new."ID";													
			end if;	

		elseif (vr_jns='SPPB') and (vr_jns<>'') then
			vr_kodesppb:=trim(regexp_replace(left(trim(coalesce(split_part(trim(split_part("TextDecoded", ':', 2)),'Nama',1))),12), E'[\\n\\r]+', ' ', 'g' )) from inbox where "SenderNumber"=new."SenderNumber" and "ID"=new."ID";			
			--select trim(regexp_replace(left(trim(coalesce(split_part(trim(split_part("TextDecoded", ':', 2)),'Nama',1))),12), E'[\\n\\r]+', ' ', 'g' )) from inbox --where "SenderNumber"=new."SenderNumber" and "ID"=new."ID";			
			vr_stssppb:=trim(status) from sc_trx.sppb_mst where nodok=vr_kodesppb;
			--select trim(status) from sc_trx.sppb_mst where nodok='PPB18080004';
		
			select coalesce(trim(hpatasan1),'') as hpatasan1,coalesce(trim(nikatasan1),'') as nikatasan1 
			into vr_hpatssppb1,vr_nikatssppb1 from (
				select a.*,
				a2.nmlengkap as nmlengkap,trim(a2.nohp1) as nohpown,
				a3.nik as nikatasan1,a3.nmlengkap as nmatasan1,trim(a3.nohp1) as hpatasan1 from sc_trx.sppb_mst a
				left outer join sc_mst.karyawan a2 on a2.nik=a.nik
				left outer join sc_mst.karyawan a3 on a3.nik=a2.nik_atasan
				) as x	where nodok=vr_kodesppb;
				
			if (vr_hpatssppb1=new."SenderNumber" or (vr_hpatssppb1=replace(new."SenderNumber",'+628','08'))) then
				if (vr_stssppb='A') then
					if (vr_konf='Y') then
						--select * from sc_his.perawatanasset
						update sc_trx.sppb_mst set status='A',approvaldate=to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp,approvalby=vr_nikatssppb1 where nodok=vr_kodesppb;	
						update sc_tmp.sppb_dtl set status='P',approvaldate=to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp,approvalby=vr_nikatssppb1 where nodoktmp=vr_kodesppb;	
						update sc_tmp.sppb_mst set status='F',approvaldate=to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp,approvalby=vr_nikatssppb1 where nodoktmp=vr_kodesppb;	
															
					elseif (vr_konf='N') then
						update sc_trx.sppb_mst set status='C',approvaldate=to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp,approvalby=vr_nikatssppb1 where nodok=vr_kodesppb;	
						--update sc_tmp.sppb_dtl set status='P',approvaldate=to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp,approvalby=vr_nikatssppb1 where nodoktmp=vr_kodesppb;	
						update sc_tmp.sppb_mst set status='F',approvaldate=to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp,approvalby=vr_nikatssppb1 where nodoktmp=vr_kodesppb;	
																
					else insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
						select "SenderNumber",			
						'Silahkan Pilih Y/N!'
						,'SYSTEM'
						from inbox
						where "ID"=new."ID";													
					END IF;					
				else 
					insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
					select "SenderNumber",			
					'Data Sedang Di proses, Proses Gagal!'
					,'SYSTEM'
					from inbox
					where "ID"=new."ID";
				end if;
			
			else insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
					select "SenderNumber",			
					'Silahkan Pilih Y/N!'
					,'SYSTEM'
					from inbox
					where "ID"=new."ID";													
			end if;	
			
		else 
			if (vr_tipe='POIN') then
				insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
				select "SenderNumber",			
				'Outlet Anda mendapat sms ini karena terdaftar dalam program promosi PT NUSA, poin.nusaboard.co.id'
				,'SYSTEM'
				from inbox
				where "ID"=new."ID";	
			elseif (vr_tipe='INTERN') then
				insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
				select "SenderNumber",			
				'Maaf Format Sms anda salah, www.nusaboard.co.id'
				,'SYSTEM'
				from inbox
				where "ID"=new."ID";
			end if;					
		end if;
	end if;
							
	RETURN NEW;  	    
    END; 

    $$;

alter function pr_cek_inbox() owner to postgres;

