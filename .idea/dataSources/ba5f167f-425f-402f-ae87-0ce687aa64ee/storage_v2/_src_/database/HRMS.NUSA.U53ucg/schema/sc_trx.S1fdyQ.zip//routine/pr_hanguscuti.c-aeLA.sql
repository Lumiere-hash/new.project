create function pr_hanguscuti() returns SETOF void
    language plpgsql
as
$$
    --author by : Fiky Ashariza 12-04-2016
--update by : Unknown 12-04-2016
--prosedur pertama penghangusan cuti awal tahun (1)
DECLARE vr_sisacuti integer;
DECLARE vr_nik character(12);
DECLARE vr_dokumen character(12);

BEGIN
/* HITUNG ULANG CUTI BALANCE */
/*tabel bantuan cuti prorata insert ke cuti ultah*/
update sc_trx.cuti_blc a set sisacuti=b.balance
from (select *,sum("in_cuti"-"out_cuti") over(partition by nik order by nik,tanggal,no_dokumen,doctype) as balance
from sc_trx.cuti_blc) b
where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen and a.doctype=b.doctype;


---delete from sc_his.cuti_blc;
insert into sc_his.cuti_blc (nik,tanggal,no_dokumen,in_cuti,out_cuti,sisacuti,doctype,status)
(SELECT nik,cast(to_char(now(),'yyyy-mm-dd 01:01:00')as timestamp),'PRORATE',coalesce(sisacuti,0),0,0,'PRORATE','F' FROM SC_MST.KARYAWAN 
WHERE tglmasukkerja<=cast(to_char('2017-12-31'::date-interval '1 year','yyyy-mm-dd')as date) and coalesce(sisacuti,0)>0 and coalesce(statuskepegawaian)<>'KO');

/* PRORATE GANTI SISA CUTI TERAKHIR 
select nik,tglmasukkerja,'PRORATE',
	case when to_char(tglmasukkerja,'dd')<='15' then  cast(to_char(tglmasukkerja,'mm') as numeric)-1
	when to_char(tglmasukkerja,'dd')>'15' then  cast(to_char(tglmasukkerja,'mm') as numeric)
	end as prorate,0,0,'PRORATE','I' 
	from sc_mst.karyawan where to_char(tglmasukkerja,'yyyy-mm-dd')<='2015-12-31' and statuskepegawaian<>'KO';	
end tabel bantuan cuti prorata insert ke cuti ultah*/	

FOR vr_nik,vr_dokumen in select trim(a.nik),trim(a.no_dokumen) from sc_trx.cuti_blc a,
		(select a.nik,a.tanggal,a.no_dokumen,max(a.doctype) as doctype from sc_trx.cuti_blc a,
		(select a.nik,a.tanggal,max(a.no_dokumen) as no_dokumen from sc_trx.cuti_blc a,
		(select nik,max(tanggal) as tanggal from sc_trx.cuti_blc 
		group by nik) as b
		where a.nik=b.nik and a.tanggal=b.tanggal
		group by a.nik,a.tanggal) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen
		group by a.nik,a.tanggal,a.no_dokumen) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen and a.doctype=b.doctype


	LOOP	

	vr_sisacuti:= coalesce(sisacuti,'0')from sc_trx.cuti_blc a,
		(select a.nik,a.tanggal,a.no_dokumen,max(a.doctype) as doctype from sc_trx.cuti_blc a,
		(select a.nik,a.tanggal,max(a.no_dokumen) as no_dokumen from sc_trx.cuti_blc a,
		(select nik,max(tanggal) as tanggal from sc_trx.cuti_blc where nik=vr_nik
		group by nik) as b
		where a.nik=b.nik and a.tanggal=b.tanggal
		group by a.nik,a.tanggal) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen
		group by a.nik,a.tanggal,a.no_dokumen) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen and a.doctype=b.doctype;
		
		IF coalesce(vr_sisacuti,0)>0 THEN --cek global jika tak mendapat cuti/cuti minus
			insert into sc_trx.cuti_blc (nik,tanggal,no_dokumen,in_cuti,out_cuti,sisacuti,doctype,status)
			values (vr_nik,cast(to_char(now(),'yyyy-mm-dd 01:01:01')as timestamp),vr_dokumen,0,vr_sisacuti,0,'HGS','HANGUS'); --insert untuk penghangusan cuti
		END IF;
	RETURN NEXT vr_nik;
	END LOOP;

	update sc_mst.karyawan set sisacuti=0 where sisacuti is null; --set 0 untuk karyawan yang belum pernah cuti
	
	
RETURN;
	

	
END;
$$;

alter function pr_hanguscuti() owner to postgres;

