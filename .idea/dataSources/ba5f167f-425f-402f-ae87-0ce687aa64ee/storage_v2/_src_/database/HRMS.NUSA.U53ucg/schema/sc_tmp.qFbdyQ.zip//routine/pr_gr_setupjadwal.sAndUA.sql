create function pr_gr_setupjadwal(vr_bulan_awal character, vr_tahun_awal character, vr_kdregu character) returns SETOF void
    language plpgsql
as
$$
    --Author : Fiky Ashariza
--Update Date:
--Update By :
DECLARE vr_kdopt character(20);
DECLARE vr_nmopt character(20);
DECLARE vr_hr_aktif numeric;
DECLARE vr_temp_ritme numeric;
DECLARE vr_hr_libur numeric;
DECLARE vr_kon_1 numeric;
DECLARE vr_kon_2 numeric;
DECLARE vr_maxweek numeric;
DECLARE vr_ritme_1 numeric;
DECLARE vr_ritme_2 numeric;
DECLARE vr_ritme_3 numeric;
DECLARE vr_ritme character(10);
DECLARE vr_operatorlist character(20);
DECLARE vr_sdom character(10);
DECLARE vr_sdom1 character(10);
DECLARE vr_initsdom1 numeric;
DECLARE vr_edom character(10);
DECLARE vr_edom1 character(10);
DECLARE vr_bulan_bef character(10);
DECLARE vr_tahun_bef character(10);
DECLARE vr_kategori_kdjam character(10);
DECLARE vr_mst_regu_eosf_val character(10);
DECLARE vr_mst_regu_eosf_index character(10);
DECLARE vr_eor_val character(10);
DECLARE vr_jam_kerja character(10);
DECLARE vr_jam_kerja2 character(10);
DECLARE vr_inisial character(10);
DECLARE vr_cek_jadwal bigint;
DECLARE vr_hari_libur bigint;
DECLARE vr_sf1_all character(10); DECLARE vr_sf1_jumat character(10); DECLARE vr_sf1_sabtu character(10);
DECLARE vr_sf2_all character(10); DECLARE vr_sf2_jumat character(10); DECLARE vr_sf2_sabtu character(10);
DECLARE vr_sf3_all character(10); DECLARE vr_sf3_jumat character(10); DECLARE vr_sf3_sabtu character(10);
DECLARE vr_nama_hari character(20);


BEGIN

	vr_sdom:=trim(to_char(date_trunc('month', cast(to_char(now(),vr_tahun_awal||'-'||vr_bulan_awal||'-'||'dd')as date)),'dd'));
	vr_edom:=trim(to_char(date_trunc('month', cast(to_char(now(),vr_tahun_awal||'-'||vr_bulan_awal||'-'||'dd')as date))+interval '1 month'-interval '1 day','dd'));
	vr_kdopt:=trim(kd_opt) from sc_mst.regu where kdregu=trim(vr_kdregu);
	vr_sdom1:=trim(to_char(date_trunc('month', cast(to_char(now(),vr_tahun_awal||'-'||vr_bulan_awal||'-'||'dd')as date))-interval '15 day','dd'));
	vr_mst_regu_eosf_val:=replace(trim(eosf_val),'*','') from sc_mst.regu where kdregu=vr_kdregu and kd_opt=vr_kdopt;	--value shift	
	vr_mst_regu_eosf_index:=trim(eosf_index) from sc_mst.regu where kdregu=vr_kdregu and kd_opt=vr_kdopt; --value index
	vr_eor_val:=replace(trim(eor_val),'*','') from sc_mst.regu where kdregu=vr_kdregu and kd_opt=vr_kdopt; --value ritme

			vr_ritme_1:=ritme_1 from sc_mst.setup_grjadwal where kd_opt=vr_kdopt;
			vr_ritme_2:=ritme_2 from sc_mst.setup_grjadwal where kd_opt=vr_kdopt;
			vr_ritme_3:=ritme_3 from sc_mst.setup_grjadwal where kd_opt=vr_kdopt;

				vr_kon_1:=kon_1 from sc_mst.setup_grjadwal where kd_opt=vr_kdopt;
				vr_kon_2:=kon_2 from sc_mst.setup_grjadwal where kd_opt=vr_kdopt;

						vr_sf1_all:=trim(sf1_all) from sc_mst.setup_grjadwal where kd_opt=vr_kdopt; 
						vr_sf2_all:=trim(sf2_all) from sc_mst.setup_grjadwal where kd_opt=vr_kdopt; 
						vr_sf3_all:=trim(sf3_all) from sc_mst.setup_grjadwal where kd_opt=vr_kdopt;

						vr_sf1_jumat:=trim(sf1_jumat) from sc_mst.setup_grjadwal where kd_opt=vr_kdopt;
						vr_sf2_jumat:=trim(sf2_jumat) from sc_mst.setup_grjadwal where kd_opt=vr_kdopt;
						vr_sf3_jumat:=trim(sf3_jumat) from sc_mst.setup_grjadwal where kd_opt=vr_kdopt; 

						vr_sf1_sabtu:=trim(sf1_sabtu) from sc_mst.setup_grjadwal where kd_opt=vr_kdopt;
						vr_sf2_sabtu:=trim(sf2_sabtu) from sc_mst.setup_grjadwal where kd_opt=vr_kdopt;
						vr_sf3_sabtu:=trim(sf3_sabtu) from sc_mst.setup_grjadwal where kd_opt=vr_kdopt;
			
	if not exists(select * from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu) then --insert bulan awal
			insert into sc_tmp.template_jadwal (tahun,bulan,kdregu,kd_opt) values (vr_tahun_awal,vr_bulan_awal,vr_kdregu,vr_kdopt);
			--update sc_tmp.template_jadwal 
			--set eosf_index=vr_mst_regu_eosf_index,eosf_val=vr_mst_regu_eosf_val,eor_val=vr_eor_val
			--where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu;
	end if;

	vr_bulan_bef:=trim(to_char(date_trunc('month', cast(to_char(now(),vr_tahun_awal||'-'||vr_bulan_awal||'-'||'dd')as date))-interval '15 day','mm'));
	vr_tahun_bef:=trim(to_char(date_trunc('month', cast(to_char(now(),vr_tahun_awal||'-'||vr_bulan_awal||'-'||'dd')as date))-interval '15 day','yyyy'));
	vr_initsdom1:=15;
		
	if not exists(select * from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu) then --inisial bulan sebelumnya
			--insert into sc_tmp.template_jadwal (tahun,bulan,kdregu,kd_opt) values (vr_tahun_bef,vr_bulan_bef,vr_kdregu,vr_kdopt);
			
	end if;		
	

	loop --iterasi membaca bulan lalu jadwal kerja
		--update sc_tmp.template_jadwal set m01_1=vr_sdom1 where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
					/* KATEGORI JAM KERJA BERDASAR REGU */
			if(vr_kdregu=(select kdregu from(select kdregu from sc_mst.regu where kdregu in ('A1','A2','A3','A4','B1','B2','B4','C1','C2','C3','C4','D1','D2','D3','D4','E1','E2','E3','E4','F1','F2','F3','GA1','GA10','GA2','GA3','GA4','GA5','GA6','GA8','GF1', 
					'GF2','GF3','GF4','GF5','GF6','H1','H2','H3','H4','HMA','HMB','I1','I2','I3','I4','J2','J3','J4','K1','K2','K3','K4','LA1','LA2','LA3','LA4', 
					'LA4','LB1','LB2','LB3','LB4','LB5','P1M','P1U','P2M','P2U','P3M','P3U','P4M','P4U','PE1','PE2','PE3','PE4','PZ11','PZ12','PZ13','PZ14','PZ15','PZ16','PZ17','PZ18','PZ19','PZ2','PZ20', 
					'PZ21','PZ23','PZ24','PZ25','PZ26','PZ27','PZ3','PZ4','PZ5','PZ6','PZ7','PZ8','PZ9','WH2','WH3','WH4','WH5' ))as x where kdregu=vr_kdregu)) then
					 


					if exists (select * from sc_trx.jadwalkerja where kdregu=vr_kdregu and to_char(tgl,'yyyy')=vr_tahun_bef and to_char(tgl,'mm')=vr_bulan_bef and to_char(tgl,'dd')=vr_sdom1) then
					vr_kategori_kdjam:= case 
							when kodejamkerja='SF1' then '1' 
							when kodejamkerja='SF2'	then '2' 
							when kodejamkerja='SF3'	then '3'
							when kodejamkerja='OFF'	then 'OFF' end as kodejam
							from sc_trx.jadwalkerja where kdregu=vr_kdregu and to_char(tgl,'yyyy')=vr_tahun_bef and to_char(tgl,'mm')=vr_bulan_bef and to_char(tgl,'dd')=vr_sdom1;
					else 
					vr_kategori_kdjam:='OFF';
					end if;
			end if;
/*		SKIP PEMBACAAN BULAN LALU	
		if (cast((vr_sdom1)as integer)=1) then
			if ((select m01_1 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m01_1=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;
		elseif (cast((vr_sdom1)as integer)=2) then
			if ((select m01_2 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m01_2=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;
		elseif (cast((vr_sdom1)as integer)=3) then
			if ((select m01_3 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m01_3=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;
		elseif (cast((vr_sdom1)as integer)=4) then
			if ((select m01_4 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m01_4=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=5) then
			if ((select m01_5 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m01_5=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=6) then
			if ((select m01_6 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m01_6=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=7) then
			if ((select m01_7 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m01_7=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=8) then
			if ((select m02_8 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m02_8=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=9) then
			if ((select m02_9 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m02_9=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=10) then
			if ((select m02_10 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m02_10=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=11) then
			if ((select m02_11 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m02_11=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=12) then
			if ((select m02_12 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m02_12=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=13) then
			if ((select m02_13 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m02_13=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=14) then
			if ((select m02_14 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m02_14=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=15) then
			if ((select m03_15 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m03_15=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=16) then
			if ((select m03_16 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m03_16=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=17) then
			if ((select m03_17 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m03_17=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=18) then
			if ((select m03_18 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m03_18=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=19) then
			if ((select m03_19 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m03_19=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=20) then
			if ((select m03_20 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m03_20=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=21) then
			if ((select m03_21 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m03_21=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=22) then
			if ((select m04_22 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m04_22=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=23) then
			if ((select m04_23 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m04_23=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=24) then
			if ((select m04_24 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m04_24=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=25) then
			if ((select m04_25 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m04_25=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=26) then
			if ((select m04_26 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m04_26=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=27) then
			if ((select m04_27 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m04_27=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=28) then
			
			if ((select m04_28 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m04_28=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=29) then
			if ((select m05_29 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m05_29=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=30) then
			if ((select m05_30 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m05_30=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=31) then
			if ((select m05_31 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m05_31=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=32) then
			if ((select m05_32 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m05_32=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=33) then
			if ((select m05_33 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m05_33=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=34) then
			if ((select m05_34 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m05_34=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		elseif (cast((vr_sdom1)as integer)=35) then
			if ((select m05_35 from sc_tmp.template_jadwal where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
			update sc_tmp.template_jadwal set m05_35=vr_kategori_kdjam where tahun=vr_tahun_bef and bulan=vr_bulan_bef and kdregu=vr_kdregu and kd_opt=vr_kdopt;
			end if;		
		end if;
	
	*/
	vr_initsdom1:= vr_initsdom1-1;
	vr_sdom1:=cast((vr_sdom1)as integer)+1;
	EXIT WHEN vr_initsdom1=0;
	return next vr_sdom1;
	end loop;
	
	

			--if(vr_mst_regu_eosf_val='OFF' and cast((vr_mst_regu_eosf_index)as integer)=1) then
				--vr_temp_ritme:=vr_eor_val;
			--end if;
					if(vr_mst_regu_eosf_val='OFF') then --seleksi hari off masuk ke iterasi hari libur
						if(cast((vr_eor_val)as integer)<>1 and cast((vr_mst_regu_eosf_index)as integer)<>1 and vr_ritme_3 is not null) then
							vr_temp_ritme:=cast((vr_eor_val)as integer);
						elseif(cast((vr_eor_val)as integer)=1 and cast((vr_mst_regu_eosf_index)as integer)<>1 and vr_ritme_3 is not null ) then --ritme 3 terisi
							vr_temp_ritme:=1;
						elseif(cast((vr_eor_val)as integer)=1 and cast((vr_mst_regu_eosf_index)as integer)<>1 and vr_ritme_3 is null ) then --jika ritme ke 3 null
							vr_temp_ritme:=cast((vr_eor_val)as integer);	
						elseif(cast((vr_mst_regu_eosf_index)as integer)=1 and cast((vr_eor_val)as integer)>1 and vr_ritme_3 is not null) then --jika ritme ke 3 terisi
							vr_temp_ritme:=cast((vr_eor_val)as integer)-1;
						elseif(cast((vr_mst_regu_eosf_index)as integer)=1 and cast((vr_eor_val)as integer)>1 and vr_ritme_3 is null) then --jika ritme ke 3 null
							vr_temp_ritme:=cast((vr_eor_val)as integer);
						elseif(cast((vr_mst_regu_eosf_index)as integer)=1 and cast((vr_eor_val)as integer)=1 and vr_ritme_3 is not null) then
							vr_temp_ritme:=3;
						elseif(cast((vr_mst_regu_eosf_index)as integer)=1 and cast((vr_eor_val)as integer)=1 and vr_ritme_3 is null) then
							vr_temp_ritme:=cast((vr_eor_val)as integer);
						end if;
						


					elseif (vr_mst_regu_eosf_val<>'OFF' AND vr_ritme_3 is not null) then
					vr_temp_ritme:=cast((vr_mst_regu_eosf_val)as integer);
					elseif (vr_mst_regu_eosf_val<>'OFF' AND vr_ritme_3 is null) then
					vr_temp_ritme:=cast((vr_mst_regu_eosf_val)as integer)+1;
					end if;
					

	loop --iterasi tanggal
		
			vr_hr_aktif:=hr_aktif from sc_mst.setup_grjadwal where kd_opt=vr_kdopt; --declare hari aktif
			
			if((vr_mst_regu_eosf_val='1' or vr_mst_regu_eosf_val='2' or vr_mst_regu_eosf_val='3')and (cast((vr_sdom)as integer)=1)) then
				vr_hr_aktif:=cast((vr_mst_regu_eosf_index)as integer)-1; --iterasi 1 loop hari aktiv
			elseif(cast((vr_sdom)as integer)=1 and vr_mst_regu_eosf_val='OFF' and ((cast((vr_mst_regu_eosf_index)as integer)-1)>0) ) then
				
				vr_hr_aktif:=0;

			end if;

						/* RITME ALUR */
		loop --iterasi hari aktif + hari libur + ritme alur

						if(vr_kon_2 is null or vr_kon_2=0) then --view kondisi
						vr_temp_ritme:=vr_temp_ritme;
						elseif ((vr_kon_2 is not null  or vr_kon_2>0) and vr_hr_aktif=vr_kon_1-1 and vr_kon_2<>0.5) then
						vr_temp_ritme:=vr_temp_ritme-1;
						elseif (vr_hr_aktif=vr_kon_1-6 and vr_kon_2=0.5) then
						vr_temp_ritme:=vr_temp_ritme-1;
						end if;

					if(vr_temp_ritme=3) then --declare ritme pola
						vr_ritme:=vr_ritme_1;
						if(vr_hr_aktif=vr_kon_1-5 and vr_kon_2=0.5) then
							vr_ritme:=vr_ritme_1||'*';
						end if;
					elseif(vr_temp_ritme=2 ) then
						vr_ritme:=vr_ritme_2;
						if(vr_hr_aktif=vr_kon_1-5 and vr_kon_2=0.5) then
							vr_ritme:=vr_ritme_2||'*';
						end if;
					elseif(vr_temp_ritme=1 ) then
						vr_ritme:=vr_ritme_3;
						if(vr_hr_aktif=vr_kon_1-5 and vr_kon_2=0.5) then
							vr_ritme:=vr_ritme_3||'*';
						elseif (vr_ritme_3 is null)then
							vr_ritme:=vr_ritme_1;
							vr_temp_ritme=3;
						end if;
					elseif(vr_temp_ritme<1) then
						vr_temp_ritme:=3;
						vr_ritme:=vr_ritme_1;
						if(vr_hr_aktif=vr_kon_1-5 and vr_kon_2=0.5) then
							vr_ritme:=vr_ritme_1||'*';
						end if;	
					end if;
			
			--update sc_mst.regu set eor_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				if(vr_ritme_3 is null) then
					update sc_tmp.template_jadwal set eor_val=vr_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				else
					update sc_tmp.template_jadwal set eor_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;	
			if (cast((vr_sdom)as integer)=1 and vr_hr_aktif>0) then
				if ((select m01_1 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m01_1=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;
			elseif (cast((vr_sdom)as integer)=2 and vr_hr_aktif>0) then
				if ((select m01_2 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m01_2=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;
			elseif (cast((vr_sdom)as integer)=3 and vr_hr_aktif>0) then
				if ((select m01_3 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m01_3=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;
			elseif (cast((vr_sdom)as integer)=4 and vr_hr_aktif>0) then
				if ((select m01_4 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m01_4=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=5 and vr_hr_aktif>0) then
				if ((select m01_5 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m01_5=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=6 and vr_hr_aktif>0) then
				if ((select m01_6 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m01_6=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=7 and vr_hr_aktif>0) then
				if ((select m01_7 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m01_7=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=8 and vr_hr_aktif>0) then
				if ((select m02_8 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m02_8=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=9 and vr_hr_aktif>0) then
				if ((select m02_9 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m02_9=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=10 and vr_hr_aktif>0) then
				if ((select m02_10 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m02_10=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=11 and vr_hr_aktif>0) then
				if ((select m02_11 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m02_11=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=12 and vr_hr_aktif>0) then
				if ((select m02_12 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m02_12=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=13 and vr_hr_aktif>0) then
				if ((select m02_13 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m02_13=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=14 and vr_hr_aktif>0) then
				if ((select m02_14 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m02_14=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=15 and vr_hr_aktif>0) then
				if ((select m03_15 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m03_15=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=16 and vr_hr_aktif>0) then
				if ((select m03_16 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m03_16=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=17 and vr_hr_aktif>0) then
				if ((select m03_17 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m03_17=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=18 and vr_hr_aktif>0) then
				if ((select m03_18 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m03_18=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=19 and vr_hr_aktif>0) then
				if ((select m03_19 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m03_19=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=20 and vr_hr_aktif>0) then
				if ((select m03_20 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m03_20=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=21 and vr_hr_aktif>0) then
				if ((select m03_21 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m03_21=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=22 and vr_hr_aktif>0) then
				if ((select m04_22 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m04_22=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=23 and vr_hr_aktif>0) then
				if ((select m04_23 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m04_23=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=24 and vr_hr_aktif>0) then
				if ((select m04_24 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m04_24=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=25 and vr_hr_aktif>0) then
				if ((select m04_25 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m04_25=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=26 and vr_hr_aktif>0) then
				if ((select m04_26 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m04_26=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=27 and vr_hr_aktif>0) then
				if ((select m04_27 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m04_27=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=28 and vr_hr_aktif>0) then
				if ((select m04_28 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m04_28=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=29 and vr_hr_aktif>0) then
				if ((select m05_29 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m05_29=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=30 and vr_hr_aktif>0) then
				if ((select m05_30 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m05_30=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=31 and vr_hr_aktif>0) then
				if ((select m05_31 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m05_31=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=32 and vr_hr_aktif>0) then
				if ((select m05_32 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m05_32=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=33 and vr_hr_aktif>0) then
				if ((select m05_33 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m05_33=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=34 and vr_hr_aktif>0) then
				if ((select m05_34 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m05_34=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			elseif (cast((vr_sdom)as integer)=35 and vr_hr_aktif>0) then
				if ((select m05_35 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
				update sc_tmp.template_jadwal set m05_35=vr_ritme,eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
				--update sc_mst.regu set eosf_index=vr_hr_aktif,eosf_val=vr_temp_ritme where kd_opt=vr_kdopt and kdregu=vr_kdregu;
				end if;		
			end if;

				if( cast((vr_sdom)as integer)<>1) then
				vr_sdom:=cast((vr_sdom)as integer)+1;
				vr_hr_aktif:=vr_hr_aktif-1;
				elseif((vr_mst_regu_eosf_val='1' or vr_mst_regu_eosf_val='2' or vr_mst_regu_eosf_val='3' ) and cast((vr_sdom)as integer)=1 and (cast((vr_mst_regu_eosf_index)as integer)-1)<>0) then
				vr_sdom:=cast((vr_sdom)as integer)+1;
				vr_hr_aktif:=vr_hr_aktif-1;
				elseif((vr_mst_regu_eosf_val='OFF' and vr_mst_regu_eosf_index='1') and cast((vr_sdom)as integer)=1 and vr_hr_aktif=(select hr_aktif from sc_mst.setup_grjadwal where kd_opt=vr_kdopt)) then
				vr_sdom:=cast((vr_sdom)as integer)+1;
				vr_hr_aktif:=vr_hr_aktif-1;
				end if;
			
			if (vr_hr_aktif<=0) then --kondisi hari libur
				vr_temp_ritme:=vr_temp_ritme-1; --RITME -1
				
				vr_hr_libur:=hr_libur from sc_mst.setup_grjadwal where kd_opt=vr_kdopt; 
				if((cast((vr_sdom)as integer)=1) and (vr_mst_regu_eosf_val='OFF')) then
					vr_hr_libur:=cast((vr_mst_regu_eosf_index)as integer)-1; --hari libur
				end if;
				exit when cast((vr_sdom)as integer)>cast((vr_edom)as integer);
					loop --iterasi hari libur

					if (cast((vr_sdom)as integer)=1) then
						if ((select m01_1 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m01_1='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;
					elseif (cast((vr_sdom)as integer)=2) then
						if ((select m01_2 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m01_2='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;
					elseif (cast((vr_sdom)as integer)=3) then
						if ((select m01_3 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m01_3='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;
					elseif (cast((vr_sdom)as integer)=4) then
						if ((select m01_4 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m01_4='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=5) then
						if ((select m01_5 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m01_5='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=6) then
						if ((select m01_6 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m01_6='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=7) then
						if ((select m01_7 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m01_7='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=8) then
						if ((select m02_8 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m02_8='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=9) then
						if ((select m02_9 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m02_9='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=10) then
						if ((select m02_10 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m02_10='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=11) then
						if ((select m02_11 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m02_11='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=12) then
						if ((select m02_12 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m02_12='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=13) then
						if ((select m02_13 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m02_13='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=14) then
						if ((select m02_14 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m02_14='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=15) then
						if ((select m03_15 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m03_15='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=16) then
						if ((select m03_16 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m03_16='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=17) then
						if ((select m03_17 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m03_17='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=18) then
						if ((select m03_18 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m03_18='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=19) then
						if ((select m03_19 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m03_19='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=20) then
						if ((select m03_20 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m03_20='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=21) then
						if ((select m03_21 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m03_21='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=22) then
						if ((select m04_22 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m04_22='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=23) then
						if ((select m04_23 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m04_23='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=24) then
						if ((select m04_24 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m04_24='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=25) then
						if ((select m04_25 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m04_25='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=26) then
						if ((select m04_26 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m04_26='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=27) then
						if ((select m04_27 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m04_27='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=28) then
						
						if ((select m04_28 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m04_28='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=29) then
						if ((select m05_29 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m05_29='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=30) then
						if ((select m05_30 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m05_30='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=31) then
						if ((select m05_31 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m05_31='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=32) then
						if ((select m05_32 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m05_32='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=33) then
						if ((select m05_33 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m05_33='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=34) then
						if ((select m05_34 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m05_34='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					elseif (cast((vr_sdom)as integer)=35) then
						if ((select m05_35 from sc_tmp.template_jadwal where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt) is null) then
						update sc_tmp.template_jadwal set m05_35='OFF',eosf_index=vr_hr_libur,eosf_val='OFF' where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						--update sc_mst.regu set eosf_index=vr_hr_libur,eosf_val='OFF' where kd_opt=vr_kdopt and kdregu=vr_kdregu;
						end if;		
					end if;

					vr_sdom:=cast((vr_sdom)as integer)+1;	
					vr_hr_libur:=vr_hr_libur-1;
					exit when vr_hr_libur=0 or cast((vr_sdom)as integer)>cast((vr_edom)as integer);
				end loop;
 
				vr_sdom:=cast((vr_sdom)as integer)-1;
					
			end if;
			
			exit when vr_hr_aktif=0 or cast((vr_sdom)as integer)>cast((vr_edom)as integer); --end iterasi berdasar end day of month
		end loop;
		
		vr_sdom:=cast((vr_sdom)as integer)+1;
		exit when cast((vr_sdom)as integer)>cast((vr_edom)as integer);
	end loop;	--end loop iterasi tanggal


/*ITERASI PENGISIAN JAM KERJA PADA KOLOM REV*/

 FOR vr_inisial in select x.inisial from 
				(select tahun,bulan,kdregu,m01_1 as tgl,'01' as inisial,m01_1_rev as tgl_rev from sc_tmp.template_jadwal 
				union all
				select tahun,bulan,kdregu,m01_2 as tgl,'02' as inisial,m01_2_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m01_3 as tgl,'03' as inisial,m01_3_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m01_4 as tgl,'04' as inisial,m01_4_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m01_5 as tgl,'05' as inisial,m01_5_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m01_6 as tgl,'06' as inisial,m01_6_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m01_7 as tgl,'07' as inisial,m01_7_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m02_8 as tgl,'08' as inisial,m02_8_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m02_9 as tgl,'09' as inisial,m02_9_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m02_10 as tgl,'10' as inisial,m02_10_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m02_11 as tgl,'11' as inisial,m02_11_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m02_12 as tgl,'12' as inisial,m02_12_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m02_13 as tgl,'13' as inisial,m02_13_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m02_14 as tgl,'14' as inisial,m02_14_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m03_15 as tgl,'15' as inisial,m03_15_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m03_16 as tgl,'16' as inisial,m03_16_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m03_17 as tgl,'17' as inisial,m03_17_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m03_18 as tgl,'18' as inisial,m03_18_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m03_19 as tgl,'19' as inisial,m03_19_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m03_20 as tgl,'20' as inisial,m03_20_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m03_21 as tgl,'21' as inisial,m03_21_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m04_22 as tgl,'22' as inisial,m04_22_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m04_23 as tgl,'23' as inisial,m04_23_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m04_24 as tgl,'24' as inisial,m04_24_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m04_25 as tgl,'25' as inisial,m04_25_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m04_26 as tgl,'26' as inisial,m04_26_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m04_27 as tgl,'27' as inisial,m04_27_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m04_28 as tgl,'28' as inisial,m04_28_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m05_29 as tgl,'29' as inisial,m05_29_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m05_30 as tgl,'30' as inisial,m05_30_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m05_31 as tgl,'31' as inisial,m05_31_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m05_32 as tgl,'32' as inisial,m05_32_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m05_33 as tgl,'33' as inisial,m05_33_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m05_34 as tgl,'34' as inisial,m05_34_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m05_35 as tgl,'35' as inisial,m05_35_rev as tgl_rev from sc_tmp.template_jadwal
				) as x
				where x.tahun=vr_tahun_awal and x.bulan=vr_bulan_awal and x.kdregu=vr_kdregu and x.tgl is not null
LOOP	

				vr_jam_kerja:=trim(x.tgl) from 
				(select tahun,bulan,kdregu,m01_1 as tgl,'01' as inisial,m01_1_rev as tgl_rev from sc_tmp.template_jadwal 
				union all
				select tahun,bulan,kdregu,m01_2 as tgl,'02' as inisial,m01_2_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m01_3 as tgl,'03' as inisial,m01_3_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m01_4 as tgl,'04' as inisial,m01_4_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m01_5 as tgl,'05' as inisial,m01_5_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m01_6 as tgl,'06' as inisial,m01_6_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m01_7 as tgl,'07' as inisial,m01_7_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m02_8 as tgl,'08' as inisial,m02_8_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m02_9 as tgl,'09' as inisial,m02_9_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m02_10 as tgl,'10' as inisial,m02_10_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m02_11 as tgl,'11' as inisial,m02_11_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m02_12 as tgl,'12' as inisial,m02_12_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m02_13 as tgl,'13' as inisial,m02_13_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m02_14 as tgl,'14' as inisial,m02_14_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m03_15 as tgl,'15' as inisial,m03_15_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m03_16 as tgl,'16' as inisial,m03_16_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m03_17 as tgl,'17' as inisial,m03_17_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m03_18 as tgl,'18' as inisial,m03_18_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m03_19 as tgl,'19' as inisial,m03_19_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m03_20 as tgl,'20' as inisial,m03_20_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m03_21 as tgl,'21' as inisial,m03_21_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m04_22 as tgl,'22' as inisial,m04_22_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m04_23 as tgl,'23' as inisial,m04_23_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m04_24 as tgl,'24' as inisial,m04_24_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m04_25 as tgl,'25' as inisial,m04_25_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m04_26 as tgl,'26' as inisial,m04_26_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m04_27 as tgl,'27' as inisial,m04_27_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m04_28 as tgl,'28' as inisial,m04_28_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m05_29 as tgl,'29' as inisial,m05_29_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m05_30 as tgl,'30' as inisial,m05_30_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m05_31 as tgl,'31' as inisial,m05_31_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m05_32 as tgl,'32' as inisial,m05_32_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m05_33 as tgl,'33' as inisial,m05_33_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m05_34 as tgl,'34' as inisial,m05_34_rev as tgl_rev from sc_tmp.template_jadwal
				union all
				select tahun,bulan,kdregu,m05_35 as tgl,'35' as inisial,m05_35_rev as tgl_rev from sc_tmp.template_jadwal
				) as x
				where x.inisial=vr_inisial and x.tahun=vr_tahun_awal and x.bulan=vr_bulan_awal and x.kdregu=vr_kdregu and x.tgl is not null;
				vr_hari_libur:=count(tgl_libur) from sc_mst.libur where to_char(tgl_libur,'yyyy-mm-dd')=vr_tahun_awal||'-'||vr_bulan_awal||'-'||vr_inisial; 

			/* SELEKSI KATEGORI JAM KERJA BERDASARKAN REGU */
			vr_nama_hari:=to_char(cast((vr_tahun_awal||'-'||vr_bulan_awal||'-'||vr_inisial)as date),'dy');

			if(vr_jam_kerja='1' or vr_jam_kerja='1*') then --shift1
				if(vr_sf1_all is not null and vr_sf1_jumat is null and vr_sf1_sabtu is null) then
					vr_jam_kerja2=vr_sf1_all;
				elseif (vr_sf1_all is not null and vr_sf1_jumat is not null and vr_sf1_sabtu is null) then
					if(vr_nama_hari='fri') then
						vr_jam_kerja2=vr_sf1_jumat;
					else
						vr_jam_kerja2=vr_sf1_all;
					end if;
				elseif (vr_sf1_all is not null and vr_sf1_jumat is not null and vr_sf1_sabtu is  not null) then
					if(vr_nama_hari='fri') then
						vr_jam_kerja2=vr_sf1_jumat;
					elseif(vr_nama_hari='sat') then
						vr_jam_kerja2=vr_sf1_sabtu;	
					else
						vr_jam_kerja2=vr_sf1_all;
					end if;				
				else
					vr_jam_kerja2:=vr_jam_kerja;
				end if;
			elseif(vr_jam_kerja='2' or vr_jam_kerja='2*') then	--shift2
				if(vr_sf2_all is not null and vr_sf2_jumat is null and vr_sf2_sabtu is null) then
					vr_jam_kerja2=vr_sf2_all;
				elseif (vr_sf2_all is not null and vr_sf2_jumat is not null and vr_sf2_sabtu is null) then
					if(vr_nama_hari='fri') then
						vr_jam_kerja2=vr_sf2_jumat;
					else
						vr_jam_kerja2=vr_sf2_all;
					end if;
				elseif (vr_sf2_all is not null and vr_sf2_jumat is not null and vr_sf2_sabtu is  not null) then
					if(vr_nama_hari='fri') then
						vr_jam_kerja2=vr_sf2_jumat;
					elseif(vr_nama_hari='sat') then
						vr_jam_kerja2=vr_sf2_sabtu;	
					else
						vr_jam_kerja2=vr_sf2_all;
					end if;				
				else
					vr_jam_kerja2:=vr_jam_kerja;
				end if;
			elseif(vr_jam_kerja='3' or vr_jam_kerja='3*') then	--shift3
				if(vr_sf3_all is not null and vr_sf3_jumat is null and vr_sf3_sabtu is null) then
					vr_jam_kerja2=vr_sf3_all;
				elseif (vr_sf3_all is not null and vr_sf3_jumat is not null and vr_sf3_sabtu is null) then
					if(vr_nama_hari='fri') then
						vr_jam_kerja2=vr_sf3_jumat;
					else
						vr_jam_kerja2=vr_sf3_all;
					end if;
				elseif (vr_sf3_all is not null and vr_sf3_jumat is not null and vr_sf3_sabtu is  not null) then
					if(vr_nama_hari='fri') then
						vr_jam_kerja2=vr_sf3_jumat;
					elseif(vr_nama_hari='sat') then
						vr_jam_kerja2=vr_sf3_sabtu;	
					else
						vr_jam_kerja2=vr_sf3_all;
					end if;				
				else
					vr_jam_kerja2:=vr_jam_kerja;
				end if;

			else
			vr_jam_kerja2:='OFF';	
			end if;	

				if(vr_hari_libur=0) then
						if (vr_inisial='01') then
							update sc_tmp.template_jadwal set m01_1_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						elseif (vr_inisial='02') then
							update sc_tmp.template_jadwal set m01_2_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						elseif (vr_inisial='03') then
							update sc_tmp.template_jadwal set m01_3_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;
						elseif (vr_inisial='04') then
							update sc_tmp.template_jadwal set m01_4_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;	
						elseif (vr_inisial='05') then
							update sc_tmp.template_jadwal set m01_5_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;	
						elseif (vr_inisial='06') then
							update sc_tmp.template_jadwal set m01_6_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;	
						elseif (vr_inisial='07') then
							update sc_tmp.template_jadwal set m01_7_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;	
						elseif (vr_inisial='08') then
							update sc_tmp.template_jadwal set m02_8_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;		
						elseif (vr_inisial='09') then
							update sc_tmp.template_jadwal set m02_9_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;	
						elseif (vr_inisial='10') then
							update sc_tmp.template_jadwal set m02_10_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;	
						elseif (vr_inisial='11') then
							update sc_tmp.template_jadwal set m02_11_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;		
						elseif (vr_inisial='12') then
							update sc_tmp.template_jadwal set m02_12_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;	
						elseif (vr_inisial='13') then
							update sc_tmp.template_jadwal set m02_13_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;		
						elseif (vr_inisial='14') then
							update sc_tmp.template_jadwal set m02_14_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;	
						elseif (vr_inisial='15') then
							update sc_tmp.template_jadwal set m03_15_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;	
						elseif (vr_inisial='16') then
							update sc_tmp.template_jadwal set m03_16_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;		
						elseif (vr_inisial='17') then
							update sc_tmp.template_jadwal set m03_17_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;	
						elseif (vr_inisial='18') then
							update sc_tmp.template_jadwal set m03_18_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;	
						elseif (vr_inisial='19') then
							update sc_tmp.template_jadwal set m03_19_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;	
						elseif (vr_inisial='20') then
							update sc_tmp.template_jadwal set m03_20_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;		
						elseif (vr_inisial='21') then
							update sc_tmp.template_jadwal set m03_21_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;	
						elseif (vr_inisial='22') then
							update sc_tmp.template_jadwal set m04_22_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;	
						elseif (vr_inisial='23') then
							update sc_tmp.template_jadwal set m04_23_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;	
						elseif (vr_inisial='24') then
							update sc_tmp.template_jadwal set m04_24_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;		
						elseif (vr_inisial='25') then
							update sc_tmp.template_jadwal set m04_25_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;	
						elseif (vr_inisial='26') then
							update sc_tmp.template_jadwal set m04_26_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;	
						elseif (vr_inisial='27') then
							update sc_tmp.template_jadwal set m04_27_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;	
						elseif (vr_inisial='28') then
							update sc_tmp.template_jadwal set m04_28_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;		
						elseif (vr_inisial='29') then
							update sc_tmp.template_jadwal set m05_29_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;		
						elseif (vr_inisial='30') then
							update sc_tmp.template_jadwal set m05_30_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;		
						elseif (vr_inisial='31') then
							update sc_tmp.template_jadwal set m05_31_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;	
						elseif (vr_inisial='32') then
							update sc_tmp.template_jadwal set m05_32_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;		
						elseif (vr_inisial='33') then
							update sc_tmp.template_jadwal set m05_33_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;	
						elseif (vr_inisial='34') then
							update sc_tmp.template_jadwal set m05_34_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;		
						elseif (vr_inisial='35') then
							update sc_tmp.template_jadwal set m05_35_rev=vr_jam_kerja2 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdopt;	
						end if;
				end if;
		
		
	RETURN NEXT vr_inisial;			
END LOOP;	--end of isi template rev			

END;
$$;

alter function pr_gr_setupjadwal(char, char, char) owner to postgres;

