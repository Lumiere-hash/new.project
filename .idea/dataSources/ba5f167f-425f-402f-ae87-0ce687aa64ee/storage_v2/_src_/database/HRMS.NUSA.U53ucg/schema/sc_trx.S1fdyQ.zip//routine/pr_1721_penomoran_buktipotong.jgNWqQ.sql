create function pr_1721_penomoran_buktipotong(xnik character, nomor_urut integer, vr_nodok character, vr_periode_awal integer, vr_periode_akhir integer, vr_tahun character) returns numeric
    language plpgsql
as
$$
DECLARE 
vr_duit numeric(18,2):=0;
vr_nomor_pelaporan character(20);
vr_group_pg character(10);
BEGIN		

	/*
	delete from sc_mst.penomoran where userid=vr_nodok and dokumen='P1721'; 
	    insert into sc_mst.penomoran 
	    (userid,dokumen,nomor,errorid,partid,counterid,xno)
	    values(vr_nodok,'P1721',' ',0,' ',1,0);
	vr_nomor_pelaporan:=trim(coalesce(nomor,'')) from sc_mst.penomoran where userid=vr_nodok and dokumen='P1721';
       */
	vr_group_pg:=trim(grouppenggajian) from sc_mst.karyawan where nik=xnik;
	vr_duit:=0; --NOMOR PELAPORAN
	
		
	delete from sc_tmp.p1721_detail where no_urut=nomor_urut and nik=xnik and nodok=vr_nodok; 

	insert into sc_tmp.p1721_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir,nomor_pelaporan,grouppenggajian)
	select vr_nodok as nodok,xnik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,'PENOMORAN BUKTI POTONG' as keterangan,vr_duit as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,
	vr_periode_awal as periode_mulai,vr_periode_akhir as periode_akhir,vr_nodok as nomor_pelaporan,vr_group_pg as grouppenggajian  from sc_mst.detail_formula
	where no_urut=nomor_urut and kdrumus='P1721';
 
	
	RETURN vr_duit;	
END;
$$;

alter function pr_1721_penomoran_buktipotong(char, integer, char, integer, integer, char) owner to postgres;

