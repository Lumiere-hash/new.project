create function after_mapping_nik() returns trigger
    language plpgsql
as
$$
declare
     
   vr_gajipokok numeric(18,2);  
begin
	if (new.status='P' and old.status='I') then
		update sc_tmp.cek_lembur set nik=new.nik, nikmap=new.nikmap where nik=new.nikmap;
		update sc_tmp.cek_absen set nik=new.nik, nikmap=new.nikmap where nik=new.nikmap;
		update sc_tmp.cek_shift set nik=new.nik where nik=new.nikmap;
		update sc_tmp.cek_borong set nik=new.nik where nik=new.nikmap;
	elseif(new.status='C' and old.status='P') then
		update sc_tmp.cek_lembur set nik=new.nikmap, nikmap='' where nik=new.nik;
		update sc_tmp.cek_absen set nik=new.nikmap, nikmap='' where nik=new.nik;
		update sc_tmp.cek_shift set nik=new.nikmap where nik=new.nik;
		update sc_tmp.cek_borong set nik=new.nikmap where nik=new.nik;
	end if;	


return new;

end;
$$;

alter function after_mapping_nik() owner to postgres;

