create function pr_rekap_cutiblc(id character) returns void
    language plpgsql
as
$$
BEGIN		
	IF coalesce(id,'')<>'' THEN
		update sc_trx.cuti_blc a set sisacuti=b.balance
		from (select *,sum("in_cuti"-"out_cuti") over(partition by nik order by nik,tanggal,doctype,no_dokumen,doctype) as balance
		from sc_trx.cuti_blc) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen and a.nik=coalesce(id,'');
	ELSE
		update sc_trx.cuti_blc a set sisacuti=b.balance
		from (select *,sum("in_cuti"-"out_cuti") over(partition by nik order by nik,tanggal,no_dokumen,doctype) as balance
		from sc_trx.cuti_blc) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen and a.doctype=b.doctype;
	END IF;
	
	RETURN;	
END;
$$;

alter function pr_rekap_cutiblc(char) owner to postgres;

