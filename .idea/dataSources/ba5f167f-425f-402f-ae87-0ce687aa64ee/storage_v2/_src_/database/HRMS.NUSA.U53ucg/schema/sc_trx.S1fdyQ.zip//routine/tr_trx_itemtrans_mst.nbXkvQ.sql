create function tr_trx_itemtrans_mst() returns trigger
    language plpgsql
as
$$
DECLARE 
	--author by fiky: 12/10/2017
	--update by fiky: 12/10/2017
     vr_nomor char(15); 
     vr_cekprefix char(15);
     vr_nowprefix char(15);  
          vr_id_dtl numeric;
          vr_qtybbm numeric;
          vr_qtybbmkecil numeric;
     vr_kdgroup char(100);
     vr_kdsubgroup char(100);
     vr_stockcode char(100);
BEGIN		
	IF tg_op = 'INSERT' THEN
		--select * from sc_trx.itemtrans_mst where nodok is null
		/*IF NOT EXISTS(select * from sc_trx.stpbk_mst where nodok=new.nodok and nik=new.nik) THEN
			insert into sc_trx.stpbk_mst 
			(branch,nodok,nodokref,nik,loccode,status,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby)
			(select branch,nodok,nodokref,nik,loccode,status,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby
			from sc_trx.itemtrans_mst where nodok=new.nodok and nik=new.nik);
		END IF; */
	
		RETURN new;
	ELSEIF tg_op = 'UPDATE' THEN

		IF (OLD.STATUS='A' AND NEW.STATUS='E') THEN
	
			insert into sc_tmp.itemtrans_mst
			(branch,nodok,nodokref,loccode,loccode_destination,itemtrans_type,itemtrans_category,description,nodok_date,totalprice,inputdate,inputby,
			updatedate,updateby,approvaldate,approvalby,hangusdate,hangusby,canceldate,cancelby,nodoktmp,status)
			(select branch,new.updateby,nodokref,loccode,loccode_destination,itemtrans_type,itemtrans_category,description,nodok_date,totalprice,inputdate,inputby,
			updatedate,updateby,approvaldate,approvalby,hangusdate,hangusby,canceldate,cancelby,nodok,'E' as status from sc_trx.itemtrans_mst where nodok=new.nodok);


			insert into sc_tmp.itemtrans_dtl
			(branch,nodok,kdgroup,kdsubgroup,stockcode,id,nodokref,loccode,loccode_destination,itemtrans_type,itemtrans_category,qty,qtybbm,satkecil,
			description,qtyonhand,inputby,inputdate,qtyunitprice,qtytotalprice,nodoktmp,status,qty_tmp)
			(select branch,new.updateby,kdgroup,kdsubgroup,stockcode,id,nodokref,loccode,loccode_destination,itemtrans_type,itemtrans_category,coalesce(qty,0),coalesce(qtybbm,0),satkecil,
			description,qtyonhand,inputby,inputdate,qtyunitprice,qtytotalprice,nodok,'A' as status,qty from sc_trx.itemtrans_dtl where nodok=new.nodok);


			delete from sc_mst.trxerror where modul='ITEMTRANS';
			insert into sc_mst.trxerror
			(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
			(new.nodok,0,vr_nomor,'','ITEMTRANS');
	
		ELSEIF (OLD.STATUS='A' AND NEW.STATUS='C') THEN
				
			insert into sc_tmp.itemtrans_mst
			(branch,nodok,nodokref,loccode,loccode_destination,itemtrans_type,itemtrans_category,description,nodok_date,totalprice,inputdate,inputby,
			updatedate,updateby,approvaldate,approvalby,hangusdate,hangusby,canceldate,cancelby,nodoktmp,status)
			(select branch,new.cancelby,nodokref,loccode,loccode_destination,itemtrans_type,itemtrans_category,description,nodok_date,totalprice,inputdate,inputby,
			updatedate,updateby,approvaldate,approvalby,hangusdate,hangusby,canceldate,cancelby,nodok,'C' as status from sc_trx.itemtrans_mst where nodok=new.nodok);


			insert into sc_tmp.itemtrans_dtl
			(branch,nodok,kdgroup,kdsubgroup,stockcode,id,nodokref,loccode,loccode_destination,itemtrans_type,itemtrans_category,qty,qtybbm,satkecil,
			description,qtyonhand,inputby,inputdate,qtyunitprice,qtytotalprice,nodoktmp,status,qty_tmp)
			(select branch,new.cancelby,kdgroup,kdsubgroup,stockcode,id,nodokref,loccode,loccode_destination,itemtrans_type,itemtrans_category,coalesce(qty,0),coalesce(qtybbm,0),satkecil,
			description,qtyonhand,inputby,inputdate,qtyunitprice,qtytotalprice,nodok,'C' as status,qty from sc_trx.itemtrans_dtl where nodok=new.nodok);


			delete from sc_mst.trxerror where modul='ITEMTRANS';
			insert into sc_mst.trxerror
			(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
			(new.nodok,0,vr_nomor,'','ITEMTRANS');

		ELSEIF (OLD.STATUS='A' AND NEW.STATUS='A1') THEN

			insert into sc_tmp.itemtrans_mst
			(branch,nodok,nodokref,loccode,loccode_destination,itemtrans_type,itemtrans_category,description,nodok_date,totalprice,inputdate,inputby,
			updatedate,updateby,approvaldate,approvalby,hangusdate,hangusby,canceldate,cancelby,nodoktmp,status)
			(select branch,new.approvalby,nodokref,loccode,loccode_destination,itemtrans_type,itemtrans_category,description,nodok_date,totalprice,inputdate,inputby,
			updatedate,updateby,approvaldate,approvalby,hangusdate,hangusby,canceldate,cancelby,nodok,'A' as status from sc_trx.itemtrans_mst where nodok=new.nodok);


			insert into sc_tmp.itemtrans_dtl
			(branch,nodok,kdgroup,kdsubgroup,stockcode,id,nodokref,loccode,loccode_destination,itemtrans_type,itemtrans_category,qty,qtybbm,satkecil,
			description,qtyonhand,inputby,inputdate,qtyunitprice,qtytotalprice,nodoktmp,status,qty_tmp)
			(select branch,new.approvalby,kdgroup,kdsubgroup,stockcode,id,nodokref,loccode,loccode_destination,itemtrans_type,itemtrans_category,coalesce(qty,0),coalesce(qtybbm,0),satkecil,
			description,qtyonhand,inputby,inputdate,qtyunitprice,qtytotalprice,nodok,'A' as status,qty from sc_trx.itemtrans_dtl where nodok=new.nodok);


			delete from sc_mst.trxerror where modul='ITEMTRANS';
			insert into sc_mst.trxerror
			(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
			(new.nodok,0,vr_nomor,'','ITEMTRANS');

		ELSEIF (OLD.STATUS='P' AND NEW.STATUS='A') THEN
			/*UPDATE sc_trx.itemtrans_mst SET STATUS='A' WHERE
			NODOK=NEW.NODOKTMP AND NIK=NEW.NIK AND KDGROUP=NEW.KDGROUP AND KDSUBGROUP=NEW.KDSUBGROUP AND STOCKCODE=NEW.STOCKCODE;*/
		END IF;


		
		RETURN NEW;
	ELSEIF tg_op = 'DELETE' THEN

		RETURN old;	
	END IF;

	/*

select * from sc_mst.nomor
select * from sc_mst.penomoran
insert into sc_mst.nomor VALUES
('ITEMTRANS','',4,'TRG1706','',0,'66666','','201706','T')
--delete from sc_mst.nomor where dokumen='ITEMTRANS';
*/
END;
$$;

alter function tr_trx_itemtrans_mst() owner to postgres;

