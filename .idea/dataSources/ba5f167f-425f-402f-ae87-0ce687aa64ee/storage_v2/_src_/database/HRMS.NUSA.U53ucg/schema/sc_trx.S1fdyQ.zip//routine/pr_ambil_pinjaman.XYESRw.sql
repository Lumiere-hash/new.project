create function pr_ambil_pinjaman(vr_param text) returns text
    language plpgsql
as
$$
DECLARE
	/*
		author 		: Fiky Ashariza
		create date	: 2019/05/07
		update date	: 
		update case	: capture pinjaman
		param using	: select select sc_trx.pr_ambil_pinjaman('1115.184'||'|'||'1115.184'||'|'||'1115.184');
		using global	: select sc_trx.pr_ambil_pinjaman('1115.184'||'|'||''||'|'||'1115.184');
	*/
	
    vr_split text;	
    vrs_nama text;	
    vrs_nodok text;	
    vr_branch text :=coalesce(branch,'') from sc_mst.branch where cdefault='YES';
vr_parameter text :='';
	vr_nik char(30); vrs_nik char(30);	vrs_user char(30);vrs_nikmap char(30);
	vr_param1 text; vr_param2 text; vr_param3 text; vr_opsigaji text;
    	vq_karyawan text := 'select nik from sc_mst.karyawan where coalesce(statuskepegawaian,'''')!=''KO''';
    	vq_inqpinjaman text := 'select * from (
                                  select a.*,b.nmlengkap from sc_trx.payroll_pinjaman_inq a
                                  left outer join sc_mst.karyawan b on a.nik=b.nik) as x where nik is not null' ;
    	vq_txpinjaman text := 'select * from (
                                  select a.*,b.nmlengkap from sc_trx.payroll_pinjaman_mst a
                                  left outer join sc_mst.karyawan b on a.nik=b.nik) as x where nik is not null' ;
    	vr_rec record;
BEGIN

	vrs_nama:=trim(split_part(vr_param, '|', 3));
	vrs_nik:=trim(split_part(vr_param, '|', 2));
	vrs_nodok:=trim(split_part(vr_param, '|', 1));
	vr_param1 := ' and nik ='''||vrs_nik||'''';
	/* cek outstanding */
	--vr_param2 := ' and to_char(tgl_kerja,''YYYY-MM-DD'') between '''||vrs_tglawal||''' and '''||vrs_tglakhir||'''';
	vr_param3 := ' and status in (''P'',''F'')';
	
    	RAISE NOTICE 'Calling 1(%)', vrs_nik;
    IF (vrs_nik != '' ) then 
     vr_parameter:=vr_param1||vr_param3;
    else 
     vr_parameter:=vr_param3;
    end if;
    
    FOR vr_rec IN EXECUTE vq_txpinjaman||''||vr_parameter -- USING n 
    LOOP

	if not exists(select * from sc_trx.payroll_pinjaman_inq where docno=vr_rec.docno and nik=vr_rec.nik and docref=vrs_nodok) then
		--select * from sc_trx.payroll_pinjaman_mst
		insert into sc_trx.payroll_pinjaman_inq
		(nik,docno,tgl,docref,doctype,in_sld,out_sld,sld,status)
		(select nik,docno,to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp,vrs_nodok as docref,'OUT' as doctype,0,
		case when sisa <= npotong and sisa>0 then sisa
		else npotong end as npotong
		,0,'F' from sc_trx.payroll_pinjaman_mst where status!='C' and docno=vr_rec.docno);
	
	end if;
		
	RAISE NOTICE 'Under Loop(%)', vr_rec.docno||vr_rec.nik; 
    END LOOP;
    
    RETURN vr_rec.docno;
END;
$$;

alter function pr_ambil_pinjaman(text) owner to postgres;

