create function tr_insert_karyawan() returns trigger
    language plpgsql
as
$$
declare
    
begin
IF(new.callplan = 'f') THEN
/* INPUT KE REGU OPERATOR */
if not exists (select * from sc_mst.regu_opr where nik=new.nik and kdregu='NS') then
	insert into sc_mst.regu_opr (kdregu,nik,input_date,input_by) 
	values ('NS',new.nik,new.inputdate,new.inputby);
end if;

/* INPUT KE DTLJADWAL KERJA PER TANGGAL MASUKKERJA HINGGA AKHIR JADWAL KERJA COPY DRI DIREKTUR */
if not exists (select * from sc_trx.dtljadwalkerja where nik=new.nik) then
	insert into sc_trx.dtljadwalkerja (nik,tgl,kdjamkerja,kdregu,inputdate,inputby)
	select new.nik as nik,tgl,kdjamkerja,kdregu,inputdate,inputby from sc_trx.dtljadwalkerja 
	where nik in (select trim(nik) from sc_mst.karyawan where bag_dept='DI' and subbag_dept='DR' and jabatan='D2' limit 1) 
	and to_char(tgl,'yyyy-mm-dd')>=to_char(new.tglmasukkerja,'yyyy-mm-dd')
	order by tgl;
end if;

ELSE

if not exists (select * from sc_mst.regu_opr where nik=new.nik and kdregu='SL') then
	insert into sc_mst.regu_opr (kdregu,nik,input_date,input_by) 
	values ('SL',new.nik,new.inputdate,new.inputby);
end if;

/* INPUT KE DTLJADWAL KERJA PER TANGGAL MASUKKERJA HINGGA AKHIR JADWAL KERJA COPY DRI DIREKTUR */
if not exists (select * from sc_trx.dtljadwalkerja where nik=new.nik) then
	insert into sc_trx.dtljadwalkerja (nik,tgl,kdjamkerja,kdregu,inputdate,inputby)
	select new.nik as nik,tgl,kdjamkerja,kdregu,inputdate,inputby from sc_trx.dtljadwalkerja 
	where nik in (select trim(nik) from sc_mst.karyawan where jabatan='AE' and statuskepegawaian<>'KO' order by tglmasukkerja asc limit 1)
	and to_char(tgl,'yyyy-mm-dd')>=to_char(new.tglmasukkerja,'yyyy-mm-dd')
	order by tgl;
end if;
end if;

/*

delete from sc_mst.regu_opr where nik='111111'

select tglmasukkerja from sc_mst.karyawan
select * from sc_mst.karyawan where nmlengkap like '%GRADLE%' "1216.006    "
select * from sc_mst.regu_opr where nik='1216.006'
select * from sc_trx.dtljadwalkerja where nik='1216.006'


insert into sc_mst.karyawan (branch,nik,nmlengkap,callname,jk,neglahir,provlahir,kotalahir,tgllahir,kd_agama,stswn,stsfisik,ketfisik,noktp,ktp_seumurhdp,ktpdikeluarkan,tgldikeluarkan,status_pernikahan,gol_darah,
					negktp,provktp,kotaktp,kecktp,kelktp,alamatktp,negtinggal,provtinggal,kotatinggal,kectinggal,keltinggal,alamattinggal,nohp1,nohp2,npwp,tglnpwp,bag_dept,subbag_dept,jabatan,lvl_jabatan,
					grade_golongan,nik_atasan,nik_atasan2,status_ptkp,besaranptkp,tglmasukkerja,tglkeluarkerja,masakerja,statuskepegawaian,kdcabang,branchaktif,grouppenggajian,gajipokok,gajibpjs,namabank,
					namapemilikrekening,norek,tjshift,idabsen,email,bolehcuti,sisacuti,inputdate,inputby,updatedate,updateby,image,idmesin,cardnumber,status,tgl_ktp,costcenter,tj_tetap,gajitetap,gajinaker,
					tjlembur,tjborong) 
select branch,'111111' as nik,
			'SABAR YA BOS' as nmlengkap,callname,jk,neglahir,provlahir,kotalahir,tgllahir,kd_agama,stswn,stsfisik,ketfisik,noktp,ktp_seumurhdp,ktpdikeluarkan,tgldikeluarkan,status_pernikahan,gol_darah,
			negktp,provktp,kotaktp,kecktp,kelktp,alamatktp,negtinggal,provtinggal,kotatinggal,kectinggal,keltinggal,alamattinggal,nohp1,nohp2,npwp,tglnpwp,bag_dept,subbag_dept,jabatan,lvl_jabatan,
			grade_golongan,nik_atasan,nik_atasan2,status_ptkp,besaranptkp,tglmasukkerja,tglkeluarkerja,masakerja,statuskepegawaian,kdcabang,branchaktif,grouppenggajian,gajipokok,gajibpjs,namabank,
			namapemilikrekening,norek,tjshift,idabsen,email,bolehcuti,sisacuti,inputdate,inputby,updatedate,updateby,image,idmesin,cardnumber,status,tgl_ktp,costcenter,tj_tetap,gajitetap,gajinaker,
			tjlembur,tjborong
  from sc_mst.karyawan where nmlengkap like '%FIKY A%'
*/
	
	
	return new;
		
end;
$$;

alter function tr_insert_karyawan() owner to postgres;

