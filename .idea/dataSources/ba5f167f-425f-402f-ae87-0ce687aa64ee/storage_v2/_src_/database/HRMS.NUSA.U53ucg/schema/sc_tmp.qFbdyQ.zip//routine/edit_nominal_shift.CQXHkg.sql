create function edit_nominal_shift() returns timestamp without time zone
    language plpgsql
as
$$
DECLARE
    vr_tgl timestamp without time zone;	
    vr_nik char(12);
    vr_nodok char(16);
   vr_upah numeric(18,2);
   vr_shift numeric(18,2);
   vr_ptg numeric(18,2);
   vr_pendapatan numeric(18,2);
   vr_totalupah numeric(18,2);
   vr_totalpendapatan numeric(18,2);
    
    
    
BEGIN
	--vr_keluarkerja:=to_char(tglakhirfix,'YYYYMM');
      --FOR listNik IN select distinct nik from sc_trx.dtljadwalkerja where to_char(tgl,'YYYYMM')=$1 and case when xnik<>'' then nik=xnik else nik<>'' end order by nik
    FOR vr_nik,vr_nodok IN select distinct nik,nodok from sc_trx.payroll_master where right(nodok,4)='1608' ORDER BY nik
			

			
		
    LOOP
	    
	
	    --FOR vr_urut IN select no_urut from sc_mst.detail_formula where kdrumus='PR' order by no_urut asc 
	    --LOOP
		
		     --insert into dumy(nik) values (vr_nik);

		   select coalesce(sum(nominal),0) into vr_shift from sc_tmp.cek_shift  where nik=vr_nik;

		   select total_upah into vr_upah from sc_trx.payroll_master  where nik=vr_nik and nodok=vr_nodok;
		   select sum(nominal) into vr_pendapatan from sc_trx.payroll_detail where nik=vr_nik and nodok=vr_nodok and aksi='A';
		   vr_totalupah=vr_upah+vr_shift;
		   vr_totalpendapatan=vr_pendapatan;
		   
		   if (vr_upah<>0.00) then
		   update sc_trx.payroll_master set total_pendapatan=vr_totalpendapatan  
		   where nik=vr_nik and nodok=vr_nodok; 
		   --update sc_trx.payroll_detail set nominal=vr_shift where nik=vr_nik and nodok=vr_nodok and no_urut=10;
		   --update sc_trx.payroll_detail set nominal=vr_shift where nik=vr_nik and nodok=vr_nodok and no_urut=10;    
		   end if;	
		   
	    
	    
    END LOOP;
    
    RETURN vr_tgl;
END;
$$;

alter function edit_nominal_shift() owner to postgres;

