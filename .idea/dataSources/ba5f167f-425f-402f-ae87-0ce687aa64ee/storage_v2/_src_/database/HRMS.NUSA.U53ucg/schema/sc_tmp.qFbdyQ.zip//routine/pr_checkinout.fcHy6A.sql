create function pr_checkinout() returns trigger
    language plpgsql
as
$$
declare
     
     vr_badgenumber character(12);
    
     
begin
--vr_status:=trim(coalesce(status,'')) from sc_tmp.cuti where branch=new.branch and kddokumen=new.kddokumen for update;
--vr_nomor
	if (length(trim(cast(new.badgenumber as character varying))) >=1) and (length(trim(cast(new.badgenumber as character varying))) <=8) then

	    select repeat('0',4-length(left(trim(cast(new.badgenumber as character varying)),length(trim(cast(new.badgenumber as character varying)))-4)))||
	    left(trim(cast(new.badgenumber as character varying)),length(trim(cast(new.badgenumber as character varying)))-4)||
	    right(trim(cast(new.badgenumber as character varying)),4) into vr_badgenumber;

	    update sc_tmp.checkinout set badgenumber=vr_badgenumber where userid=new.userid;
		
	end if;

return new;

end;
$$;

alter function pr_checkinout() owner to postgres;

