create function pr_reportabsen(vr_bulan character, vr_tahun character) returns SETOF void
    language plpgsql
as
$$
DECLARE vr_maxtgl date;
DECLARE vr_nik character(12);
DECLARE vr_cekdouble integer;
DECLARE vr_kdregu character(12);
DECLARE vr_blnthn_now character(12);
DECLARE vr_day_now character(12);
DECLARE vr_day_transready character(12);
BEGIN

--select * from sc_trx.listlinkjadwalcuti where to_char(tgl,'mm')='06' and nik=vr_nik order by tgl
--select * from sc_trx.listjadwalkerja
 vr_day_transready=to_char(max(tgl),'dd') from sc_trx.transready;
					delete from sc_trx.report_absen where bulan=vr_bulan and tahun=vr_tahun; 
 FOR vr_nik in select nik from sc_mst.karyawan where tglkeluarkerja is null
		LOOP
			vr_maxtgl:=max(tgl) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'mm')=vr_bulan and to_char(tgl,'yyyy')=vr_tahun;
			vr_kdregu:=max(trim(kdregu)) from sc_trx.dtljadwalkerja where nik=vr_nik and tgl=vr_maxtgl;
			vr_cekdouble=count(*) from sc_trx.report_absen where nik=vr_nik and bulan=vr_bulan and tahun=vr_tahun;
			vr_blnthn_now=to_char(now(),'yyyy-mm');

			vr_day_now=trim(to_char(now(),'dd'));
			--vr_day_select=trim(to_char(cast(to_char(now(),vr_tahun||vr_bulan||'01')as date),'dd'));
		
				IF vr_blnthn_now=(vr_tahun||'-'||vr_bulan) THEN
					--insert into sc_trx.report_absen
					--select trim(nik) as nik,trim(kdregu) as kdregu,trim(to_char(tgl,'mm'))as bulan,trim(to_char(tgl,'yyyy'))as tahun,
					insert into sc_trx.report_absen (nik,kdregu,bulan,tahun)(select trim(nik) as nik,trim(kdregu) as kdregu,trim(to_char(tgl,'mm'))as bulan,trim(to_char(tgl,'yyyy'))as tahun from sc_trx.listlinkjadwalcuti where nik=vr_nik and tgl=vr_maxtgl);
						--if(vr_day_transready>=(select trim(to_char(cast(to_char(now(),vr_tahun||vr_bulan||'01')as date),'dd')))) then command smentara

						if(vr_day_transready>='01') then 						
							update sc_trx.report_absen set tgl1=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-01'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl1='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;

						if(vr_day_transready>='02') then 
							update sc_trx.report_absen set tgl2=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-02'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl2='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;

						if(vr_day_transready>='03') then 
							update sc_trx.report_absen set tgl3=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-03'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl3='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;

						if(vr_day_transready>='04') then 
							update sc_trx.report_absen set tgl4=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-04'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl4='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;

						if(vr_day_transready>='05') then 
							update sc_trx.report_absen set tgl5=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-05'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl5='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;

						if(vr_day_transready>='06') then 
							update sc_trx.report_absen set tgl6=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-06'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl6='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;

						if(vr_day_transready>='07') then 
							update sc_trx.report_absen set tgl7=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-07'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl7='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;

						if(vr_day_transready>='08') then 
							update sc_trx.report_absen set tgl8=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-08'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl8='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;

						if(vr_day_transready>='09') then 
							update sc_trx.report_absen set tgl9=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-09'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl9='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;

						if(vr_day_transready>='10') then 
							update sc_trx.report_absen set tgl10=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-10'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl10='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;

						if(vr_day_transready>='11') then 
							update sc_trx.report_absen set tgl11=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-11'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl11='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;

						if(vr_day_transready>='12') then 
							update sc_trx.report_absen set tgl12=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-12'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl12='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;

						if(vr_day_transready>='13') then 
							update sc_trx.report_absen set tgl13=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-13'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl13='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;

						if(vr_day_transready>='14') then 
							update sc_trx.report_absen set tgl14=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-14'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl14='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;

						if(vr_day_transready>='15') then 
							update sc_trx.report_absen set tgl15=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-15'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl15='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;

						if(vr_day_transready>='16') then 
							update sc_trx.report_absen set tgl16=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-16'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl16='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;

						if(vr_day_transready>='17') then 
							update sc_trx.report_absen set tgl17=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-17'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl17='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;

						if(vr_day_transready>='18') then 
							update sc_trx.report_absen set tgl18=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-18'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl18='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;

						if(vr_day_transready>='19') then 
							update sc_trx.report_absen set tgl19=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-19'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl19='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;
						if(vr_day_transready>='20') then 
							update sc_trx.report_absen set tgl20=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-20'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl20='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;

						if(vr_day_transready>='21') then 
							update sc_trx.report_absen set tgl21=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-21'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl21='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;

						if(vr_day_transready>='22') then 
							update sc_trx.report_absen set tgl22=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-22'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl22='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;

						if(vr_day_transready>='23') then 
							update sc_trx.report_absen set tgl23=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-23'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl23='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;


						if(vr_day_transready>='24') then 
							update sc_trx.report_absen set tgl24=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-24'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl24='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;


						if(vr_day_transready>='25') then 
							update sc_trx.report_absen set tgl25=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-25'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl25='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;


						if(vr_day_transready>='26') then 
							update sc_trx.report_absen set tgl26=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-26'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl26='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;


						if(vr_day_transready>='27') then 
							update sc_trx.report_absen set tgl27=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-27'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl27='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;


						if(vr_day_transready>='28') then 
							update sc_trx.report_absen set tgl28=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-28'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl28='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;

						if(vr_day_transready>='29') then 
							update sc_trx.report_absen set tgl29=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-29'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl29='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;


						if(vr_day_transready>='30') then 
							update sc_trx.report_absen set tgl30=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-30'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl30='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;

						
						if(vr_day_transready>='31') then 
							update sc_trx.report_absen set tgl31=coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-31'),'OFF')
							where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun;
						else 
							update sc_trx.report_absen set tgl31='OFF' where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
						end if;

						
					update sc_trx.report_absen set shift2=coalesce((select count(kdpokok) from sc_trx.listlinkjadwalcuti where kdpokok='SF2' and nik=vr_nik and to_char(tgl,'yyyy-mm')=vr_tahun||'-'||vr_bulan and (to_char(tgl,'yyyy-mm-dd') between vr_tahun||'-'||vr_bulan||'-'||'01' and vr_tahun||'-'||vr_bulan||'-'||vr_day_transready)),'0') where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
					update sc_trx.report_absen set shift3=coalesce((select count(kdpokok) from sc_trx.listlinkjadwalcuti where kdpokok='SF3' and nik=vr_nik and to_char(tgl,'yyyy-mm')=vr_tahun||'-'||vr_bulan and (to_char(tgl,'yyyy-mm-dd') between vr_tahun||'-'||vr_bulan||'-'||'01' and vr_tahun||'-'||vr_bulan||'-'||vr_day_transready)),'0') where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
					update sc_trx.report_absen set alpha=coalesce((select count(kdpokok) from sc_trx.listlinkjadwalcuti where kdpokok='AL' and nik=vr_nik and to_char(tgl,'yyyy-mm')=vr_tahun||'-'||vr_bulan and (to_char(tgl,'yyyy-mm-dd') between vr_tahun||'-'||vr_bulan||'-'||'01' and vr_tahun||'-'||vr_bulan||'-'||vr_day_transready)),'0') where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
					update sc_trx.report_absen set cuti=coalesce((select count(kdpokok) from sc_trx.listlinkjadwalcuti where kdpokok='CT' OR kdpokok='CB' and nik=vr_nik and to_char(tgl,'yyyy-mm')=vr_tahun||'-'||vr_bulan and (to_char(tgl,'yyyy-mm-dd') between vr_tahun||'-'||vr_bulan||'-'||'01' and vr_tahun||'-'||vr_bulan||'-'||vr_day_transready)),'0') where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
					update sc_trx.report_absen set ctkhusus=coalesce((select count(kdpokok) from sc_trx.listlinkjadwalcuti where kdpokok='CK' and nik=vr_nik and to_char(tgl,'yyyy-mm')=vr_tahun||'-'||vr_bulan and (to_char(tgl,'yyyy-mm-dd') between vr_tahun||'-'||vr_bulan||'-'||'01' and vr_tahun||'-'||vr_bulan||'-'||vr_day_transready)),'0') where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
					update sc_trx.report_absen set dinas=coalesce((select count(kdpokok) from sc_trx.listlinkjadwalcuti where kdpokok='DN' and nik=vr_nik and to_char(tgl,'yyyy-mm')=vr_tahun||'-'||vr_bulan and (to_char(tgl,'yyyy-mm-dd') between vr_tahun||'-'||vr_bulan||'-'||'01' and vr_tahun||'-'||vr_bulan||'-'||vr_day_transready)),'0') where nik=vr_nik and kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun; 
					

					ELSE
					
					insert into sc_trx.report_absen
					select trim(nik) as nik,trim(kdregu) as kdregu,trim(to_char(tgl,'mm'))as bulan,trim(to_char(tgl,'yyyy'))as tahun,
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-01'),'OFF')as tgl1, 
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-02'),'OFF')as tgl2, 
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-03'),'OFF')as tgl3, 
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-04'),'OFF')as tgl4, 
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-05'),'OFF')as tgl5, 
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-06'),'OFF')as tgl6, 
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-07'),'OFF')as tgl7, 
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-08'),'OFF')as tgl8, 
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-09'),'OFF')as tgl9, 
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-10'),'OFF')as tgl10, 
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-11'),'OFF')as tgl11, 
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-12'),'OFF')as tgl12, 
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-13'),'OFF')as tgl13, 
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-14'),'OFF')as tgl14, 
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-15'),'OFF')as tgl15, 
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-16'),'OFF')as tgl16, 
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-17'),'OFF')as tgl17, 
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-18'),'OFF')as tgl18, 
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-19'),'OFF')as tgl19, 
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-20'),'OFF')as tgl20, 
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-21'),'OFF')as tgl21, 
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-22'),'OFF')as tgl22,
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-23'),'OFF')as tgl23, 
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-24'),'OFF')as tgl24, 
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-25'),'OFF')as tgl25, 
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-26'),'OFF')as tgl26, 
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-27'),'OFF')as tgl27, 
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-28'),'OFF')as tgl28, 
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-29'),'OFF')as tgl29, 
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-30'),'OFF')as tgl30, 
					coalesce((select trim(kdpokok) from sc_trx.listlinkjadwalcuti where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-31'),'OFF')as tgl31,
					coalesce((select count(kdpokok) from sc_trx.listlinkjadwalcuti where kdpokok='SF2' and nik=vr_nik and to_char(tgl,'yyyy-mm')=vr_tahun||'-'||vr_bulan),'0') as shift2,
					coalesce((select count(kdpokok) from sc_trx.listlinkjadwalcuti where kdpokok='SF3' and nik=vr_nik and to_char(tgl,'yyyy-mm')=vr_tahun||'-'||vr_bulan),'0') as shift3,
					coalesce((select count(kdpokok) from sc_trx.listlinkjadwalcuti where kdpokok='AL' and nik=vr_nik and to_char(tgl,'yyyy-mm')=vr_tahun||'-'||vr_bulan),'0') as alpha,
					coalesce((select count(kdpokok) from sc_trx.listlinkjadwalcuti where (kdpokok='CT' or kdpokok='CB') and nik=vr_nik and to_char(tgl,'yyyy-mm')=vr_tahun||'-'||vr_bulan),'0') as cuti,
					coalesce((select count(kdpokok) from sc_trx.listlinkjadwalcuti where kdpokok='CK' and nik=vr_nik and to_char(tgl,'yyyy-mm')=vr_tahun||'-'||vr_bulan),'0') as ctkhusus,
					coalesce((select count(kdpokok) from sc_trx.listlinkjadwalcuti where kdpokok='DN' and nik=vr_nik and to_char(tgl,'yyyy-mm')=vr_tahun||'-'||vr_bulan),'0') as dinas
					
					from sc_trx.listlinkjadwalcuti where nik=vr_nik and tgl=vr_maxtgl;

					END IF;


	RETURN NEXT vr_nik;	
END LOOP;		
	RETURN;
	
END;
$$;

alter function pr_reportabsen(char, char) owner to postgres;

