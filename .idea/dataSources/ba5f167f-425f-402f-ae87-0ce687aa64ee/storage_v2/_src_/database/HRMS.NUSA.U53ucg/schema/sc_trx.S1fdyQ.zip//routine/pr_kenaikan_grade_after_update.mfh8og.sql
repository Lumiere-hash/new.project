create function pr_kenaikan_grade_after_update() returns trigger
    language plpgsql
as
$$
declare
     
     --vr_nomor char(30);
     --vr_status char(10);
     
begin

--select old.status;
if (new.status='F')and(old.status='A') then 
	--vr_status:=new.status;
	--echo 'vr_status';
	--raise notice 'xxx';
	update sc_mst.karyawan set grade_golongan=new.kdgrade,grouppenggajian=new.kdgroup_pg,gajipokok=new.gaji_pokok,gajibpjs=new.gaji_bpjs where nik=new.nik; 
	update sc_trx.kenaikan_grade set status='P' where nodok=new.nodok;
end if;
return new;

end;
$$;

alter function pr_kenaikan_grade_after_update() owner to postgres;

