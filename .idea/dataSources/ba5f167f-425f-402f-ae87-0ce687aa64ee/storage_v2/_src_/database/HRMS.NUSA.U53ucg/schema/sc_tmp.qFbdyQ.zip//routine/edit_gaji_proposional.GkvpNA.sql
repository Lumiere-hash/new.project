create function edit_gaji_proposional() returns timestamp without time zone
    language plpgsql
as
$$
DECLARE
    vr_tgl timestamp without time zone;	
    vr_nik char(12);
    vr_nodok char(16);
   vr_upah numeric(18,2);
   vr_ptg numeric(18,2);
   vr_gaji numeric(18,2);
   vr_pendapatan numeric(18,2);
   vr_totalupah numeric(18,2);
   vr_totalpendapatan numeric(18,2);
    
    
    
BEGIN
	--vr_keluarkerja:=to_char(tglakhirfix,'YYYYMM');
      --FOR listNik IN select distinct nik from sc_trx.dtljadwalkerja where to_char(tgl,'YYYYMM')=$1 and case when xnik<>'' then nik=xnik else nik<>'' end order by nik
    FOR vr_nik IN select nik from sc_mst.karyawan 
			where tglmasukkerja='2016-09-13' and statuskepegawaian<>'KO'
			order by nmlengkap
			

			
		
    LOOP
	    
	
	    --FOR vr_urut IN select no_urut from sc_mst.detail_formula where kdrumus='PR' order by no_urut asc 
	    --LOOP
		
		     --insert into dumy(nik) values (vr_nik);

		  
			select gajipokok into vr_upah from sc_mst.karyawan 
			where tglmasukkerja='2016-09-13' and statuskepegawaian<>'KO'
			order by nmlengkap;

			vr_gaji=(vr_upah/25)*16;
			update sc_tmp.payroll_detail set nominal=vr_gaji 
			where nik=vr_nik and no_urut=1;

		  
	    
	    
    END LOOP;
    
    RETURN vr_tgl;
END;
$$;

alter function edit_gaji_proposional() owner to postgres;

