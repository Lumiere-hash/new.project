create function msubsupplier() returns trigger
    language plpgsql
as
$$
DECLARE 
	--author by fiky: 12/08/2017
	--update by fiky: 12/10/2017
	vr_nomor character(20);
	vr_lastdoc numeric;
BEGIN		
/* NOTE:
BPB	:	BUKTI PENERIMAAN BARANG:
SO	:	SALES ORDER:
DO	:	DELIVERY ORDER:
PBK	:	PERMINTAAN BARANG KELUAR:
BBK	:	BUKTI BARANG KELUAR:
*/

		--UPDATE SC_MST.STKGDW SET ONHAND='200' WHERE loccode='SBYMRG' and stockcode='PEN000002';
	IF tg_op = 'INSERT' THEN

			/*
			select * from sc_mst.nomor
			select * from sc_mst.penomoran
			insert into sc_mst.nomor (dokumen,part,count3,prefix,docno,cekclose)
			values ('M_SUBSUPLIER','',4,'',5,'F'); */
			vr_lastdoc:=case 
			when max((right(trim(kdsubsupplier),4))) is null or max((right(trim(kdsubsupplier),4)))='' then '0'
			else max((right(trim(kdsubsupplier),4))) end lastdoc
			from sc_mst.msubsupplier
			where kdsupplier=new.kdsupplier;
			
			update sc_mst.nomor set docno=vr_lastdoc where dokumen='M_SUBSUPLIER';
				
			delete from sc_mst.penomoran where userid=new.inputby and dokumen='M_SUBSUPLIER';	
			
			    insert into sc_mst.penomoran 
			    (userid,dokumen,nomor,errorid,partid,counterid,xno)
			    values(new.inputby,'M_SUBSUPLIER',' ',0,' ',1,0);

				vr_nomor:=trim(coalesce(nomor,'')) from sc_mst.penomoran where userid=new.inputby and dokumen='M_SUBSUPLIER';
				--select * from sc_mst.msubsupplier
				/*update  sc_mst.msubsupplier a set id=a1.urutnya,kdsubsupplier=
				case 
				when length(a1.urutnya::char)=1 then a1.kdsupplier||'.'||'000'||a1.urutnya
				when length(a1.urutnya::char)=2 then a1.kdsupplier||'.'||'00'||a1.urutnya
				when length(a1.urutnya::char)=3 then a1.kdsupplier||'.'||'0'||a1.urutnya
				when length(a1.urutnya::char)=4 then a1.kdsupplier||'.'||a1.urutnya end 
				
				from (select a1.*,row_number() over(partition by kdsupplier order by inputdate asc) as urutnya
				from sc_mst.msubsupplier  a1) a1
				where a.inputdate=a1.inputdate and  a.kdsupplier=a1.kdsupplier and a.inputdate=new.inputdate;
				*/

				update sc_mst.msubsupplier set kdsubsupplier=kdsupplier||'.'||vr_nomor
				where kdsupplier=new.kdsupplier and nmsubsupplier=new.nmsubsupplier and inputdate=new.inputdate and inputby=new.inputby;
			--alter table sc_mst.msubsupplier add column id integer;
				
		RETURN new;
	ELSEIF tg_op = 'UPDATE' THEN

		
		RETURN NEW;
	ELSEIF tg_op = 'DELETE' THEN
				/*update  sc_mst.msubsupplier a set id=a1.urutnya,kdsubsupplier=
				case 
				when length(a1.urutnya::char)=1 then a1.kdsupplier||'.'||'000'||a1.urutnya
				when length(a1.urutnya::char)=2 then a1.kdsupplier||'.'||'00'||a1.urutnya
				when length(a1.urutnya::char)=3 then a1.kdsupplier||'.'||'0'||a1.urutnya
				when length(a1.urutnya::char)=4 then a1.kdsupplier||'.'||a1.urutnya end 
				
				from (select a1.*,row_number() over(partition by kdsupplier order by inputdate asc) as urutnya
				from sc_mst.msubsupplier  a1) a1
				where a.id=a1.id and a.inputdate>=a1.inputdate and  a.kdsupplier=a1.kdsupplier; */
		RETURN old;	
	END IF;
	
END;
$$;

alter function msubsupplier() owner to postgres;

