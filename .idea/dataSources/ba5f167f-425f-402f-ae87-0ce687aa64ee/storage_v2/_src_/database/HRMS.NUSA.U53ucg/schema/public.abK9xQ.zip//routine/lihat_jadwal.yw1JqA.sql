create function lihat_jadwal(periode character, dokno character, xnik character) returns timestamp without time zone
    language plpgsql
as
$$
DECLARE
    listNik RECORD;
    listJadwal RECORD;
    vr_tgl timestamp;
    vr_sisacuti integer;
    vr_stsptg char(3);
    vr_jenis character;
    vr_dokcuti character(12);
    vr_xpot boolean;
    vr_gaji numeric(18,2);
    vr_hari integer;
    vr_patokan numeric(18,2);
    vr_sisabaru integer;
     vr_tglawal integer;
    vr_tglblcawal date;
    vr_tglblcakhir character;
    vr_tglakhir integer;
    vr_periode character;
    vr_tglan date;
    vr_tglanakhir date;
    vr_tglawalfix date;
    vr_tglakhirfix date;
    
BEGIN

    select value3 into vr_hari from sc_mst.option where kdoption='E';
    select value3 into vr_tglawal from sc_mst.option where kdoption='STPC1' and trim(nmoption)='SETUP CLOSING AWAL';
    select value3 into vr_tglakhir from sc_mst.option where kdoption='STPC2' and trim(nmoption)='SETUP CLOSING AKHIR';
    
	
	
	select cast('01-'||substring(periode,1,2)||'-'||substring(periode,3,4) as date) into vr_tglblcawal;
	
	select cast((vr_tglblcawal - interval '1 month') as date) into vr_tglan;

	select cast(to_char(vr_tglan,'YYYY-MM')||'-'||vr_tglawal as date) into vr_tglawalfix;

	
	select cast(vr_tglblcawal as date) into vr_tglanakhir;
	select cast(to_char(vr_tglanakhir,'YYYY-MM')||'-'||vr_tglakhir as date) into vr_tglakhirfix;

	--insert into dumy(tgl) values (vr_tglakhirfix);
	
     
   --FOR listNik IN select distinct nik from sc_trx.dtljadwalkerja where to_char(tgl,'YYYYMM')=$1 and case when xnik<>'' then nik=xnik else nik<>'' end order by nik
    FOR listNik IN select distinct nik from sc_trx.dtljadwalkerja where (to_char(tgl,'YYYY-MM-DD') between to_char(vr_tglawalfix,'YYYY-MM-DD')  and to_char(vr_tglakhirfix,'YYYY-MM-DD')) and case when xnik<>'' then nik=xnik else nik<>'' end order by nik
    LOOP
	    select gajipokok into vr_gaji from sc_mst.karyawan where nik=listNik.nik;

	    vr_patokan := vr_gaji/vr_hari;
	    
	   --insert into dumy(tgl) values (vr_tglawalfix);
	    FOR listJadwal IN select tgl from sc_trx.dtljadwalkerja where nik=listNik.nik and to_char(tgl,'YYYY-MM-DD') between to_char(vr_tglawalfix,'YYYY-MM-DD')  and to_char(vr_tglakhirfix,'YYYY-MM-DD')order by tgl
	    LOOP
		
		
		      --insert into dumy(jumlah,tgl) values (listNik.nik,listJadwal.tgl);
                      select tpcuti,trim(nodok),trim(status_ptg) into vr_jenis,vr_dokcuti,vr_stsptg from sc_trx.cuti_karyawan where nik=listNik.nik and to_char(tgl_mulai,'YYYYMMDD')>=to_char(listJadwal.tgl,'YYYYMMDD') and to_char(tgl_selesai,'YYYYMMDD')<=to_char(listJadwal.tgl,'YYYYMMDD');
                      
		      IF (coalesce(vr_dokcuti,'')<>'' and vr_stsptg='A1')  THEN --cuti biasa
		        update sc_tmp.potongan_absen set flag_cuti='NO',cuti_nominal=0 where nodok=dokno and nik=listNik.nik and tgl_kerja=listJadwal.tgl;
		           --insert into dumy(tgl,status) values (listJadwal.tgl,vr_dokcuti);
		        
		      ELSEIF (coalesce(vr_dokcuti,'')<>'' and vr_stsptg<>'A1') THEN --cuti biasa   	
			update sc_tmp.potongan_absen set flag_cuti='YES',cuti_nominal=vr_patokan where nodok=dokno and nik=listNik.nik and tgl_kerja=listJadwal.tgl;

		      ELSEIF (coalesce(vr_dokcuti,'')='') THEN --tidak ada dokumen
		      update sc_tmp.potongan_absen set flag_cuti='YES',cuti_nominal=vr_patokan where nodok=dokno and nik=listNik.nik and tgl_kerja=listJadwal.tgl;	

		   		           		           
                      END IF;
                   
                      
		       
		--tgl 2 
		--tgl 3
		--tgl 4
		--tgl 5
	    END LOOP;
	    
    END LOOP;
    
    RETURN vr_tgl;
END;
$$;

alter function lihat_jadwal(char, char, char) owner to postgres;

