create function tr_pdca_dtl() returns trigger
    language plpgsql
as
$$
declare
--created by Fiky ::18/07/2017
     vr_nomor char(12); 
     vr_cekprefix char(4);
     vr_nowprefix char(4);
begin    

	IF TG_OP ='INSERT' THEN 
			
			--select * from sc_tmp.pdca_mst
			--select * from sc_tmp.pdca_dtl
			--delete from sc_tmp.pdca_dtl where nomor in ('7','8','9')
			/*
			
-- Constraint: sc_tmp.pdca_dtl_pkey
-- ALTER TABLE sc_tmp.pdca_dtl DROP CONSTRAINT pdca_dtl_pkey;
ALTER TABLE sc_tmp.pdca_dtl
  ADD CONSTRAINT pdca_dtl_pkey PRIMARY KEY(nik, docno, nomor, doctype, docdate);

  
INSERT INTO "sc_tmp"."pdca_dtl" ("nik", "docno", "nomor", "doctype", "docref", "docdate", "docpage", "revision", "planperiod", "descplan", "idbu", "qtytime", "do_c", "percentage", "remark", "status", "inputdate", "inputby") 
VALUES ('1115.184', '1115.184', 0, 'ISD', '', '18-12-2017', '', '', '201712', 'TEST PLAN', 'NJRM', '12:10', '12:15', '4', 'TEST', 'I', '2017-12-19 23:49:47', '1115.184 ')
			*/
			IF (NEW.STATUS NOT IN ('E1','R1','A1','O1')) THEN
				update  sc_tmp.pdca_dtl a set nomor=a1.urutnya,planperiod=to_char(a1.docdate,'yyyymm')
				from (select a1.*,row_number() over(partition by docno order by nik,docno,doctype,inputdate,descplan,idbu,qtytime) as urutnya
				from sc_tmp.pdca_dtl a1) a1
				where a.nik=a1.nik and a.docno=a1.docno and a.doctype=a1.doctype and a.inputdate=a1.inputdate and a.nomor=a1.nomor and a.descplan=a1.descplan
				and a.idbu=a1.idbu and a.qtytime=a1.qtytime
				and a.docno=new.docno  and a.nomor>=new.nomor;
			
			/* update ke master pdca*/
				update sc_tmp.pdca_mst set 
				ttlpercent=(select sum(coalesce(percentage,0)) from sc_tmp.pdca_dtl where docno=new.docno and status not in ('C','D')),
				ttlplan=(select count(*) from sc_tmp.pdca_dtl where docno=new.docno and status not in ('C','D')),
				status=''
				where docno=new.docno;
			END IF;
				update sc_tmp.pdca_dtl set  planperiod=to_char(docdate,'yyyymm'),status='E' where docno=new.docno and status='E1';
				update sc_tmp.pdca_dtl set  planperiod=to_char(docdate,'yyyymm'),status='A' where docno=new.docno and status='R1';
				update sc_tmp.pdca_dtl set  planperiod=to_char(docdate,'yyyymm'),status='R' where docno=new.docno and status='O1';

				--select to_char(docdate,'yyyymm'),planperiod from sc_tmp.pdca_dtl
	RETURN NEW;
	ELSEIF TG_OP ='UPDATE' THEN
			/* NO RESOURCE UPDATE */
		if (new.status='' and old.status<>'') then
			update sc_tmp.pdca_mst set 
			ttlpercent=(select sum(coalesce(percentage,0)) from sc_tmp.pdca_dtl where docno=new.docno and status not in ('C','D')),
			ttlplan=(select count(*) from sc_tmp.pdca_dtl where docno=new.docno and status not in ('C','D')),
			status=''
			where docno=new.docno;

			update sc_tmp.pdca_dtl set status=old.status,planperiod=to_char(docdate,'yyyymm') where docno=new.docno and nomor=new.nomor;
			update sc_tmp.pdca_dtl set status='R',planperiod=to_char(docdate,'yyyymm') where docno=new.docno and nomor=new.nomor and realisasidate is not null;
			
			if (old.status='E') then
			--select * from sc_his.pdca_log_dtl_activity
				vr_nomor:='PDCA'||to_char(new.docdate,'YYYYMM');
				insert into sc_his.pdca_log_dtl_activity
				(nik,docno,nomor,doctype,docref,docdate,docpage,revision,planperiod,descplan,idbu,qtytime,do_c,percentage,remark,status,
				old_idbu,old_descplan,old_qtytime,old_do_c,old_percentage,old_remark,updateby,updatedate,ipaddress,browser)
				(select nik,vr_nomor,nomor,doctype,docref,docdate,docpage,revision,planperiod,descplan,idbu,qtytime,do_c,percentage,remark,status,
				old.idbu,old.descplan,old.qtytime,old.do_c,old.percentage,old.remark,new.docno,to_char(now(),'yyyy-mm-dd hh24:mi:ss')::date,'' as ipaddress,'' as browser from sc_tmp.pdca_dtl where nomor=new.nomor and docno=new.docno and docdate=new.docdate and doctype=new.doctype and nik=new.nik);
			END IF;	
		elseif (new.status='B' and old.status='R') then /* STATUS BELUM TERSELESAIKAN */
			update sc_tmp.pdca_mst set 
			ttlpercent=(select sum(coalesce(percentage,0)) from sc_tmp.pdca_dtl where docno=new.docno and status not in ('C','D')), /* BELUM TERSELESAIKAN PERSEN KOSONG*/
			ttlplan=(select count(*) from sc_tmp.pdca_dtl where docno=new.docno and status not in ('C','D')),
			status=''
			where docno=new.docno;
		elseif (new.status='R' and old.status='B') then
			update sc_tmp.pdca_mst set 
			ttlpercent=(select sum(coalesce(percentage,0)) from sc_tmp.pdca_dtl where docno=new.docno and status not in ('C','D')),
			ttlplan=(select count(*) from sc_tmp.pdca_dtl where docno=new.docno and status not in ('C','D')),
			status=''
			where docno=new.docno;
		elseif (new.status='R' and old.status='O') then
			update sc_tmp.pdca_mst set 
			ttlpercent=(select sum(coalesce(percentage,0)) from sc_tmp.pdca_dtl where docno=new.docno and status not in ('C','D')),
			ttlplan=(select count(*) from sc_tmp.pdca_dtl where docno=new.docno and status not in ('C','D')),
			status=''
			where docno=new.docno;	
		elseif (new.status='O' and old.status='R') then /* STATUS REALISASI KE CHECKING */
			update sc_tmp.pdca_mst set 
			ttlpercent=(select sum(coalesce(percentage,0)) from sc_tmp.pdca_dtl where docno=new.docno and status not in ('C','D')), /* BELUM TERSELESAIKAN PERSEN KOSONG*/
			ttlplan=(select count(*) from sc_tmp.pdca_dtl where docno=new.docno and status not in ('C','D')),
			status=''
			where docno=new.docno;	
		end if;
	
	RETURN NEW;
	ELSEIF TG_OP ='DELETE' THEN

			
			/* update ke master pdca*/
			update sc_tmp.pdca_mst set 
			ttlpercent=(select sum(coalesce(percentage,0)) from sc_tmp.pdca_dtl where docno=old.docno and status not in ('C','D')),
			ttlplan=(select count(*) from sc_tmp.pdca_dtl where docno=old.docno and status not in ('C','D')),
			status=''
			where docno=old.docno;

			update  sc_tmp.pdca_dtl a set nomor=a1.urutnya,planperiod=to_char(a1.docdate,'yyyymm')
			from (select a1.*,row_number() over(partition by docno order by nik,docno,doctype,inputdate,descplan,idbu,qtytime) as urutnya
			from sc_tmp.pdca_dtl a1) a1
			where a.nik=a1.nik and a.docno=a1.docno and a.doctype=a1.doctype and a.inputdate=a1.inputdate and a.nomor=a1.nomor and a.descplan=a1.descplan
			and a.idbu=a1.idbu and a.qtytime=a1.qtytime
			and a.docno=old.docno and a.nomor>=old.nomor ;
	
	RETURN OLD;
	END IF;
    
    
    return new;
        
end;
$$;

alter function tr_pdca_dtl() owner to postgres;

