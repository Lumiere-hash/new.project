create function tr_trx_stpbk_mst() returns trigger
    language plpgsql
as
$$
DECLARE 
	--author by fiky: 12/08/2017
	--update by fiky: 12/08/2017
     vr_nomor char(12); 
     vr_cekprefix char(4);
     vr_nowprefix char(4);  
BEGIN		
	IF tg_op = 'INSERT' THEN

		RETURN new;
	ELSEIF tg_op = 'UPDATE' THEN

		
		IF (new.status='P' and old.status='A') THEN
			--update sc_trx.stpbk_dtl set status='P' where nodok=new.nodok;
		ELSEIF (new.status='E' and old.status='A') THEN
			if not exists(select * from sc_tmp.stpbk_mst where nodoktmp=new.nodok) then
				insert into sc_tmp.stpbk_mst 
				(branch,nodok,nodokref,nik,loccode,status,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodoktmp,tgldok)
				(select branch,new.updateby,nodokref,nik,loccode,'E',keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodok,tgldok
				from sc_trx.stpbk_mst where nodok=new.nodok and nik=new.nik);
				
				insert into sc_tmp.stpbk_dtl 
				(branch,nodok,nik,kdgroup,kdsubgroup,stockcode,loccode,desc_barang,qtypbk,qtybbk,qtyonhand, status,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodokref,nodoktmp,id)
				(select branch,new.updateby,nik,kdgroup,kdsubgroup,stockcode,loccode,desc_barang,qtypbk,qtybbk,qtyonhand,'E' as status,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodokref,nodok,id
				from sc_trx.stpbk_dtl where nodok=new.nodok and nik=new.nik);
			end if;
		ELSEIF (new.status='A' and old.status='A') THEN /* TARIKAN APPROVAL KE TEMPORARY */
			--SELECT * FROM sc_mst.trxtype
			if not exists(select * from sc_tmp.stpbk_mst where nodoktmp=new.nodok) then
				insert into sc_tmp.stpbk_mst 
				(branch,nodok,nodokref,nik,loccode,status,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodoktmp,tgldok)
				(select branch,new.approvalby,nodokref,nik,loccode,'A',keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodok,tgldok
				from sc_trx.stpbk_mst where nodok=new.nodok and nik=new.nik);
				
				insert into sc_tmp.stpbk_dtl 
				(branch,nodok,nik,kdgroup,kdsubgroup,stockcode,loccode,desc_barang,qtypbk,qtybbk,qtyonhand,status,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodokref,nodoktmp,id)
				(select branch,new.approvalby,nik,kdgroup,kdsubgroup,stockcode,loccode,desc_barang,qtypbk,qtybbk,qtyonhand,status,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodokref,nodok,id
				from sc_trx.stpbk_dtl where nodok=new.nodok and nik=new.nik);
			end if;
			----select * from sc_trx.stpbk_dtl;
			
		ELSEIF (new.status='C' and old.status='P') THEN
			update sc_trx.stpbk_dtl set status='C' where nodok=new.nodok;
		ELSEIF (new.status='H' and old.status in ('P','S')) THEN --HANGUS PERMINTAAN 
			if not exists(select * from sc_tmp.stpbk_mst where nodoktmp=new.nodok and nodok=new.approvalby) then
				insert into sc_tmp.stpbk_mst 
				(branch,nodok,nodokref,nik,loccode,status,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodoktmp,tgldok)
				(select branch,new.approvalby,nodokref,nik,loccode,'H',keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodok,tgldok
				from sc_trx.stpbk_mst where nodok=new.nodok and nik=new.nik);
				
				insert into sc_tmp.stpbk_dtl 
				(branch,nodok,nik,kdgroup,kdsubgroup,stockcode,loccode,desc_barang,qtypbk,qtybbk,qtyonhand,status,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodokref,nodoktmp,id)
				(select branch,new.approvalby,nik,kdgroup,kdsubgroup,stockcode,loccode,desc_barang,qtypbk,qtybbk,qtyonhand,status,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodokref,nodok,id
				from sc_trx.stpbk_dtl where nodok=new.nodok and nik=new.nik);
			end if;
		ELSEIF (new.status='C' and old.status='A') THEN
			if not exists(select * from sc_tmp.stpbk_mst where nodoktmp=new.nodok) then
				insert into sc_tmp.stpbk_mst 
				(branch,nodok,nodokref,nik,loccode,status,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodoktmp,tgldok)
				(select branch,new.updateby,nodokref,nik,loccode,'C',keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodok,tgldok
				from sc_trx.stpbk_mst where nodok=new.nodok and nik=new.nik);
				
				insert into sc_tmp.stpbk_dtl 
				(branch,nodok,nik,kdgroup,kdsubgroup,stockcode,loccode,desc_barang,qtypbk,qtybbk,qtyonhand,status,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodokref,nodoktmp,id)
				(select branch,new.updateby,nik,kdgroup,kdsubgroup,stockcode,loccode,desc_barang,qtypbk,qtybbk,qtyonhand,status,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodokref,nodok,id
				from sc_trx.stpbk_dtl where nodok=new.nodok and nik=new.nik);
			end if;
		END IF; 
		RETURN NEW;
	ELSEIF tg_op = 'DELETE' THEN

		RETURN old;	
	END IF;
	
END;
$$;

alter function tr_trx_stpbk_mst() owner to postgres;

