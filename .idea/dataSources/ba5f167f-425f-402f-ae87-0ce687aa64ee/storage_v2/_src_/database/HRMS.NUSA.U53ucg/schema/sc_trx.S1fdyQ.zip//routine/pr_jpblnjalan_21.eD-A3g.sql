create function pr_jpblnjalan_21(id character, nomor integer, userid character, periode integer) returns numeric
    language plpgsql
as
$$
DECLARE 
--vr_duit numeric(18,2):=0;
vr_pendapatan1 numeric(18,2):=0;
vr_pendapatan2 numeric(18,2):=0;
vr_duit numeric(18,2):=0;
vr_periodesebelum integer;
BEGIN		

	vr_periodesebelum=periode-1;

	
	select coalesce(sum(nominal),0) into vr_pendapatan1 from sc_trx.p21_detail where nik=id and periode_mulai between 1 and periode and no_urut='15';
	select sum(nominal) into vr_pendapatan2 from sc_tmp.p21_detail where nik=id and periode_mulai between 1 and periode and no_urut='15';
		
	--select sum(nominal) into vr_pendapatan2 from sc_tmp.p21_detail where nik=id and periode_mulai=periode and no_urut='22';	

	if (periode<1) then 
	vr_duit=0;
	else vr_duit=vr_pendapatan1+vr_pendapatan2;
	end if;
	
	delete from sc_tmp.p21_detail where nodok=userid and nik=id and no_urut=nomor and periode_mulai=periode;

	insert into sc_tmp.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select userid as nodok,id as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_duit as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,
	periode as periode_mulai,periode as periode_akhir from sc_mst.detail_formula
	where no_urut=nomor and kdrumus='P21';
	
	RETURN vr_duit;	
END;
$$;

alter function pr_jpblnjalan_21(char, integer, char, integer) owner to postgres;

