create function tr_archives_mst() returns trigger
    language plpgsql
as
$$
declare
--created by Fiky ::18/05/2018
     vr_nomor char(12); 
     vr_lastdoc numeric; 
     vr_cekprefix char(4);
     vr_nowprefix char(4);
begin    

	IF TG_OP ='INSERT' THEN 

	RETURN NEW;
	ELSEIF TG_OP ='UPDATE' THEN
			
			/* NO RESOURCE UPDATE 
			select * from sc_mst.nomor	
			select * from sc_mst.penomoran	
			select * from sc_his.archives_mst
			select * from sc_mst.mbarang
			insert into sc_mst.nomor
			(dokumen,part,count3,prefix,sufix,docno,userid,modul,periode,cekclose)
			values
			('ARSIP_DOC','',4,'AC1808','',1,'FIKY','','201808','F');
			*/
		if (new.status='F' and old.status='I') then
			delete from sc_mst.penomoran where userid=new.docno;
			delete from sc_mst.trxerror where userid=new.docno;  

			vr_lastdoc:= case 
			when max((right(trim(docno),4))) is null or max((right(trim(docno),4)))='' then '0'::numeric
			else max((right(trim(docno),4)))::numeric end lastdoc
			from sc_his.archives_mst
			where to_char(docdate,'yyyymm')=to_char(new.docdate,'yyyymm');

			update sc_mst.nomor set  prefix='AC'||to_char(new.docdate,'YYMM') ,docno=vr_lastdoc where dokumen='ARSIP_DOC';

			insert into sc_mst.penomoran 
			(userid,dokumen,nomor,errorid,partid,counterid,xno)
			values(new.docno,'ARSIP_DOC',' ',0,' ',1,0);
			vr_nomor:=trim(coalesce(nomor,'')) from sc_mst.penomoran where userid=new.docno and dokumen='ARSIP_DOC';
		
			insert into sc_his.archives_mst
			(docno,docdate,docref,archives_id,archives_number,archives_exp,old_archives_number,old_archives_exp,namapengurus,
			contactpengurus,ttlvalue,description,status,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodoktmp,att_name,att_dir)
			(select vr_nomor,docdate,docref,archives_id,archives_number,archives_exp,old_archives_number,old_archives_exp,namapengurus,
			contactpengurus,ttlvalue,description,'A' as status,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodoktmp,att_name,att_dir from sc_tmp.archives_mst where docno=new.docno);

			delete from sc_tmp.archives_mst where docno=new.docno;
		elseif (new.status='F' and old.status='E') then
			delete from sc_his.archives_mst where docno=trim(new.nodoktmp);
			
			insert into sc_his.archives_mst
			(docno,docdate,docref,archives_id,archives_number,archives_exp,old_archives_number,old_archives_exp,namapengurus,
			contactpengurus,ttlvalue,description,status,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodoktmp,att_name,att_dir)
			(select new.nodoktmp,docdate,docref,archives_id,archives_number,archives_exp,old_archives_number,old_archives_exp,namapengurus,
			contactpengurus,ttlvalue,description,'A' as status,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodoktmp,att_name,att_dir from sc_tmp.archives_mst where docno=new.docno);

			delete from sc_tmp.archives_mst where docno=new.docno;
		elseif (new.status='F' and old.status='A') then
			delete from sc_his.archives_mst where docno=new.nodoktmp;
			
			insert into sc_his.archives_mst
			(docno,docdate,docref,archives_id,archives_number,archives_exp,old_archives_number,old_archives_exp,namapengurus,
			contactpengurus,ttlvalue,description,status,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodoktmp,att_name,att_dir)
			(select new.nodoktmp,docdate,docref,archives_id,archives_number,archives_exp,old_archives_number,old_archives_exp,namapengurus,
			contactpengurus,ttlvalue,description,'P' as status,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodoktmp,att_name,att_dir from sc_tmp.archives_mst where docno=new.docno);
			--select * from sc_mst.archives
			update sc_mst.archives set 
			archives_id=new.archives_number,
			archives_number=new.archives_number,
			archives_exp=new.archives_exp,
			old_archives_number=new.old_archives_number,
			old_archives_exp=new.old_archives_exp,
			namapengurus=new.namapengurus,
			contactpengurus=new.contactpengurus,
			ttlvalue=new.ttlvalue
			where docno=new.archives_id;
			
			
			delete from sc_tmp.archives_mst where docno=new.docno;
		elseif (new.status='F' and old.status='C') then
			delete from sc_his.archives_mst where docno=new.nodoktmp;
			
			insert into sc_his.archives_mst
			(docno,docdate,docref,archives_id,archives_number,archives_exp,old_archives_number,old_archives_exp,namapengurus,
			contactpengurus,ttlvalue,description,status,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodoktmp,att_name,att_dir)
			(select new.nodoktmp,docdate,docref,archives_id,archives_number,archives_exp,old_archives_number,old_archives_exp,namapengurus,
			contactpengurus,ttlvalue,description,'C' as status,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodoktmp,att_name,att_dir from sc_tmp.archives_mst where docno=new.docno);
			delete from sc_tmp.archives_mst where docno=new.docno;			
		end if;
	
			
	RETURN NEW;
	END IF;
    
    
    return new;
        
end;
$$;

alter function tr_archives_mst() owner to postgres;

