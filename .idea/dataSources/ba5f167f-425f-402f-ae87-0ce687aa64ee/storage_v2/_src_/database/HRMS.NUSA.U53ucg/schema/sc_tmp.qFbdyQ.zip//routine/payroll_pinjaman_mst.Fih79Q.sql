create function payroll_pinjaman_mst() returns trigger
    language plpgsql
as
$$
declare
     vr_pinjaman character(25);
     vr_nomor char(12); 
     vr_cekprefix char(4);
     vr_nowprefix char(4);

begin

		IF (TG_OP='INSERT') THEN 
			if not exists(select * from sc_mst.nomor where dokumen='P_PINJAMAN') then
					insert into sc_mst.nomor 
					(dokumen,count3,prefix,docno,userid,periode,cekclose,part)
					values
					('P_PINJAMAN',4,'PKRD1901',0,'66666','201901','T','');
			end if;
			
			delete from sc_mst.penomoran where userid=new.docno;
			delete from sc_mst.trxerror where userid=new.docno;  

			select trim(split_part(trim(prefix),'PKRD',2)) as cekprefix into vr_cekprefix from sc_mst.nomor where dokumen='P_PINJAMAN';
			select to_char(tgl,'YYMM') as cekbulan into vr_nowprefix  from sc_tmp.payroll_pinjaman_mst where docno=new.docno ;
			if(vr_nowprefix<>vr_cekprefix) then 
				update sc_mst.nomor set prefix='PKRD'||vr_nowprefix,docno=0 where dokumen='P_PINJAMAN';
			end if;
			insert into sc_mst.penomoran 
			(userid,dokumen,nomor,errorid,partid,counterid,xno)
			values(new.docno,'P_PINJAMAN',' ',0,' ',1,0);
			vr_nomor:=trim(coalesce(nomor,'')) from sc_mst.penomoran where userid=new.docno;

			insert into sc_trx.payroll_pinjaman_mst 
			( branch,nik,docno,tgl,nominal,sisa,tenor,npotong,status,description,inputby,inputdate,last_docref,last_pay)
			(select branch,nik,vr_nomor,tgl,nominal,sisa,tenor,npotong,'I' as status,description,inputby,inputdate,last_docref,last_pay from sc_tmp.payroll_pinjaman_mst  where docno=new.docno);
			
			delete  from sc_tmp.payroll_pinjaman_mst where docno=new.docno;
			return new;
		ELSEIF (TG_OP='UPDATE') THEN
			return new;
		END IF;	
			
return new;

end;
$$;

alter function payroll_pinjaman_mst() owner to postgres;

