create function tr_tmp_ajustment_mst() returns trigger
    language plpgsql
as
$$
DECLARE 
	--author by fiky: 12/08/2017
	--update by fiky: 16/10/2017
     vr_nomor char(12); 
     vr_cekprefix char(10);
     vr_nowprefix char(10);  
     vr_qtypbk numeric;  
     vr_qtybbk numeric;  
     vr_qtyonhand numeric;  

BEGIN		
	IF tg_op = 'INSERT' THEN
		RETURN new;
	ELSEIF tg_op = 'UPDATE' THEN
		IF (new.status='F' and old.status='I') THEN
/*

select * from sc_mst.nomor
select * from sc_mst.penomoran
insert into sc_mst.nomor VALUES
('AJ_ATK','',4,'AJS170618','',0,'66666','','201706','T')
--delete from sc_mst.nomor where dokumen='AJ_ATK';
*/

		delete from sc_mst.penomoran where userid=new.nodok;
		delete from sc_mst.trxerror where userid=new.nodok;    
		select trim(split_part(trim(prefix),'AJS',2))as cekprefix into vr_cekprefix from sc_mst.nomor where dokumen='AJ_ATK';
		--select to_char(now(),'YYMM') as cekbulan into vr_nowprefix;
		select to_char(podate,'YYMM') as cekbulaninto into  vr_nowprefix from sc_tmp.po_mst where nodok=new.nodok;
		
		if(vr_nowprefix<>vr_cekprefix) then 
			update sc_mst.nomor set prefix='AJS'||vr_nowprefix,docno=0 where dokumen='AJ_ATK';
		end if;
		insert into sc_mst.penomoran 
		(userid,dokumen,nomor,errorid,partid,counterid,xno)
		values(new.nodok,'AJ_ATK',' ',0,' ',1,0);
		vr_nomor:=trim(coalesce(nomor,'')) from sc_mst.penomoran where userid=new.nodok;

				
		insert into sc_trx.ajustment_mst
			(branch,nodok,nodokref,loccode,loccode_destination,ajustment_type,ajustment_category,description,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,
			hangusdate,hangusby,canceldate,cancelby,nodoktmp,status,ajustment_date,totalprice)
			(select branch,vr_nomor,nodokref,loccode,loccode_destination,ajustment_type,ajustment_category,description,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,
			hangusdate,hangusby,canceldate,cancelby,nodoktmp,'A' as status,ajustment_date,totalprice from sc_tmp.ajustment_mst where nodok=new.nodok);		


		insert into sc_trx.ajustment_dtl
			(branch,nodok,nodokref,kdgroup,kdsubgroup,stockcode,loccode,loccode_destination,ajustment_type,ajustment_category,qty,satkecil,description,nodoktmp,status,
			id,qtyonhand,inputby,inputdate,qtyunitprice,qtytotalprice)
			(select branch,vr_nomor,nodokref,kdgroup,kdsubgroup,stockcode,loccode,loccode_destination,ajustment_type,ajustment_category,qty,satkecil,description,nodoktmp,'A' as status,
			id,qtyonhand,inputby,inputdate,qtyunitprice,qtytotalprice from sc_tmp.ajustment_dtl where nodok=new.nodok);		


		delete from sc_tmp.ajustment_mst where nodok=new.nodok;
		delete from sc_tmp.ajustment_dtl where nodok=new.nodok;

	
		END IF;
	
		RETURN new;
	ELSEIF tg_op = 'DELETE' THEN


		RETURN old;	
	END IF;
	
END;
$$;

alter function tr_tmp_ajustment_mst() owner to postgres;

