create function pr_updbpjs() returns trigger
    language plpgsql
as
$$
declare
vr_status_tanggungan char(1);
begin
--select * from sc_trx.riwayat_keluarga where nik=new.nik and no_urut=new.no_urut;
vr_status_tanggungan:=trim(status_tanggungan) from sc_trx.riwayat_keluarga where nik=new.nik and no_urut=new.no_urut;
update sc_trx.riwayat_keluarga set 
kode_bpjs=NULL,kodekomponen=NULL,id_bpjs=NULL, kodefaskes=NULL, kodefaskes2=NULL, kelas=NULL,tgl_berlaku=NULL, keterangan=NULL 
where nik=new.nik and no_urut=new.no_urut and vr_status_tanggungan='F';
    return new;
        
end;
$$;

alter function pr_updbpjs() owner to postgres;

