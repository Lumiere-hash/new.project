create function pr_exceljadwalregu(vr_bulan character, vr_tahun character) returns SETOF void
    language plpgsql
as
$$
DECLARE vr_maxtgl date;
DECLARE vr_kdregu character(12);
BEGIN
/* AUTHOR : FIKY 21-09-2016 */
	delete from sc_trx.exceljadwalregu where bulan=vr_bulan and tahun=vr_tahun; 
 FOR vr_kdregu in select kdregu from sc_mst.regu where kdregu in (select kdregu from sc_trx.jadwalkerja)
		LOOP

			vr_maxtgl:=max(tgl) from sc_trx.jadwalkerja where kdregu=vr_kdregu and to_char(tgl,'mm')=vr_bulan and to_char(tgl,'yyyy')=vr_tahun;

				insert into sc_trx.exceljadwalregu 
				select trim(kdregu),trim(to_char(tgl,'mm'))as bulan,trim(to_char(tgl,'yyyy'))as tahun,
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-01'),'OFF')as tgl1, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-02'),'OFF')as tgl2, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-03'),'OFF')as tgl3, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-04'),'OFF')as tgl4, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-05'),'OFF')as tgl5, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-06'),'OFF')as tgl6, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-07'),'OFF')as tgl7, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-08'),'OFF')as tgl8, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-09'),'OFF')as tgl9, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-10'),'OFF')as tgl10, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-11'),'OFF')as tgl11, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-12'),'OFF')as tgl12, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-13'),'OFF')as tgl13, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-14'),'OFF')as tgl14, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-15'),'OFF')as tgl15, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-16'),'OFF')as tgl16, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-17'),'OFF')as tgl17, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-18'),'OFF')as tgl18, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-19'),'OFF')as tgl19, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-20'),'OFF')as tgl20, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-21'),'OFF')as tgl21, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-22'),'OFF')as tgl22, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-23'),'OFF')as tgl23, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-24'),'OFF')as tgl24, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-25'),'OFF')as tgl25, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-26'),'OFF')as tgl26, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-27'),'OFF')as tgl27, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-28'),'OFF')as tgl28, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-29'),'OFF')as tgl29, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-30'),'OFF')as tgl30, 
				coalesce((select trim(kodejamkerja) from sc_trx.jadwalkerja where  kdregu=vr_kdregu and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-31'),'OFF')as tgl31 
				from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_maxtgl;

	RETURN NEXT vr_kdregu;	
END LOOP;		
	RETURN;
	
END;
$$;

alter function pr_exceljadwalregu(char, char) owner to postgres;

