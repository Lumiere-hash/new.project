create function pr_load_export_import() returns character
    language plpgsql
as
$$
DECLARE 

BEGIN
-- exportcsv --
    /* delete */
    delete from exportcsv 
    where nodok not in (
        select nodok 
        from sc_im.exportcsv
    );
    
    /* if exist */
	update exportcsv a set 
        nodok           = b.nodok           , 
        nmlisting       = b.nmlisting       , 
        dir_list        = b.dir_list        , 
        dir_source      = b.dir_source      , 
        dir_temporary   = b.dir_temporary     
	from sc_im.exportcsv b 
    where a.nodok = b.nodok;

	/* not exist */	
	insert into exportcsv (
        select * 
        from sc_im.exportcsv 
        where nodok not in (
            select nodok 
            from exportcsv
        )
    );
-- exportcsv --

-- importcsv --
    /* delete */
    delete from importcsv 
    where nodok not in (
        select nodok 
        from sc_im.importcsv
    );
    
    /* if exist */
	update importcsv a set 
        nodok           = b.nodok           , 
        nmlisting       = b.nmlisting       , 
        dir_list        = b.dir_list        , 
        dir_source      = b.dir_source      , 
        dir_temporary   = b.dir_temporary     
	from sc_im.importcsv b 
    where a.nodok = b.nodok;

	/* not exist */	
	insert into importcsv (
        select * 
        from sc_im.importcsv 
        where nodok not in (
            select nodok 
            from importcsv
        )
    );
-- importcsv --

	RETURN '';
END;
$$;

alter function pr_load_export_import() owner to postgres;

