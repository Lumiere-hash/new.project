create function p1721_locktrg_after() returns trigger
    language plpgsql
as
$$
declare
     vr_nodok char(30);

begin
/*STATUS = I:INSERT, U:UPDATE, D:DELETE, T:TRUNCATE*/
--select * from sc_tmp.p1721_lock_triger

IF (new.lock_status='f' and after_status='I') then
perform sc_tmp.pr_hitungulang_p1721(character, character, character, character);
ELSEIF (new.lock_status='f' and after_status='U') then
perform sc_tmp.pr_hitungulang_p1721(character, character, character, character);
ELSEIF (new.lock_status='f' and after_status='D') then
perform sc_tmp.pr_hitungulang_p1721(character, character, character, character);
ELSEIF (new.lock_status='f' and after_status='T') then
end if;

return new;

end;
$$;

alter function p1721_locktrg_after() owner to postgres;

