create function pr_p21_master() returns trigger
    language plpgsql
as
$$
BEGIN
		
	IF (tg_op = 'UPDATE') THEN	---(tg_op = 'INSERT') or triger ubah update
		if (new.status='H' and old.status='I') then --H untuk hitung ulang
			update sc_tmp.p21_master set 						--ambil detail
			total_pajak=(select sum(nominal) from sc_tmp.p21_detail where nodok=new.nodok and nik=new.nik and no_urut='63'),
			total_potongan=(select sum(nominal) from sc_tmp.p21_detail where nodok=new.nodok and nik=new.nik and aksi='B'),
			total_pendapatan=(select sum(nominal) from sc_tmp.p21_detail where nodok=new.nodok and nik=new.nik and aksi='A'),
			gaji_netto=(select sum(nominal) from sc_tmp.p21_detail where nodok=new.nodok and nik=new.nik and no_urut='20')
			where nodok=new.nodok and nik=new.nik;
			update sc_tmp.payroll_detail set nominal=(select sum(nominal) from sc_tmp.p21_detail where nodok=new.nodok and nik=new.nik and no_urut='63') 
			where nodok=new.nodok and nik=new.nik and no_urut=28;

			update sc_tmp.p21_rekap set 
			total_pendapatan=(select sum(total_pendapatan) from sc_tmp.p21_master where nodok=new.nodok and kddept=new.kddept),
			total_potongan=(select sum(total_potongan) from sc_tmp.p21_master where nodok=new.nodok and kddept=new.kddept),
			total_pajak=(select sum(total_pajak) from sc_tmp.p21_master where nodok=new.nodok and kddept=new.kddept)
			where nodok=new.nodok and kddept=new.kddept;	
			update sc_tmp.p21_master set status='I' where nodok=new.nodok and nik=new.nik;
			RETURN new;
		end if;
		RETURN new;
		
	ELSEIF tg_op = 'DELETE' THEN
		update sc_tmp.p21_rekap set 
		total_pendapatan=(select sum(total_pendapatan) from sc_tmp.p21_master where nodok=old.nodok and kddept=old.kddept),
		total_potongan=(select sum(total_potongan) from sc_tmp.p21_master where nodok=old.nodok and kddept=old.kddept),
		total_pajak=(select sum(total_pajak) from sc_tmp.p21_master where nodok=old.nodok and kddept=old.kddept)
		where nodok=old.nodok and kddept=old.kddept;	
		RETURN new;	
	END IF;
	RETURN new;
END;
$$;

alter function pr_p21_master() owner to postgres;

