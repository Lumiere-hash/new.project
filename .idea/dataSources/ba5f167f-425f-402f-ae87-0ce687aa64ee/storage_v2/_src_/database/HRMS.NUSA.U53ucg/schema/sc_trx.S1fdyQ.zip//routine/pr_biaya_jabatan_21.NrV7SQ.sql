create function pr_biaya_jabatan_21(id character, nomor integer, userid character) returns numeric
    language plpgsql
as
$$
DECLARE 
--vr_duit numeric(18,2):=0;
vr_pendapatan numeric(18,2):=0;
--vr_pengurang numeric(18,2):=0;
--vr_netto numeric(18,2):=0;
vr_biaya numeric(18,2):=0;
vr_pendapatan2 numeric(18,2):=0;
vr_patokan numeric(18,2):=0;
BEGIN		
	
	select sum(nominal) into vr_pendapatan from sc_tmp.p21_detail where nik=id and aksi='A';	
	--select sum(nominal) into vr_pengurang from sc_tmp.p21_detail where nik=id and aksi='B';	

	--vr_netto=vr_pendapatan-vr_pengurang;
	vr_patokan=5000000;
	vr_pendapatan2=vr_pendapatan*5/100.00;
	if vr_pendapatan2<vr_patokan then 
		vr_biaya=vr_pendapatan2; 
	else vr_biaya=vr_patokan;
	end if;
	
	delete from sc_tmp.p21_detail where nodok=userid and nik=id and no_urut=nomor;

	insert into sc_tmp.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by)
	select userid as nodok,id as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_biaya as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by from sc_mst.detail_formula
	where no_urut=nomor and kdrumus='P21';

	--insert into dumy(nominal) values(vr_biaya);
	
	RETURN vr_biaya;	
END;
$$;

alter function pr_biaya_jabatan_21(char, integer, char) owner to postgres;

