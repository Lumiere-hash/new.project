create function pr_upah_borong_mst_after_update() returns trigger
    language plpgsql
as
$$
declare
     
     --vr_nomor char(30);
     --vr_status char(10);
     
begin

--select old.status;
if (new.status='F')and(old.status='A') then 
	--vr_status:=new.status;
	--echo 'vr_status';
	--raise notice 'xxx';
	--update sc_mst.karyawan set grade_golongan=new.kdgrade,grouppenggajian=new.kdgroup_pg,gajipokok=new.gaji_pokok,gajibpjs=new.gaji_bpjs where nik=new.nik; 
	update sc_trx.upah_borong_mst set status='P' where nodok=new.nodok;

	--insert into sc_tmp.payroll_borong (
	--nodok,nodok_ref,nik,tgl_dok,periode,kddept,kdsubdept,kdjabatan,kdlvljabatan,nmatasan,tgl_kerja,total_upah,
	--status,keterangan
	--)

	--select nik,nodok,nik,tgl_dok,periode,kddept,kdsubdept,kdjabatan,kdlvljabatan,nmatasan,tgl_kerja,total_upah,
	--'I' as status,keterangan
	--from sc_trx.upah_borong_mst where nodok=new.nodok and nik=new.nik;	
else if (new.status='F')and(old.status='P') then 
	update sc_trx.upah_borong_mst set status='P' where nodok=new.nodok;
end if;
end if;
return new;

end;
$$;

alter function pr_upah_borong_mst_after_update() owner to postgres;

