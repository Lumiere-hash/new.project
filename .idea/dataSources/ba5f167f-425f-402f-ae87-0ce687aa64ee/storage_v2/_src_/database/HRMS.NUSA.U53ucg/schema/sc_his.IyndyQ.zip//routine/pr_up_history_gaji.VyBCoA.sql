create function pr_up_history_gaji(vr_param text) returns text
    language plpgsql
as
$$
DECLARE
	/*
		author 		: Fiky Ashariza
		create date	: 2019/01/01
		update date	: 
		update case	: Perubahan dari generate program ke store procedure
	*/
	vr_nominallvl numeric(18,2);	
	vr_nominalwil numeric(18,2);	
	
	vr_split text;	
	vr_branch text :=coalesce(branch,'') from sc_mst.branch where cdefault='YES';
	vr_tgl date; vrs_tgl text;	
	vr_param1 text; vrs_user text;
	vq_karyawan text := 'select nik from sc_mst.karyawan where coalesce(statuskepegawaian,'''')!=''KO''';
	vr_rec record;
BEGIN

	vrs_tgl := trim(split_part(vr_param, '|', 1));
	vrs_user := trim(split_part(vr_param, '|', 2));
	vr_param1 := ' and nik is not null';
	RAISE NOTICE 'Calling 1(%)', vrs_tgl;

/*	select * from sc_mst.m_lvlgp
	select * from sc_mst.m_wilayah_nominal
select coalesce(b.nominal,0) as nominalgp,coalesce(c.nominal,0) as nominalwil from sc_mst.karyawan a 
left outer join sc_mst.m_lvlgp b on a.kdlvlgp = b.kdlvlgp 
left outer join sc_mst.m_wilayah_nominal c on a.kdwilayahnominal = c.kdwilayahnominal
where nik=vr_rec.nik; 
*/
    FOR vr_rec IN EXECUTE vq_karyawan||vr_param1 --USING n
    LOOP
		if not exists(select * from sc_his.history_gaji where nik=vr_rec.nik and periode=to_char(vrs_tgl::date,'yyyymm')) then

			select coalesce(b.nominal,0) as nominallvl,coalesce(c.nominal,0) as nominalwil into vr_nominallvl, vr_nominalwil from sc_mst.karyawan a 
			left outer join sc_mst.m_lvlgp b on a.kdlvlgp = b.kdlvlgp 
			left outer join sc_mst.m_wilayah_nominal c on a.kdwilayahnominal = c.kdwilayahnominal
			where nik=vr_rec.nik;

			
			insert into sc_his.history_gaji 
			(branch,nik,periode,nominal,inputdate,inputby,updatedate,updateby,gajipokok,gajitj,k_gplvl,k_gpwil)
			(select vr_branch,nik,to_char(vrs_tgl::date,'yyyymm'),coalesce(gajitetap,0),to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp,vrs_user,null,null,coalesce(gajipokok,0),coalesce(tj_tetap,0),vr_nominallvl, vr_nominalwil 
			from sc_mst.karyawan where nik=vr_rec.nik);
		end if;
		
    
	   RAISE NOTICE 'Under Loop(%)', vr_rec.nik; 
    END LOOP;
    
    RETURN vr_rec.nik;
END;
$$;

alter function pr_up_history_gaji(text) owner to postgres;

