create function pr_gr_jadwalkerja(vr_bulan_awal numeric, vr_tahun_awal numeric, vr_bulan_akhir numeric, vr_tahun_akhir numeric, vr_kdregu character) returns SETOF void
    language plpgsql
as
$$
DECLARE vr_table_array numeric;
DECLARE vr_table_array2 numeric;
DECLARE vr_s_table date;
DECLARE vr_s_table_rev date;
DECLARE vr_cek_tglakhir date;
DECLARE vr_cek_tglrev date;
DECLARE vr_tgljadwal_bef date;
DECLARE vr_tgljadwal_aft numeric;
DECLARE vr_tgljadwal_identify numeric;
DECLARE vr_tgljadwal_identifyEX numeric;
DECLARE vr_nik character(12);
DECLARE vr_cekdouble numeric;

BEGIN


	--select tgl from sc_trx.jadwalkerja where kdregu='A1' order by tgl
		perform sc_tmp.pr_calendar_jadwal(vr_bulan_awal,vr_tahun_awal,vr_bulan_akhir,vr_tahun_akhir,vr_kdregu);
		vr_table_array:=1;
 --vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu order by tgl;
		--update sc_tmp.calendar_jadwal set kdregu=vr_kdregu where bulan=vr_bulan_awal and tahun=vr_tahun_awal;
		--update sc_tmp.calendar_jadwal set kdregu=vr_kdregu where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;

		
 
		LOOP	--select to_char(now(),'yyyy-mm-'||1)
		
			if(vr_table_array=1) then
				vr_s_table:=m01_1 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
								
					vr_cek_tglrev:=m01_1 from sc_tmp.calendar_jadwal where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir and kdregu=vr_kdregu;			
					vr_tgljadwal_identifyEX:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl=vr_cek_tglrev;			
								
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0 and vr_tgljadwal_identifyEX=0 )then
						update sc_tmp.calendar_jadwal set m01_1_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						--insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table; 
						
					end if;

				
			elseif(vr_table_array=2) then
				vr_s_table:=m01_2 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;

					vr_cek_tglrev:=m01_2 from sc_tmp.calendar_jadwal where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir and kdregu=vr_kdregu;			
					vr_tgljadwal_identifyEX:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl=vr_cek_tglrev;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0 and vr_tgljadwal_identifyEX=0)then
						update sc_tmp.calendar_jadwal set m01_2_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						--insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
					end if;

			elseif(vr_table_array=3) then
				vr_s_table:=m01_3 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;

					vr_cek_tglrev:=m01_3 from sc_tmp.calendar_jadwal where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir and kdregu=vr_kdregu;			
					vr_tgljadwal_identifyEX:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl=vr_cek_tglrev;
											
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0 and vr_tgljadwal_identifyEX=0)then
						update sc_tmp.calendar_jadwal set m01_3_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						--insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;					
					end if;

			elseif(vr_table_array=4) then
				vr_s_table:=m01_4 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					vr_cek_tglrev:=m01_4 from sc_tmp.calendar_jadwal where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir and kdregu=vr_kdregu;			
					vr_tgljadwal_identifyEX:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl=vr_cek_tglrev;			
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0 and vr_tgljadwal_identifyEX=0)then
						update sc_tmp.calendar_jadwal set m01_4_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						--update sc_tmp.calendar_jadwal set m01_4_rev=cast(to_char(vr_s_table,'yyyy-mm-'||vr_tgljadwal_identify)as date) where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						--insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
					end if;

			elseif(vr_table_array=5) then
				vr_s_table:=m01_5 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					vr_cek_tglrev:=m01_5 from sc_tmp.calendar_jadwal where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir and kdregu=vr_kdregu;			
					vr_tgljadwal_identifyEX:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl=vr_cek_tglrev;			
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0 and vr_tgljadwal_identifyEX=0)then
						update sc_tmp.calendar_jadwal set m01_5_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						--update sc_tmp.calendar_jadwal set m01_5_rev=cast(to_char(vr_s_table,'yyyy-mm-'||vr_tgljadwal_identify)as date) where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						--insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
					end if;

			elseif(vr_table_array=6) then
				vr_s_table:=m01_6 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					vr_cek_tglrev:=m01_6 from sc_tmp.calendar_jadwal where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir and kdregu=vr_kdregu;			
					vr_tgljadwal_identifyEX:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl=vr_cek_tglrev;			
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0 and vr_tgljadwal_identifyEX=0)then
						update sc_tmp.calendar_jadwal set m01_6_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						--insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
					end if;
					
			elseif(vr_table_array=7) then
				vr_s_table:=m01_7 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					vr_cek_tglrev:=m01_7 from sc_tmp.calendar_jadwal where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir and kdregu=vr_kdregu;			
					vr_tgljadwal_identifyEX:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl=vr_cek_tglrev;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0 and vr_tgljadwal_identifyEX=0)then
						update sc_tmp.calendar_jadwal set m01_7_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						--insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
					end if;


			elseif(vr_table_array=8) then
				vr_s_table:=m02_8 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0)then
						update sc_tmp.calendar_jadwal set m02_8_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						--insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
					end if;
			elseif(vr_table_array=9) then
				vr_s_table:=m02_9 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0)then
						update sc_tmp.calendar_jadwal set m02_9_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						--insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
					end if;
			elseif(vr_table_array=10) then
				vr_s_table:=m02_10 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0)then
						update sc_tmp.calendar_jadwal set m02_10_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						--insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
					end if;
			elseif(vr_table_array=11) then
				vr_s_table:=m02_11 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0)then
						update sc_tmp.calendar_jadwal set m02_11_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						---insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
					end if;
			elseif(vr_table_array=12) then
				vr_s_table:=m02_12 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0)then
						update sc_tmp.calendar_jadwal set m02_12_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						---insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
					end if;
			elseif(vr_table_array=13) then
				vr_s_table:=m02_13 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0)then
						update sc_tmp.calendar_jadwal set m02_13_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						---insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
					end if;
			elseif(vr_table_array=14) then
				vr_s_table:=m02_14 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0)then
						update sc_tmp.calendar_jadwal set m02_14_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						---insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
					end if;
			elseif(vr_table_array=15) then
				vr_s_table:=m03_15 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0)then
						update sc_tmp.calendar_jadwal set m03_15_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						---insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
					end if;
			elseif(vr_table_array=16) then
				vr_s_table:=m03_16 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0)then
						update sc_tmp.calendar_jadwal set m03_16_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						---insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
					end if;
			elseif(vr_table_array=17) then
				vr_s_table:=m03_17 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0)then
						update sc_tmp.calendar_jadwal set m03_17_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						---insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
					end if;
			elseif(vr_table_array=18) then
				vr_s_table:=m03_18 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0)then
						update sc_tmp.calendar_jadwal set m03_18_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						---insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
					end if;
			elseif(vr_table_array=19) then
				vr_s_table:=m03_19 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0)then
						update sc_tmp.calendar_jadwal set m03_19_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						---insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
						
					end if;
			elseif(vr_table_array=20) then
				vr_s_table:=m03_20 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0)then
						update sc_tmp.calendar_jadwal set m03_20_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						---insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
					end if;
			elseif(vr_table_array=21) then
				vr_s_table:=m03_21 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0)then
						update sc_tmp.calendar_jadwal set m03_21_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						---insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
					end if;
			elseif(vr_table_array=22) then
				vr_s_table:=m04_22 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0)then
						update sc_tmp.calendar_jadwal set m04_22_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						---insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
					end if;
			elseif(vr_table_array=23) then
				vr_s_table:=m04_23 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0)then
						update sc_tmp.calendar_jadwal set m04_23_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						---insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
					end if;
			elseif(vr_table_array=24) then
				vr_s_table:=m04_24 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0)then
						update sc_tmp.calendar_jadwal set m04_24_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						---insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
					end if;
			elseif(vr_table_array=25) then
				vr_s_table:=m04_25 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0)then
						update sc_tmp.calendar_jadwal set m04_25_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						---insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
					end if;
			elseif(vr_table_array=26) then
				vr_s_table:=m04_26 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0)then
						update sc_tmp.calendar_jadwal set m04_26_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						---insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
					end if;
			elseif(vr_table_array=27) then
				vr_s_table:=m04_27 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0)then
						update sc_tmp.calendar_jadwal set m04_27_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						---insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
					end if;
			elseif(vr_table_array=28) then
				vr_s_table:=m04_28 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0)then
						update sc_tmp.calendar_jadwal set m04_28_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						---insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
					end if;
			elseif(vr_table_array=29) then
				vr_s_table:=m05_29 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0)then
						update sc_tmp.calendar_jadwal set m05_29_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						---insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
					end if;
			elseif(vr_table_array=30) then
				vr_s_table:=m05_30 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0)then
						update sc_tmp.calendar_jadwal set m05_30_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						---insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
					end if;
			elseif(vr_table_array=31) then
				vr_s_table:=m05_31 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0)then
						update sc_tmp.calendar_jadwal set m05_31_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						---insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
					end if;
			elseif(vr_table_array=32) then
				vr_s_table:=m05_32 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0)then
						update sc_tmp.calendar_jadwal set m05_32_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						---insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
					end if;
			elseif(vr_table_array=33) then
				vr_s_table:=m05_33 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0)then
						update sc_tmp.calendar_jadwal set m05_33_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						---insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
					end if;
			elseif(vr_table_array=34) then
				vr_s_table:=m05_34 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0)then
						update sc_tmp.calendar_jadwal set m05_34_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						--insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
					end if;
			elseif(vr_table_array=35) then
				vr_s_table:=m05_35 from sc_tmp.calendar_jadwal where bulan=vr_bulan_awal and tahun=vr_tahun_awal and kdregu=vr_kdregu;
				vr_tgljadwal_bef:=tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_s_table;
				
				vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m01_1 as tgl,m01_1_rev as tgl_rev from sc_tmp.calendar_jadwal 
								union all
								select tahun,bulan,kdregu,m01_2 as tgl,m01_2_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_3 as tgl,m01_3_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_4 as tgl,m01_4_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_5 as tgl,m01_5_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_6 as tgl,m01_6_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m01_7 as tgl,m01_7_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_8 as tgl,m02_8_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_9 as tgl,m02_9_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_10 as tgl,m02_10_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_11 as tgl,m02_11_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_12 as tgl,m02_12_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_13 as tgl,m02_13_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m02_14 as tgl,m02_14_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_15 as tgl,m03_15_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_16 as tgl,m03_16_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_17 as tgl,m03_17_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_18 as tgl,m03_18_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_19 as tgl,m03_19_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_20 as tgl,m03_20_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m03_21 as tgl,m03_21_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_22 as tgl,m04_22_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_23 as tgl,m04_23_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_24 as tgl,m04_24_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_25 as tgl,m04_25_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_26 as tgl,m04_26_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_27 as tgl,m04_27_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m04_28 as tgl,m04_28_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_s_table;
					if(vr_tgljadwal_bef=vr_s_table and vr_tgljadwal_identify=0)then
						update sc_tmp.calendar_jadwal set m05_35_rev=vr_s_table where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
						--insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)select kdregu,kodejamkerja,inputdate,inputby,vr_s_table as tgl from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_tgljadwal_bef;
					end if;
			
			else
				exit when vr_table_array>35;
			end if;		
				
		vr_table_array:=vr_table_array+1;
						exit when vr_table_array>35;
	
END LOOP;		
	/*--RETURN;*/
	vr_table_array2:=1;
		LOOP
				if(vr_table_array2=1) then
					
					vr_s_table_rev:=m02_8_rev from sc_tmp.calendar_jadwal where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir and kdregu=vr_kdregu;
					vr_cek_tglrev:=m01_1_rev from sc_tmp.calendar_jadwal where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir and kdregu=vr_kdregu;
					vr_cek_tglakhir=m01_1 from sc_tmp.calendar_jadwal where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir and kdregu=vr_kdregu;
					vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl=vr_cek_tglakhir;
					vr_tgljadwal_aft:=count(tgl) from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_cek_tglrev;			
					if(vr_cek_tglrev is null and vr_tgljadwal_identify=0 and vr_tgljadwal_aft=0 ) then
						update sc_tmp.calendar_jadwal set m01_1_rev=vr_s_table_rev where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
					end if;
				elseif(vr_table_array2=2) then
					vr_s_table_rev:=m02_9_rev from sc_tmp.calendar_jadwal where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir and kdregu=vr_kdregu;
					vr_cek_tglrev:=m01_2_rev from sc_tmp.calendar_jadwal where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir and kdregu=vr_kdregu;
					vr_cek_tglakhir=m01_2 from sc_tmp.calendar_jadwal where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir and kdregu=vr_kdregu;
					vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_cek_tglakhir;
					vr_tgljadwal_aft:=count(tgl) from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_cek_tglrev;			
					if(vr_cek_tglrev is null and vr_tgljadwal_identify=0  and vr_tgljadwal_aft=0 ) then
						update sc_tmp.calendar_jadwal set m01_2_rev=vr_s_table_rev where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
					end if;
				elseif(vr_table_array2=3) then
					vr_s_table_rev:=m02_10_rev from sc_tmp.calendar_jadwal where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir and kdregu=vr_kdregu;
					vr_cek_tglrev:=m01_3_rev from sc_tmp.calendar_jadwal where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir and kdregu=vr_kdregu;
					vr_cek_tglakhir=m01_3 from sc_tmp.calendar_jadwal where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir and kdregu=vr_kdregu;
					vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_cek_tglakhir;
					vr_tgljadwal_aft:=count(tgl) from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_cek_tglrev;			
					if(vr_cek_tglrev is null and vr_tgljadwal_identify=0  and vr_tgljadwal_aft=0 ) then
						update sc_tmp.calendar_jadwal set m01_3_rev=vr_s_table_rev where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
					end if;
				elseif(vr_table_array2=4) then

					vr_s_table_rev:=m02_11_rev from sc_tmp.calendar_jadwal where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir and kdregu=vr_kdregu;
					vr_cek_tglrev:=m01_4_rev from sc_tmp.calendar_jadwal where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir and kdregu=vr_kdregu;
					vr_cek_tglakhir=m01_4 from sc_tmp.calendar_jadwal where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir and kdregu=vr_kdregu;
					vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_cek_tglakhir;
					vr_tgljadwal_aft:=count(tgl) from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_cek_tglrev;			
					if(vr_cek_tglrev is null and vr_tgljadwal_identify=0  and vr_tgljadwal_aft=0 ) then
						update sc_tmp.calendar_jadwal set m01_4_rev=vr_s_table_rev where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
					end if;
				elseif(vr_table_array2=5) then

					vr_s_table_rev:=m02_12_rev from sc_tmp.calendar_jadwal where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir and kdregu=vr_kdregu;
					vr_cek_tglrev:=m01_5_rev from sc_tmp.calendar_jadwal where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir and kdregu=vr_kdregu;
					vr_cek_tglakhir=m01_5 from sc_tmp.calendar_jadwal where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir and kdregu=vr_kdregu;
					vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_cek_tglakhir;
					vr_tgljadwal_aft:=count(tgl) from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_cek_tglrev;			
					if(vr_cek_tglrev is null and vr_tgljadwal_identify=0  and vr_tgljadwal_aft=0 ) then
						update sc_tmp.calendar_jadwal set m01_5_rev=vr_s_table_rev where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
					end if;
				elseif(vr_table_array2=6) then
					vr_s_table_rev:=m02_13_rev from sc_tmp.calendar_jadwal where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir and kdregu=vr_kdregu;
					vr_cek_tglrev:=m01_6_rev from sc_tmp.calendar_jadwal where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir and kdregu=vr_kdregu;
					vr_cek_tglakhir=m01_6 from sc_tmp.calendar_jadwal where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir and kdregu=vr_kdregu;
					vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_cek_tglakhir;
					vr_tgljadwal_aft:=count(tgl) from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_cek_tglrev;			
					if(vr_cek_tglrev is null and vr_tgljadwal_identify=0  and vr_tgljadwal_aft=0 ) then
						update sc_tmp.calendar_jadwal set m01_6_rev=vr_s_table_rev where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
					end if;
				elseif(vr_table_array2=7) then
					vr_s_table_rev:=m02_14_rev from sc_tmp.calendar_jadwal where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir and kdregu=vr_kdregu;
					vr_cek_tglrev:=m01_7_rev from sc_tmp.calendar_jadwal where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir and kdregu=vr_kdregu;
					vr_cek_tglakhir=m01_7 from sc_tmp.calendar_jadwal where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir and kdregu=vr_kdregu;
					vr_tgljadwal_identify:=count(x.tgl_rev) from 
								(select tahun,bulan,kdregu,m05_29 as tgl,m05_29_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_30 as tgl,m05_30_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_31 as tgl,m05_31_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_32 as tgl,m05_32_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_33 as tgl,m05_33_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_34 as tgl,m05_34_rev as tgl_rev from sc_tmp.calendar_jadwal
								union all
								select tahun,bulan,kdregu,m05_35 as tgl,m05_35_rev as tgl_rev from sc_tmp.calendar_jadwal
								) as x
								where x.kdregu=vr_kdregu and x.tgl_rev=vr_cek_tglakhir;
					vr_tgljadwal_aft:=count(tgl) from sc_trx.jadwalkerja where kdregu=vr_kdregu and tgl=vr_cek_tglrev;			
					if(vr_cek_tglrev is null and vr_tgljadwal_identify=0  and vr_tgljadwal_aft=0 ) then
						update sc_tmp.calendar_jadwal set m01_7_rev=vr_s_table_rev where bulan=vr_bulan_akhir and tahun=vr_tahun_akhir;
					end if;
				else
				exit when vr_table_array2>7;
			end if;	
			vr_table_array2:=vr_table_array2+1;
						exit when vr_table_array2>7;	
		END LOOP;


		
RETURN;

	
	
END;
$$;

alter function pr_gr_jadwalkerja(numeric, numeric, numeric, numeric, char) owner to postgres;

