create function tr_mbarang_stkgdw() returns trigger
    language plpgsql
as
$$
declare
--created by Fiky ::26/07/2017
--triger penomoran mutasi asset referensi mutasi
--update 17/04/2018 - penambahan master gudang
     vr_nomor char(12); 
     vr_cekprefix char(4);
     vr_nowprefix char(4);
     vr_loccode char(12);
     vr_lastdoc numeric;
begin    

	IF TG_OP ='INSERT' THEN 
		--select * from sc_mst.mgudang
		FOR vr_loccode in select trim(loccode) from sc_mst.mgudang order by locaname desc
			LOOP
			if not exists(select * from sc_mst.stkgdw where loccode=vr_loccode and stockcode=new.nodok) then
			insert into sc_mst.stkgdw 
			(branch,stockcode,loccode,kdgroup,kdsubgroup,satkecil)
			(select branch,nodok,vr_loccode,kdgroup,kdsubgroup,satkecil from sc_mst.mbarang where left(kdgroup,3) in ('BRG','JSA') and nodok=new.nodok);
			end if;
		
		end loop;
		if not exists(select * from sc_mst.mapping_satuan_brg where kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.nodok) then
			if (left(new.kdgroup,3)='BRG' OR left(new.kdgroup,3)='JSA') then
			--delete from sc_mst.stkgdw where stockcode='KRTS0001'
			insert into sc_mst.mapping_satuan_brg (branch,satkecil,satbesar,qty,kdgroup,kdsubgroup,stockcode,qtykecil)
			--(select branch,satkecil,satkecil,1 as qty,kdgroup,kdsubgroup,nodok as stockcode from sc_mst.mbarang where nodok='KRTS0001')
			values
			(new.branch,new.satkecil,new.satkecil,1,new.kdgroup,new.kdsubgroup,new.nodok,1);
			end if;
		end if;
		/*
			insert into sc_mst.stkgdw 
			(branch,stockcode,loccode,kdgroup,kdsubgroup,satkecil)
			(select branch,nodok,'MJKCNI',kdgroup,kdsubgroup,satkecil from sc_mst.mbarang where left(kdgroup,3) in ('BRG','JSA') and nodok='JSA-OPR-0002');

			insert into sc_mst.mapping_satuan_brg (branch,satkecil,satbesar,qty,kdgroup,kdsubgroup,stockcode,qtykecil)
			values
			('MJKCNI','AC','AC',1,'JSA','OPR','JSA-OPR-0002',1);

		*/
	RETURN NEW;
	ELSEIF TG_OP ='UPDATE' THEN
	
			
		
	RETURN NEW;
	
	END IF;
    
    return new;
        
end;
$$;

alter function tr_mbarang_stkgdw() owner to postgres;

