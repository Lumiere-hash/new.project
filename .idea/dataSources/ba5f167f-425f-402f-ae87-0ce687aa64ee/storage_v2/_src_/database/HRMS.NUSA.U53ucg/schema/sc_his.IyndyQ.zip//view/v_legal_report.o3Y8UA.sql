create view v_legal_report
            (docno, docname, doctype, docdate, docref, docrefname, coperator, coperatorname, idbu, namebu, status,
             progress, description, inputdate, inputby, updatedate, updateby, finishdate, finishby, docnokeep, docnotmp,
             attachment, attachment_dir, negosiasi, negosiasi_date, klarifikasi, klarifikasi_date, sp1, sp1_date, sp2,
             sp2_date, sp3, sp3_date, somasi, somasi_date, nmbu, initial)
as
SELECT x.docno,
       x.docname,
       x.doctype,
       x.docdate,
       x.docref,
       x.docrefname,
       x.coperator,
       x.coperatorname,
       x.idbu,
       x.namebu,
       x.status,
       x.progress,
       x.description,
       x.inputdate,
       x.inputby,
       x.updatedate,
       x.updateby,
       x.finishdate,
       x.finishby,
       x.docnokeep,
       x.docnotmp,
       x.attachment,
       x.attachment_dir,
       a.negosiasi,
       a.negosiasi_date,
       b.klarifikasi,
       b.klarifikasi_date,
       c.sp1,
       c.sp1_date,
       d.sp2,
       d.sp2_date,
       e.sp3,
       e.sp3_date,
       f.somasi,
       f.somasi_date,
       y.desc_cabang AS nmbu,
       y.initial
FROM sc_his.legal_master x
         LEFT JOIN (SELECT a_1.docno,
                           CASE
                               WHEN a_1.operationcategory = 'A'::bpchar THEN 'NEGOSIASI'::text
                               ELSE ''::text
                               END           AS negosiasi,
                           a_1.dateoperation AS negosiasi_date
                    FROM sc_his.legal_detail a_1,
                         (SELECT max(legal_detail.docdate) AS docdate,
                                 legal_detail.docno
                          FROM sc_his.legal_detail
                          WHERE legal_detail.operationcategory = 'A'::bpchar
                          GROUP BY legal_detail.docno) b_1
                    WHERE a_1.docno = b_1.docno
                      AND a_1.docdate = b_1.docdate) a ON x.docno = a.docno
         LEFT JOIN (SELECT a_1.docno,
                           CASE
                               WHEN a_1.operationcategory = 'B'::bpchar THEN 'KLARIFIKASI'::text
                               ELSE ''::text
                               END           AS klarifikasi,
                           a_1.dateoperation AS klarifikasi_date
                    FROM sc_his.legal_detail a_1,
                         (SELECT max(legal_detail.docdate) AS docdate,
                                 legal_detail.docno
                          FROM sc_his.legal_detail
                          WHERE legal_detail.operationcategory = 'B'::bpchar
                          GROUP BY legal_detail.docno) b_1
                    WHERE a_1.docno = b_1.docno
                      AND a_1.docdate = b_1.docdate) b ON x.docno = b.docno
         LEFT JOIN (SELECT a_1.docno,
                           CASE
                               WHEN a_1.operationcategory = 'C'::bpchar THEN 'SP1'::text
                               ELSE ''::text
                               END           AS sp1,
                           a_1.dateoperation AS sp1_date
                    FROM sc_his.legal_detail a_1,
                         (SELECT max(legal_detail.docdate) AS docdate,
                                 legal_detail.docno
                          FROM sc_his.legal_detail
                          WHERE legal_detail.operationcategory = 'C'::bpchar
                          GROUP BY legal_detail.docno) b_1
                    WHERE a_1.docno = b_1.docno
                      AND a_1.docdate = b_1.docdate) c ON x.docno = c.docno
         LEFT JOIN (SELECT a_1.docno,
                           CASE
                               WHEN a_1.operationcategory = 'D'::bpchar THEN 'SP2'::text
                               ELSE ''::text
                               END           AS sp2,
                           a_1.dateoperation AS sp2_date
                    FROM sc_his.legal_detail a_1,
                         (SELECT max(legal_detail.docdate) AS docdate,
                                 legal_detail.docno
                          FROM sc_his.legal_detail
                          WHERE legal_detail.operationcategory = 'D'::bpchar
                          GROUP BY legal_detail.docno) b_1
                    WHERE a_1.docno = b_1.docno
                      AND a_1.docdate = b_1.docdate) d ON x.docno = d.docno
         LEFT JOIN (SELECT a_1.docno,
                           CASE
                               WHEN a_1.operationcategory = 'E'::bpchar THEN 'SP3'::text
                               ELSE ''::text
                               END           AS sp3,
                           a_1.dateoperation AS sp3_date
                    FROM sc_his.legal_detail a_1,
                         (SELECT max(legal_detail.docdate) AS docdate,
                                 legal_detail.docno
                          FROM sc_his.legal_detail
                          WHERE legal_detail.operationcategory = 'E'::bpchar
                          GROUP BY legal_detail.docno) b_1
                    WHERE a_1.docno = b_1.docno
                      AND a_1.docdate = b_1.docdate) e ON x.docno = e.docno
         LEFT JOIN (SELECT a_1.docno,
                           CASE
                               WHEN a_1.operationcategory = 'F'::bpchar THEN 'SOMASI'::text
                               ELSE ''::text
                               END           AS somasi,
                           a_1.dateoperation AS somasi_date
                    FROM sc_his.legal_detail a_1,
                         (SELECT max(legal_detail.docdate) AS docdate,
                                 legal_detail.docno
                          FROM sc_his.legal_detail
                          WHERE legal_detail.operationcategory = 'F'::bpchar
                          GROUP BY legal_detail.docno) b_1
                    WHERE a_1.docno = b_1.docno
                      AND a_1.docdate = b_1.docdate) f ON x.docno = f.docno
         LEFT JOIN sc_mst.kantorwilayah y ON x.idbu = y.kdcabang;

alter table v_legal_report
    owner to postgres;

