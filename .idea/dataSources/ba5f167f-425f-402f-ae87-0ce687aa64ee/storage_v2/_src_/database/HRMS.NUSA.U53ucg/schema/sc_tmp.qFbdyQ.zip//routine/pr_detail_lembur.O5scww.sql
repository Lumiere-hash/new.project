create function pr_detail_lembur() returns trigger
    language plpgsql
as
$$
declare
     
     vr_potongan numeric;
     vr_gaji numeric(18,2);
     vr_nominal numeric(18,2);
     vr_pertama money;
     vr_kedua money;
     vr_ketiga money;
     vr_rentangatas1 numeric;
    vr_rentangbawah1 numeric;
    vr_pengkali1 numeric(5,2);
    vr_pengkali2 numeric(5,2);
    vr_pengkali3 numeric(5,2);
    vr_pengkali4 numeric(5,2);
    vr_pengkali5 numeric(5,2);
    vr_durasi numeric;
    vr_durasi2 numeric;
    vr_dokno character(16);
    vr_tglkerja date;
    vr_nik char(12);
    vr_jam_selesai time;
    vr_jam_mulai time;
    vr_jenis character(10);
     
begin
--vr_status:=trim(coalesce(status,'')) from sc_tmp.cuti where branch=new.branch and kddokumen=new.kddokumen for update;
--vr_nomor
--vr_durasi2:=coalesce(jumlah_jam_absen,
	if (new.status='P' and old.status='I') then
		vr_durasi2:=coalesce(jumlah_jam_absen,1) from sc_tmp.detail_lembur where nodok_ref=new.nodok_ref;
		select gajipokok into vr_gaji from sc_mst.karyawan where nik=vr_nik;	
		select nik,jumlah_jam,nodok_ref,tgl_kerja,jam_mulai,jam_selesai_absen,tplembur into vr_nik,vr_durasi,vr_dokno,vr_tglkerja,vr_jam_mulai,vr_jam_selesai,vr_jenis from sc_tmp.detail_lembur where nodok_ref=new.nodok_ref;
		select gajipokok into vr_gaji from sc_mst.karyawan where nik=vr_nik;	
		select value3 into vr_potongan from sc_mst.option where kdoption='E';
		select jml_pengkali into vr_pengkali1 from sc_mst.lembur where rentang_bawah=1 and rentang_atas=1 and tplembur='BIASA';
		select jml_pengkali into vr_pengkali2 from sc_mst.lembur where rentang_bawah=2 and rentang_atas=7 and tplembur='BIASA';
		select jml_pengkali into vr_pengkali3 from sc_mst.lembur where rentang_bawah=7 and rentang_atas=12 and tplembur='BIASA';
		select jml_pengkali into vr_pengkali4 from sc_mst.lembur where rentang_bawah=1 and rentang_atas=7 and tplembur='LIBUR';
		select jml_pengkali into vr_pengkali5 from sc_mst.lembur where rentang_bawah=7 and rentang_atas=12 and tplembur='LIBUR';
		
		select gajipokok into vr_gaji from sc_mst.karyawan where nik=new.nik;	
		--vr_durasi2=cast(to_char(cast(vr_jam_selesai as time) - cast(vr_jam_mulai as time),'HH24')as integer);
		--select to_char(cast('06:00:00' as time) - cast('04:59:00' as time),'HH')
		--if vr_durasi2>vr_durasi
	
		if (vr_durasi2=0 and trim(vr_jenis)='BIASA') then 
		select total into vr_nominal from(
			select nodok_ref,nik,tgl_kerja,jumlah_jam,sum(pertama)+sum(kedua)+sum(ketiga) as total 
			from (
				select *,
				case when jumlah_jam-60 >=0 then (60*(vr_gaji/173.00)*60*vr_pengkali1)
				     else 0 end as pertama,
				case when (jumlah_jam-60)>0 and ((jumlah_jam-60)-420) <0 then ((jumlah_jam-60)*(vr_gaji/173.00)*60*vr_pengkali2)
				     when (jumlah_jam-60)>0 and ((jumlah_jam-60)-420) >=0 then (420*(vr_gaji/173.00)*60*vr_pengkali2)
				     else 0 end as kedua,
				case when (jumlah_jam-480)>0 then ((jumlah_jam-480)*(vr_gaji/173.00)*60*vr_pengkali3)
				else 0 end as ketiga
				from  (
					select nodok_ref,nik,nominal,tgl_kerja,jumlah_jam,jam_selesai_absen from sc_tmp.detail_lembur
					where nodok_ref=vr_dokno
				) as x
			) as t1
			group by nodok_ref,nik,tgl_kerja,jumlah_jam
		) as t2;
		elseif (vr_durasi2=0 and trim(vr_jenis)='LIBUR') then 
			--vr_nominal=(vr_pengkali1*vr_durasi*vr_gaji)/173;
			--vr_nominal=2;
			select total into vr_nominal from(
			select nodok_ref,nik,tgl_kerja,jumlah_jam,sum(kedua)+sum(ketiga) as total 
			from (
				select *,
				case when (jumlah_jam-60)>0 and ((jumlah_jam-60)-420) <0 then (jumlah_jam-60)*(vr_gaji/173.00)*60*vr_pengkali4
				     when (jumlah_jam-60)>0 and ((jumlah_jam-60)-420) >=0 then 420*(vr_gaji/173.00)*60*vr_pengkali4
				     else 0 end as kedua,
				case when (jumlah_jam-480)>0 then (jumlah_jam-480)*(vr_gaji/173.00)*60*vr_pengkali5
				else 0 end as ketiga
				from  (
					select nodok_ref,nik,nominal,tgl_kerja,jumlah_jam,jam_selesai_absen from sc_tmp.detail_lembur
					where nodok_ref=vr_dokno
				) as x
			) as t1
			group by nodok_ref,nik,tgl_kerja,jumlah_jam
		) as t2;
		elseif (vr_durasi<=vr_durasi2 and trim(vr_jenis)='BIASA') then
			--vr_nominal=(vr_pengkali1*vr_durasi2*vr_gaji)/173;
		select total into vr_nominal from(
			select nodok_ref,nik,tgl_kerja,jumlah_jam,sum(pertama)+sum(kedua)+sum(ketiga) as total 
			from (
				select *,
				case when jumlah_jam-60 >=0 then (60*(vr_gaji/173.00/60.00)*vr_pengkali1)
				     else 0 end as pertama,
				case when (jumlah_jam-60)>0 and ((jumlah_jam-60)-420) <0 then ((jumlah_jam-60)*(vr_gaji/173.00/60.00)*vr_pengkali2)
				     when (jumlah_jam-60)>0 and ((jumlah_jam-60)-420) >=0 then (420*(vr_gaji/173.00/60.00)*vr_pengkali2)
				     else 0 end as kedua,
				case when (jumlah_jam-480)>0 then ((jumlah_jam-480)*(vr_gaji/173.00/60.00)*vr_pengkali3)
				else 0 end as ketiga
				from  (
					select nodok_ref,nik,nominal,tgl_kerja,jumlah_jam,jam_selesai_absen from sc_tmp.detail_lembur
					where nodok_ref=vr_dokno
				) as x
			) as t1
			group by nodok_ref,nik,tgl_kerja,jumlah_jam
		) as t2;
		elseif (vr_durasi<=vr_durasi2 and trim(vr_jenis)='LIBUR') then 
			--vr_nominal=(vr_pengkali1*vr_durasi*vr_gaji)/173;
			--vr_nominal=2;
			select total into vr_nominal from(
			select nodok_ref,nik,tgl_kerja,jumlah_jam,sum(kedua)+sum(ketiga) as total 
			from (
				select *,
				case when (jumlah_jam-60)>0 and ((jumlah_jam-60)-420) <0 then (jumlah_jam-60)*(vr_gaji/173.00/60.00)*vr_pengkali4
				     when (jumlah_jam-60)>0 and ((jumlah_jam-60)-420) >=0 then 420*(vr_gaji/173.00/60.00)*vr_pengkali4
				     else 0 end as kedua,
				case when (jumlah_jam-480)>0 then (jumlah_jam-480)*(vr_gaji/173.00/60.00)*vr_pengkali5
				else 0 end as ketiga
				from  (
					select nodok_ref,nik,nominal,tgl_kerja,jumlah_jam,jam_selesai_absen from sc_tmp.detail_lembur
					where nodok_ref=vr_dokno
				) as x
			) as t1
			group by nodok_ref,nik,tgl_kerja,jumlah_jam
		) as t2;
		elseif (vr_durasi2<=vr_durasi and trim(vr_jenis)='BIASA') then
			--vr_nominal=(vr_pengkali1*vr_durasi2*vr_gaji)/173;
		select total into vr_nominal from(
			select nodok_ref,nik,tgl_kerja,jumlah_jam_absen,sum(pertama)+sum(kedua)+sum(ketiga) as total 
			from (
				select *,
				case when (jumlah_jam_absen-60) >=0 then (1*(vr_gaji/173.00)*60*vr_pengkali1)
				     else 0 end as pertama,
				case when (jumlah_jam_absen-60)>0 and ((jumlah_jam_absen-60)-420) <0 then ((jumlah_jam_absen-60)*(vr_gaji/173.00/60.00)*vr_pengkali2)
				     when (jumlah_jam_absen-60)>0 and ((jumlah_jam_absen-60)-420) >=0 then (420*(vr_gaji/173.00/60.00)*vr_pengkali2)
				     else 0 end as kedua,
				case when (jumlah_jam_absen-480)>0 then ((jumlah_jam_absen-480)*(vr_gaji/173.00/60.00)*vr_pengkali3)
				else 0 end as ketiga
				from  (
					select nodok_ref,nik,nominal,tgl_kerja,jumlah_jam_absen,jam_selesai_absen from sc_tmp.detail_lembur
					where nodok_ref=vr_dokno
				) as x
			) as t1
			group by nodok_ref,nik,tgl_kerja,jumlah_jam_absen
		) as t2;
		elseif (vr_durasi2<=vr_durasi and trim(vr_jenis)='LIBUR') then
			--vr_nominal=(vr_pengkali1*vr_durasi*vr_gaji)/173;
			--vr_nominal=2;
			select total into vr_nominal from(
			select nodok_ref,nik,tgl_kerja,jumlah_jam_absen,sum(kedua)+sum(ketiga) as total 
			from (
				select *,
				case when (jumlah_jam_absen-60)>0 and ((jumlah_jam_absen-60)-420) <0 then (jumlah_jam_absen-60)*(vr_gaji/173.00/60.00)*vr_pengkali4
				     when (jumlah_jam_absen-60)>0 and ((jumlah_jam_absen-60)-420) >=0 then 420*(vr_gaji/173.00/60.00)*vr_pengkali4
				     else 0 end as kedua,
				case when (jumlah_jam_absen-480)>0 then (jumlah_jam_absen-480)*(vr_gaji/173.00/60.00)*vr_pengkali5
				else 0 end as ketiga
				from  (
					select nodok_ref,nik,nominal,tgl_kerja,jumlah_jam_absen,jam_selesai_absen from sc_tmp.detail_lembur
					where nodok_ref=vr_dokno
				) as x
			) as t1
			group by nodok_ref,nik,tgl_kerja,jumlah_jam_absen
		) as t2;
		end if;
		
	
		
		update sc_tmp.detail_lembur set nominal=vr_nominal where nodok_ref=new.nodok_ref;
		--insert into dumy (jumlah) values (vr_nominal);
	end if;

return new;

end;
$$;

alter function pr_detail_lembur() owner to postgres;

