create function lihat_lembur(periode character, dokno character, xnik character) returns timestamp without time zone
    language plpgsql
as
$$
DECLARE
    listNik RECORD;
    listJadwal RECORD;
    vr_tgl timestamp;
    vr_sisacuti integer;

    vr_jenis character;
    vr_doklembur character(12);
    vr_rentangatas1 numeric;
    vr_rentangbawah1 numeric;
    vr_pengkali1 numeric;
    vr_rentangatas2 numeric;
    vr_rentangbawah2 numeric;
    vr_pengkali2 numeric;
    vr_rentangatas3 numeric;
    vr_rentangbawah3 numeric;
    vr_pengkali3 numeric;
    vr_gaji money;
    vr_potongan money;
    vr_tglawal integer;
    vr_tglblcawal date;
    vr_tglblcakhir character;
    vr_tglakhir integer;
    vr_periode character;
    vr_tglan date;
    vr_tglanakhir date;
    vr_tglawalfix date;
    vr_tglakhirfix date;
    vr_jamabsen timestamp;
    vr_durasi integer;
BEGIN

    select rentang_atas into vr_rentangatas1 from sc_mst.lembur where kdlembur='2' and tplembur='BIASA';
        select rentang_bawah into vr_rentangbawah1 from sc_mst.lembur where kdlembur='2' and tplembur='BIASA';
            select jml_pengkali into vr_pengkali1 from sc_mst.lembur where kdlembur='2' and tplembur='BIASA';
            
    select rentang_atas into vr_rentangatas2 from sc_mst.lembur where kdlembur='4' and tplembur='BIASA';
        select rentang_bawah into vr_rentangbawah2 from sc_mst.lembur where kdlembur='4' and tplembur='BIASA';
            select jml_pengkali into vr_pengkali2 from sc_mst.lembur where kdlembur='4' and tplembur='BIASA';
                        
    select rentang_atas into vr_rentangatas3 from sc_mst.lembur where kdlembur='5' and tplembur='BIASA';
        select rentang_bawah into vr_rentangbawah3 from sc_mst.lembur where kdlembur='4' and tplembur='BIASA';
            select jml_pengkali into vr_pengkali3 from sc_mst.lembur where kdlembur='4' and tplembur='BIASA';
    select cast(value3 as character) into vr_tglawal from sc_mst.option where kdoption='STPC1' and trim(nmoption)='SETUP CLOSING AWAL';
    select value3 into vr_tglakhir from sc_mst.option where kdoption='STPC2' and trim(nmoption)='SETUP CLOSING AKHIR';
    
	
	
	
	select cast((substring(periode,3,4)||'-'||substring(periode,1,2)||'-01') as date)  into vr_tglblcawal;
	
	select cast((vr_tglblcawal - interval '1 month') as date) into vr_tglan;

	select cast(to_char(vr_tglan,'YYYY-MM')||'-'||vr_tglawal as date) into vr_tglawalfix;

	
	select cast(vr_tglblcawal as date) into vr_tglanakhir;
	select cast(to_char(vr_tglanakhir,'YYYY-MM')||'-'||vr_tglakhir as date) into vr_tglakhirfix;

	

     
   -- FOR listNik IN select distinct nik from sc_trx.dtljadwalkerja where to_char(tgl,'YYYYMM')=$1 and case when xnik<>'' then nik=xnik else nik<>'' end order by nik
    FOR listNik IN select distinct nik from sc_trx.lembur where to_char(tgl_kerja,'YYYY-MM-DD') between '$vr_tglawalfix' and '$vr_tglakhirfix' and
    case when xnik<>'' then nik=xnik else nik<>'' end order by nik
    LOOP
	    select gajipokok into vr_gaji from sc_mst.karyawan where nik=listNik.nik;

	    select kdlembur,trim(nodok),durasi into vr_jenis,vr_doklembur,vr_durasi from sc_trx.lembur where nik=listNik.nik;	
	    vr_potongan:= (1/173*jml_pengkali1*vr_durasi)*vr_gaji;
	   
	    FOR listJadwal IN select tgl from sc_trx.transready where nik=listNik.nik and to_char(tgl_kerja,'YYYY-MM-DD') between '$vr_tglawalfix' and '$vr_tglakhirfix' order by tgl
	    LOOP
		
		
                      select jam_pulang_absen into vr_jamabsen from sc_trx.transready where nik=listNik.nik and to_char(tgl,'YYYYMMDD')>=to_char(listJadwal.tgl,'YYYYMMDD') and to_char(tgl_selesai,'YYYYMMDD')<=to_char(listJadwal.tgl,'YYYYMMDD');
			
                      
		      IF (coalesce(vr_doklembur,'')<>'') THEN --lembur
		       
		          update sc_tmp.detail_lembur set nominal=vr_potongan where   nodok=dokno and nodok_ref=vr_doklembur;
		      ELSEIF (coalesce(vr_doklembur,'')='') then 
			 update sc_tmp.detail_lembur set nominal=0 where  nodok=dokno and nodok_ref=vr_doklembur;		
		  	           		           
                      END IF;
                   
                      
		       
		
	    END LOOP;
	    
    END LOOP;
    
    RETURN vr_tgl;
END;
$$;

alter function lihat_lembur(char, char, char) owner to postgres;

