CREATE TRIGGER "number_tmp_aupd_status_f" AFTER UPDATE OF "status" ON "number_tmp" WHEN [NEW].[status] = 'F'
OR  [NEW].[status] = 'f'
BEGIN
    INSERT INTO [number_mst]
        ([branch],
        [userid],
        [documen],
        [part],
        [count],
        [prefix],
        [suffix],
        [docno],
        [increment],
        [comparison],
        [upload],
        [status])
        SELECT [branch],
        [userid],
        [documen],
        [part],
        [count],
        [prefix],
        [suffix],
        [docno],
        [increment],
        [comparison],
        [upload],
        [OLD].[status] as [status]
    FROM   [number_tmp]
    WHERE  [branch] = [NEW].[branch]
    AND [userid]= [NEW].[userid]
    AND [documen] = [NEW].[documen]
    AND [part] = [NEW].[part];
    DELETE FROM
        [number_tmp]
    WHERE  [branch] = [NEW].[branch]
    AND [userid]= [NEW].[userid]
    AND [documen] = [NEW].[documen]
    AND [part] = [NEW].[part];
END;

