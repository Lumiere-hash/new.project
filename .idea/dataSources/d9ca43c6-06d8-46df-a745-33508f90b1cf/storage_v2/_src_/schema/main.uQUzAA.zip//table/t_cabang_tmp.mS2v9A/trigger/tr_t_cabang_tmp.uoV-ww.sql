CREATE TRIGGER "tr_t_cabang_tmp"
AFTER INSERT
ON "t_cabang_tmp"
BEGIN
  -- Type the SQL Here.
			insert into t_cabang_mst
			(
			fc_branch,
			fc_groupcabang,
			fv_name,
			fv_add1,
			fv_add2,
			fv_city,
			fv_area,
			fv_email,
			fv_contac,
			fv_directory,
			fc_default,
			fc_statusprs,
			fd_prsdate,
			fd_potrfdate,
			fd_bpbtrfdate,
			fd_stktrfdate,
			fd_suptrfdate,
			fc_statustrf,
			fc_corporate,
			fc_active
			) select 
			fc_branch,
			fc_groupcabang,
			fv_name,
			fv_add1,
			fv_add2,
			fv_city,
			fv_area,
			fv_email,
			fv_contac,
			fv_directory,
			fc_default,
			fc_statusprs,
			fd_prsdate,
			fd_potrfdate,
			fd_bpbtrfdate,
			fd_stktrfdate,
			fd_suptrfdate,
			fc_statustrf,
			fc_corporate,
			fc_active
			from t_cabang_tmp where trim(fc_groupcabang) not in (select trim(fc_groupcabang) from t_cabang_mst) and trim(fc_groupcabang) = trim(new.fc_groupcabang);
END;

