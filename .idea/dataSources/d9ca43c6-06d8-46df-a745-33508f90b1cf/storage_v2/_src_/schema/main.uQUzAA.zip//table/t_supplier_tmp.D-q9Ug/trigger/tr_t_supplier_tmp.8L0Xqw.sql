CREATE TRIGGER "tr_t_supplier_tmp"
AFTER INSERT
ON "t_supplier_tmp"
BEGIN
  -- Type the SQL Here.

	insert into t_supplier_mst
(
fc_branch,
fc_suppcode,
fv_suppname,
fv_suppadd1,
fv_suppadd2,
fv_suppcity,
fc_suppzip,
fv_supppro,
fv_supptel,
fv_supptfax,
fd_updatedate,
fc_updateby,
fd_inputdate,
fc_supphold,
fd_lastpurch,
fd_lasttrx,
fm_crdlimit,
fm_totalpo,
fm_totalap,
fc_status,
ft_note1,
ft_note2,
fv_npwp,
fd_pkp,
fv_pkpname,
fm_cashtitip,
fm_pdctitip,
fc_supptype,
fc_pps,
fc_pph22,
fm_pph22

)
select
fc_branch,
fc_suppcode,
fv_suppname,
fv_suppadd1,
fv_suppadd2,
fv_suppcity,
fc_suppzip,
fv_supppro,
fv_supptel,
fv_supptfax,
fd_updatedate,
fc_updateby,
fd_inputdate,
fc_supphold,
fd_lastpurch,
fd_lasttrx,
fm_crdlimit,
fm_totalpo,
fm_totalap,
fc_status,
ft_note1,
ft_note2,
fv_npwp,
fd_pkp,
fv_pkpname,
fm_cashtitip,
fm_pdctitip,
fc_supptype,
fc_pps,
fc_pph22,
fm_pph22
from t_supplier_tmp where /*trim(fc_suppcode) not in (select trim(fc_suppcode) from t_supplier_mst) and */ trim(fc_suppcode)=trim(new.fc_suppcode);

END;

