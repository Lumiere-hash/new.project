CREATE VIEW "vw_inmst_mob_tmp" AS SELECT 
		a.*,
    trim(coalesce(b.fv_custname,'')) as fv_custname ,
    trim(coalesce(b.fv_custadd1,'')) as fv_custadd1 ,
    trim(coalesce(b.fv_custcity,'')) as fv_custcity 
   FROM (select trim(coalesce(a.rowid        ,'')) as rowid        ,
				trim(coalesce(a.fc_branch    ,'')) as fc_branch    ,
				trim(coalesce(a.fc_trxno     ,'')) as fc_trxno     ,
				trim(coalesce(a.fd_entrydate ,'')) as fd_entrydate ,
				trim(coalesce(a.fc_operator  ,'')) as fc_operator  ,
				trim(coalesce(a.fc_status    ,'')) as fc_status    ,
				trim(coalesce(a.fc_loccode   ,'')) as fc_loccode   ,
				trim(coalesce(a.fc_from      ,'')) as fc_from      ,
				trim(coalesce(a.fc_fromno    ,'')) as fc_fromno    ,
				trim(coalesce(a.fv_reference ,'')) as fv_reference ,
				trim(coalesce(a.fd_reftgl    ,'')) as fd_reftgl    ,
				trim(coalesce(a.fc_fromcode  ,'')) as fc_fromcode  ,
				trim(coalesce(a.fn_item      ,'')) as fn_item      ,
				trim(coalesce(a.fm_netto     ,'')) as fm_netto     ,
				trim(coalesce(a.fm_dpp       ,'')) as fm_dpp       ,
				trim(coalesce(a.fm_ppn       ,'')) as fm_ppn       ,
				trim(coalesce(a.fm_valuestock,'')) as fm_valuestock,
				trim(coalesce(a.fd_updatedate,'')) as fd_updatedate,
				trim(coalesce(a.fc_reason    ,'')) as fc_reason    ,
				trim(coalesce(a.fc_userupd   ,'')) as fc_userupd   ,
				trim(coalesce(a.ft_note      ,'')) as ft_note      ,
				trim(coalesce(a.fn_ppn       ,'')) as fn_ppn       ,
				trim(coalesce(a.fc_idbu      ,'')) as fc_idbu      ,
				trim(coalesce(a.fc_trfwh     ,'')) as fc_trfwh     ,
				trim(coalesce(a.fc_hubrk     ,'')) as fc_hubrk     ,
				trim(coalesce(a.fd_tglconf   ,'')) as fd_tglconf   ,
				trim(coalesce(a.fc_userconf  ,'')) as fc_userconf  ,
				trim(coalesce(a.fn_pph22     ,'')) as fn_pph22     ,
				trim(coalesce(a.fm_ttlpph22  ,'')) as fm_ttlpph22  ,
				trim(coalesce(a.fc_statusgnt ,'')) as fc_statusgnt ,
				trim(coalesce(a.fc_expedisi  ,'')) as fc_expedisi  ,
				trim(coalesce(a.fc_nopol     ,'')) as fc_nopol     ,
				trim(coalesce(a.fc_namedriver,'')) as fc_namedriver,
				trim(coalesce(a.fc_hpdriver  ,'')) as fc_hpdriver  ,
				trim(coalesce(a.fc_franco    ,'')) as fc_franco    ,
				trim(coalesce(a.ft_image     ,'')) as ft_image     ,
				trim(coalesce(b.fv_deskripsi ,'')) as status       ,
				trim(coalesce(c.fc_locaname  ,'')) as locname      ,
				trim(coalesce(c.fc_locaname  ,'')) as fc_locaname  ,
				trim(coalesce(c.fc_locaadd   ,'')) as fc_locaadd   ,
				trim(coalesce(d.fv_deskripsi ,'')) as tipe         ,
				trim(coalesce(f.fv_suppname  ,'')) as fv_suppname  ,
				trim(coalesce(f.fv_suppadd1  ,'')) as fv_suppadd1  ,
				trim(coalesce(f.fv_suppcity  ,'')) as fv_suppcity  ,
				trim(coalesce(g.fv_expdname  ,'')) as fv_expdname  ,
    strftime('%d-%m-%Y',a.fd_entrydate) AS fv_entrydate,
    strftime('%d-%m-%Y',a.fd_reftgl)AS fv_reftgl,
		h.fc_custcode,
		h.fc_potipe from t_inmst_mob_tmp a
     LEFT JOIN t_trxstatus b ON trim(b.fc_trx) = 'BPB' AND trim(a.fc_status) = trim(b.fc_kode)
     LEFT JOIN t_trxtype d ON trim(d.fc_trx) = 'BPB' AND trim(a.fc_from) = trim(d.fc_kode)
     LEFT JOIN t_supplier_mst f ON trim(a.fc_branch) = trim(f.fc_branch) AND trim(a.fc_fromcode) = trim(f.fc_suppcode)
     --LEFT JOIN t_expedisi_mst g ON trim(a.fc_expedisi) = trim(g.fc_expedisi)
     LEFT JOIN vw_t_expedisi_sup g ON trim(a.fc_expedisi) = trim(g.fc_expedisi)
     LEFT JOIN t_pomst_trx h ON trim(a.fc_fromno) = trim(h.fc_pono)
     LEFT JOIN t_gudang_mst c ON trim(c.fc_loccode) = trim(a.fc_loccode)) a
		 LEFT JOIN t_customer_mst b ON trim(a.fc_custcode) = trim(b.fc_custcode);

