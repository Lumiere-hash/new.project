CREATE TRIGGER "tr_t_user_web_tmp_ains"
AFTER INSERT
ON "t_user_web_tmp"
BEGIN
  -- Type the SQL Here.

		insert into t_user_web_mst
		(
			branch,
			nik,
			username,
			passwordweb,
			location,
			level_id,
			level_akses,
			divisi,
			groupuser,
			expdate,
			hold_id,
			inputdate,
			inputby,
			editdate,
			editby,
			lastlogin,
			image,
			idbu,
			status,
			loccode,
			erptype,
			id_device,
			lock_device,
			id_dept,
			nm_dept,
			id_subdept,
			nm_subdept,
			id_jabatan,
			nm_jabatan,
			id_wilayah,
			nm_wilayah,
			nmlengkap
			
		)
			select
			branch,
			nik,
			username,
			passwordweb,
			location,
			level_id,
			level_akses,
			divisi,
			groupuser,
			expdate,
			hold_id,
			inputdate,
			inputby,
			editdate,
			editby,
			lastlogin,
			image,
			idbu,
			'F' as status,
			loccode,
			erptype,
			id_device,
			lock_device,
			id_dept,
			nm_dept,
			id_subdept,
			nm_subdept,
			id_jabatan,
			nm_jabatan,
			id_wilayah,
			nm_wilayah,
			nmlengkap
			from t_user_web_tmp where username not in (select username from t_user_web_mst )and username=NEW.username;


END;

