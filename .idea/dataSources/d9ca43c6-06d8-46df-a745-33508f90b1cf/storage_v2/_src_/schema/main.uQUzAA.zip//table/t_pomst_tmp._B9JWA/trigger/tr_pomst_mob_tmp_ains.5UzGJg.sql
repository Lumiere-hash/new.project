CREATE TRIGGER "tr_pomst_mob_tmp_ains"
AFTER INSERT
ON "t_pomst_tmp"
BEGIN
  -- Type the SQL Here.

insert into t_pomst_trx
		(
					fc_branch,
					fc_pono,
					fd_podate,
					fc_operator,
					fc_postatus,
					fc_potipe,
					fc_employee,
					fc_shiptype,
					fc_shipterm,
					fd_shipdate,
					fn_itempo,
					fn_itemappreq,
					fn_itemappved,
					fn_itemappdelv,
					fn_itempodelv,
					fn_itempodel,
					fd_agepo,
					fc_suppcode,
					fc_custcode,
					fc_shipto,
					fm_ttldisc,
					fm_ttlbrutto,
					fm_ttlnetto,
					fm_ttldpp,
					fm_ttlppn,
					fv_approvedby1,
					fv_approvedby2,
					fc_flagprint,
					ft_note,
					fn_ppn,
					fc_idbu,
					fn_pph22,
					fm_ttlpph22,
					fc_pognt,
					fc_sjgntref,
					fc_createbymobile

		)
			select
					fc_branch,
					fc_pono,
					fd_podate,
					fc_operator,
					fc_postatus,
					fc_potipe,
					fc_employee,
					fc_shiptype,
					fc_shipterm,
					fd_shipdate,
					fn_itempo,
					fn_itemappreq,
					fn_itemappved,
					fn_itemappdelv,
					fn_itempodelv,
					fn_itempodel,
					fd_agepo,
					fc_suppcode,
					fc_custcode,
					fc_shipto,
					fm_ttldisc,
					fm_ttlbrutto,
					fm_ttlnetto,
					fm_ttldpp,
					fm_ttlppn,
					fv_approvedby1,
					fv_approvedby2,
					fc_flagprint,
					ft_note,
					fn_ppn,
					fc_idbu,
					fn_pph22,
					fm_ttlpph22,
					fc_pognt,
					fc_sjgntref,
					fc_createbymobile
			from t_pomst_tmp where trim(fc_pono)=trim(NEW.fc_pono) ;


	insert into t_podtl_trx
	(
				fc_branch,
				fc_pono,
				fc_stockcode,
				fn_nomor,
				fd_pricedate,
				fn_term,
				fn_qty,
				fc_extratype,
				fn_extra,
				fc_kondisi,
				fm_formula,
				fm_pricelist,
				fn_disc1p,
				fn_disc2p,
				fn_disc3p,
				fm_discval,
				fc_excludeppn,
				fm_brutto,
				fm_netto,
				fm_dpp,
				fm_ppn,
				fc_approved,
				fc_approvedref,
				fn_qtydelv,
				fn_extradelv,
				fc_reason,
				fc_status,
				fn_pph22,
				fm_pph22
	)
		select
				fc_branch,
				fc_pono,
				fc_stockcode,
				fn_nomor,
				fd_pricedate,
				fn_term,
				fn_qty,
				fc_extratype,
				fn_extra,
				fc_kondisi,
				fm_formula,
				fm_pricelist,
				fn_disc1p,
				fn_disc2p,
				fn_disc3p,
				fm_discval,
				fc_excludeppn,
				fm_brutto,
				fm_netto,
				fm_dpp,
				fm_ppn,
				fc_approved,
				fc_approvedref,
				fn_qtydelv,
				fn_extradelv,
				fc_reason,
				fc_status,
				fn_pph22,
				fm_pph22
		from t_podtl_tmp where trim(fc_pono)=trim(NEW.fc_pono);
		
			insert into t_popps 
			(
				fc_branch,     
				fc_pono,       
				fn_nomor,      
				fc_kapal,      
				fc_pps,        
				fc_tonase,     
				fc_inputby,    
				fd_inputdate,  
				fc_updateby,   
				fd_updatedate, 
				fc_flag,       
				fc_status,     
				fc_expedisi,   
				fc_kontainerno

			)
				select
				fc_branch,     
				fc_pono,       
				fn_nomor,      
				fc_kapal,      
				fc_pps,        
				fc_tonase,     
				fc_inputby,    
				fd_inputdate,  
				fc_updateby,   
				fd_updatedate, 
				fc_flag,       
				fc_status,     
				fc_expedisi,   
				fc_kontainerno
				from t_popps_tmp where trim(fc_pono) not in (select trim(fc_pono) from t_popps) and trim(fc_pono) = trim(new.fc_pono);
		
		
--delete from t_podtl_tmp where trim(fc_pono)=trim(NEW.fc_pono);
--delete from t_popps_tmp where trim(fc_pono)=trim(NEW.fc_pono);
--delete from t_pomst_tmp where trim(fc_pono)=trim(NEW.fc_pono);


END;

