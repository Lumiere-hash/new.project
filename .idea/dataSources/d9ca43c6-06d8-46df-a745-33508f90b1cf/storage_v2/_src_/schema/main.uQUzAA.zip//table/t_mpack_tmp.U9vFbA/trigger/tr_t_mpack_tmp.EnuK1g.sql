CREATE TRIGGER "tr_t_mpack_tmp"
AFTER INSERT
ON "t_mpack_tmp"
BEGIN
  -- Type the SQL Here.
	insert into t_mpack 
			(
				fc_brand,
				fc_group,
				fc_subgrp,
				fc_type,
				fc_pack,
				fv_packname,
				fc_stocktype,
				fc_packhold,
				fc_editable,
				fc_konsinyasi
			) 
				select
				fc_brand,
				fc_group,
				fc_subgrp,
				fc_type,
				fc_pack,
				fv_packname,
				fc_stocktype,
				fc_packhold,
				fc_editable,
				fc_konsinyasi
				from t_mpack_tmp where trim(fc_brand)=trim(new.fc_brand) and trim(fc_group)=trim(new.fc_group) and 
				trim(fc_subgrp)=trim(new.fc_subgrp) and trim(fc_type)=trim(new.fc_type) and trim(fc_pack)=trim(new.fc_pack);
	
	
END;

