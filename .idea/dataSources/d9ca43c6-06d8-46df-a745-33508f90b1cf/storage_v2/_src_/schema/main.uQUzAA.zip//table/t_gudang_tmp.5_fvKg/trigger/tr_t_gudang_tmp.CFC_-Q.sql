CREATE TRIGGER "tr_t_gudang_tmp"
AFTER INSERT
ON "t_gudang_tmp"
BEGIN
  -- Type the SQL Here.
	insert into t_gudang_mst
(
fc_loccode,
fc_locaname,
fc_locaadd,
fc_locacity,
fc_status,
fc_hold,
fc_flag,
fc_custcode,
fc_sms,
fc_type,
fc_idbu,
fc_reject,
fc_locgnt
)
select
fc_loccode,
fc_locaname,
fc_locaadd,
fc_locacity,
fc_status,
fc_hold,
fc_flag,
fc_custcode,
fc_sms,
fc_type,
fc_idbu,
fc_reject,
fc_locgnt
from t_gudang_tmp where trim(fc_loccode) not in (select trim(fc_loccode) from t_gudang_mst) 
and trim(fc_loccode) = trim(new.fc_loccode);

END;

