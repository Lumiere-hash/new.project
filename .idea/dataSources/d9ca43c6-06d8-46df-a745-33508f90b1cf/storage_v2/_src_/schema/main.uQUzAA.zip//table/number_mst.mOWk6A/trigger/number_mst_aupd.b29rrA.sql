CREATE TRIGGER "number_mst_aupd" AFTER UPDATE OF "comparison" ON "number_mst" WHEN [OLD].[comparison] < [NEW].[comparison]
BEGIN
    UPDATE
        [number_mst]
    SET
        [docno] = '1'
    WHERE [branch] = [NEW].[branch]
    AND [userid]= [NEW].[userid]
    AND [documen] = [NEW].[documen]
    AND [part] = [NEW].[part];
END;

