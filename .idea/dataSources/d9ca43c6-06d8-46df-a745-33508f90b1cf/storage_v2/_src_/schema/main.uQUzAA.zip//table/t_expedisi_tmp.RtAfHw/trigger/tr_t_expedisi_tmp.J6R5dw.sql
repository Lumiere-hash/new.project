CREATE TRIGGER "tr_t_expedisi_tmp"
AFTER INSERT
ON "t_expedisi_tmp"
BEGIN
  -- Type the SQL Here.
	insert into t_expedisi_mst
(
fc_branch,
fc_expedisi,
fv_expdname,
fv_expdadd1,
fv_expdadd2,
fv_expdcity,
fc_expdzip,
fv_epxdpro,
fv_expdtel,
fv_expdfax,
fc_inputby,
fd_inputdate,
fc_updateby,
fd_updatedate,
fc_expdhold,
fd_lasttrx,
fm_crdlimit,
fm_totalclaim,
fm_totalreturn,
fn_patokan,
fm_pricelist,
fc_status,
ft_note1,
ft_note2,
fv_expdnpwp,
fd_expdpkp,
fv_expdpkpname,
fv_ownername,
fv_bankname,
fv_bankacct,
fv_bankarea,
fv_bankcity
) select 
fc_branch,
fc_expedisi,
fv_expdname,
fv_expdadd1,
fv_expdadd2,
fv_expdcity,
fc_expdzip,
fv_epxdpro,
fv_expdtel,
fv_expdfax,
fc_inputby,
fd_inputdate,
fc_updateby,
fd_updatedate,
fc_expdhold,
fd_lasttrx,
fm_crdlimit,
fm_totalclaim,
fm_totalreturn,
fn_patokan,
fm_pricelist,
fc_status,
ft_note1,
ft_note2,
fv_expdnpwp,
fd_expdpkp,
fv_expdpkpname,
fv_ownername,
fv_bankname,
fv_bankacct,
fv_bankarea,
fv_bankcity from t_expedisi_tmp where trim(fc_expedisi) not in (select trim(fc_expedisi) from t_expedisi_mst) and trim(fc_expedisi)=trim(new.fc_expedisi);



END;

