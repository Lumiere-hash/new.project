CREATE TRIGGER "checkin_tmp_aupd_status_c" AFTER UPDATE OF "status" ON "checkin_tmp" WHEN [NEW].[status] = 'C'
OR  [NEW].[status] = 'c'
BEGIN
    DELETE FROM
        [checkin_tmp]
    WHERE
        [branch] = [NEW].[branch]
    AND [checkinid] = [NEW].[checkinid]
    AND [visitdate] = [NEW].[visitdate]
    AND [customeroutletcode] = [NEW].[customeroutletcode];
END;

