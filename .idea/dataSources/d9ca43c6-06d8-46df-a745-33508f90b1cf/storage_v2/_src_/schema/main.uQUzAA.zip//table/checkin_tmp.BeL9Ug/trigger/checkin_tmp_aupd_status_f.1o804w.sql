CREATE TRIGGER "checkin_tmp_aupd_status_f" AFTER UPDATE OF "status" ON "checkin_tmp" WHEN [NEW].[status] = 'F'
OR  [NEW].[status] = 'f'
BEGIN
    INSERT INTO [checkin_trx]
        ([branch], 
        [checkinid], 
        [userid], 
        [checkindate], 
        [visitdate], 
        [customeroutletcode], 
        [customeroutletname], 
        [type], 
        [latitude], 
        [longitude], 
        [inputdate], 
        [inputby], 
        [checkintime], 
        [checkouttime], 
        [description], 
        [upload],
        [status])
        SELECT [branch], 
           [checkinid], 
           [userid], 
           [checkindate], 
           [visitdate], 
           [customeroutletcode], 
           [customeroutletname], 
           [type], 
           [latitude], 
           [longitude], 
           [inputdate], 
           [inputby], 
           [checkintime], 
           [checkouttime], 
           [description], 
           [upload],
           [status]
    FROM   [checkin_tmp]
    WHERE  [branch] = [NEW].[branch]
           AND [checkinid] = [NEW].[checkinid]
           AND [visitdate] = [NEW].[visitdate]
           AND [customeroutletcode] = [NEW].[customeroutletcode];
    DELETE FROM
        [checkin_tmp]
    WHERE
        [branch] = [NEW].[branch]
    AND [checkinid] = [NEW].[checkinid]
    AND [visitdate] = [NEW].[visitdate]
    AND [customeroutletcode] = [NEW].[customeroutletcode];
END;

