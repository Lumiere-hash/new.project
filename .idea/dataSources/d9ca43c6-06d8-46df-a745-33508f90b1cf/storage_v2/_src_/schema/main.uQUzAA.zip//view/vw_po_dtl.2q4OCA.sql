CREATE VIEW "vw_po_dtl" AS 
SELECT 
		a.rowid,
		a.fc_branch,    
    a.fc_pono,
    a.fc_stockcode,
    a.fn_nomor,
    a.fd_pricedate,
    a.fn_term,
    a.fn_qty,
    a.fc_extratype,
    a.fn_extra,
    a.fc_kondisi,
    a.fm_formula,
    a.fm_pricelist,
    a.fn_disc1p,
    a.fn_disc2p,
    a.fn_disc3p,
    a.fm_discval,
    a.fc_excludeppn,
    a.fm_brutto,
    a.fm_netto,
    a.fm_dpp,
    a.fm_ppn,
    a.fc_approved,
    a.fc_approvedref,
    a.fn_qtydelv,
    a.fn_extradelv,
    a.fc_reason,
    a.fc_status,
    a.fn_pph22,
    a.fm_pph22,
    b.fv_stockname AS stockname,
    c.fv_packname AS packname
   FROM ((t_podtl_trx a
     LEFT JOIN t_stock_mst b ON (((trim(a.fc_branch) = trim(b.fc_branch)) AND (trim(a.fc_stockcode) = trim(b.fc_stockcode)))))
     LEFT JOIN t_mpack c ON (((trim(b.fc_brand) = trim(c.fc_brand)) AND (trim(b.fc_group) = trim(c.fc_group)) AND (trim(b.fc_subgrp) = trim(c.fc_subgrp)) AND (trim(b.fc_type) = trim(c.fc_type)) AND (trim(b.fc_pack) = trim(c.fc_pack)))));

