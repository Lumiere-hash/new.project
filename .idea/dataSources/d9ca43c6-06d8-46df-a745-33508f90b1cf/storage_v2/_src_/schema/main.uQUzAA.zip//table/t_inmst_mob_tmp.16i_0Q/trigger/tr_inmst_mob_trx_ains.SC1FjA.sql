CREATE TRIGGER "tr_inmst_mob_trx_ains"
AFTER INSERT
ON "t_inmst_mob_tmp"
WHEN new.fc_status!='IM'
BEGIN
  -- Type the SQL Here.
		
insert into t_inmst_mob_trx
		(
					fc_branch,
					fc_trxno,
					fd_entrydate,
					fc_operator,
					fc_status,
					fc_loccode,
					fc_from,
					fc_fromno,
					fv_reference,
					fd_reftgl,
					fc_fromcode,
					fn_item,
					fm_netto,
					fm_dpp,
					fm_ppn,
					fm_valuestock,
					fd_updatedate,
					fc_reason,
					fc_userupd,
					ft_note,
					fn_ppn,
					fc_idbu,
					fc_trfwh,
					fc_hubrk,
					fd_tglconf,
					fc_userconf,
					fn_pph22,
					fm_ttlpph22,
					fc_statusgnt,
					fc_expedisi,
					fc_nopol,
					fc_namedriver,
					fc_hpdriver,
					fc_franco,
					ft_image

		)
			select
					fc_branch,
					fc_trxno,
					fd_entrydate,
					fc_operator,
					fc_status,
					fc_loccode,
					fc_from,
					fc_fromno,
					fv_reference,
					fd_reftgl,
					fc_fromcode,
					fn_item,
					fm_netto,
					fm_dpp,
					fm_ppn,
					fm_valuestock,
					fd_updatedate,
					fc_reason,
					fc_userupd,
					ft_note,
					fn_ppn,
					fc_idbu,
					fc_trfwh,
					fc_hubrk,
					fd_tglconf,
					fc_userconf,
					fn_pph22,
					fm_ttlpph22,
					fc_statusgnt,
					fc_expedisi,
					fc_nopol,
					fc_namedriver,
					fc_hpdriver,
					fc_franco,
					ft_image
			from t_inmst_mob_tmp where fc_trxno=NEW.fc_trxno AND NEW.fc_status!='IM' ;


	insert into t_indtl_mob_trx
	(
				fc_branch,
				fc_trxno,
				fc_stockcode,
				fn_nomor,
				fn_qty,
				fn_qtyrec,
				fn_extra,
				fn_extrarec,
				fc_reason,
				fm_pricelist,
				fn_disc1p,
				fn_disc2p,
				fn_disc3p,
				fm_formula,
				fc_excludeppn,
				fm_brutto,
				fm_netto,
				fm_dpp,
				fm_ppn,
				fm_valuestock,
				fc_editcost,
				fc_update,
				fc_docno,
				fc_taxin,
				fn_pph22,
				fm_pph22,
				fn_qtygnt,
				fn_extragnt,
				fn_qtygntmp,
				fn_extragntmp,
				ft_note

	)
		select
				fc_branch,
				fc_trxno,
				fc_stockcode,
				fn_nomor,
				fn_qty,
				fn_qtyrec,
				fn_extra,
				fn_extrarec,
				fc_reason,
				fm_pricelist,
				fn_disc1p,
				fn_disc2p,
				fn_disc3p,
				fm_formula,
				fc_excludeppn,
				fm_brutto,
				fm_netto,
				fm_dpp,
				fm_ppn,
				fm_valuestock,
				fc_editcost,
				fc_update,
				fc_docno,
				fc_taxin,
				fn_pph22,
				fm_pph22,
				fn_qtygnt,
				fn_extragnt,
				fn_qtygntmp,
				fn_extragntmp,
				ft_note
		from t_indtl_mob_tmp where trim(fc_trxno)=trim(NEW.fc_trxno)  AND NEW.fc_status!='IM';
		
delete from t_inmst_mob_tmp where trim(fc_trxno)=trim(NEW.fc_trxno) AND NEW.fc_status!='IM';
delete from t_indtl_mob_tmp where trim(fc_trxno)=trim(NEW.fc_trxno) AND NEW.fc_status!='IM';


END;

