create function pr_hanguscuti_nik(nike character) returns SETOF void
    language plpgsql
as
$$
--author by : Fiky Ashariza 12-04-2016
--update by : --
DECLARE vr_sisacuti integer;
DECLARE vr_nik character(12);
DECLARE vr_dokumen character(12);

--DECLARE vr_out integer;


BEGIN

update sc_trx.cuti_blc a set sisacuti=b.balance
		from (select *,sum("in_cuti"-"out_cuti") over(partition by nik order by nik,tanggal,no_dokumen,doctype) as balance
		from sc_trx.cuti_blc) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen and a.doctype=b.doctype;
		

/*	select coalesce(sisacuti,0),a.no_dokumen into vr_sisacuti,vr_dokumen from sc_trx.cuti_blc a,
		(select a.nik,a.tanggal,a.no_dokumen,max(a.doctype) as doctype from sc_trx.cuti_blc a,
		(select a.nik,a.tanggal,max(a.no_dokumen) as no_dokumen from sc_trx.cuti_blc a,
		(select nik,max(tanggal) as tanggal from sc_trx.cuti_blc where nik=vr_nik
		group by nik) as b
		where a.nik=b.nik and a.tanggal=b.tanggal
		group by a.nik,a.tanggal) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen
		group by a.nik,a.tanggal,a.no_dokumen) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen and a.doctype=b.doctype and a.nik=nike;
*/
	vr_sisacuti:=sisacuti from sc_mst.karyawan where nik=nike;
	vr_dokumen:=nike;

	
		IF (vr_sisacuti>0) THEN --cek global jika tak mendapat cuti/cuti minus
		
		insert into sc_trx.cuti_blc values
		(nike,cast(to_char(now(),'yyyy-mm-dd 00:02:02')as timestamp),vr_dokumen,0,vr_sisacuti,0,'HGS','HANGUS');
		END IF;

		
	RETURN;
	

	
END;
$$;

alter function pr_hanguscuti_nik(char) owner to postgres;

