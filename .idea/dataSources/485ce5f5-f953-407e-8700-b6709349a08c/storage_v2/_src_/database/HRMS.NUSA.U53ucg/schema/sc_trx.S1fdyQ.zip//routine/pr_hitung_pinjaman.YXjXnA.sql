create function pr_hitung_pinjaman(vr_param text) returns text
    language plpgsql
as
$$
DECLARE
	/*
		author 		: Fiky Ashariza
		create date	: 2019/05/07
		update date	: 
		update case	: capture pinjaman
		param using	: select select sc_trx.pr_hitung_pinjaman('1115.184'||'|'||'1115.184'||'|'||'1115.184');
		using global	: select sc_trx.pr_hitung_pinjaman('1115.184'||'|'||''||'|'||'1115.184');
	*/
	
    vr_split text;	
    vrs_nama text;	
    vrs_nodok text;	
    vr_branch text :=coalesce(branch,'') from sc_mst.branch where cdefault='YES';
vr_parameter text :='';
	vr_nik char(30); vrs_nik char(30);	vrs_user char(30);vrs_nikmap char(30); vr_sld numeric(18,2);
	vr_param1 text; vr_param2 text; vr_param3 text; vr_opsigaji text;
    	vq_karyawan text := 'select nik from sc_mst.karyawan where coalesce(statuskepegawaian,'''')!=''KO''';
    	vq_inqpinjaman text := 'select * from (
                                  select a.*,b.nmlengkap from sc_trx.payroll_pinjaman_inq a
                                  left outer join sc_mst.karyawan b on a.nik=b.nik) as x where nik is not null' ;
    	vq_txpinjaman text := 'select * from (
                                  select a.*,b.nmlengkap from sc_trx.payroll_pinjaman_mst a
                                  left outer join sc_mst.karyawan b on a.nik=b.nik) as x where nik is not null' ;
    	vr_rec record;
BEGIN

	vrs_nama:=trim(split_part(vr_param, '|', 3));
	vrs_nik:=trim(split_part(vr_param, '|', 2));
	vrs_nodok:=trim(split_part(vr_param, '|', 1));
	vr_param1 := ' and nik ='''||vrs_nik||'''';
	/* cek outstanding */
	--vr_param2 := ' and to_char(tgl_kerja,''YYYY-MM-DD'') between '''||vrs_tglawal||''' and '''||vrs_tglakhir||'''';
	vr_param3 := ' and status in (''P'',''F'',''U'')';
	
    	RAISE NOTICE 'Calling 1(%)', vrs_nik;
    IF (vrs_nik != '' ) then 
     vr_parameter:=vr_param1||vr_param3;
    else 
     vr_parameter:=vr_param3;
    end if;
    
    FOR vr_rec IN EXECUTE vq_txpinjaman||''||vr_parameter -- USING n 
    LOOP


		update sc_trx.payroll_pinjaman_inq a set sld=b.cocoldonkbang
		from (select *,sum("in_sld"-"out_sld") over(partition by nik,docno order by nik,docno,tgl,doctype,docref) as cocoldonkbang
		from sc_trx.payroll_pinjaman_inq) b
		where a.nik=b.nik and a.docno=b.docno and a.tgl=b.tgl and a.doctype=b.doctype and a.docref=b.docref;
		--and a.nik=new.nik and a.tgl>=new.tgl and a.docno=new.docno;
		
		select coalesce(a.sld,0) into vr_sld from sc_trx.payroll_pinjaman_inq a,	
		(select a.nik,a.docno,a.tgl,a.doctype, max(a.docref) as docref from sc_trx.payroll_pinjaman_inq a,	
		(select a.nik,a.docno,a.tgl,max(a.doctype) as doctype from sc_trx.payroll_pinjaman_inq a,
		(select nik,docno,max(tgl) as tgl from sc_trx.payroll_pinjaman_inq where nik=vr_rec.nik  and docno=vr_rec.docno
		group by nik,docno) as b where a.nik=b.nik and a.docno=b.docno and a.tgl=b.tgl
		group by a.nik,a.docno,a.tgl) as b where a.nik=b.nik and a.docno=b.docno and a.tgl=b.tgl and a.doctype=b.doctype
		group by a.nik,a.docno,a.tgl,a.doctype) as b where a.nik=b.nik and a.docno=b.docno and a.tgl=b.tgl and a.doctype=b.doctype and a.docref=b.docref;
		


			--select * from  sc_trx.payroll_pinjaman_inq;
			--select * from  sc_trx.payroll_pinjaman_mst;
		if (vr_sld<=0) then
			update sc_trx.payroll_pinjaman_mst set sisa=0 ,status='U' where docno=vr_rec.docno and nik=vr_rec.nik;
		elseif (vr_sld>0) then
			update sc_trx.payroll_pinjaman_mst set sisa=vr_sld,status='P' where docno=vr_rec.docno and nik=vr_rec.nik;
		end if;
		
	RAISE NOTICE 'Under Loop(%)', vr_rec.docno||vr_rec.nik; 
    END LOOP;
    
    RETURN vr_rec.docno;
END;
$$;

alter function pr_hitung_pinjaman(text) owner to postgres;

