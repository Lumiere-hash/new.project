create function pr_upah_borong_dtl_after() returns trigger
    language plpgsql
as
$$
declare
     
     --vr_nomor char(30);
     
begin
--vr_status:=trim(coalesce(status,'')) from sc_tmp.cuti where branch=new.branch and kddokumen=new.kddokumen for update;
--vr_nomor

--delete from sc_mst.penomoran where userid=new.nodok; 
--insert into sc_mst.penomoran 
        --(userid,dokumen,nomor,errorid,partid,counterid,xno)
        --values(new.nodok,'IJIN-KARYAWAN',' ',0,' ',1,0);

--vr_nomor:=trim(coalesce(nomor,'')) from sc_mst.penomoran where userid=new.nodok;
 --if (trim(vr_nomor)!='') or (not vr_nomor is null) then
	UPDATE sc_trx.upah_borong_mst set total_upah=(select sum(upah_borong)as total_upah from sc_trx.upah_borong_dtl where nodok=new.nodok)
	where nodok=new.nodok;
		
--end if;

return new;

end;
$$;

alter function pr_upah_borong_dtl_after() owner to postgres;

