create function pr_update_nominalborong() returns numeric
    language plpgsql
as
$$
DECLARE 
vr_duit numeric(18,2):=0;
vr_nik char(12);
BEGIN		

FOR vr_nik IN select distinct nik from sc_tmp.payroll_master 
			where kddept='FSL'
			order by nik
			

			
		
    LOOP				

	
		select sum(total_upah) into vr_duit from sc_tmp.cek_borong
		where nik=vr_nik;

		if (vr_duit is null) then 
		vr_duit=0; 
		end if;
		
		--delete from sc_tmp.payroll_detail where nodok=userid and nik=id and no_urut=nomor;

		update sc_tmp.payroll_detail set nominal=vr_duit
		where no_urut=6 and nik=vr_nik;
	
  END LOOP;
	RETURN vr_duit;	
END;
$$;

alter function pr_update_nominalborong() owner to postgres;

