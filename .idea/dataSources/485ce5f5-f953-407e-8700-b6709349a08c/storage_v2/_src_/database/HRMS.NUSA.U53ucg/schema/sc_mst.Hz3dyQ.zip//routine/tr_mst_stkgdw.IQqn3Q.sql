create function tr_mst_stkgdw() returns trigger
    language plpgsql
as
$$
DECLARE 
	--author by fiky: 12/08/2017
	--update by fiky: 12/08/2017

BEGIN		
/* NOTE:
BPB	:	BUKTI PENERIMAAN BARANG:
SO	:	SALES ORDER:
DO	:	DELIVERY ORDER:
PBK	:	PERMINTAAN BARANG KELUAR:
BBK	:	BUKTI BARANG KELUAR:
*/

		--UPDATE SC_MST.STKGDW SET ONHAND='200' WHERE loccode='SBYMRG' and stockcode='PEN000002';
	IF tg_op = 'INSERT' THEN
		if not exists (select * from sc_trx.stgblco where branch=new.branch and loccode=new.loccode 
		and kdgroup=new.kdgroup 
		and stockcode=new.stockcode 
		and stockcode=new.stockcode 
		and doctype='SLD') then
			insert into sc_trx.stgblco (branch,loccode,kdgroup,kdsubgroup,stockcode,trxdate,doctype,docno,docref,qty_in,qty_out,qty_sld,hist,ctype)
			(select branch,loccode,kdgroup,kdsubgroup,stockcode,to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp as trxdate,'SLD','' as docno,'' as docref,
			coalesce(onhand,0) as qty_in,0 as qty_out,0 as qty_sld,null as hist,null as ctype from sc_mst.stkgdw
			where branch=new.branch and loccode=new.loccode and stockcode=new.stockcode and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup);
		end if;
		--select * from sc_trx.stgblco 
		--select * from sc_mst.stkgdw 
		--select * from sc_mst.mbarang
		update sc_mst.mbarang set 
		onhand=(select sum(coalesce(onhand,0)) from sc_mst.stkgdw where  branch=new.branch and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode),
		allocated=(select sum(coalesce(allocated,0)) from sc_mst.stkgdw where  branch=new.branch and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode),
		uninvoiced=(select sum(coalesce(uninvoiced,0)) from sc_mst.stkgdw where  branch=new.branch and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode ),
		tmpalloca=(select sum(coalesce(tmpalloca,0)) from sc_mst.stkgdw where  branch=new.branch and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode)
		where branch=new.branch and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and nodok=new.stockcode ;
		
		RETURN new;
	ELSEIF tg_op = 'UPDATE' THEN
/*
		if not exists (select * from sc_trx.stgblco where branch=new.branch and loccode=new.loccode and stockcode=new.stockcode and doctype='SLD') then
			insert into sc_trx.stgblco (branch,loccode,stockcode,trxdate,doctype,docno,docref,qty_in,qty_out,qty_sld,hist,ctype)
			(select branch,loccode,stockcode,to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp as trxdate,'BBK','' as docno,'' as docref,
			coalesce(onhand,0) as qty_in,0 as qty_out,0 as qty_sld,null as hist,null as ctype from sc_mst.stkgdw
			where branch=new.branch and loccode=new.loccode and stockcode=new.stockcode );
		end if;
*/
		update sc_mst.mbarang set 
		onhand=(select sum(coalesce(onhand,0)) from sc_mst.stkgdw where  branch=new.branch and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode),
		allocated=(select sum(coalesce(allocated,0)) from sc_mst.stkgdw where  branch=new.branch and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode),
		uninvoiced=(select sum(coalesce(uninvoiced,0)) from sc_mst.stkgdw where  branch=new.branch and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode ),
		tmpalloca=(select sum(coalesce(tmpalloca,0)) from sc_mst.stkgdw where  branch=new.branch and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode)
		where branch=new.branch and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and nodok=new.stockcode ;
		
		RETURN NEW;
	ELSEIF tg_op = 'DELETE' THEN
		update sc_mst.mbarang set 
		onhand=(select sum(coalesce(onhand,0)) from sc_mst.stkgdw where  branch=old.branch and kdgroup=old.kdgroup and kdsubgroup=old.kdsubgroup and stockcode=old.stockcode),
		allocated=(select sum(coalesce(allocated,0)) from sc_mst.stkgdw where  branch=old.branch and kdgroup=old.kdgroup and kdsubgroup=old.kdsubgroup and stockcode=old.stockcode),
		uninvoiced=(select sum(coalesce(uninvoiced,0)) from sc_mst.stkgdw where branch=old.branch and kdgroup=old.kdgroup and kdsubgroup=old.kdsubgroup and stockcode=old.stockcode),
		tmpalloca=(select sum(coalesce(tmpalloca,0)) from sc_mst.stkgdw where branch=old.branch and kdgroup=old.kdgroup and kdsubgroup=old.kdsubgroup and stockcode=old.stockcode)
		where branch=old.branch and kdgroup=old.kdgroup and kdsubgroup=old.kdsubgroup and nodok=old.stockcode ;
		
		RETURN old;	
	END IF;
	
END;
$$;

alter function tr_mst_stkgdw() owner to postgres;

