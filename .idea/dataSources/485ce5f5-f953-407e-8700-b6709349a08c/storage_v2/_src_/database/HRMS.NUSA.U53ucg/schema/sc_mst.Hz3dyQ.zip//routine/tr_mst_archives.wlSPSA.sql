create function tr_mst_archives() returns trigger
    language plpgsql
as
$$
DECLARE 
	--author by fiky: 12/08/2017
	--update by fiky: 12/10/2017
	vr_nomor character(20);
	vr_lastdoc numeric;

BEGIN		
/* NOTE:
BPB	:	BUKTI PENERIMAAN BARANG:
SO	:	SALES ORDER:
DO	:	DELIVERY ORDER:
PBK	:	PERMINTAAN BARANG KELUAR:
BBK	:	BUKTI BARANG KELUAR:
*/

		--select * from sc_mst.archives
		
		--select * from sc_mst.nomor
		--select * from sc_mst.penomoran
		--insert into sc_mst.nomor (dokumen,part,count3,prefix,sufix,docno,userid,modul,periode,cekclose) values ('M_ARSIP','',4,'','',1,'FIKY','','201817','F');
		--delete from sc_mst.penomoran
		--delete from sc_mst.archives
	IF tg_op = 'INSERT' THEN

			
			vr_lastdoc:=case 
			when max((right(trim(docno),4))) is null or max((right(trim(docno),4)))='' then '0'
			else max((right(trim(docno),4))) end lastdoc
			from sc_mst.archives
			where trim(docno)!=trim(new.docno) and docdate!=new.docdate;

			update sc_mst.nomor set docno=vr_lastdoc where dokumen='M_ARSIP';
				
			delete from sc_mst.penomoran where trim(userid)=trim(new.inputby) and trim(dokumen)='M_ARSIP';	
			insert into sc_mst.penomoran 
			(userid,dokumen,nomor,errorid,partid,counterid,xno)
			values(trim(new.inputby),'M_ARSIP',' ',0,' ',1,0);

			vr_nomor:=trim(coalesce(nomor,'')) from sc_mst.penomoran where trim(userid)=trim(new.inputby) and trim(dokumen)='M_ARSIP';

			update sc_mst.archives set docno=new.kdgroup||'.'||new.kdsubgroup||'.'||vr_nomor
			where inputby=trim(new.inputby) and inputdate=new.inputdate;
			
				
		RETURN new;
	ELSEIF tg_op = 'UPDATE' THEN

		
		RETURN NEW;
	ELSEIF tg_op = 'DELETE' THEN

		RETURN old;	
	END IF;
	
END;
$$;

alter function tr_mst_archives() owner to postgres;

