create function pr_koreksicb_after_update() returns trigger
    language plpgsql
as
$$
declare
--@author : Fiky Ashariza
--@update by : Fiky Ashariza
--@update date : 28-01-2019

	vr_type char(12);
begin
	--select * from sc_trx.cutibersama
	/*IF (tg_op = 'INSERT') THEN
		insert into sc_tmp.cuti_blc
		select nik,cast(to_char(now(),'dd-mm-yyyy HH24:MM:SS')as timestamp) as tanggal,trim(new.nodok) as no_dokumen,0 as in_cuti,new.jumlahcuti as out_cuti,0 as sisacuti,'OUT' as doctype,'F' as status
		from sc_mst.karyawan;

	return new;
	*/

	IF (tg_op = 'INSERT') THEN
		vr_type:=trim(coalesce(new.doctype,''));
			IF (vr_type='X') THEN -- CUTI KHUSUS

			ELSEIF (vr_type='Y') THEN -- CUTI BERSAMA
				update sc_trx.koreksicb a set
				tgl_awal=b.tgl_awal,
				jumlahcuti=b.jumlahcuti,
				tgl_akhir=b.tgl_akhir
				from sc_trx.cutibersama b where a.docref=b.nodok and a.nodok=new.nodok;
			END IF;

	ELSEIF (tg_op = 'UPDATE') THEN
		vr_type:=trim(coalesce(new.doctype,''));
		if (new.status='P' and old.status='I') then
			IF (vr_type='X') THEN --CEK DOKUMEN UNTUK KOREKSI KONDISI KHUSUS
				if (new.operator='+') then
					insert into sc_trx.cuti_blc --blc
					select nik,new.tgl_dok as tanggal,new.nodok as no_dokumen,new.jumlahcuti as in_cuti,0 as out_cuti,0 as sisacuti,'IN' as doctype,'F' as status
					from sc_mst.karyawan where nik=new.nik;
				else
					insert into sc_trx.cuti_blc --blc
					select nik,new.tgl_dok as tanggal,new.nodok as no_dokumen,0 as in_cuti,new.jumlahcuti as out_cuti,0 as sisacuti,'OUT' as doctype,'F' as status
					from sc_mst.karyawan where nik=new.nik;
				end if;


			ELSEIF (vr_type='Y') THEN
				if (new.operator='+') then
					insert into sc_trx.cuti_blc
					select nik,new.tgl_dok as tanggal,new.nodok as no_dokumen,new.jumlahcuti as in_cuti, 0 as out_cuti,0 as sisacuti,'IN' as doctype,'F' as status
					from sc_mst.karyawan where nik=new.nik;
				else
					insert into sc_trx.cuti_blc
					select nik,new.tgl_dok as tanggal,new.nodok as no_dokumen,0 as in_cuti, new.jumlahcuti as out_cuti,0 as sisacuti,'OUT' as doctype,'F' as status
					from sc_mst.karyawan where nik=new.nik;
				end if;

			END IF;
		elseif (new.status='C' and old.status='I') then /* PEMBATALAN SEBELUM SUKSES APPROV */
				--NO OPERATION TRIGGERED
                elseif (new.status='C' and old.status='P') then /* PEMBATALAN SETELAH SUKSES APPROV */
			delete from sc_trx.cuti_blc where no_dokumen=old.nodok ;
		end if;
	return new;
	ELSEIF (tg_op = 'DELETE') THEN
		delete from sc_trx.cuti_lalu where no_dokumen=old.nodok and nik=old.nik;
		delete from sc_trx.cuti_blc where no_dokumen=old.nodok and nik=old.nik;

	return old;
	END IF;
	PERFORM sc_trx.pr_rekap_cutiblcall();
	return null;
end;

$$;

alter function pr_koreksicb_after_update() owner to postgres;

