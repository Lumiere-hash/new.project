create function tr_mst_msubasuransi() returns trigger
    language plpgsql
as
$$
DECLARE 
	--author by fiky: 12/08/2017
	--update by fiky: 12/10/2017
	vr_nomor character(20);
	vr_lastdoc character(20);

BEGIN		
/* NOTE:
BPB	:	BUKTI PENERIMAAN BARANG:
SO	:	SALES ORDER:
DO	:	DELIVERY ORDER:
PBK	:	PERMINTAAN BARANG KELUAR:
BBK	:	BUKTI BARANG KELUAR:
*/

		--UPDATE SC_MST.STKGDW SET ONHAND='200' WHERE loccode='SBYMRG' and stockcode='PEN000002';
	IF tg_op = 'INSERT' THEN

			/*
			select * from sc_mst.nomor
			select * from sc_mst.penomoran
			insert into sc_mst.nomor (dokumen,part,count3,prefix,docno,cekclose)
			values ('M_SUBASURANSI','',4,'',5,'F'); */

			--vr_lastdoc:=0;

			/*vr_lastdoc:=case 
			when max((right(trim(kdsubasuransi),4))) is null or max((right(trim(kdsubasuransi),4)))='' then '0'
			else max((right(trim(kdsubasuransi),4)))end lastdoc
			from sc_mst.msubasuransi
			where kdasuransi=new.kdasuransi;*/

			vr_lastdoc:=coalesce(max(trim(coalesce(trim(split_part(trim(kdsubasuransi),'.',2)),'0'))),'0')::character(20) from sc_mst.msubasuransi where kdasuransi=new.kdasuransi and kdsubasuransi<>'';
			--coalesce(max((right(trim(coalesce(kdsubasuransi,'0')),4))),'0')::numeric from sc_mst.msubasuransi where kdasuransi=new.kdasuransi;



			--select coalesce(trim(split_part(trim(max(kdsubasuransi)),'.',2)),'0')::numeric from sc_mst.msubasuransi 
			--where kdasuransi=new.kdasuransi;

			
----select coalesce(max((right(trim(coalesce(kdsubasuransi,'0')),4))),'0')::numeric from sc_mst.msubasuransi where kdasuransi='xx';



			---select '0001'::numeric

			/*select case 
			when max((right(trim(kdsubasuransi),4))) is null or max((right(trim(kdsubasuransi),4)))='' then '0'
			else trim(max((right(trim(kdsubasuransi),4)))) end lastdoc
			from sc_mst.msubasuransi
			where kdasuransi=new.kdasuransi; */




			--RAISE NOTICE 'Calling cs_create_job(%)', vr_lastdoc;
			--select * from sc_mst.nomor
			update sc_mst.nomor set docno=vr_lastdoc::numeric where dokumen='M_SUBASURANSI';
				
			delete from sc_mst.penomoran where userid=new.inputby and dokumen='M_SUBASURANSI';	
			insert into sc_mst.penomoran 
			(userid,dokumen,nomor,errorid,partid,counterid,xno)
			values(new.inputby,'M_SUBASURANSI',' ',0,' ',1,0);

			vr_nomor:=trim(coalesce(nomor,'')) from sc_mst.penomoran where userid=new.inputby and dokumen='M_SUBASURANSI';

			update sc_mst.msubasuransi set kdsubasuransi=kdasuransi||'.'||vr_nomor
			where kdasuransi=new.kdasuransi and inputby=new.inputby and inputdate=new.inputdate;
			
				
		RETURN new;
	ELSEIF tg_op = 'UPDATE' THEN

		
		RETURN NEW;
	ELSEIF tg_op = 'DELETE' THEN
				/*update  sc_mst.msubasuransi a set id=a1.urutnya,kdsubsupplier=
				case 
				when length(a1.urutnya::char)=1 then a1.kdsupplier||'.'||'000'||a1.urutnya
				when length(a1.urutnya::char)=2 then a1.kdsupplier||'.'||'00'||a1.urutnya
				when length(a1.urutnya::char)=3 then a1.kdsupplier||'.'||'0'||a1.urutnya
				when length(a1.urutnya::char)=4 then a1.kdsupplier||'.'||a1.urutnya end 
				
				from (select a1.*,row_number() over(partition by kdsupplier order by inputdate asc) as urutnya
				from sc_mst.msubasuransi  a1) a1
				where a.id=a1.id and a.inputdate>=a1.inputdate and  a.kdsupplier=a1.kdsupplier; */
		RETURN old;	
	END IF;
	
END;
$$;

alter function tr_mst_msubasuransi() owner to postgres;

