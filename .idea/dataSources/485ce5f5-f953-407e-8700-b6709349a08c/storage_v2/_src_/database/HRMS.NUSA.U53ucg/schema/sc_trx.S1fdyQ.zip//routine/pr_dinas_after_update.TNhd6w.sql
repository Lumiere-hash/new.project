create function pr_dinas_after_update() returns trigger
    language plpgsql
as
$$
declare
     
     /* PENAMBAHAN APPROVAL */
     
begin


--select old.status;
if (new.status='P')and(old.status='A') then 

--select * from sc_trx.lembur

	/*---SELF SMS----*/
	insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
	select b.nohp1,			
	'Sdr/i '||b.nmlengkap||' Dinas no. '||a.nodok||' Telah Di Setujui,Tgl : '||to_char(tgl_mulai,'DD-MM-YYYY')||' s/d '||to_char(tgl_selesai,'DD-MM-YYYY')
	,nmlengkap
	from sc_trx.dinas a
	left outer join sc_mst.karyawan b on a.nik=b.nik
	where a.nodok=new.nodok and b.nohp1 is not null;

	/*---SMS KE HRD----*/	
	insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
	select telepon,isi,creator from (
	select telepon,'Dinas no : '||nodok||' '||nmlengkap||' tgl: '||to_char(tgl_mulai,'DD-MM-YYYY')||' s/d '||to_char(tgl_selesai,'DD-MM-YYYY')||' Telah Di setujui' as isi,'OSIN' as creator  from
	(select t0.*,trim(t3.nohp1) as telepon,t1.nodok,t1.nik,t1.nmlengkap,t1.tgl_mulai,t1.tgl_selesai,t1.nik as nik from sc_mst.notif_sms t0
	left outer join (select	case b.kdcabang	when 'SBYMRG' then 'Y'	end as kanwil_sby,
				case b.kdcabang	when 'SMGDMK' then 'Y'	end as kanwil_dmk,
				case b.kdcabang	when 'SMGCND' then 'Y'	end as kanwil_smg,
				case b.kdcabang	when 'JKTKPK' then 'Y'	end as kanwil_jkt,
				a.*,b.nmlengkap from sc_trx.dinas a
			left outer join sc_mst.karyawan b on a.nik=b.nik
			where nodok=new.nodok 
			) as t1
			on t0.kanwil_sby=t1.kanwil_sby or
			t0.kanwil_smg=t1.kanwil_smg or
			t0.kanwil_dmk=t1.kanwil_dmk or
			t0.kanwil_jkt=t1.kanwil_jkt
	left outer join sc_mst.karyawan t3 on t0.nik=t3.nik		
	where dinas='Y') as t2 ) as t3
	where telepon is not null and isi is not null and creator is not null;

	/* SMS KE ATASAN 1&2 */
	insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
	select telepon,textdecoded,nmlengkap from 
	(select c.nohp1 as telepon,			
	'Sdr/i '||a.nmlengkap||' Dinas no. '||b.nodok||' Di Setujui,TGL :'||to_char(tgl_mulai,'DD-MM-YYYY')||' s/d '||to_char(tgl_selesai,'DD-MM-YYYY') as textdecoded
	,a.nmlengkap,a.nik,b.nodok
	from sc_mst.karyawan a  
	left outer join  sc_trx.dinas b on b.nik=a.nik
	left outer join  sc_mst.karyawan c on a.nik_atasan=c.nik
	left outer join  sc_mst.karyawan d on a.nik_atasan2=d.nik where b.nodok is not null
	union all
	select d.nohp1 as telepon,			
	'Sdr/i '||a.nmlengkap||' Dinas no. '||b.nodok||' Di Setujui,TGL :'||to_char(tgl_mulai,'DD-MM-YYYY')||' s/d '||to_char(tgl_selesai,'DD-MM-YYYY') as textdecoded
	,a.nmlengkap,a.nik,b.nodok
	from sc_mst.karyawan a  
	left outer join  sc_trx.dinas b on b.nik=a.nik
	left outer join  sc_mst.karyawan c on a.nik_atasan=c.nik
	left outer join  sc_mst.karyawan d on a.nik_atasan2=d.nik where b.nodok is not null) as x
	where nodok=new.nodok and telepon is not null and textdecoded is not null and nmlengkap is not null;

	update sc_trx.approvals_system set status='U',asstatus='P' where docno = new.nodok and status!='U';
	
elseif (new.status='C')and(old.status='P') then 
	/*---SELF SMS----*/
	insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
	select b.nohp1,			
	'Sdr/i '||b.nmlengkap||' Dinas no. '||a.nodok||' Dibatalkan,Tgl : '||to_char(tgl_mulai,'DD-MM-YYYY')||' s/d '||to_char(tgl_selesai,'DD-MM-YYYY')
	,nmlengkap
	from sc_trx.dinas a
	left outer join sc_mst.karyawan b on a.nik=b.nik
	where a.nodok=new.nodok and b.nohp1 is not null;

	/*---SMS KE HRD----*/	
	insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
	select telepon,isi,creator from (
	select telepon,'Dinas no : '||nodok||' '||nmlengkap||' tgl: '||to_char(tgl_mulai,'DD-MM-YYYY')||' s/d '||to_char(tgl_selesai,'DD-MM-YYYY')||' Di batalkan' as isi,'OSIN' as creator from
	(select t0.*,trim(t3.nohp1) as telepon,t1.nodok,t1.nik,t1.nmlengkap,t1.tgl_mulai,t1.tgl_selesai,t1.nik as nik from sc_mst.notif_sms t0
	left outer join (select	case b.kdcabang	when 'SBYMRG' then 'Y'	end as kanwil_sby,
				case b.kdcabang	when 'SMGDMK' then 'Y'	end as kanwil_dmk,
				case b.kdcabang	when 'SMGCND' then 'Y'	end as kanwil_smg,
				case b.kdcabang	when 'JKTKPK' then 'Y'	end as kanwil_jkt,
				a.*,b.nmlengkap from sc_trx.dinas a
			left outer join sc_mst.karyawan b on a.nik=b.nik
			where nodok=new.nodok 
			) as t1
			on t0.kanwil_sby=t1.kanwil_sby or
			t0.kanwil_smg=t1.kanwil_smg or
			t0.kanwil_dmk=t1.kanwil_dmk or
			t0.kanwil_jkt=t1.kanwil_jkt
	left outer join sc_mst.karyawan t3 on t0.nik=t3.nik		
	where dinas='Y') as t2) as t3
	where telepon is not null and isi is not null and creator is not null;

	/* SMS KE ATASAN 1&2 */
	insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
	select telepon,textdecoded,nmlengkap from 
	(select c.nohp1 as telepon,			
	'Sdr/i '||a.nmlengkap||' Dinas no. '||b.nodok||' Dibatalkan,TGL :'||to_char(tgl_mulai,'DD-MM-YYYY')||' s/d '||to_char(tgl_selesai,'DD-MM-YYYY') as textdecoded
	,a.nmlengkap,a.nik,b.nodok
	from sc_mst.karyawan a  
	left outer join  sc_trx.dinas b on b.nik=a.nik
	left outer join  sc_mst.karyawan c on a.nik_atasan=c.nik
	left outer join  sc_mst.karyawan d on a.nik_atasan2=d.nik where b.nodok is not null
	union all
	select d.nohp1 as telepon,			
	'Sdr/i '||a.nmlengkap||' Dinas no. '||b.nodok||' Dibatalkan,TGL :'||to_char(tgl_mulai,'DD-MM-YYYY')||' s/d '||to_char(tgl_selesai,'DD-MM-YYYY') as textdecoded
	,a.nmlengkap,a.nik,b.nodok
	from sc_mst.karyawan a  
	left outer join  sc_trx.dinas b on b.nik=a.nik
	left outer join  sc_mst.karyawan c on a.nik_atasan=c.nik
	left outer join  sc_mst.karyawan d on a.nik_atasan2=d.nik where b.nodok is not null) as x
	where nodok=new.nodok and telepon is not null and textdecoded is not null and nmlengkap is not null ;
	
	update sc_trx.approvals_system set status='C',asstatus='C' where docno = new.nodok and status!='C';
	
elseif ((new.status='C')and(old.status='A'))  then
	/*---SELF SMS----*/
	insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
	select b.nohp1,			
	'Sdr/i '||b.nmlengkap||' Dinas no. '||a.nodok||' Ditolak/Dibatalkan,Tgl : '||to_char(tgl_mulai,'DD-MM-YYYY')||' s/d '||to_char(tgl_selesai,'DD-MM-YYYY')
	,nmlengkap
	from sc_trx.dinas a
	left outer join sc_mst.karyawan b on a.nik=b.nik
	where a.nodok=new.nodok and b.nohp1 is not null;

	update sc_trx.approvals_system set status='C',asstatus='C' where docno = new.nodok and status!='C';
/* RESEND SMS */
elseif (new.status='M')and(old.status='A') then 
					--Dinas SMS	
	insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
	select telepon,left(sms,160),pengirim from 
	(select c.nohp1 as telepon,
'No. Dinas: '||a.nodok||'
Nama: '||b.nmlengkap||'
Tgl Awal: '||to_char(tgl_mulai,'DD-MM-YYYY')||' s/d Tgl Akhir: '||to_char(tgl_selesai,'DD-MM-YYYY')||'
Conf: Y/N
Ket Tujuan: '||tujuan as sms,
	'OSIN' as pengirim
	from sc_trx.dinas a
	left outer join sc_mst.karyawan b on a.nik=b.nik
	left outer join sc_mst.karyawan c on c.nik=b.nik_atasan
	where nodok=new.nodok
	) as t1;
	update sc_trx.dinas set status=old.status where nodok=new.nodok;
elseif (new.status='A' and old.status='I') then

	delete from sc_mst.trxerror where modul='DINAS' and userid=new.input_by;
	insert into sc_mst.trxerror
	(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
	(new.input_by,0,new.nodok,'','DINAS');

perform sc_trx.pr_capture_approvals_system();
end if;
return new;

end;
$$;

alter function pr_dinas_after_update() owner to postgres;

