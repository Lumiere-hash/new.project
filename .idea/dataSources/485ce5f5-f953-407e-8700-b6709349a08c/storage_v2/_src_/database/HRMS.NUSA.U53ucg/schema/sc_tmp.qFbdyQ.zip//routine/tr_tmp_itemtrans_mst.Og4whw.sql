create function tr_tmp_itemtrans_mst() returns trigger
    language plpgsql
as
$$
DECLARE 
	--author by fiky: 12/10/2017
	--update by fiky: 12/10/2017
     vr_nomor char(15); 
     vr_cekprefix char(15);
     vr_nowprefix char(15);  
          vr_id_dtl numeric;
          vr_qtybbm numeric;
          vr_qtybbmkecil numeric;
     vr_kdgroup char(100);
     vr_kdsubgroup char(100);
     vr_stockcode char(100);
BEGIN		
	IF tg_op = 'INSERT' THEN
		--select * from sc_tmp.itemtrans_mst where nodok is null
		/*IF NOT EXISTS(select * from sc_tmp.stpbk_mst where nodok=new.nodok and nik=new.nik) THEN
			insert into sc_tmp.stpbk_mst 
			(branch,nodok,nodokref,nik,loccode,status,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby)
			(select branch,nodok,nodokref,nik,loccode,status,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby
			from sc_tmp.itemtrans_mst where nodok=new.nodok and nik=new.nik);
		END IF; */
	
		RETURN new;
	ELSEIF tg_op = 'UPDATE' THEN

		IF (OLD.STATUS='I' AND NEW.STATUS='F') THEN
			delete from sc_mst.penomoran where userid=new.nodok;
			delete from sc_mst.trxerror where userid=new.nodok;    


			--select trim(split_part(trim(prefix),'TRG',2))as cekprefix into vr_cekprefix from sc_mst.nomor where dokumen='ITEMTRANS';
			select to_char(nodok_date,'YYMM') cekprefix into vr_cekprefix from sc_tmp.itemtrans_mst where nodok=new.nodok;
			select to_char(now(),'YYMM') as cekbulan into vr_nowprefix;
			if(vr_nowprefix<>vr_cekprefix) then 
				update sc_mst.nomor set prefix='TRG'||vr_nowprefix,docno=0 where dokumen='ITEMTRANS';
			end if;
			insert into sc_mst.penomoran 
			(userid,dokumen,nomor,errorid,partid,counterid,xno)
			values(new.nodok,'ITEMTRANS',' ',0,' ',1,0);
			vr_nomor:=trim(coalesce(nomor,'')) from sc_mst.penomoran where userid=new.nodok;
	
			insert into sc_trx.itemtrans_mst
			(branch,nodok,nodokref,loccode,loccode_destination,itemtrans_type,itemtrans_category,description,nodok_date,totalprice,inputdate,inputby,
			updatedate,updateby,approvaldate,approvalby,hangusdate,hangusby,canceldate,cancelby,nodoktmp,status)
			(select branch,vr_nomor,nodokref,loccode,loccode_destination,itemtrans_type,itemtrans_category,description,nodok_date,totalprice,inputdate,inputby,
			updatedate,updateby,approvaldate,approvalby,hangusdate,hangusby,canceldate,cancelby,nodoktmp,'A' as status from sc_tmp.itemtrans_mst where nodok=new.nodok);


			insert into sc_trx.itemtrans_dtl
			(branch,nodok,kdgroup,kdsubgroup,stockcode,id,nodokref,loccode,loccode_destination,itemtrans_type,itemtrans_category,qty,qtybbm,satkecil,
			description,qtyonhand,inputby,inputdate,qtyunitprice,qtytotalprice,nodoktmp,status,qty_tmp)
			(select branch,vr_nomor,kdgroup,kdsubgroup,stockcode,id,nodokref,loccode,loccode_destination,itemtrans_type,itemtrans_category,coalesce(qty,0),coalesce(qtybbm,0),satkecil,
			description,qtyonhand,inputby,inputdate,qtyunitprice,qtytotalprice,nodoktmp,'A' as status,qty_tmp from sc_tmp.itemtrans_dtl where nodok=new.nodok);

			/* update '' untuk tidak mengurangi stock onhand per item detail */
			update sc_tmp.itemtrans_dtl set status='' where nodok=new.nodok;
			
			delete from sc_tmp.itemtrans_mst where nodok=new.nodok;
			delete from sc_tmp.itemtrans_dtl where nodok=new.nodok;
			

			delete from sc_mst.trxerror where modul='ITEMTRANS';
			insert into sc_mst.trxerror
			(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
			(new.nodok,0,vr_nomor,'','ITEMTRANS');
	
		ELSEIF (OLD.STATUS='E' AND NEW.STATUS='F') THEN
			delete from sc_trx.itemtrans_mst where nodok=new.nodoktmp;
			delete from sc_trx.itemtrans_dtl where nodok=new.nodoktmp;
			
			/* update E KE F untuk update stock onhand per item detail */
			update sc_tmp.itemtrans_dtl set status='F' where nodok=new.nodok;
			
			insert into sc_trx.itemtrans_mst
			(branch,nodok,nodokref,loccode,loccode_destination,itemtrans_type,itemtrans_category,description,nodok_date,totalprice,inputdate,inputby,
			updatedate,updateby,approvaldate,approvalby,hangusdate,hangusby,canceldate,cancelby,nodoktmp,status)
			(select branch,new.nodoktmp,nodokref,loccode,loccode_destination,itemtrans_type,itemtrans_category,description,nodok_date,totalprice,inputdate,inputby,
			updatedate,updateby,approvaldate,approvalby,hangusdate,hangusby,canceldate,cancelby,nodoktmp,'A' as status from sc_tmp.itemtrans_mst where nodok=new.nodok);


			insert into sc_trx.itemtrans_dtl
			(branch,nodok,kdgroup,kdsubgroup,stockcode,id,nodokref,loccode,loccode_destination,itemtrans_type,itemtrans_category,qty,qtybbm,satkecil,
			description,qtyonhand,inputby,inputdate,qtyunitprice,qtytotalprice,nodoktmp,status,qty_tmp)
			(select branch,new.nodoktmp,kdgroup,kdsubgroup,stockcode,id,nodokref,loccode,loccode_destination,itemtrans_type,itemtrans_category,coalesce(qty,0),coalesce(qtybbm,0),satkecil,
			description,qtyonhand,inputby,inputdate,qtyunitprice,qtytotalprice,nodoktmp,'A' as status,qty_tmp from sc_tmp.itemtrans_dtl where nodok=new.nodok);

			
			delete from sc_tmp.itemtrans_mst where nodok=new.nodok;
			delete from sc_tmp.itemtrans_dtl where nodok=new.nodok;

			delete from sc_mst.trxerror where modul='ITEMTRANS';
			insert into sc_mst.trxerror
			(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
			(new.nodok,0,vr_nomor,'','ITEMTRANS');

		ELSEIF (OLD.STATUS='C' AND NEW.STATUS='F') THEN
			delete from sc_trx.itemtrans_mst where nodok=new.nodoktmp;
			delete from sc_trx.itemtrans_dtl where nodok=new.nodoktmp;
			
			/* update C KE F untuk update stock onhand per item detail */
			update sc_tmp.itemtrans_dtl set status='F' where nodok=new.nodok;
			
			insert into sc_trx.itemtrans_mst
			(branch,nodok,nodokref,loccode,loccode_destination,itemtrans_type,itemtrans_category,description,nodok_date,totalprice,inputdate,inputby,
			updatedate,updateby,approvaldate,approvalby,hangusdate,hangusby,canceldate,cancelby,nodoktmp,status)
			(select branch,new.nodoktmp,nodokref,loccode,loccode_destination,itemtrans_type,itemtrans_category,description,nodok_date,totalprice,inputdate,inputby,
			updatedate,updateby,approvaldate,approvalby,hangusdate,hangusby,canceldate,cancelby,nodoktmp,'C' as status from sc_tmp.itemtrans_mst where nodok=new.nodok);


			insert into sc_trx.itemtrans_dtl
			(branch,nodok,kdgroup,kdsubgroup,stockcode,id,nodokref,loccode,loccode_destination,itemtrans_type,itemtrans_category,qty,qtybbm,satkecil,
			description,qtyonhand,inputby,inputdate,qtyunitprice,qtytotalprice,nodoktmp,status,qty_tmp)
			(select branch,new.nodoktmp,kdgroup,kdsubgroup,stockcode,id,nodokref,loccode,loccode_destination,itemtrans_type,itemtrans_category,coalesce(qty,0),coalesce(qtybbm,0),satkecil,
			description,qtyonhand,inputby,inputdate,qtyunitprice,qtytotalprice,nodoktmp,'C' as status,qty_tmp from sc_tmp.itemtrans_dtl where nodok=new.nodok);

			
			delete from sc_tmp.itemtrans_mst where nodok=new.nodok;
			delete from sc_tmp.itemtrans_dtl where nodok=new.nodok;

			delete from sc_mst.trxerror where modul='ITEMTRANS';
			insert into sc_mst.trxerror
			(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
			(new.nodok,0,vr_nomor,'','ITEMTRANS');

		ELSEIF (OLD.STATUS='A' AND NEW.STATUS='F') THEN
			delete from sc_trx.itemtrans_mst where nodok=new.nodoktmp;
			delete from sc_trx.itemtrans_dtl where nodok=new.nodoktmp;
			
			/* update C KE F untuk update stock onhand per item detail */
			update sc_tmp.itemtrans_dtl set status='F' where nodok=new.nodok;
			
			insert into sc_trx.itemtrans_mst
			(branch,nodok,nodokref,loccode,loccode_destination,itemtrans_type,itemtrans_category,description,nodok_date,totalprice,inputdate,inputby,
			updatedate,updateby,approvaldate,approvalby,hangusdate,hangusby,canceldate,cancelby,nodoktmp,status)
			(select branch,new.nodoktmp,nodokref,loccode,loccode_destination,itemtrans_type,itemtrans_category,description,nodok_date,totalprice,inputdate,inputby,
			updatedate,updateby,approvaldate,approvalby,hangusdate,hangusby,canceldate,cancelby,nodoktmp,'P' as status from sc_tmp.itemtrans_mst where nodok=new.nodok);


			insert into sc_trx.itemtrans_dtl
			(branch,nodok,kdgroup,kdsubgroup,stockcode,id,nodokref,loccode,loccode_destination,itemtrans_type,itemtrans_category,qty,qtybbm,satkecil,
			description,qtyonhand,inputby,inputdate,qtyunitprice,qtytotalprice,nodoktmp,status,qty_tmp)
			(select branch,new.nodoktmp,kdgroup,kdsubgroup,stockcode,id,nodokref,loccode,loccode_destination,itemtrans_type,itemtrans_category,coalesce(qty,0),coalesce(qtybbm,0),satkecil,
			description,qtyonhand,inputby,inputdate,qtyunitprice,qtytotalprice,nodoktmp,'P' as status,qty_tmp from sc_tmp.itemtrans_dtl where nodok=new.nodok);
			/* INSERT CATATAN KE STGBLCO */
			--select * from sc_trx.stgblco

			insert into sc_trx.stgblco
			(branch,loccode,kdgroup,kdsubgroup,stockcode,trxdate,doctype,docno,docref,qty_in,qty_out,qty_sld,hist,ctype)
			(select branch,loccode,kdgroup,kdsubgroup,stockcode,to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp as trxdate,'TRG' AS doctype,nodoktmp as docno,nodokref as docref,
			0,qty as qty_out,0 as qty_sld,'' as hist,'' as ctype from sc_tmp.itemtrans_dtl
			where nodok=new.nodok and loccode=new.loccode);

			
			
			delete from sc_tmp.itemtrans_mst where nodok=new.nodok;
			delete from sc_tmp.itemtrans_dtl where nodok=new.nodok;

			delete from sc_mst.trxerror where modul='ITEMTRANS';
			insert into sc_mst.trxerror
			(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
			(new.nodok,0,vr_nomor,'','ITEMTRANS');

		ELSEIF (OLD.STATUS='P' AND NEW.STATUS='A') THEN
			/*UPDATE sc_trx.itemtrans_mst SET STATUS='A' WHERE
			NODOK=NEW.NODOKTMP AND NIK=NEW.NIK AND KDGROUP=NEW.KDGROUP AND KDSUBGROUP=NEW.KDSUBGROUP AND STOCKCODE=NEW.STOCKCODE;*/
		END IF;


		
		RETURN NEW;
	ELSEIF tg_op = 'DELETE' THEN

		RETURN old;	
	END IF;

	/*

select * from sc_mst.nomor
select * from sc_mst.penomoran
insert into sc_mst.nomor VALUES
('ITEMTRANS','',4,'TRG1706','',0,'66666','','201706','T')
--delete from sc_mst.nomor where dokumen='ITEMTRANS';
*/
END;
$$;

alter function tr_tmp_itemtrans_mst() owner to postgres;

