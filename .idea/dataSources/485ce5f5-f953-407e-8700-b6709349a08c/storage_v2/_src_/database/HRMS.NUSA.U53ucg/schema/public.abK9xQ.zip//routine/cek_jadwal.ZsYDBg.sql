create function cek_jadwal(tglawal date, tglakhir date, dokno character, xnik character) returns timestamp without time zone
    language plpgsql
as
$$
DECLARE
/* PENAMBAHAN OPSI PAYROL04 
UPDATE BY FIKY / 30/04/2019 
BRANCH NUSA
*/
    listNik RECORD;
    listJadwal RECORD;
    vr_tgl timestamp;
    vr_sisacuti integer;
    vr_stsptg char(3);
    vr_jenis character;
    vr_dokcuti character(12);
    vr_dokdinas character(12);
    vr_dokijin character(12);
   	vr_dokcb character(12);
    vr_xpot boolean;
    vr_gaji numeric(18,2);
    vr_hari integer;
    vr_patokan numeric(18,2);
    vr_sisabaru integer;
    vr_tglawal integer;
    vr_tglblcawal date;
    vr_tglblcakhir character;
    vr_tglakhir integer;
    vr_periode character;
    vr_opsigaji character;
   
  
    
BEGIN

  /* PENAMBAHAN OPTION SETTING UNTUK PERHITUNGAN GAJIPOKOK DAN TETAP*/
  /* PAYROL04  A: GAJIPOKOK , B: GAJITETAP*/
	select value3 into vr_hari from sc_mst.option where kdoption='E';
	select value1 into vr_opsigaji	from sc_mst.option where kdoption='PAYROL04';
	
     
   --FOR listNik IN select distinct nik from sc_trx.dtljadwalkerja where to_char(tgl,'YYYYMM')=$1 and case when xnik<>'' then nik=xnik else nik<>'' end order by nik
    FOR listNik IN select distinct nik from sc_trx.dtljadwalkerja where (to_char(tgl,'YYYY-MM-DD') between to_char(tglawal,'YYYY-MM-DD')  and to_char(tglakhir,'YYYY-MM-DD')) and case when xnik<>'' then nik=xnik else nik<>'' end order by nik
    LOOP
	    
		if (vr_opsigaji='A') then 
			select gajipokok into vr_gaji from sc_mst.karyawan where nik=listNik.nik;
			vr_patokan := vr_gaji/vr_hari;
		elseif(vr_opsigaji='B') then
			select gajitetap into vr_gaji from sc_mst.karyawan where nik=listNik.nik;
			vr_patokan := vr_gaji/vr_hari;
		end if;
	    
	   --insert into dumy(tgl) values (vr_tglawalfix);
	    FOR listJadwal IN select tgl from sc_trx.dtljadwalkerja where nik=listNik.nik and to_char(tgl,'YYYY-MM-DD') between to_char(tglawal,'YYYY-MM-DD')  and to_char(tglakhir,'YYYY-MM-DD')order by tgl
	    LOOP
		
		
		      --insert into dumy(jumlah,tgl) values (listNik.nik,listJadwal.tgl);
                      select tpcuti,trim(nodok),trim(status_ptg) into vr_jenis,vr_dokcuti,vr_stsptg from sc_trx.cuti_karyawan where nik=listNik.nik and to_char(listJadwal.tgl,'YYYYMMDD') >= to_char(tgl_mulai,'YYYYMMDD') and to_char(listJadwal.tgl,'YYYYMMDD')<= to_char(tgl_selesai,'YYYYMMDD');

			 select nodok into vr_dokdinas from sc_trx.dinas where nik=listNik.nik and status='P' and to_char(listJadwal.tgl,'YYYYMMDD') >= to_char(tgl_mulai,'YYYYMMDD') and to_char(listJadwal.tgl,'YYYYMMDD')<= to_char(tgl_selesai,'YYYYMMDD');

		      select nodok into vr_dokijin from sc_trx.ijin_karyawan where nik=listNik.nik and kdijin_absensi='KD' and status='P' and to_char(listJadwal.tgl,'YYYYMMDD')= to_char(tgl_kerja,'YYYYMMDD');

		     select b.nodok into vr_dokcb from sc_tmp.cuti_blc a

			LEFT OUTER JOIN sc_trx.cutibersama b on a.no_dokumen=b.nodok

			where NIK=listNik.nik and to_char(listJadwal.tgl,'YYYYMMDD') >= to_char(tgl_awal,'YYYYMMDD')  and  to_char(listJadwal.tgl,'YYYYMMDD')<=to_char(tgl_akhir,'YYYYMMDD') and coalesce(b.status,'')not in ('C','I');
                      
		      IF (coalesce(vr_dokcuti,'')<>'' and vr_stsptg<>'A2')  THEN --cuti biasa
		        update sc_tmp.cek_absen set flag_cuti='NO',cuti_nominal=0 where nodok=dokno and nik=listNik.nik and tgl_kerja=listJadwal.tgl;
		           --insert into dumy(tgl,status) values (listJadwal.tgl,vr_dokcuti);
		        

			ELSEIF (coalesce(vr_dokijin,'')<>'')  THEN --ijin sakit karyawan
			update sc_tmp.cek_absen set flag_cuti='NO',cuti_nominal=0 where nodok=dokno and nik=listNik.nik and tgl_kerja=listJadwal.tgl;


		      ELSEIF (coalesce(vr_dokdinas,'')<>'')  THEN --Dinas karyawan
		      update sc_tmp.cek_absen set flag_cuti='NO',cuti_nominal=0 where nodok=dokno and nik=listNik.nik and tgl_kerja=listJadwal.tgl;
		     
		     ELSEIF (coalesce(vr_dokcb,'')<>'') THEN --cuti bersama   	
			update sc_tmp.cek_absen set flag_cuti='NO',cuti_nominal=0 where nodok=dokno and nik=listNik.nik and tgl_kerja=listJadwal.tgl;
	
		      ELSEIF (coalesce(vr_dokcuti,'')<>'' and vr_stsptg='A2') THEN --cuti biasa   	
			update sc_tmp.cek_absen set flag_cuti='YES',cuti_nominal=vr_patokan where nodok=dokno and nik=listNik.nik and tgl_kerja=listJadwal.tgl;

		      ELSEIF (coalesce(vr_dokcuti,'')='' and coalesce(vr_dokdinas,'')='' and coalesce(vr_dokcb,'')='') THEN --tidak ada dokumen
		      update sc_tmp.cek_absen set flag_cuti='YES',cuti_nominal=vr_patokan where nodok=dokno and nik=listNik.nik and tgl_kerja=listJadwal.tgl;	

		   		           		           
                      END IF;
                   
                      
		       
		--tgl 2 
		--tgl 3
		--tgl 4
		--tgl 5
	    END LOOP;
	    
    END LOOP;
    
    RETURN vr_tgl;
END;
$$;

alter function cek_jadwal(date, date, char, char) owner to postgres;

