create function tr_legal_master() returns trigger
    language plpgsql
as
$$
DECLARE 
	--author by fiky: 12/08/2017
	--update by fiky: 12/08/2017
     vr_nomor char(20); 
     vr_nomor_valid char(20); 
     vr_lastdoc numeric; 
     vr_initialcabang char(3); 
     vr_romawi char(3);
BEGIN		
	IF tg_op = 'UPDATE' THEN
		IF (new.status='F' and old.status='I') THEN
		--001/SMG/VIII/2019 
		/*

		--UPDATE SC_TMP.LEGAL_MASTER set status='F';
--select * from sc_mst.nomor;
alter table sc_mst.nomor add column group_nomor char(20);
--delete from sc_mst.nomor where dokumen='P_LEGAL';
insert into sc_mst.nomor
(dokumen,part,count3,prefix,sufix,docno,userid,modul,periode,cekclose,group_nomor)
values
('P_LEGAL','',3,'','',0,'123456','I.D.A.1','202010','T','LEGAL');


		*/
	
		--select * from sc_mst.nomor;
		--select * from sc_his.legal_master;
		--select * from sc_tmp.legal_master;
			select romawi(to_char(new.docdate,'MM')::integer) into vr_romawi;
			vr_initialcabang:= coalesce(initial,'') from sc_mst.kantorwilayah where kdcabang=new.idbu;
			
			delete from sc_mst.penomoran where userid=new.docno;
			delete from sc_mst.trxerror where userid=new.docno;    

			vr_lastdoc:= case 
			when max((left(trim(docno),3))) is null or max((right(trim(docno),3)))='' then '0'::numeric
			else max((left(trim(docno),3)))::numeric end lastdoc
			from sc_his.legal_master
			where to_char(docdate,'yyyymm')=to_char(new.docdate,'yyyymm');

			update sc_mst.nomor set docno=vr_lastdoc where dokumen='P_LEGAL';
			--update sc_mst.nomor set  prefix='LLG'||to_char(new.docdate,'YYMM') ,docno=vr_lastdoc where dokumen='P_LEGAL';
			
			insert into sc_mst.penomoran 
			(userid,dokumen,nomor,errorid,partid,counterid,xno)
			values(new.docno,'P_LEGAL',' ',0,' ',1,0);
			vr_nomor:=trim(coalesce(nomor,'')) from sc_mst.penomoran where userid=new.docno;

			vr_nomor_valid:= vr_nomor||'/'||vr_initialcabang||'/'||vr_romawi||'/'||to_char(new.docdate,'YYYY');

			
			insert into sc_his.legal_master
			(docno,docname,doctype,docdate,docref,docrefname,coperator,coperatorname,idbu,namebu,status,
			progress,description,inputdate,inputby,updatedate,updateby,finishdate,finishby,docnokeep,docnotmp,attachment,attachment_dir)
			(select vr_nomor_valid as docno,docname,doctype,docdate,vr_nomor_valid as docref,docrefname,coperator,coperatorname,idbu,namebu,'A' as status,
			progress,description,inputdate,inputby,updatedate,updateby,finishdate,finishby,docnokeep,docnotmp,attachment,attachment_dir from sc_tmp.legal_master where docno=new.docno);

			insert into sc_his.legal_detail
			(docno,sort,docname,doctype,docdate,docref,docrefname,coperator,coperatorname,dateoperation,operationcategory,idbu,namebu,
			status,progress,description,inputdate,inputby,updatedate,updateby,finishdate,finishby,docnokeep,docnotmp,attachment,attachment_dir)
			(select vr_nomor_valid as docno,sort,docname,doctype,docdate,vr_nomor_valid as docref,docrefname,coperator,coperatorname,dateoperation,operationcategory,idbu,namebu,
			status,progress,description,inputdate,inputby,updatedate,updateby,finishdate,finishby,docnokeep,docnotmp,attachment,attachment_dir from sc_tmp.legal_detail where docno=new.docno);

			delete from sc_tmp.legal_detail where docno=new.docno;
			delete from sc_tmp.legal_master where docno=new.docno;
		ELSEIF (new.status='F' and old.status='E') THEN
			delete from sc_his.legal_detail where docno=new.docnotmp;
			delete from sc_his.legal_master where docno=new.docnotmp;
		
			insert into sc_his.legal_master
			(docno,docname,doctype,docdate,docref,docrefname,coperator,coperatorname,idbu,namebu,status,
			progress,description,inputdate,inputby,updatedate,updateby,finishdate,finishby,docnokeep,docnotmp,attachment,attachment_dir)
			(select new.docnotmp as docno,docname,doctype,docdate,docref,docrefname,coperator,coperatorname,idbu,namebu,'A' as status,
			progress,description,inputdate,inputby,updatedate,updateby,finishdate,finishby,docnokeep,docnotmp,attachment,attachment_dir from sc_tmp.legal_master where docno=new.docno);

			insert into sc_his.legal_detail
			(docno,sort,docname,doctype,docdate,docref,docrefname,coperator,coperatorname,dateoperation,operationcategory,idbu,namebu,
			status,progress,description,inputdate,inputby,updatedate,updateby,finishdate,finishby,docnokeep,docnotmp,attachment,attachment_dir)
			(select new.docnotmp as docno,sort,docname,doctype,docdate,docref,docrefname,coperator,coperatorname,dateoperation,operationcategory,idbu,namebu,
			status,progress,description,inputdate,inputby,updatedate,updateby,finishdate,finishby,docnokeep,docnotmp,attachment,attachment_dir from sc_tmp.legal_detail where docno=new.docno);

			delete from sc_tmp.legal_detail where docno=new.docno;
			delete from sc_tmp.legal_master where docno=new.docno;
		
		END IF;
		RETURN NEW;	
	END IF;
	
END;
$$;

alter function tr_legal_master() owner to postgres;

