create function payroll_pinjaman_mst() returns trigger
    language plpgsql
as
$$
declare
     vr_pinjaman character(25);
     vr_nomor char(12); 
     vr_cekprefix char(4);
     vr_nowprefix char(4);

begin
IF (TG_OP='UPDATE') THEN 
			--select * from sc_trx.payroll_pinjaman_inq;
			--select * from sc_trx.payroll_pinjaman_mst;
			if (old.status='I' and new.status='F') then
				insert into sc_trx.payroll_pinjaman_inq
				(nik,docno,tgl,docref,doctype,in_sld,out_sld,sld,status)
				(select nik,docno,tgl,'SALDO_AWAL' as docref,'IN' as doctype,nominal ,0,0,'F' from sc_trx.payroll_pinjaman_mst where docno=new.docno);
			--bonus jika hangus 
			elseif (old.status='P' and new.status='H') then
				insert into sc_trx.payroll_pinjaman_inq
				(nik,docno,tgl,docref,doctype,in_sld,out_sld,sld,status)
				(select nik,docno,tgl,'' as docref,'OUT' as doctype,0,sisa,0,'F' from sc_trx.payroll_pinjaman_mst where docno=new.docno);
			elseif (old.status='I' and new.status='C') then
				delete from sc_trx.payroll_pinjaman_inq where docno=new.docno;
			end if;
		

			update sc_mst.karyawan set pinjaman = (select sum(coalesce(sisa,0.0)) from sc_trx.payroll_pinjaman_mst where nik=new.nik and status not in ('H','C'))
			where nik=new.nik;
			
return new;
END IF;
return new;
end;
$$;

alter function payroll_pinjaman_mst() owner to postgres;

