create function mutasi_after() returns trigger
    language plpgsql
as
$$
declare
     vr_status char(10);
     vr_nomor char(12);
     vr_ttl numeric;
     vr_last numeric;
     vr_oldkddept character(12);vr_old_kdsubdept character(12);vr_old_jabatan character(12);vr_old_kdlevel character(12);vr_old_nikatasan character(12);
     
begin

	delete from sc_mst.penomoran where userid=new.nodokumen; 
	insert into sc_mst.penomoran 
        (userid,dokumen,nomor,errorid,partid,counterid,xno)
        values(new.nodokumen,'MUTASI',' ',0,' ',1,0);

	vr_nomor:=trim(coalesce(nomor,'')) from sc_mst.penomoran where userid=new.nodokumen;
	if (trim(vr_nomor)!='') or (not vr_nomor is null) then
		select bag_dept,subbag_dept,jabatan,lvl_jabatan,nik_atasan into vr_oldkddept,vr_old_kdsubdept,vr_old_jabatan,vr_old_kdlevel,vr_old_nikatasan from sc_mst.karyawan where nik=new.nik;
	
		insert into sc_mst.mutasi (nik,oldkddept,oldkdsubdept,oldkdjabatan,oldkdlevel,oldnikatasan,newkddept,newkdsubdept,newkdjabatan,newkdlevel,newnikatasan,nodoksk,tglsk,tglmemo,tglefektif,
		ket,inputdate,inputby,approvaldate,approvalby,updatedate,updateby,nodokumen,newnikatasan2,oldnikatasan2,status)
		select nik,vr_oldkddept as oldkddept,vr_old_kdsubdept as oldkdsubdept,vr_old_jabatan as oldkdjabatan,vr_old_kdlevel as oldkdlevel,vr_old_nikatasan as oldnikatasan,newkddept,newkdsubdept,newkdjabatan,newkdlevel,newnikatasan,nodoksk,tglsk,tglmemo,tglefektif,
		ket,inputdate,inputby,approvaldate,approvalby,updatedate,updateby,vr_nomor,newnikatasan2,oldnikatasan2,'I' as status from sc_tmp.mutasi where nik=new.nik and nodokumen=new.nodokumen;
	end if;	

		delete from sc_tmp.mutasi
		where nik=new.nik and nodokumen=new.nodokumen;
		--select * from sc_tmp.mutasi
    
	return new;


end;
$$;

alter function mutasi_after() owner to postgres;

