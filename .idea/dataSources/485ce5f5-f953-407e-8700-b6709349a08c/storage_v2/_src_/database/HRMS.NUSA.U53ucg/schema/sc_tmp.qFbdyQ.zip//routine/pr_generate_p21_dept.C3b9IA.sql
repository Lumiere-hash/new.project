create function pr_generate_p21_dept(vr_nodok character, periode integer, keluarkerja character, vr_gp character, vr_kddept character) returns timestamp without time zone
    language plpgsql
as
$$
DECLARE
	/* 
		Update By : Fiky A 
		Update Date : 14/02/2019 
		Update Case : P1 -> P2 TERGENERATE U/ CNI
	*/
    vr_nik char(12);
    vr_tglkeluarkerja char(4);
    vr_urut integer;
    vr_keluarkerja integer;
    vr_return timestamp without time zone;
    
    
    
BEGIN

   FOR vr_nik IN select a.nik,a.tglkeluarkerja from sc_mst.karyawan a
		left outer join sc_mst.departmen b on a.bag_dept=b.kddept
		where a.grouppenggajian in (select coalesce(kdgroup_pg) from sc_mst.group_penggajian where case when vr_gp='P1' then kdgroup_pg in (vr_gp,'P2') else kdgroup_pg in (vr_gp) end) 
		and a.bag_dept=vr_kddept and ((a.tglkeluarkerja is null) OR ((to_char(a.tglkeluarkerja,'YYYYMM')=keluarkerja)))								
		order by nmlengkap asc

    LOOP
	    select to_char(tglkeluarkerja,'MM') into vr_tglkeluarkerja from sc_mst.karyawan where nik=vr_nik;
	    if vr_tglkeluarkerja is null then 
	    vr_keluarkerja=12; 
	    else vr_keluarkerja=vr_tglkeluarkerja;
	    end if;
	    insert into sc_tmp.p21_master(nodok,nik,periode_mulai,periode_akhir,kddept,status) values (vr_nodok,vr_nik,periode,periode,vr_kddept,'I');

		     perform sc_trx.pr_ambil_gp_21(vr_nik,1,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_ambil_tj_21(vr_nik,2,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_ambil_tm_21(vr_nik,3,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_ambil_tp_21(vr_nik,4,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_ambil_ts_21(vr_nik,5,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_ambil_tl_21(vr_nik,6,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_ambil_ub_21(vr_nik,7,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_tunjangan_lembur_21(vr_nik,8,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_pengobatan_21(vr_nik,9,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_ambil_jkk_per_21(vr_nik,10,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_ambil_jkm_per_21(vr_nik,11,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_ambil_bpjs_per_21(vr_nik,12,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_subtotal_reguler_21(vr_nik,13,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_bonus_21(vr_nik,14,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_bruto_21(vr_nik,15,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_biaya_jabatan_21(vr_nik,16,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_ambil_jht_kar_21(vr_nik,17,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_ambil_jp_kar_21(vr_nik,18,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_subtotal_potong_21(vr_nik,19,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_ambil_netto_21(vr_nik,20,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_peng_reg_21(vr_nik,21,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_pro_reg_21(vr_nik,22,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_total_pro_21(vr_nik,23,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_peng_nonreg_21(vr_nik,24,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_total_bruto_21(vr_nik,25,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_jbtsetahun_21(vr_nik,26,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_jhtblnjalan_21(vr_nik,27,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_sisajht_21(vr_nik,28,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_jpblnjalan_21(vr_nik,29,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_sisajp_21(vr_nik,30,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_totalptgsetahun_21(vr_nik,31,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_netto_setahun_21(vr_nik,32,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_ambil_ptkp_21(vr_nik,33,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_pkp_21(vr_nik,34,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_pphsetahun_21(vr_nik,35,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_jbtsetahunreg_21(vr_nik,36,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_jhtblnjalanreg_21(vr_nik,37,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_sisajhtreg_21(vr_nik,38,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_jpblnjalanreg_21(vr_nik,39,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_sisajpreg_21(vr_nik,40,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_totalptgsthnreg_21(vr_nik,41,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_netto_setahunreg_21(vr_nik,42,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_ambil_ptkp_21(vr_nik,43,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_pkpreg_21(vr_nik,44,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_pphsetahunreg_21(vr_nik,45,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_ratiobln_21(vr_nik,46,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_ratioblnjln_21(vr_nik,47,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_pph21blnjln_21(vr_nik,48,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_pph21blnsd_21(vr_nik,49,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_selisih_21(vr_nik,50,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_pph21blnjln_21(vr_nik,51,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_pph21krgbyr_21(vr_nik,52,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_pph21selisih_21(vr_nik,53,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_pph21sisablnamor_21(vr_nik,54,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_amorblnjln_21(vr_nik,55,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_pph21blnjlnnr_21(vr_nik,56,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_pphsetahun_21(vr_nik,57,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_pphsetahunreg_21(vr_nik,58,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_pph21nr_21(vr_nik,59,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_pph21nrjln_21(vr_nik,60,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_pph21blnjlnnr_21(vr_nik,61,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_pph21nrjln_21(vr_nik,62,vr_nodok,periode,vr_keluarkerja);
		     perform sc_trx.pr_totalpph21_21(vr_nik,63,vr_nodok,periode,vr_keluarkerja);
		     	    
    END LOOP;
		update sc_tmp.p21_master set status='H' where nodok=vr_nodok and kddept=vr_kddept;
		update sc_mst.trxerror set errorcode='0' where userid=trim(vr_nodok) and modul='PPH21_GEN';
    RETURN vr_return;
END;
$$;

alter function pr_generate_p21_dept(char, integer, char, char, char) owner to postgres;

