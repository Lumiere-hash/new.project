create view qv_uangmakan
            (nik, nmlengkap, nmdept, nmjabatan, tgl, tglhari, checktime, keterangan, nominal, rank, nominalrp) as
SELECT x2.nik,
       x2.nmlengkap,
       x2.nmdept,
       x2.nmjabatan,
       x2.tgl,
       x2.tglhari,
       x2.checktime,
       x2.keterangan,
       x2.nominal,
       x2.rank,
       x2.nominal::money AS nominalrp
FROM (SELECT a.nik,
             a.nmlengkap,
             a.nmdept,
             a.nmjabatan,
             a.tgl,
             a.tglhari,
             a.checktime,
             a.keterangan,
             a.nominal,
             a.rank
      FROM (SELECT t1.nik,
                   t1.nmlengkap,
                   t1.nmdept,
                   t1.nmjabatan,
                   t1.tgl,
                   t1.tglhari,
                   t1.checktime,
                   t1.keterangan,
                   t1.nominal,
                   rank() OVER (PARTITION BY t1.nik ORDER BY t1.nik) AS rank
            FROM (SELECT t1_1.nik,
                         t1_1.nmlengkap,
                         t1_1.nmdept,
                         t1_1.nmjabatan,
                         t1_1.tgl,
                         t1_1.tglhari,
                         t1_1.checktime,
                         t1_1.keterangan,
                         t1_1.nominal
                  FROM (SELECT a_1.branch,
                               a_1.nik,
                               a_1.tgl,
                               a_1.checkin,
                               a_1.checkout,
                               a_1.nominal,
                               a_1.keterangan,
                               a_1.tgl_dok,
                               a_1.dok_ref,
                               b.nmlengkap,
                               b.kdcabang,
                               c.kddept,
                               c.nmdept,
                               e.nmjabatan,
                               (to_char(a_1.tgl::timestamp with time zone, 'yyyy-mm-dd'::text) || ','::text) ||
                               CASE
                                   WHEN to_char(a_1.tgl::timestamp with time zone, 'Dy'::text) = 'Mon'::text
                                       THEN 'Senin'::text
                                   WHEN to_char(a_1.tgl::timestamp with time zone, 'Dy'::text) = 'Tue'::text
                                       THEN 'Selasa'::text
                                   WHEN to_char(a_1.tgl::timestamp with time zone, 'Dy'::text) = 'Wed'::text THEN 'Rabu'::text
                                   WHEN to_char(a_1.tgl::timestamp with time zone, 'Dy'::text) = 'Thu'::text
                                       THEN 'Kamis'::text
                                   WHEN to_char(a_1.tgl::timestamp with time zone, 'Dy'::text) = 'Fri'::text
                                       THEN 'Jumat'::text
                                   WHEN to_char(a_1.tgl::timestamp with time zone, 'Dy'::text) = 'Sat'::text
                                       THEN 'Sabtu'::text
                                   ELSE 'Out Date'::text
                                   END AS tglhari,
                               (
                                       CASE
                                           WHEN to_char(a_1.checkin::interval, 'HH24:MI:SS'::text) IS NULL THEN ''::text
                                           ELSE to_char(a_1.checkin::interval, 'HH24:MI:SS'::text)
                                           END || '|'::text) ||
                               CASE
                                   WHEN to_char(a_1.checkout::interval, 'HH24:MI:SS'::text) IS NULL THEN ''::text
                                   ELSE to_char(a_1.checkout::interval, 'HH24:MI:SS'::text)
                                   END AS checktime
                        FROM sc_trx.uangmakan a_1
                                 LEFT JOIN sc_mst.karyawan b ON a_1.nik = b.nik
                                 LEFT JOIN sc_mst.departmen c ON b.bag_dept = c.kddept
                                 LEFT JOIN sc_mst.subdepartmen d
                                           ON b.bag_dept = d.kddept AND b.subbag_dept = d.kdsubdept
                                 LEFT JOIN sc_mst.jabatan e ON b.bag_dept = e.kddept AND b.jabatan = e.kdjabatan AND
                                                               b.subbag_dept = e.kdsubdept
                        ORDER BY b.nmlengkap, a_1.tgl) t1_1
                  GROUP BY t1_1.nik, t1_1.nmlengkap, t1_1.nmdept, t1_1.nmjabatan, t1_1.tgl, t1_1.tglhari,
                           t1_1.checktime, t1_1.keterangan, t1_1.nominal
                  UNION ALL
                  SELECT t1_1.nik,
                         t1_1.nmlengkap          AS nama,
                         NULL::character varying AS nmdept,
                         NULL::character varying AS nmjabatan,
                         NULL::date              AS tgl,
                         NULL::text              AS tglhari,
                         NULL::text              AS checktime,
                         'TOTAL'::text           AS keterangan,
                         sum(t1_1.nominal)       AS sum
                  FROM (SELECT a_1.branch,
                               a_1.nik,
                               a_1.tgl,
                               a_1.checkin,
                               a_1.checkout,
                               a_1.nominal,
                               a_1.keterangan,
                               a_1.tgl_dok,
                               a_1.dok_ref,
                               b.nmlengkap,
                               b.kdcabang,
                               c.kddept,
                               c.nmdept,
                               e.nmjabatan,
                               (to_char(a_1.tgl::timestamp with time zone, 'yyyy-mm-dd'::text) || ','::text) ||
                               CASE
                                   WHEN to_char(a_1.tgl::timestamp with time zone, 'Dy'::text) = 'Mon'::text
                                       THEN 'Senin'::text
                                   WHEN to_char(a_1.tgl::timestamp with time zone, 'Dy'::text) = 'Tue'::text
                                       THEN 'Selasa'::text
                                   WHEN to_char(a_1.tgl::timestamp with time zone, 'Dy'::text) = 'Wed'::text THEN 'Rabu'::text
                                   WHEN to_char(a_1.tgl::timestamp with time zone, 'Dy'::text) = 'Thu'::text
                                       THEN 'Kamis'::text
                                   WHEN to_char(a_1.tgl::timestamp with time zone, 'Dy'::text) = 'Fri'::text
                                       THEN 'Jumat'::text
                                   WHEN to_char(a_1.tgl::timestamp with time zone, 'Dy'::text) = 'Sat'::text
                                       THEN 'Sabtu'::text
                                   ELSE 'Out Date'::text
                                   END AS tglhari,
                               (
                                       CASE
                                           WHEN to_char(a_1.checkin::interval, 'HH24:MI:SS'::text) IS NULL THEN ''::text
                                           ELSE to_char(a_1.checkin::interval, 'HH24:MI:SS'::text)
                                           END || '|'::text) ||
                               CASE
                                   WHEN to_char(a_1.checkout::interval, 'HH24:MI:SS'::text) IS NULL THEN ''::text
                                   ELSE to_char(a_1.checkout::interval, 'HH24:MI:SS'::text)
                                   END AS checktime
                        FROM sc_trx.uangmakan a_1
                                 LEFT JOIN sc_mst.karyawan b ON a_1.nik = b.nik
                                 LEFT JOIN sc_mst.departmen c ON b.bag_dept = c.kddept
                                 LEFT JOIN sc_mst.subdepartmen d
                                           ON b.bag_dept = d.kddept AND b.subbag_dept = d.kdsubdept
                                 LEFT JOIN sc_mst.jabatan e ON b.bag_dept = e.kddept AND b.jabatan = e.kdjabatan AND
                                                               b.subbag_dept = e.kdsubdept
                        ORDER BY a_1.nik, a_1.tgl) t1_1
                  GROUP BY t1_1.nik, t1_1.nmdept, t1_1.nmjabatan, t1_1.nmlengkap) t1
            GROUP BY t1.nik, t1.nmlengkap, t1.nmdept, t1.nmjabatan, t1.tgl, t1.tglhari, t1.checktime, t1.keterangan,
                     t1.nominal
            ORDER BY t1.nmlengkap, t1.tglhari) a
      UNION ALL
      SELECT x.nik,
             'GRAND TOTAL UANG MAKAN'::bpchar AS nmlengkap,
             x.nmdept,
             x.nmjabatan,
             NULL::date                       AS date,
             x.tglhari,
             x.checktime,
             x.keterangan,
             sum(x.nominal)                   AS sum,
             NULL::bigint                     AS rank
      FROM (SELECT ''::text        AS nik,
                   ''::text        AS nmlengkap,
                   ''::text        AS nmdept,
                   ''::text        AS nmjabatan,
                   ''::text        AS tglhari,
                   ''::text        AS checktime,
                   ''::text        AS keterangan,
                   sum(t1.nominal) AS nominal
            FROM (SELECT a.branch,
                         a.nik,
                         a.tgl,
                         a.checkin,
                         a.checkout,
                         a.nominal,
                         a.keterangan,
                         a.tgl_dok,
                         a.dok_ref,
                         b.nmlengkap,
                         b.kdcabang,
                         c.kddept,
                         c.nmdept,
                         e.nmjabatan,
                         (to_char(a.tgl::timestamp with time zone, 'yyyy-mm-dd'::text) || ','::text) ||
                         CASE
                             WHEN to_char(a.tgl::timestamp with time zone, 'Dy'::text) = 'Mon'::text THEN 'Senin'::text
                             WHEN to_char(a.tgl::timestamp with time zone, 'Dy'::text) = 'Tue'::text THEN 'Selasa'::text
                             WHEN to_char(a.tgl::timestamp with time zone, 'Dy'::text) = 'Wed'::text THEN 'Rabu'::text
                             WHEN to_char(a.tgl::timestamp with time zone, 'Dy'::text) = 'Thu'::text THEN 'Kamis'::text
                             WHEN to_char(a.tgl::timestamp with time zone, 'Dy'::text) = 'Fri'::text THEN 'Jumat'::text
                             WHEN to_char(a.tgl::timestamp with time zone, 'Dy'::text) = 'Sat'::text THEN 'Sabtu'::text
                             ELSE 'Out Date'::text
                             END AS tglhari,
                         (
                                 CASE
                                     WHEN to_char(a.checkin::interval, 'HH24:MI:SS'::text) IS NULL THEN ''::text
                                     ELSE to_char(a.checkin::interval, 'HH24:MI:SS'::text)
                                     END || '|'::text) ||
                         CASE
                             WHEN to_char(a.checkout::interval, 'HH24:MI:SS'::text) IS NULL THEN ''::text
                             ELSE to_char(a.checkout::interval, 'HH24:MI:SS'::text)
                             END AS checktime
                  FROM sc_trx.uangmakan a
                           LEFT JOIN sc_mst.karyawan b ON a.nik = b.nik
                           LEFT JOIN sc_mst.departmen c ON b.bag_dept = c.kddept
                           LEFT JOIN sc_mst.subdepartmen d ON b.bag_dept = d.kddept AND b.subbag_dept = d.kdsubdept
                           LEFT JOIN sc_mst.jabatan e ON b.bag_dept = e.kddept AND b.jabatan = e.kdjabatan AND
                                                         b.subbag_dept = e.kdsubdept
                  ORDER BY a.nik, a.tgl) t1
            GROUP BY t1.nik, t1.nmdept, t1.nmjabatan, t1.nmlengkap) x
      GROUP BY x.nik, x.nmlengkap, x.nmdept, x.nmjabatan, x.tglhari, x.checktime, x.keterangan) x2;

alter table qv_uangmakan
    owner to postgres;

