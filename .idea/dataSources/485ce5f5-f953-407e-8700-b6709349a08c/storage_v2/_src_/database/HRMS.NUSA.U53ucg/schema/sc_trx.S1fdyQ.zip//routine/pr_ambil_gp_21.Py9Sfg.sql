create function pr_ambil_gp_21(xnik character, nomor integer, userid character, periode integer, bulankeluar integer) returns numeric
    language plpgsql
as
$$
DECLARE 
vr_gp numeric(18,2):=0;
vr_duit numeric(18,2):=0;
vr_periode char(6);
vr_bulanmasuk char(6);
vr_bulankeluar char(6);
vr_hariaktif numeric(18);
BEGIN		

	select gajipokok into vr_gp from sc_mst.karyawan where nik=xnik;
	select to_char(periode_akhir,'YYYYMM') into vr_periode from sc_tmp.payroll_rekap where nodok=userid;
	select to_char(tglmasukkerja,'YYYYMM') into vr_bulanmasuk from sc_mst.karyawan where nik=xnik;
	select to_char(tglkeluarkerja,'YYYYMM') into vr_bulankeluar from sc_mst.karyawan where nik=xnik;
	
	
	select count(*) as jumlah into vr_hariaktif from sc_trx.dtljadwalkerja 
	where nik=xnik and to_char(tgl,'YYYYMM')=vr_periode;

	if (vr_periode=vr_bulanmasuk) then 
	vr_duit=(vr_gp/25)*vr_hariaktif;
	elseif (vr_periode=vr_bulankeluar) then 
	vr_duit=(vr_gp/25)*vr_hariaktif;
	elseif (vr_periode=vr_bulanmasuk and vr_periode=vr_bulankeluar) then 
	vr_duit=(vr_gp/25)*vr_hariaktif;
	else vr_duit=vr_gp;
	end if;	
	
	delete from sc_tmp.p21_detail where nodok=userid and nik=xnik and no_urut=nomor;

	insert into sc_tmp.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select userid as nodok,xnik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_duit as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,periode as periode_mulai,periode as periode_akhir from sc_mst.detail_formula
	where no_urut=nomor and kdrumus='P21';
 
	
	RETURN vr_duit;	
END;
$$;

alter function pr_ambil_gp_21(char, integer, char, integer, integer) owner to postgres;

