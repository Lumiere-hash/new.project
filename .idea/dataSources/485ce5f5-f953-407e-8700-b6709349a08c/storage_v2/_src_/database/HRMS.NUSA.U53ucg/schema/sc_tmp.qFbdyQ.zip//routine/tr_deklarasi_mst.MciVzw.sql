create function tr_deklarasi_mst() returns trigger
    language plpgsql
as
$$
declare
vr_total_dek numeric(18,2);
vr_um_dek numeric(18,2);
vr_sisa_dek numeric(18,2);  
begin


IF (new.status='H' and old.status='I') then
		vr_total_dek:=sum(coalesce(bbm_rupiah,0) + coalesce(parkir,0) + coalesce(tol,0) + coalesce(uangsaku,0) + coalesce(laundry,0) + coalesce(transport,0) + coalesce(lain,0))
		from sc_tmp.deklarasi_dtl where  nik=new.nik and nodok_ref=new.nodok_ref and nodok=new.nodok;

		vr_um_dek:=coalesce(uangmuka) from sc_tmp.deklarasi_mst where  nik=new.nik and nodok_ref=new.nodok_ref and nodok=new.nodok;
		vr_sisa_dek:=vr_um_dek - vr_total_dek;
		
		update sc_tmp.deklarasi_mst set total=vr_total_dek,sisa=vr_sisa_dek,status='I'  where  nik=new.nik and nodok_ref=new.nodok_ref and nodok=new.nodok;
end if;

IF (new.status='P' and old.status='I') then
		insert into sc_trx.deklarasi_dtl  
		  (branch, nik, nodok, tgl, status, km_awal, km_akhir,bbm_liter, bbm_rupiah, parkir, tol,uangsaku,laundry,transport,lain,keterangan,update_date,update_by,input_date,input_by ,
		  id, nodok_ref ) 
		  (select branch, nik, new.nodok_ref as nodok, tgl,'P' as status, km_awal, km_akhir,bbm_liter, bbm_rupiah, parkir, tol,uangsaku,laundry,transport,lain,keterangan,update_date,update_by,input_date,input_by ,
		  id, new.nodok as nodok_ref  from sc_tmp.deklarasi_dtl where  nik=new.nik and nodok_ref=new.nodok_ref and nodok=new.nodok);

		insert into sc_trx.deklarasi_mst  
		  (branch,nik,nodok,tgl_dok,status,total,uangmuka,sisa,keterangan,update_date,update_by,input_date,input_by, nodok_ref, approval_by,approval_date) 
		  (select branch,nik,new.nodok_ref as nodok,tgl_dok,'P' as status,total,uangmuka,sisa,keterangan,update_date,update_by,input_date,input_by, new.nodok as nodok_ref, approval_by,approval_date
		  from sc_tmp.deklarasi_mst where  nik=new.nik and nodok_ref=new.nodok_ref and nodok=new.nodok);
		   

		
		delete from sc_tmp.deklarasi_mst where  nik=new.nik and nodok_ref=new.nodok_ref ;
		delete from sc_tmp.deklarasi_dtl where  nik=new.nik and nodok_ref=new.nodok_ref ;



	
	
end if;

return new;

end;
$$;

alter function tr_deklarasi_mst() owner to postgres;

