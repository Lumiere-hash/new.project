create function pr_cutibased_nusa(vr_tgl date) returns SETOF void
    language plpgsql
as
$$
--create by Fiky Ashariza
--06-03-2019
DECLARE vr_ceknik char(12);
--DECLARE ngeluping char(12);
--DECLARE variabele integer;
DECLARE vr_year character varying ;	
DECLARE vr_month character varying ;	
DECLARE vr_day character varying ;	

BEGIN
/* ****************************************************** WARNING BASED NUSA ******************************************************************* */
vr_year := to_char(vr_tgl,'yyyy');	
vr_month := to_char(vr_tgl,'mm');	
vr_day := to_char(vr_tgl,'dd');	

/* PENAMBAHAN CUTI 12 PER JANUARI */
insert into sc_trx.cuti_blc
(nik,tanggal,no_dokumen,in_cuti,out_cuti,sisacuti,doctype,status)
(select nik,(vr_year||'-01-01 00:05:05'):: timestamp as tanggal,
	'CA'||vr_year as no_dokumen,12 as in_cuti,0 as out_cuti, 0 as sisacuti,'IN' as doctype, 'CA'||vr_year as status from sc_mst.karyawan 
	where coalesce(statuskepegawaian,'')!='KO' and to_char(tglmasukkerja+ interval'1 year','yyyy') < vr_year 
	and nik not in (select nik from sc_trx.cuti_blc where no_dokumen='CA'||vr_year)
	);	

IF (vr_month = '03') then
/* QUERY PENGHANGUSAN MARET 01 */
insert into sc_trx.cuti_blc 
(nik,tanggal,no_dokumen,in_cuti,out_cuti,sisacuti,doctype,status)
(select a.nik,(vr_year||'-03-01 01:01:01')::timestamp tanggal,'HGS'||vr_year as no_dokumen,0 as in_cuti,case when sisacuti>12 then sisacuti-12 else 0 end as out_cuti,0 as sisacuti,'HGS','HGS'||vr_year from sc_trx.cuti_blc a,
	(select a.nik,a.tanggal,a.no_dokumen,max(a.doctype) as doctype from sc_trx.cuti_blc a,
	(select a.nik,a.tanggal,max(a.no_dokumen) as no_dokumen from sc_trx.cuti_blc a,
	(select nik,max(tanggal) as tanggal from sc_trx.cuti_blc 
		where tanggal<(vr_year||'-03-01 00:00:00')::timestamp and nik not in (select nik from sc_trx.cuti_blc where no_dokumen='HGS'||vr_year)
	group by nik) as b
	where a.nik=b.nik and a.tanggal=b.tanggal
	group by a.nik,a.tanggal) b
	where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen
	group by a.nik,a.tanggal,a.no_dokumen) b
	where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen and a.doctype=b.doctype
	and a.nik not in (select nik from sc_trx.cuti_blc where no_dokumen='HGS'||vr_year)
	);
end if;
/* QUERY PENAMBAHAN CUTI KARYAWAN BARU */
insert into sc_trx.cuti_blc
(nik,tanggal,no_dokumen,in_cuti,out_cuti,sisacuti,doctype,status)
(select nik,cast(to_char(tglmasukkerja+ interval'1 year','YYYY-MM-DD HH24:05:05') as timestamp) as tanggal,
	'CA'||vr_year as no_dokumen,
	case when cast(to_char(tglmasukkerja,'dd') as numeric)<=15 then 13-to_number(to_char(tglmasukkerja,'MM'),'99')
	when cast(to_char(tglmasukkerja,'dd') as numeric)>15 then 12-to_number(to_char(tglmasukkerja,'MM'),'99')
	end in_cuti,0 as out_cuti, 0 as sisacuti,'IN' as doctype, 'CA'||vr_year as status from sc_mst.karyawan 
	where coalesce(statuskepegawaian,'')!='KO' and to_char(tglmasukkerja+ interval'1 year','yyyy-mm-dd')::date<vr_tgl
	and trim(nik) not in (select distinct trim(nik) from sc_trx.cuti_blc where no_dokumen='CA'||vr_year) 
	);	

/* ****************************************************** END WARNING BASED NUSA ******************************************************************* */

RAISE NOTICE 'Calling cs_create_job(%)', (vr_year||'-01-01 00:05:05');
END;
$$;

alter function pr_cutibased_nusa(date) owner to postgres;

