create function pr_final_form1721() returns trigger
    language plpgsql
as
$$
declare
     vr_nodok char(30);
     vr_tahun char(30);
     vr_kddept char(30);
     vr_penomoran character(20);
     vr_nik character(20);
begin

IF (new.status='P' and old.status='I') then

	
	
	/*
	delete from sc_mst.penomoran where userid=vr_nodok and dokumen='P1721'; 
	    insert into sc_mst.penomoran 
	    (userid,dokumen,nomor,errorid,partid,counterid,xno)
	    values(vr_nodok,'P1721',' ',0,' ',1,0);
	vr_nomor_pelaporan:=trim(coalesce(nomor,'')) from sc_mst.penomoran where userid=vr_nodok and dokumen='P1721';
       */

	--vr_penomoran:=sc_trx.pr_1721_pkp_setahun(new.nik,16,vr_nodok,vr_periode_awal,vr_periode_akhir,vr_tahun) as nomor;
	
	vr_nodok:=trim(kddept||to_char(tgl_dok,'yyyy'))as nodok from sc_tmp.p1721_rekap where nodok=new.nodok and kddept=new.kddept and grouppenggajian=new.grouppenggajian;
	delete from sc_trx.p1721_rekap where nodok=vr_nodok and kddept=new.kddept and grouppenggajian=new.grouppenggajian;
	delete from sc_trx.p1721_detail where nodok=vr_nodok and grouppenggajian=new.grouppenggajian;
	
	
	INSERT INTO sc_trx.p1721_rekap(
		nodok,tgl_dok,total_pajak,total_pendapatan,total_potongan,
		input_date,update_date,status,approval_date,approval_by,delete_by,delete_date,cancel_by,cancel_date,periode_mulai,periode_akhir,kddept,grouppenggajian
	    )
	SELECT vr_nodok as nodok,tgl_dok,total_pajak,total_pendapatan,total_potongan,
		input_date,update_date,status,approval_date,approval_by,delete_by,delete_date,cancel_by,cancel_date,periode_mulai,periode_akhir,kddept,grouppenggajian

	from sc_tmp.p1721_rekap where nodok=new.nodok and kddept=new.kddept and grouppenggajian=new.grouppenggajian;
	
	for vr_nik in select trim(nik) from sc_tmp.p1721_detail where no_urut=99 and grouppenggajian=new.grouppenggajian and nik in (select trim(nik) from sc_mst.karyawan where bag_dept=new.kddept) 
	loop

		perform sc_trx.pr_1721_penomoran_buktipotong_final(vr_nik,99, new.nodok);
		--SELECT sc_trx.pr_1721_penomoran_buktipotong_final('07791607',99,'66666');
		
	
	end loop;

	insert into sc_trx.p1721_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir,nomor_pelaporan,grouppenggajian)
	select vr_nodok as nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'P' as status,keterangan,nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,periode_mulai,periode_akhir,nomor_pelaporan,grouppenggajian from sc_tmp.p1721_detail
	where nodok=new.nodok and nik in (select trim(nik) from sc_mst.karyawan where bag_dept=new.kddept) and grouppenggajian=new.grouppenggajian;


	
	delete from sc_tmp.p1721_rekap where nodok=new.nodok and kddept=new.kddept;
	delete from sc_tmp.p1721_detail where nodok=new.nodok and nik in (select nik from sc_mst.karyawan where bag_dept=new.kddept);
end if;
--select * from sc_trx.p1721_detail limit 10
return new;

end;
$$;

alter function pr_final_form1721() owner to postgres;

