create function mutasi_after() returns trigger
    language plpgsql
as
$$
declare
     vr_status char(10);
     vr_nomor char(12);
begin

	if(new.status='P' and old.status='I') then	

	update sc_mst.karyawan set bag_dept=new.newkddept, subbag_dept=new.newkdsubdept, lvl_jabatan=new.newkdlevel,nik_atasan=new.newnikatasan,jabatan=new.newkdjabatan,nik_atasan2=new.newnikatasan2 
	where nik=new.nik;

	end if;	
    
    return new;
        
end;
$$;

alter function mutasi_after() owner to postgres;

