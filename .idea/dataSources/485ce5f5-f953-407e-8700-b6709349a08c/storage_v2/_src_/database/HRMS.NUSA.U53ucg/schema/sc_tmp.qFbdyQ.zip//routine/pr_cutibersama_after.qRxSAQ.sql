create function pr_cutibersama_after() returns trigger
    language plpgsql
as
$$
declare
     
     vr_nomor char(30);
     
begin

delete from sc_mst.penomoran where userid=new.nodok; 
insert into sc_mst.penomoran 
        (userid,dokumen,nomor,errorid,partid,counterid,xno)
        values(new.nodok,'CUTI-BERSAMA',' ',0,' ',1,0);

vr_nomor:=trim(coalesce(nomor,'')) from sc_mst.penomoran where userid=new.nodok;

 if (trim(vr_nomor)!='') or (not vr_nomor is null) then
	INSERT INTO sc_trx.cutibersama(
		nodok,tgl_dok,status,tgl_awal,tgl_akhir,input_by,input_date,update_by,update_date,jumlahcuti,keterangan
	    )
	SELECT vr_nomor,tgl_dok,status,tgl_awal,tgl_akhir,input_by,input_date,update_by,update_date,jumlahcuti,keterangan

	from sc_tmp.cutibersama where nodok=new.nodok;
       
delete from sc_tmp.cutibersama where nodok=new.nodok;

end if;

return new;

end;
$$;

alter function pr_cutibersama_after() owner to postgres;

