create function update_badgenumber(vr_tglawal character, vr_tglakhir character) returns timestamp without time zone
    language plpgsql
as
$$
DECLARE
    vr_tgl timestamp without time zone;	
   
    
    
    
BEGIN
	    update sc_tmp.checkinout set badgenumber=case when (length(trim(cast(badgenumber as character varying))) >=1) and (length(trim(cast(badgenumber as character varying))) <=7) 
	    then repeat('0',4-length(left(trim(cast(badgenumber as character varying)),length(trim(cast(badgenumber as character varying)))-4)))||
	    left(trim(cast(badgenumber as character varying)),length(trim(cast(badgenumber as character varying)))-4)||
	    right(trim(cast(badgenumber as character varying)),4)
	    ELSE badgenumber
	    end
	    where to_char(checktime,'YYYY-MM-DD') between vr_tglawal and vr_tglakhir;


    
    RETURN vr_tgl;
END;
$$;

alter function update_badgenumber(char, char) owner to postgres;

