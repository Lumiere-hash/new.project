create function pr_detail_lembur_insert() returns trigger
    language plpgsql
as
$$
declare
     
     vr_durasi2 integer;
     vr_jamselesai time;
     vr_jammulai time;

   
   
begin
--vr_status:=trim(coalesce(status,'')) from sc_tmp.cuti where branch=new.branch and kddokumen=new.kddokumen for update;
--vr_nomor
vr_jammulai:=jam_mulai from sc_tmp.detail_lembur where nodok=new.nodok and nodok_ref=new.nodok_ref;
vr_jamselesai:=jam_selesai_absen from sc_tmp.detail_lembur where nodok=new.nodok and nodok_ref=new.nodok_ref;
	if (vr_jamselesai is not null) then
		
	vr_durasi2:=extract(epoch from cast(to_char(cast(vr_jamselesai as time) - cast(vr_jammulai as time),'HH24:mi')as time)::interval)/60 as durasi;	

	 update sc_tmp.detail_lembur set jumlah_jam_absen=vr_durasi2 where nodok=new.nodok and nodok_ref=new.nodok_ref;
	--insert into dumy(waktu,jumlah) values (vr_jamselesai,vr_durasi2);	
	--insert into dumy(jumlah) values (vr_durasi2);	
	end if;

return new;

end;
$$;

alter function pr_detail_lembur_insert() owner to postgres;

