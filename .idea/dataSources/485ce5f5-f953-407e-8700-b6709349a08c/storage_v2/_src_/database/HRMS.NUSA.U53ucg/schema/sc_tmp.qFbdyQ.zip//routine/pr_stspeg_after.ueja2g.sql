create function pr_stspeg_after() returns trigger
    language plpgsql
as
$$

declare
    vr_nomor char(30);
    /* ALTER TABLE STATUS */
begin
    delete from sc_mst.penomoran where userid = new.nodok;
    insert into sc_mst.penomoran (userid, dokumen, nomor, errorid, partid, counterid, xno)
    values (new.nodok, 'STATUS-PEG', ' ', 0, ' ', 1, 0);


    vr_nomor
        := trim(coalesce(nomor, '')) from sc_mst.penomoran where userid = new.nodok;
    raise notice '%',trim(new.kdkepegawaian);
    if
            (trim(vr_nomor) != '') or (not vr_nomor is null) then

        INSERT INTO sc_trx.status_kepegawaian(nodok, nik, kdkepegawaian, tgl_mulai, tgl_selesai, cuti, keterangan,
                                              input_date, update_date, input_by, update_by, nosk, status)

        SELECT vr_nomor,
               nik,
               kdkepegawaian,
               tgl_mulai,
               tgl_selesai,
               cuti,
               keterangan,
               input_date,
               update_date,
               input_by,
               update_by,
               nosk,
               'A'::CHAR(4)


        from sc_tmp.status_kepegawaian
        where nodok = new.nodok
          and nik = new.nik;

/*UBAH DOKUMEN KE SEDANG AKTIF*/
        UPDATE sc_trx.status_kepegawaian as trx
        SET status = 'B',
            update_date = tmp.input_date,
            input_by = tmp.input_by
        FROM (
                 SELECT input_date, input_by
                 FROM sc_tmp.status_kepegawaian) AS tmp
        WHERE
                trx.nodok = vr_nomor and nik = new.nik;

/*UBAH DOKUMEN KE SUDAH BERAKHIR*/
        UPDATE sc_trx.status_kepegawaian SET status='C'
        WHERE nik=new.nik and nodok <> vr_nomor;

/*HOLD USER*/
        if (trim(new.kdkepegawaian) = 'KO') then
            UPDATE sc_mst."user" as mst
            SET hold_id = 'Y',
                expdate = tmp.input_date,
                editby = tmp.input_by
            FROM (
                     SELECT nik,input_date, input_by
                     FROM sc_tmp.status_kepegawaian) AS tmp
            WHERE
                    mst.nik = tmp.nik;
        end if;

        delete
        from sc_tmp.status_kepegawaian
        where nodok = new.nodok
          and nik = new.nik;


    end if;


    return new;


end;

$$;

alter function pr_stspeg_after() owner to postgres;

