create function tr_deklarasi_dtl() returns trigger
    language plpgsql
as
$$
DECLARE
vr_total_dek numeric(18,2);
vr_um_dek numeric(18,2);
vr_sisa_dek numeric(18,2);
BEGIN
		
	IF (tg_op = 'INSERT') or (tg_op = 'UPDATE') THEN	

		vr_total_dek:=sum(coalesce(bbm_rupiah,0) + coalesce(parkir,0) + coalesce(tol,0) + coalesce(uangsaku,0) + coalesce(laundry,0) + coalesce(transport,0) + coalesce(lain,0))
		from sc_tmp.deklarasi_dtl where  nik=new.nik and nodok_ref=new.nodok_ref and nodok=new.nodok;

		vr_um_dek:=coalesce(uangmuka) from sc_tmp.deklarasi_mst where  nik=new.nik and nodok_ref=new.nodok_ref and nodok=new.nodok;
		vr_sisa_dek:=vr_um_dek - vr_total_dek;
		
		update sc_tmp.deklarasi_mst set total=vr_total_dek,sisa=vr_sisa_dek  where  nik=new.nik and nodok_ref=new.nodok_ref and nodok=new.nodok;

		
		RETURN new;
		
	ELSEIF tg_op = 'DELETE' THEN
		vr_total_dek:=sum(coalesce(bbm_rupiah,0) + coalesce(parkir,0) + coalesce(tol,0) + coalesce(uangsaku,0) + coalesce(laundry,0) + coalesce(transport,0) + coalesce(lain,0))
		from sc_tmp.deklarasi_dtl where  nik=old.nik and nodok_ref=old.nodok_ref and nodok=old.nodok;

		vr_um_dek:=coalesce(uangmuka) from sc_tmp.deklarasi_mst where  nik=old.nik and nodok_ref=old.nodok_ref and nodok=old.nodok;
		vr_sisa_dek:=vr_um_dek - vr_total_dek;
		
		update sc_tmp.deklarasi_mst set total=vr_total_dek,sisa=vr_sisa_dek where  nik=old.nik and nodok_ref=old.nodok_ref and nodok=old.nodok;
		
		RETURN old;	
	END IF;
	
END;
$$;

alter function tr_deklarasi_dtl() owner to postgres;

