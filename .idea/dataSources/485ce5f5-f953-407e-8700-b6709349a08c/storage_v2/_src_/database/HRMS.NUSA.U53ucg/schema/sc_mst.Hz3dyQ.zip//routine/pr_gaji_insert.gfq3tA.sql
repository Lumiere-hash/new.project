create function pr_gaji_insert() returns trigger
    language plpgsql
as
$$
declare
     
   vr_k_gplvl numeric(18,2);
   vr_k_gpwil numeric(18,2);
   vr_gajipokok numeric(18,2);
   vr_gajitetap numeric(18,2);
   vr_tj_tetap numeric(18,2);
   vr_branch text :=coalesce(branch,'') from sc_mst.branch where cdefault='YES';
   /* RESTRUKTUR 04/05/2019 
alter table sc_his.history_gaji add column k_gplvl numeric(18,2),add column k_gpwil numeric(18,2);
   */
   
   
begin
	if (new.status='P' and old.status='I') then
		--select coalesce(nominal,0.00) into vr_gajipokok from sc_mst.dtlgaji_karyawan where nik=new.nik and no_urut=1;
		
		select coalesce(ttlgp,0),coalesce(nominalwilayah,0),coalesce(nominallvlgp,0) into vr_gajipokok,vr_k_gpwil,vr_k_gplvl from (
			select a.*,b.nominal as nominalwilayah,c.nominal as nominallvlgp,
			(coalesce(b.nominal,0) + coalesce(c.nominal,0) ) as ttlgp from sc_mst.lv_m_karyawan a
			left outer join sc_mst.m_wilayah_nominal b on a.kdwilayahnominal=b.kdwilayahnominal
			left outer join sc_mst.m_lvlgp c on a.kdlvlgp=c.kdlvlgp ) as x
			where nik=new.nik;
		
		select sum(coalesce(nominal,0.00)) into vr_tj_tetap from sc_mst.dtlgaji_karyawan where nik=new.nik and no_urut<>1;
		select sum(coalesce(nominal,0.00)) into vr_gajitetap from sc_mst.dtlgaji_karyawan where nik=new.nik;
			
		/* UPDATE HISTORY GAJI */
		update sc_mst.karyawan set gajipokok=vr_gajipokok,tj_tetap=vr_tj_tetap,gajitetap=vr_gajitetap  where nik=new.nik;
		delete from sc_his.history_gaji where periode=to_char(now(),'yyyymm') and nik=new.nik;
		insert into sc_his.history_gaji 
			(branch,nik,periode,nominal,inputdate,inputby,updatedate,updateby,gajipokok,gajitj,k_gplvl,k_gpwil)
			(select vr_branch,nik,to_char(now(),'yyyymm'),coalesce(gajitetap,0),new.editdate,new.editby,null,null,coalesce(gajipokok,0),coalesce(tj_tetap,0),vr_k_gplvl,vr_k_gpwil
			from sc_mst.karyawan where nik=new.nik);
			
		insert into sc_his.history_dtlgaji_karyawan  
		(nik,gajipokok,tj_tetap,gajitetap,editby,editdate)
		(select nik,nominal,vr_tj_tetap,vr_gajitetap,new.editby,to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp 
		from sc_mst.dtlgaji_karyawan where nik=new.nik and no_urut=1 and nik not in 
		(select nik from sc_his.history_dtlgaji_karyawan where editdate = to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp  and editby = new.editby)
		group by nik,nominal);

	ELSEIF(new.status='U') THEN
		--select coalesce(nominal,0.00) into vr_gajipokok from sc_mst.dtlgaji_karyawan where nik=new.nik and no_urut=1;
		select coalesce(ttlgp,0),coalesce(nominalwilayah,0),coalesce(nominallvlgp,0) into vr_gajipokok,vr_k_gpwil,vr_k_gplvl from (
			select a.*,b.nominal as nominalwilayah,c.nominal as nominallvlgp,
			(coalesce(b.nominal,0) + coalesce(c.nominal,0) ) as ttlgp from sc_mst.lv_m_karyawan a
			left outer join sc_mst.m_wilayah_nominal b on a.kdwilayahnominal=b.kdwilayahnominal
			left outer join sc_mst.m_lvlgp c on a.kdlvlgp=c.kdlvlgp ) as x
			where nik=new.nik;
		
		select sum(coalesce(nominal,0.00)) into vr_tj_tetap from sc_mst.dtlgaji_karyawan where nik=new.nik and no_urut<>1;
		select sum(coalesce(nominal,0.00)) into vr_gajitetap from sc_mst.dtlgaji_karyawan where nik=new.nik;

		/* UPDATE HISTORY GAJI */
		update sc_mst.karyawan set gajipokok=vr_gajipokok,tj_tetap=vr_tj_tetap,gajitetap=vr_gajitetap  where nik=new.nik;
		delete from sc_his.history_gaji where periode=to_char(now(),'yyyymm') and nik=new.nik;
		insert into sc_his.history_gaji 
			(branch,nik,periode,nominal,inputdate,inputby,updatedate,updateby,gajipokok,gajitj,k_gplvl,k_gpwil)
			(select vr_branch,nik,to_char(now(),'yyyymm'),coalesce(gajitetap,0),new.editdate,new.editby,null,null,coalesce(gajipokok,0),coalesce(tj_tetap,0),vr_k_gplvl,vr_k_gpwil  
			from sc_mst.karyawan where nik=new.nik);

		insert into sc_his.history_dtlgaji_karyawan  
		(nik,gajipokok,tj_tetap,gajitetap,editby,editdate)
		(select nik,nominal,vr_tj_tetap,vr_gajitetap,new.editby,to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp 
		from sc_mst.dtlgaji_karyawan where nik=new.nik and no_urut=1 and nik not in 
		(select nik from sc_his.history_dtlgaji_karyawan where editdate = to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp  and editby = new.editby)
		group by nik,nominal);
		--select * from sc_mst.dtlgaji_karyawan
		update  sc_mst.dtlgaji_karyawan set status=old.status where nik=new.nik and no_urut=1;
	end if;	

return new;

end;
$$;

alter function pr_gaji_insert() owner to postgres;

