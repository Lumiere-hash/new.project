create function pr_ambil_tm_21(id character, nomor integer, userid character, periode integer, bulankeluar integer) returns numeric
    language plpgsql
as
$$
DECLARE 
vr_duit numeric(18,2);
vr_duit1 numeric(18,2);
vr_duit2 numeric(18,2);
BEGIN		

	select coalesce(sum(nominal),0) into vr_duit1 from sc_mst.dtlgaji_karyawan where nik=id and no_urut=8 and keterangan='TUNJANGAN MASA KERJA';
 	select coalesce(sum(nominal),0) into vr_duit2 from sc_mst.dtlgaji_karyawan where nik=id and no_urut=9 and keterangan='TUNJANGAN PRESTASI';

	--vr_duit=vr_duit1+vr_duit2;
	vr_duit=vr_duit1;
	
	delete from sc_tmp.p21_detail where nodok=userid and nik=id and no_urut=nomor and periode_mulai=periode;

	insert into sc_tmp.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select userid as nodok,id as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_duit as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,
	periode as periode_mulai,periode as periode_akhir from sc_mst.detail_formula
	where no_urut=nomor and kdrumus='P21';
 
	
	RETURN vr_duit;	
END;
$$;

alter function pr_ambil_tm_21(char, integer, char, integer, integer) owner to postgres;

