create function pr_nipnbi_after() returns trigger
    language plpgsql
as
$$

DECLARE
    -- Created By FIKY : 03/04/2016
    -- Update By ARBI : 24/01/2022
    -- Tambahan Perbedaan Format NIK Untuk Karyawan Borong
    vr_idabsen CHAR(12);
    vr_nik CHAR(12);
    vr_nomor CHAR(12);
    vr_nik_prefix CHAR(12);
    vr_dokumen CHAR(12);
BEGIN
    IF(new.tjborong = 't') THEN
        vr_nik_prefix := TO_CHAR(new.tglmasukkerja, 'YY');
        vr_dokumen := 'NIP-BORONG';
    ELSE
        vr_nik_prefix := TO_CHAR(new.tglmasukkerja, 'MMYY') || '.';
        vr_dokumen := 'NIP-PEGAWAI';
    END IF;
    vr_idabsen := TRIM(COALESCE(idabsen, '')) FROM sc_tmp.karyawan WHERE idabsen = new.idabsen AND nik = new.nik;
    vr_nik := TRIM(COALESCE(nik, '')) FROM sc_tmp.karyawan WHERE idabsen = new.idabsen AND nik = new.nik;

    DELETE FROM sc_mst.penomoran WHERE userid = vr_nik;
    DELETE FROM sc_mst.trxerror WHERE userid = vr_nik;

    INSERT INTO sc_mst.penomoran (userid, dokumen, nomor, errorid, partid, counterid, xno)
    VALUES (vr_nik, vr_dokumen, ' ', 0, ' ', 1, 0);

    vr_nomor := TRIM(COALESCE(nomor, '')) FROM sc_mst.penomoran WHERE userid = vr_nik;
    IF(NULLIF(TRIM(vr_nomor), '') IS NOT NULL) THEN
        INSERT INTO sc_mst.karyawan (branch, nik, nmlengkap, callname, jk, neglahir, provlahir, kotalahir, tgllahir, kd_agama, stswn, stsfisik, ketfisik, noktp, ktp_seumurhdp,
            ktpdikeluarkan, tgldikeluarkan, status_pernikahan, gol_darah, negktp, provktp, kotaktp, kecktp, kelktp, alamatktp, negtinggal, provtinggal, kotatinggal, kectinggal,
            keltinggal, alamattinggal, nohp1, nohp2, npwp, tglnpwp, bag_dept, subbag_dept, jabatan, lvl_jabatan, grade_golongan, nik_atasan, nik_atasan2, status_ptkp, besaranptkp,
            tglmasukkerja, tglkeluarkerja, masakerja, statuskepegawaian, kdcabang, branchaktif, grouppenggajian, gajipokok, gajibpjs, namabank, namapemilikrekening, norek, tjshift,
            idabsen, email, bolehcuti, sisacuti, inputdate, inputby, updatedate, updateby, image, idmesin, cardnumber, status, tgl_ktp, costcenter, tj_tetap, gajitetap, gajinaker,
            tjlembur, tjborong, nokk, kdwilayahnominal, kdlvlgp, pinjaman, kdgradejabatan, deviceid, callplan)
        SELECT branch, vr_nik_prefix || vr_nomor AS nik, nmlengkap, callname, jk, neglahir, provlahir, kotalahir, tgllahir, kd_agama, stswn, stsfisik,
            ketfisik, noktp, ktp_seumurhdp, ktpdikeluarkan, tgldikeluarkan, status_pernikahan, gol_darah, negktp, provktp, kotaktp, kecktp, kelktp, alamatktp, negtinggal,
            provtinggal, kotatinggal, kectinggal, keltinggal, alamattinggal, nohp1, nohp2, npwp, tglnpwp, bag_dept, subbag_dept, jabatan, lvl_jabatan, grade_golongan, nik_atasan,
            nik_atasan2, status_ptkp, besaranptkp, tglmasukkerja, tglkeluarkerja, masakerja, statuskepegawaian, kdcabang, branchaktif, grouppenggajian, gajipokok, gajibpjs, namabank,
            namapemilikrekening, norek, tjshift, idabsen, email, bolehcuti, sisacuti, inputdate, inputby, updatedate, updateby, image, idmesin, cardnumber, status, tgl_ktp,
            costcenter, tj_tetap, gajitetap, gajinaker, tjlembur, tjborong, nokk, kdwilayahnominal, kdlvlgp, pinjaman, kdgradejabatan, deviceid, callplan
        FROM sc_tmp.karyawan
        WHERE nik = new.nik;

        DELETE FROM sc_tmp.karyawan WHERE nik = vr_nik;
        INSERT INTO sc_mst.trxerror (userid, errorcode, nomorakhir1, nomorakhir2, modul)
        VALUES (vr_nik, '0', vr_nomor, vr_nomor, 'KARYAWAN');
    ELSE
        INSERT INTO sc_mst.trxerror (userid, errorcode, nomorakhir1, nomorakhir2, modul)
        VALUES (vr_nik, '1', '', '', 'KARYAWAN');
    END IF;
    RETURN new;
END;
$$;

alter function pr_nipnbi_after() owner to postgres;

