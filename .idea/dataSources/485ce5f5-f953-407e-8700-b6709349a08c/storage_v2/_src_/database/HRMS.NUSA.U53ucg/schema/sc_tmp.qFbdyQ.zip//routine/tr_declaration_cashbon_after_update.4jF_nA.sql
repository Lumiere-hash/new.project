create function tr_declaration_cashbon_after_update() returns trigger
    language plpgsql
as
$$
DECLARE
    number VARCHAR;

BEGIN
    IF ( UPPER(NEW.status) = 'F' AND UPPER(OLD.status) <> 'F' ) THEN
        DELETE FROM sc_mst.penomoran WHERE TRUE AND userid = NEW.declarationid;
        IF NOT EXISTS ( SELECT TRUE FROM sc_mst.nomor WHERE TRUE AND dokumen = 'DECLCASHB' ) THEN
            INSERT INTO sc_mst.nomor (
                dokumen,
                part,
                count3,
                prefix,
                sufix,
                docno,
                userid,
                modul,
                periode,
                cekclose
            ) VALUES (
                         'DECLCASHB',
                         '',
                         4,
                         CONCAT('DC', TO_CHAR(NOW(), 'YY')),
                         '',
                         0,
                         NEW.inputby,
                         '',
                         TO_CHAR(NOW(), 'YYYY'),
                         'T'
                     );
        END IF;

        INSERT INTO sc_mst.penomoran (
            userid,
            dokumen,
            nomor,
            errorid,
            partid,
            counterid,
            xno
        ) VALUES (
                     NEW.declarationid,
                     'DECLCASHB',
                     '',
                     0,
                     '',
                     1,
                     0
                 );

        SELECT COALESCE(TRIM(nomor), '') INTO number
        FROM sc_mst.penomoran WHERE TRUE
                                AND userid = new.declarationid;

        if (COALESCE(TRIM(number), '') <> '') THEN
            DELETE FROM sc_trx.declaration_cashbon WHERE TRUE
                                                     AND declarationid = NEW.declarationid;

            INSERT INTO sc_trx.declaration_cashbon (
                branch,
                declarationid,
                cashbonid,
                dutieid,
                superior,
                status,
                paymenttype,
                totalcashbon,
                totaldeclaration,
                returnamount,
                inputby,
                inputdate,
                updateby,
                updatedate,
                approveby,
                approvedate
            ) SELECT
                  branch,
                  number AS declarationid,
                  cashbonid,
                  dutieid,
                  superior,
                  OLD.status AS status,
                  paymenttype,
                  totalcashbon,
                  totaldeclaration,
                  returnamount,
                  inputby,
                  inputdate,
                  updateby,
                  updatedate,
                  approveby,
                  approvedate
            FROM sc_tmp.declaration_cashbon WHERE TRUE
                                              AND declarationid = NEW.declarationid;

            DELETE FROM sc_trx.declaration_cashbon_component WHERE TRUE
                                                               AND declarationid = NEW.declarationid;

            INSERT INTO sc_trx.declaration_cashbon_component (
                branch,
                declarationid,
                componentid,
                dutieid,
                perday,
                nominal,
                description,
                inputby,
                inputdate,
                updateby,
                updatedate
            ) SELECT
                  branch,
                  number AS declarationid,
                  componentid,
                  dutieid,
                  perday,
                  nominal,
                  description,
                  inputby,
                  inputdate,
                  updateby,
                  updatedate
            FROM sc_tmp.declaration_cashbon_component WHERE TRUE
                                                        AND declarationid = NEW.declarationid;

            DELETE FROM sc_tmp.declaration_cashbon WHERE TRUE
                                                     AND declarationid = NEW.declarationid;

            DELETE FROM sc_tmp.declaration_cashbon_component WHERE TRUE
                                                               AND declarationid = NEW.declarationid;
        END IF;
    END IF;

    IF ( UPPER(NEW.status) = 'U' AND UPPER(OLD.status) <> 'U' ) THEN
        DELETE FROM sc_trx.declaration_cashbon WHERE TRUE
                                                 AND declarationid = NEW.declarationid;

        INSERT INTO sc_trx.declaration_cashbon (
            branch,
            declarationid,
            cashbonid,
            dutieid,
            superior,
            status,
            paymenttype,
            totalcashbon,
            totaldeclaration,
            returnamount,
            inputby,
            inputdate,
            updateby,
            updatedate,
            approveby,
            approvedate
        ) SELECT
              branch,
              declarationid,
              cashbonid,
              dutieid,
              superior,
              OLD.status AS status,
              paymenttype,
              totalcashbon,
              totaldeclaration,
              returnamount,
              inputby,
              inputdate,
              updateby,
              updatedate,
              approveby,
              approvedate
        FROM sc_tmp.declaration_cashbon WHERE TRUE
                                          AND declarationid = NEW.declarationid;

        DELETE FROM sc_trx.declaration_cashbon_component WHERE TRUE
                                                           AND declarationid = NEW.declarationid;

        INSERT INTO sc_trx.declaration_cashbon_component (
            branch,
            declarationid,
            componentid,
            dutieid,
            perday,
            nominal,
            description,
            inputby,
            inputdate,
            updateby,
            updatedate
        ) SELECT
              branch,
              declarationid,
              componentid,
              dutieid,
              perday,
              nominal,
              description,
              inputby,
              inputdate,
              updateby,
              updatedate
        FROM sc_tmp.declaration_cashbon_component WHERE TRUE
                                                    AND declarationid = NEW.declarationid;

        DELETE FROM sc_tmp.declaration_cashbon WHERE TRUE
                                                 AND declarationid = NEW.declarationid;

        DELETE FROM sc_tmp.declaration_cashbon_component WHERE TRUE
                                                           AND declarationid = NEW.declarationid;
    END IF;
    RETURN NEW;
END;
$$;

alter function tr_declaration_cashbon_after_update() owner to postgres;

