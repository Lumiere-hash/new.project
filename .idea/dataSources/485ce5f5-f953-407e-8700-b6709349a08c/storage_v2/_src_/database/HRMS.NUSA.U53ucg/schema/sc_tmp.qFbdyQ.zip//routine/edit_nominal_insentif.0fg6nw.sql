create function edit_nominal_insentif() returns timestamp without time zone
    language plpgsql
as
$$
DECLARE
    vr_tgl timestamp without time zone;	
    vr_nik char(12);
    vr_nodok char(16);
   vr_upah numeric(18,2);
   vr_ptg numeric(18,2);
   vr_pendapatan numeric(18,2);
   vr_totalupah numeric(18,2);
   vr_totalpendapatan numeric(18,2);
    
    
    
BEGIN
	--vr_keluarkerja:=to_char(tglakhirfix,'YYYYMM');
      --FOR listNik IN select distinct nik from sc_trx.dtljadwalkerja where to_char(tgl,'YYYYMM')=$1 and case when xnik<>'' then nik=xnik else nik<>'' end order by nik
    FOR vr_nik IN select distinct nik from sc_trx.payroll_master where nodok='PRGPJ1608' ORDER BY nik
			

			
		
    LOOP
	    
	
	    --FOR vr_urut IN select no_urut from sc_mst.detail_formula where kdrumus='PR' order by no_urut asc 
	    --LOOP
		
		     --insert into dumy(nik) values (vr_nik);

		   select sum(total_upah) into vr_upah from sc_trx.payroll_master  where nik=vr_nik and nodok='PRGPJ1608';

		   select sum(total_pendapatan) into vr_pendapatan from sc_trx.payroll_master  where nik=vr_nik and nodok='PRGPJ1608';
		   --select total_pendapatan into vr_pendapatan from sc_tmp.payroll_master where nik=vr_nik;

		   select sum(nominal) into vr_ptg from sc_trx.payroll_detail 
		   where no_urut in (16,17) and nodok='PRGPJ1608' and nik=vr_nik;
		   vr_totalupah=vr_upah-vr_ptg;
		   vr_totalpendapatan=vr_pendapatan-vr_ptg;
		   
		   if (vr_upah<>0.00) then
		   update sc_trx.payroll_master set total_upah=vr_totalupah,total_pendapatan=vr_totalpendapatan  
		   where nik=vr_nik and nodok='PRGPJ1608';   
		   end if;	
		   
	    
	    
    END LOOP;
    
    RETURN vr_tgl;
END;
$$;

alter function edit_nominal_insentif() owner to postgres;

