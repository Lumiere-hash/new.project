create function tr_pdca_list_gen() returns trigger
    language plpgsql
as
$$
declare
--created by Fiky ::18/07/2017
     vr_nomor char(12); 
     vr_cekprefix char(4);
     vr_nowprefix char(4);
begin    

	IF TG_OP ='INSERT' THEN 

	RETURN NEW;
	ELSEIF TG_OP ='UPDATE' THEN
			/* NO RESOURCE UPDATE */
		if (((new.status='I' and old.status='I') or (coalesce(new.status,'')='' and coalesce(old.status,'')='')) and new.nomor!='999') then
		--select * from sc_his.pdca_list_gen
		update sc_his.pdca_list_gen set --total %
			tgl1=(select coalesce(sum(tgl1::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl2=(select coalesce(sum(tgl2::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl3=(select coalesce(sum(tgl3::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl4=(select coalesce(sum(tgl4::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl5=(select coalesce(sum(tgl5::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl6=(select coalesce(sum(tgl6::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl7=(select coalesce(sum(tgl7::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl8=(select coalesce(sum(tgl8::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl9=(select coalesce(sum(tgl9::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl10=(select coalesce(sum(tgl10::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl11=(select coalesce(sum(tgl11::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl12=(select coalesce(sum(tgl12::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl13=(select coalesce(sum(tgl13::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl14=(select coalesce(sum(tgl14::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl15=(select coalesce(sum(tgl15::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl16=(select coalesce(sum(tgl16::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl17=(select coalesce(sum(tgl17::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl18=(select coalesce(sum(tgl18::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl19=(select coalesce(sum(tgl19::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl20=(select coalesce(sum(tgl20::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl21=(select coalesce(sum(tgl21::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl22=(select coalesce(sum(tgl22::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl23=(select coalesce(sum(tgl23::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl24=(select coalesce(sum(tgl24::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl25=(select coalesce(sum(tgl25::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl26=(select coalesce(sum(tgl26::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl27=(select coalesce(sum(tgl27::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl28=(select coalesce(sum(tgl28::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl29=(select coalesce(sum(tgl29::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl30=(select coalesce(sum(tgl30::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3'),
			tgl31=(select coalesce(sum(tgl31::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')
		where nik=new.nik and nomor='999' and planperiod=new.planperiod and urutcategory='1';
			
		update sc_his.pdca_list_gen set --total plan select * from sc_his.pdca_list_gen 
			tgl1=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik and planperiod=new.planperiod  and urutcategory='1'),
			tgl2=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik and  planperiod=new.planperiod  and urutcategory='1'),
			tgl3=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik  and  planperiod=new.planperiod  and urutcategory='1'),
			tgl4=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik  and  planperiod=new.planperiod  and urutcategory='1'),
			tgl5=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik and   planperiod=new.planperiod  and urutcategory='1'),
			tgl6=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik  and  planperiod=new.planperiod  and urutcategory='1'),
			tgl7=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik  and  planperiod=new.planperiod  and urutcategory='1'),
			tgl8=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik  and  planperiod=new.planperiod  and urutcategory='1'),
			tgl9=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik  and  planperiod=new.planperiod  and urutcategory='1'),
			tgl10=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik  and  planperiod=new.planperiod  and urutcategory='1'),
			tgl11=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik  and  planperiod=new.planperiod  and urutcategory='1'),
			tgl12=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik  and  planperiod=new.planperiod  and urutcategory='1'),
			tgl13=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik  and  planperiod=new.planperiod  and urutcategory='1'),
			tgl14=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik  and  planperiod=new.planperiod  and urutcategory='1'),
			tgl15=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik  and  planperiod=new.planperiod  and urutcategory='1'),
			tgl16=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik  and  planperiod=new.planperiod  and urutcategory='1'),
			tgl17=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik  and  planperiod=new.planperiod  and urutcategory='1'),
			tgl18=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik  and  planperiod=new.planperiod  and urutcategory='1'),
			tgl19=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik  and  planperiod=new.planperiod  and urutcategory='1'),
			tgl20=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik  and  planperiod=new.planperiod  and urutcategory='1'),
			tgl21=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik  and  planperiod=new.planperiod  and urutcategory='1'),
			tgl22=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik  and  planperiod=new.planperiod  and urutcategory='1'),
			tgl23=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik  and  planperiod=new.planperiod  and urutcategory='1'),
			tgl24=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik  and  planperiod=new.planperiod  and urutcategory='1'),
			tgl25=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik  and  planperiod=new.planperiod  and urutcategory='1'),
			tgl26=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik  and  planperiod=new.planperiod  and urutcategory='1'),
			tgl27=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik  and  planperiod=new.planperiod  and urutcategory='1'),
			tgl28=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik  and  planperiod=new.planperiod  and urutcategory='1'),
			tgl29=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik  and  planperiod=new.planperiod  and urutcategory='1'),
			tgl30=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik  and  planperiod=new.planperiod  and urutcategory='1'),
			tgl31=(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik  and  planperiod=new.planperiod  and urutcategory='1')
		where nik=new.nik and nomor='999' and planperiod=new.planperiod and urutcategory='2';

		
		update sc_his.pdca_list_gen set ---avg
			tgl1= round((select coalesce(sum(tgl1::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999'  and nik=new.nik and planperiod=new.planperiod  and urutcategory='1') ,2),
			tgl2= round((select coalesce(sum(tgl2::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999'  and nik=new.nik and planperiod=new.planperiod  and urutcategory='1') ,2),
			tgl3= round((select coalesce(sum(tgl3::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999'  and nik=new.nik and planperiod=new.planperiod  and urutcategory='1') ,2),
			tgl4= round((select coalesce(sum(tgl4::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999'  and nik=new.nik and planperiod=new.planperiod  and urutcategory='1') ,2),
			tgl5= round((select coalesce(sum(tgl5::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999'  and nik=new.nik and planperiod=new.planperiod  and urutcategory='1') ,2),
			tgl6= round((select coalesce(sum(tgl6::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999'  and nik=new.nik and planperiod=new.planperiod  and urutcategory='1') ,2),
			tgl7= round((select coalesce(sum(tgl7::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999'  and nik=new.nik and planperiod=new.planperiod  and urutcategory='1') ,2),
			tgl8= round((select coalesce(sum(tgl8::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999'  and nik=new.nik and planperiod=new.planperiod  and urutcategory='1') ,2),
			tgl9= round((select coalesce(sum(tgl9::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999'  and nik=new.nik and planperiod=new.planperiod  and urutcategory='1') ,2),
			tgl10=round((select coalesce(sum(tgl10::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik and planperiod=new.planperiod  and urutcategory='1'),2),
			tgl11=round((select coalesce(sum(tgl11::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik and planperiod=new.planperiod  and urutcategory='1'),2),
			tgl12=round((select coalesce(sum(tgl12::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik and planperiod=new.planperiod  and urutcategory='1'),2),
			tgl13=round((select coalesce(sum(tgl13::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik and planperiod=new.planperiod  and urutcategory='1'),2),
			tgl14=round((select coalesce(sum(tgl14::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik and planperiod=new.planperiod  and urutcategory='1'),2),
			tgl15=round((select coalesce(sum(tgl15::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik and planperiod=new.planperiod  and urutcategory='1'),2),
			tgl16=round((select coalesce(sum(tgl16::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik and planperiod=new.planperiod  and urutcategory='1'),2),
			tgl17=round((select coalesce(sum(tgl17::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik and planperiod=new.planperiod  and urutcategory='1'),2),
			tgl18=round((select coalesce(sum(tgl18::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik and planperiod=new.planperiod  and urutcategory='1'),2),
			tgl19=round((select coalesce(sum(tgl19::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik and planperiod=new.planperiod  and urutcategory='1'),2),
			tgl20=round((select coalesce(sum(tgl20::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik and planperiod=new.planperiod  and urutcategory='1'),2),
			tgl21=round((select coalesce(sum(tgl21::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik and planperiod=new.planperiod  and urutcategory='1'),2),
			tgl22=round((select coalesce(sum(tgl22::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik and planperiod=new.planperiod  and urutcategory='1'),2),
			tgl23=round((select coalesce(sum(tgl23::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik and planperiod=new.planperiod  and urutcategory='1'),2),
			tgl24=round((select coalesce(sum(tgl24::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik and planperiod=new.planperiod  and urutcategory='1'),2),
			tgl25=round((select coalesce(sum(tgl25::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik and planperiod=new.planperiod  and urutcategory='1'),2),
			tgl26=round((select coalesce(sum(tgl26::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik and planperiod=new.planperiod  and urutcategory='1'),2),
			tgl27=round((select coalesce(sum(tgl27::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik and planperiod=new.planperiod  and urutcategory='1'),2),
			tgl28=round((select coalesce(sum(tgl28::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik and planperiod=new.planperiod  and urutcategory='1'),2),
			tgl29=round((select coalesce(sum(tgl29::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik and planperiod=new.planperiod  and urutcategory='1'),2),
			tgl30=round((select coalesce(sum(tgl30::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik and planperiod=new.planperiod  and urutcategory='1'),2),
			tgl31=round((select coalesce(sum(tgl31::numeric),0) from sc_his.pdca_list_gen where nik=new.nik and nomor!='999' and planperiod=new.planperiod and urutcategory='3')/(select count(nik) from sc_his.pdca_list_gen where nomor<>'999' and nik=new.nik and planperiod=new.planperiod  and urutcategory='1'),2)
		where nik=new.nik and nomor='999' and planperiod=new.planperiod and urutcategory='3';
		
		end if;
	
			
	RETURN NEW;
	END IF;
    
    
    return new;
        
end;
$$;

alter function tr_pdca_list_gen() owner to postgres;

