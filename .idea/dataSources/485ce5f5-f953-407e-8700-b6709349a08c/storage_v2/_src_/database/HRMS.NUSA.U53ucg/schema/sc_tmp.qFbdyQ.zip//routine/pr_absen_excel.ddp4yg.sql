create function pr_absen_excel() returns trigger
    language plpgsql
as
$$
declare
	vr_id numeric; 
	vr_ipaddress char(16);	
	vr_badgenumber char(10);	
begin
	
	
	--if not exists(select * from sc_tmp.absen_excel where badgenumber=new.badgenumber and checktime=new.checktime) then
		delete from sc_tmp.checkinout where badgenumber=new.badgenumber and checktime=cast(to_char(new.checkdate,'yyyy-mm-dd')||' '||to_char(new.checktime,'HH24:MI:SS') as timestamp without time zone);	
		insert into sc_tmp.checkinout
			select 1111 as userid,badgenumber,nama,(cast(checkdate||' '||checktime as timestamp without time zone))as checktime,'X' as inputan,null,null from sc_tmp.absen_excel
			where badgenumber=new.badgenumber and checkdate=new.checkdate and checktime=new.checktime
		group by userid,nama,badgenumber,checkdate,checktime;
	--else then
		
	--end if;

	delete from sc_tmp.absen_excel where badgenumber=new.badgenumber;

	return new;
		
end;
$$;

alter function pr_absen_excel() owner to postgres;

