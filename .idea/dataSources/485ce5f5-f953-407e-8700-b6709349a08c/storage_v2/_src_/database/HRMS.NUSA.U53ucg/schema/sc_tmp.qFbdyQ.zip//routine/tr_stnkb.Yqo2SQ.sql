create function tr_stnkb() returns trigger
    language plpgsql
as
$$
declare
--created by Fiky ::14/07/2017
     vr_nomor char(12); 
     vr_cekprefix char(4);
     vr_nowprefix char(4);
begin    

	IF TG_OP ='INSERT' THEN 

	
	ELSEIF TG_OP ='UPDATE' THEN 
		IF (new.status='F' and old.status='I') THEN
			if (new.jenispengurusan='1T') then 
				update sc_tmp.stnkb set 
				kdgroup=b.kdgroup,
				nopol         =b.nopol           ,
				nmkendaraan   =b.nmbarang     ,
				nmpemilik     =b.nmpemilik       ,
				addpemilik    =b.addpemilik      ,
				hppemilik     =b.hppemilik       ,
				typeid        =b.typeid          ,
				jenisid       =b.jenisid         ,
				modelid       =b.modelid         ,
				tahunpembuatan=b.tahunpembuatan  ,
				silinder      =b.silinder        ,
				warna         =b.warna           ,
				bahanbakar    =b.bahanbakar      ,
				warnatnkb     =b.warnatnkb       ,
				tahunreg      =b.tahunreg        ,
				nobpkb        =b.nobpkb          ,
				kdlokasi      =b.kdlokasi        ,
				expstnkb      =b.expstnkb        ,
				old_expstnkb      =b.expstnkb        ,
				old_exppkbstnkb   =b.exppkbstnkb     ,
				old_nopkb         =b.nopkb           ,
				old_nominalpkb    =b.nominalpkb      
				from sc_mst.mbarang b where b.kdrangka=new.kdrangka and b.kdmesin=new.kdmesin;
				--from sc_mst.kendaraan b where b.kdrangka='MH1JFB120DK190742' and b.kdmesin='JFB1E2145692';
			elseif (new.jenispengurusan='5T') then
				update sc_tmp.stnkb set 
				kdgroup=b.kdgroup,
				old_nopol         =b.nopol           ,
				old_kdgroup       =b.kdgroup         ,
				old_nmkendaraan   =b.nmbarang     ,
				old_nmpemilik     =b.nmpemilik       ,
				old_addpemilik    =b.addpemilik      ,
				old_hppemilik     =b.hppemilik       ,
				old_typeid        =b.typeid          ,
				old_jenisid       =b.jenisid         ,
				old_modelid       =b.modelid         ,
				old_tahunpembuatan=b.tahunpembuatan  ,
				old_silinder      =b.silinder        ,
				old_warna         =b.warna           ,
				old_bahanbakar    =b.bahanbakar      ,
				old_warnatnkb     =b.warnatnkb       ,
				old_tahunreg      =b.tahunreg        ,
				old_nobpkb        =b.nobpkb          ,
				old_kdlokasi      =b.kdlokasi        ,
				old_expstnkb      =b.expstnkb        ,
				old_exppkbstnkb   =b.exppkbstnkb     ,
				old_nopkb         =b.nopkb           ,
				old_nominalpkb    =b.nominalpkb      
				from sc_mst.mbarang b where b.kdrangka=new.kdrangka and b.kdmesin=new.kdmesin;
				--from sc_mst.kendaraan b where b.kdrangka='MH1JFB120DK190742' and b.kdmesin='JFB1E2145692';
			end if;
		

			delete from sc_mst.penomoran where userid=new.nodok;
			delete from sc_mst.trxerror where userid=new.nodok;    

			select trim(split_part(trim(prefix),'TNS',2)) as cekprefix into vr_cekprefix from sc_mst.nomor where dokumen='STNK-BARU';
			select to_char(now(),'YYMM') as cekbulan into vr_nowprefix;
			if(vr_nowprefix<>vr_cekprefix) then 
				update sc_mst.nomor set prefix='TNS'||vr_nowprefix,docno=0 where dokumen='STNK-BARU';
			end if;
			insert into sc_mst.penomoran 
			(userid,dokumen,nomor,errorid,partid,counterid,xno)
			values(new.nodok,'STNK-BARU',' ',0,' ',1,0);
			vr_nomor:=trim(coalesce(nomor,'')) from sc_mst.penomoran where userid=new.nodok;
			
			insert into sc_his.stnkb
				(nodok,tgldok,dokref,kdrangka,kdmesin,nopol,kdgroup,nmkendaraan,nmpemilik,addpemilik,hppemilik,typeid,jenisid,modelid,tahunpembuatan,silinder,warna,bahanbakar,
				warnatnkb,tahunreg,nobpkb,kdlokasi,expstnkb,exppkbstnkb,nopkb,nominalpkb,noskum,nokohir,old_nopol,old_kdgroup,old_nmkendaraan,old_nmpemilik,old_addpemilik,old_hppemilik,
				old_typeid,old_jenisid,old_modelid,old_tahunpembuatan,old_silinder,old_warna,old_bahanbakar,old_warnatnkb,old_tahunreg,old_nobpkb,old_kdlokasi,old_expstnkb,old_exppkbstnkb,old_nopkb,old_nominalpkb,old_noskum,old_nokohir,
				keterangan,status,inputdate,inputby,updatedate,updateby,jenispengurusan)
				(select vr_nomor,tgldok,dokref,kdrangka,kdmesin,nopol,kdgroup,nmkendaraan,nmpemilik,addpemilik,hppemilik,typeid,jenisid,modelid,tahunpembuatan,silinder,warna,bahanbakar,
				warnatnkb,tahunreg,nobpkb,kdlokasi,expstnkb,exppkbstnkb,nopkb,nominalpkb,noskum,nokohir,old_nopol,old_kdgroup,old_nmkendaraan,old_nmpemilik,old_addpemilik,old_hppemilik,
				old_typeid,old_jenisid,old_modelid,old_tahunpembuatan,old_silinder,old_warna,old_bahanbakar,old_warnatnkb,old_tahunreg,old_nobpkb,old_kdlokasi,old_expstnkb,old_exppkbstnkb,old_nopkb,old_nominalpkb,old_noskum,old_nokohir,
				keterangan,'A',inputdate,inputby,updatedate,updateby,jenispengurusan from sc_tmp.stnkb where nodok=new.nodok and kdrangka=new.kdrangka and kdmesin=new.kdmesin);


			
			delete from sc_tmp.stnkb where nodok=new.nodok;
		ELSEIF (new.status='F' and old.status='E') THEN
			delete from sc_his.stnkb where nodok=new.nodoktmp;
			insert into sc_his.stnkb
				(nodok,tgldok,dokref,kdrangka,kdmesin,nopol,kdgroup,nmkendaraan,nmpemilik,addpemilik,hppemilik,typeid,jenisid,modelid,tahunpembuatan,silinder,warna,bahanbakar,
				warnatnkb,tahunreg,nobpkb,kdlokasi,expstnkb,exppkbstnkb,nopkb,nominalpkb,noskum,nokohir,old_nopol,old_kdgroup,old_nmkendaraan,old_nmpemilik,old_addpemilik,old_hppemilik,
				old_typeid,old_jenisid,old_modelid,old_tahunpembuatan,old_silinder,old_warna,old_bahanbakar,old_warnatnkb,old_tahunreg,old_nobpkb,old_kdlokasi,old_expstnkb,old_exppkbstnkb,old_nopkb,old_nominalpkb,old_noskum,old_nokohir,
				keterangan,status,inputdate,inputby,updatedate,updateby,jenispengurusan)
				(select NEW.NODOKTMP,tgldok,dokref,kdrangka,kdmesin,nopol,kdgroup,nmkendaraan,nmpemilik,addpemilik,hppemilik,typeid,jenisid,modelid,tahunpembuatan,silinder,warna,bahanbakar,
				warnatnkb,tahunreg,nobpkb,kdlokasi,expstnkb,exppkbstnkb,nopkb,nominalpkb,noskum,nokohir,old_nopol,old_kdgroup,old_nmkendaraan,old_nmpemilik,old_addpemilik,old_hppemilik,
				old_typeid,old_jenisid,old_modelid,old_tahunpembuatan,old_silinder,old_warna,old_bahanbakar,old_warnatnkb,old_tahunreg,old_nobpkb,old_kdlokasi,old_expstnkb,old_exppkbstnkb,old_nopkb,old_nominalpkb,old_noskum,old_nokohir,
				keterangan,'A',inputdate,inputby,updatedate,updateby,jenispengurusan from sc_tmp.stnkb where nodok=new.nodok and kdrangka=new.kdrangka and kdmesin=new.kdmesin);

			delete from sc_tmp.stnkb where nodok=new.nodok;
		ELSEIF (new.status='F' and old.status='A') THEN
			delete from sc_his.stnkb where nodok=new.nodoktmp;
			insert into sc_his.stnkb
				(nodok,tgldok,dokref,kdrangka,kdmesin,nopol,kdgroup,nmkendaraan,nmpemilik,addpemilik,hppemilik,typeid,jenisid,modelid,tahunpembuatan,silinder,warna,bahanbakar,
				warnatnkb,tahunreg,nobpkb,kdlokasi,expstnkb,exppkbstnkb,nopkb,nominalpkb,noskum,nokohir,old_nopol,old_kdgroup,old_nmkendaraan,old_nmpemilik,old_addpemilik,old_hppemilik,
				old_typeid,old_jenisid,old_modelid,old_tahunpembuatan,old_silinder,old_warna,old_bahanbakar,old_warnatnkb,old_tahunreg,old_nobpkb,old_kdlokasi,old_expstnkb,old_exppkbstnkb,old_nopkb,old_nominalpkb,old_noskum,old_nokohir,
				keterangan,status,inputdate,inputby,updatedate,updateby,jenispengurusan)
				(select NEW.NODOKTMP,tgldok,dokref,kdrangka,kdmesin,nopol,kdgroup,nmkendaraan,nmpemilik,addpemilik,hppemilik,typeid,jenisid,modelid,tahunpembuatan,silinder,warna,bahanbakar,
				warnatnkb,tahunreg,nobpkb,kdlokasi,expstnkb,exppkbstnkb,nopkb,nominalpkb,noskum,nokohir,old_nopol,old_kdgroup,old_nmkendaraan,old_nmpemilik,old_addpemilik,old_hppemilik,
				old_typeid,old_jenisid,old_modelid,old_tahunpembuatan,old_silinder,old_warna,old_bahanbakar,old_warnatnkb,old_tahunreg,old_nobpkb,old_kdlokasi,old_expstnkb,old_exppkbstnkb,old_nopkb,old_nominalpkb,old_noskum,old_nokohir,
				keterangan,'P',inputdate,inputby,updatedate,updateby,jenispengurusan from sc_tmp.stnkb where nodok=new.nodok and kdrangka=new.kdrangka and kdmesin=new.kdmesin);
				IF (NEW.jenispengurusan='1T') THEN 
					update sc_mst.mbarang set
					exppkbstnkb=new.exppkbstnkb,
					nopkb=new.nopkb,
					nominalpkb=new.nominalpkb
					where kdgroup=new.kdgroup and kdrangka=new.kdrangka and kdmesin=new.kdmesin;
				ELSEIF(NEW.jenispengurusan='5T') THEN
					update sc_mst.mbarang set
					nopol         =	new.nopol           ,
					nmpemilik     =	new.nmpemilik       ,
					addpemilik    =	new.addpemilik      ,
					hppemilik     =	new.hppemilik       ,
					typeid        =	new.typeid          ,
					jenisid       =	new.jenisid         ,
					modelid       =	new.modelid         ,
					tahunpembuatan=	new.tahunpembuatan  ,
					silinder      =	new.silinder        ,
					warna         =	new.warna           ,
					bahanbakar    =	new.bahanbakar      ,
					warnatnkb     =	new.warnatnkb       ,
					tahunreg      =	new.tahunreg        ,
					nobpkb        =	new.nobpkb          ,
					kdlokasi      =	new.kdlokasi        ,
					expstnkb      =	new.expstnkb        
					where kdgroup=new.kdgroup and kdrangka=new.kdrangka and kdmesin=new.kdmesin;	
				END IF;
			delete from sc_tmp.stnkb where nodok=new.nodok;	
		ELSEIF (new.status='F' and old.status='C') THEN
			delete from sc_his.stnkb where nodok=new.nodoktmp;
			insert into sc_his.stnkb
				(nodok,tgldok,dokref,kdrangka,kdmesin,nopol,kdgroup,nmkendaraan,nmpemilik,addpemilik,hppemilik,typeid,jenisid,modelid,tahunpembuatan,silinder,warna,bahanbakar,
				warnatnkb,tahunreg,nobpkb,kdlokasi,expstnkb,exppkbstnkb,nopkb,nominalpkb,noskum,nokohir,old_nopol,old_kdgroup,old_nmkendaraan,old_nmpemilik,old_addpemilik,old_hppemilik,
				old_typeid,old_jenisid,old_modelid,old_tahunpembuatan,old_silinder,old_warna,old_bahanbakar,old_warnatnkb,old_tahunreg,old_nobpkb,old_kdlokasi,old_expstnkb,old_exppkbstnkb,old_nopkb,old_nominalpkb,old_noskum,old_nokohir,
				keterangan,status,inputdate,inputby,updatedate,updateby,jenispengurusan)
				(select NEW.NODOKTMP,tgldok,dokref,kdrangka,kdmesin,nopol,kdgroup,nmkendaraan,nmpemilik,addpemilik,hppemilik,typeid,jenisid,modelid,tahunpembuatan,silinder,warna,bahanbakar,
				warnatnkb,tahunreg,nobpkb,kdlokasi,expstnkb,exppkbstnkb,nopkb,nominalpkb,noskum,nokohir,old_nopol,old_kdgroup,old_nmkendaraan,old_nmpemilik,old_addpemilik,old_hppemilik,
				old_typeid,old_jenisid,old_modelid,old_tahunpembuatan,old_silinder,old_warna,old_bahanbakar,old_warnatnkb,old_tahunreg,old_nobpkb,old_kdlokasi,old_expstnkb,old_exppkbstnkb,old_nopkb,old_nominalpkb,old_noskum,old_nokohir,
				keterangan,'C',inputdate,inputby,updatedate,updateby,jenispengurusan from sc_tmp.stnkb where nodok=new.nodok and kdrangka=new.kdrangka and kdmesin=new.kdmesin);
			delete from sc_tmp.stnkb where nodok=new.nodok;	
		END IF;
	RETURN NEW;
	END IF;
/*
select * from sc_tmp.stnkb
select * from sc_his.stnkb
--truncate sc_his.stnkb,sc_tmp.stnkb
select * from sc_mst.nomor
insert into sc_mst.nomor VALUES
('STNK-BARU','',4,'TNS1706','',0,'66666','','201606','T')
--delete from sc_mst.nomor where dokumen='STNK-BARU';
*/
     
    
    return new;
        
end;
$$;

alter function tr_stnkb() owner to postgres;

