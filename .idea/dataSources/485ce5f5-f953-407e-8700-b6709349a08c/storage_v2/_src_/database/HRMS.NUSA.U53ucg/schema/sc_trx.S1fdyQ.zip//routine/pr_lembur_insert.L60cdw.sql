create function pr_lembur_insert() returns trigger
    language plpgsql
as
$$
declare
     
     vr_durasi integer;
     vr_jamselesai timestamp;
     vr_jammulai timestamp;
     vr_istirahat integer;
     vr_totaldurasi integer;
     
begin
vr_jammulai:=tgl_jam_mulai from sc_trx.lembur where nodok=new.nodok;
vr_jamselesai:=tgl_jam_selesai from sc_trx.lembur where nodok=new.nodok;
vr_istirahat:=durasi_istirahat from sc_trx.lembur where nodok=new.nodok;

	if (vr_jamselesai>vr_jammulai) then 
		
		--vr_durasi:=extract(epoch from cast(to_char(cast(vr_jamselesai as timestamp) - cast(vr_jammulai as timestamp),'HH24:mi')as time)::interval)/60 as durasi;
		vr_durasi:=extract(epoch from cast(to_char(vr_jamselesai-vr_jammulai,'HH24:MI')as time)::interval)/60 as durasi;
		--insert into dumy(jumlah) values (vr_durasi);
		vr_totaldurasi=vr_durasi-vr_istirahat;
		update sc_trx.lembur set durasi=vr_totaldurasi where nodok=new.nodok;
	end if;
return new;

end;
$$;

alter function pr_lembur_insert() owner to postgres;

