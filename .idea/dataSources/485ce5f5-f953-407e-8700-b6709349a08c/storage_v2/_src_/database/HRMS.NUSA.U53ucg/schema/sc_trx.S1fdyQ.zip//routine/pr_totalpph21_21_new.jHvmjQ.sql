create function pr_totalpph21_21_new(id character, nomor integer, userid character, periode integer, bulankeluar integer) returns numeric
    language plpgsql
as
$$
DECLARE 

--vr_pkp numeric(18,2):=0;
vr_periodesebelum integer;
vr_ratio numeric(18,2):=0;
vr_pph5 numeric(18,2):=0;
vr_pph15 numeric(18,2):=0;
vr_pphsetahun numeric(18,2):=0;
vr_bpot21 char(3);

BEGIN		

	--select besaranptkp into vr_duit from sc_mst.karyawan where nik=id;
	vr_periodesebelum=periode-1;
	--select nominal into vr_ratio from sc_tmp.p21_detail where nik=id  and no_urut=62 and periode_mulai=periode;	
	--select nominal into vr_pph5 from sc_tmp.p21_detail where nik=id  and no_urut=61 and periode_mulai=periode;	

	select trim(value1) into vr_bpot21 from sc_mst.option where kdoption='BPOTP21';
        if (vr_bpot21='YES') then 

		select round(d.prosen*gajinetto,0) as pph21 into vr_pphsetahun
		from(
		select a.nik,b.status_ptkp,kategoriter,sum(nominal) as gajinetto
		from sc_tmp.p21_detail  a
		left outer join sc_mst.karyawan b on a.nik=b.nik
		left outer join sc_mst.ptkp c on trim(b.status_ptkp)=trim(c.kodeptkp)
		where no_urut=20 and a.nik=id
		group by a.nik,b.status_ptkp,kategoriter) 
		as a
		left outer join sc_mst.kategoriter d on a.kategoriter=d.kategoriter and gajinetto>=d.min and gajinetto<d.max;
	else
		select round(d.prosen*gajinetto,0) as pph21 into vr_pphsetahun
		from(
		select a.nik,b.status_ptkp,kategoriter,sum(nominal) as gajinetto
		from sc_tmp.p21_detail  a
		left outer join sc_mst.karyawan b on a.nik=b.nik
		left outer join sc_mst.ptkp c on trim(b.status_ptkp)=trim(c.kodeptkp)
		where no_urut=15 and a.nik=id
		group by a.nik,b.status_ptkp,kategoriter) 
		as a
		left outer join sc_mst.kategoriter d on a.kategoriter=d.kategoriter and gajinetto>=d.min and gajinetto<d.max;
	end if;

	---vr_pphsetahun=vr_pph5+vr_ratio;	
	
	delete from sc_tmp.p21_detail where nodok=userid and nik=id and no_urut=nomor and periode_mulai=periode;

	insert into sc_tmp.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select userid as nodok,id as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_pphsetahun as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,
	periode as periode_mulai,periode as periode_akhir from sc_mst.detail_formula
	where no_urut=nomor and kdrumus='P21';

	
	

	--insert into dumy(nominal) values (vr_pph5);
	
	RETURN vr_pphsetahun;	
END;
$$;

alter function pr_totalpph21_21_new(char, integer, char, integer, integer) owner to postgres;

