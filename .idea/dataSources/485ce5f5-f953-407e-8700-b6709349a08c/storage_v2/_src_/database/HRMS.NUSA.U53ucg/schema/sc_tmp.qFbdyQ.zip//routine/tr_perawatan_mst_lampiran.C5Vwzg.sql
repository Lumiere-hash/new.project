create function tr_perawatan_mst_lampiran() returns trigger
    language plpgsql
as
$$
DECLARE 
	--author by fiky: 12/06/2019
	--update by fiky: 16/06/2019
     vr_nomor char(12); 
     vr_cekprefix char(4);
     vr_nowprefix char(4);  
     vr_qtypbk numeric;  
     vr_qtybbk numeric;  
     vr_qtyonhand numeric;  

BEGIN		
	IF tg_op = 'INSERT' THEN

		update  sc_tmp.perawatan_mst_lampiran a set id=a1.urutnya
		from (select a1.*,row_number() over(partition by nodok,nodokref order by id asc) as urutnya
		from sc_tmp.perawatan_mst_lampiran a1) a1
		where a.id=a1.id and a.nodok=a1.nodok and a.inputdate=a1.inputdate and a.nodokref=a1.nodokref;

		update sc_tmp.perawatanspk a set 
		ttlservis=b.nservis,
		ttldiskon=b.ndiskon,
		ttldpp=b.ndpp,
		ttlppn=b.nppn,
		ttlnetto=b.nnetto
		from (select nodok,nodokref, sum(nservis) as nservis,sum(ndiskon) as ndiskon,sum(nnetto) as nnetto,sum(ndpp) as ndpp,sum(nppn) as nppn from sc_tmp.perawatan_mst_lampiran
		group by nodok,nodokref) b
		where a.nodok=b.nodok and a.nodokref=b.nodokref and
		a.nodok=new.nodok and b.nodokref=new.nodokref;
		
		RETURN new;
	ELSEIF tg_op = 'UPDATE' THEN
	
		update sc_tmp.perawatanspk a set 
		ttlservis=b.nservis,
		ttldiskon=b.ndiskon,
		ttldpp=b.ndpp,
		ttlppn=b.nppn,
		ttlnetto=b.nnetto
		from (select nodok,nodokref, sum(nservis) as nservis,sum(ndiskon) as ndiskon,sum(nnetto) as nnetto,sum(ndpp) as ndpp,sum(nppn) as nppn from sc_tmp.perawatan_mst_lampiran
		group by nodok,nodokref) b
		where a.nodok=b.nodok and a.nodokref=b.nodokref and
		a.nodok=new.nodok and b.nodokref=new.nodokref;
		
		RETURN new;
	ELSEIF tg_op = 'DELETE' THEN

		update sc_tmp.perawatanspk a set 
		ttlservis=b.nservis,
		ttldiskon=b.ndiskon,
		ttldpp=b.ndpp,
		ttlppn=b.nppn,
		ttlnetto=b.nnetto
		from (select nodok,nodokref, sum(nservis) as nservis,sum(ndiskon) as ndiskon,sum(nnetto) as nnetto,sum(ndpp) as ndpp,sum(nppn) as nppn from sc_tmp.perawatan_mst_lampiran
		group by nodok,nodokref) b
		where a.nodok=b.nodok and a.nodokref=b.nodokref and
		a.nodok=old.nodok and b.nodokref=old.nodokref;
		
		RETURN old;	
	END IF;
	
END;
$$;

alter function tr_perawatan_mst_lampiran() owner to postgres;

