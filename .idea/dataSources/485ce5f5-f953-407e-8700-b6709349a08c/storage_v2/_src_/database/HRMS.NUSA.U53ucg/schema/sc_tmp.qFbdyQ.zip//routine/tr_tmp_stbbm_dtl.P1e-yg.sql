create function tr_tmp_stbbm_dtl() returns trigger
    language plpgsql
as
$$
DECLARE 
	--author by fiky: 12/10/2017
	--update by fiky: 12/11/2017
     vr_nomor char(12); 
     vr_cekprefix char(4);
     vr_nowprefix char(4);  
	vr_id_dtl numeric;
	vr_qtybbm numeric;
	vr_qtybbm_v numeric;
	vr_qtybbmkecil numeric;
	vr_sum_qtybbmkecil_dtlref numeric;
	vr_sum_qtybbmkecil_dtl numeric;
	vr_sum_qtybbmkecil_test numeric;
	vr_sum_qtybbmkecil_koreksi numeric;
     vr_kdgroup char(100);
     vr_kdsubgroup char(100);
     vr_stockcode char(100);
     vr_nodok char(100);
     vr_nodokref char(100);
     vr_fromcode char(100);
     vr_nodoktypemst char(100);
BEGIN		
	IF tg_op = 'INSERT' THEN

		IF EXISTS(select * from sc_tmp.stbbm_mst where nodok=new.nodok and nodokref=new.nodokref and nodoktype='AJS') THEN		
			update  sc_tmp.stbbm_dtl a set id=a1.urutnya
			from (select a1.*,row_number() over(partition by nodok order by inputdate asc) as urutnya
			from sc_tmp.stbbm_dtl a1) a1
			where a.id=a1.id and a.nodok=a1.nodok and a.kdgroup=a1.kdgroup and a.kdsubgroup=a1.kdsubgroup and a.stockcode=a1.stockcode
			and a.nodok=new.nodok and a.id>=new.id ;
		END IF;
		
		RETURN new;
	ELSEIF tg_op = 'UPDATE' THEN
		--select * from sc_trx.stbbm_dtlref
		--select * from sc_tmp.stbbm_dtlref
		--select * from sc_tmp.stbbm_dtl
		--select * from sc_trx.po_dtl
		vr_nodoktypemst:=trim(coalesce(nodoktype,'')) from sc_tmp.stbbm_mst where nodok=new.nodok;
		IF (vr_nodoktypemst='PO') THEN
			IF (OLD.STATUS!='' AND NEW.STATUS='') THEN
				--select * from sc_trx.po_dtlref
				--select * from sc_trx.po_dtl where nodok='PO1711010003'
				--select * from sc_tmp.stbbm_dtl	
				--select 90909.12+9090.88
				--select * from sc_tmp.stbbm_dtlref	
				/* fix
				update sc_tmp.stbbm_dtl set 
				qtybbm=(coalesce(old.qtybbm,0)-coalesce(old.qtybbm,0))+coalesce(new.qtybbm,0),
				qtybbmkecil=round((coalesce(old.qtybbmkecil,0)-coalesce(old.qtybbmkecil,0))+coalesce(qtyreckecil,0)/coalesce(qtyrec,0)*coalesce(new.qtybbm,0)) ,
				status=old.status
				where nodok=new.nodok and nodokref=new.nodokref and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and id=new.id;
				*/

				update sc_tmp.stbbm_dtl a set 
				qtybbm=(coalesce(old.qtybbm,0)-coalesce(old.qtybbm,0))+coalesce(new.qtybbm,0),
				qtybbmkecil=round((coalesce(old.qtybbmkecil,0)-coalesce(old.qtybbmkecil,0))+coalesce(qtyreckecil,0)/coalesce(qtyrec,0)*coalesce(new.qtybbm,0)) ,
				nbrutto=(coalesce(b.ttlbrutto,0)/coalesce(b.qtykecil,0))*round((coalesce(old.qtybbmkecil,0)-coalesce(old.qtybbmkecil,0))+coalesce(qtyreckecil,0)/coalesce(qtyrec,0)*coalesce(new.qtybbm,0)),
				ndiskon=(coalesce(b.ttldiskon,0)/coalesce(b.qtykecil,0))*round((coalesce(old.qtybbmkecil,0)-coalesce(old.qtybbmkecil,0))+coalesce(qtyreckecil,0)/coalesce(qtyrec,0)*coalesce(new.qtybbm,0)),
				ndpp=(coalesce(b.ttldpp,0)/coalesce(b.qtykecil,0))*round((coalesce(old.qtybbmkecil,0)-coalesce(old.qtybbmkecil,0))+coalesce(qtyreckecil,0)/coalesce(qtyrec,0)*coalesce(new.qtybbm,0)),
				nppn=(coalesce(b.ttlppn,0)/coalesce(b.qtykecil,0))*round((coalesce(old.qtybbmkecil,0)-coalesce(old.qtybbmkecil,0))+coalesce(qtyreckecil,0)/coalesce(qtyrec,0)*coalesce(new.qtybbm,0)),
				nnetto=(coalesce(b.ttlnetto,0)/coalesce(b.qtykecil,0))*round((coalesce(old.qtybbmkecil,0)-coalesce(old.qtybbmkecil,0))+coalesce(qtyreckecil,0)/coalesce(qtyrec,0)*coalesce(new.qtybbm,0)),
				status=old.status
				from sc_trx.po_dtl b
				where 
				b.nodok=a.nodokref and b.kdgroup=a.kdgroup and b.kdsubgroup=a.kdsubgroup and b.stockcode=a.stockcode and b.id=a.id
				and a.nodok=new.nodok and a.nodokref=new.nodokref and a.kdgroup=new.kdgroup and a.kdsubgroup=new.kdsubgroup and a.stockcode=new.stockcode and a.id=new.id;



				vr_sum_qtybbmkecil_dtl:=coalesce(sum(qtybbmkecil),0) from sc_tmp.stbbm_dtl where nodok=new.nodok and nodokref=new.nodokref and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and id=new.id;
				vr_sum_qtybbmkecil_koreksi:=0;

				FOR vr_id_dtl,vr_nodokref,vr_fromcode,vr_kdgroup,vr_kdsubgroup,vr_stockcode,vr_qtybbmkecil,vr_qtybbm in select id,nodokref,fromcode,kdgroup,kdsubgroup,stockcode,qtyreckecil,qtyrec from sc_tmp.stbbm_dtlref 
				where nodok=new.nodok and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode order by fromcode asc
				--select id,nodokref,fromcode,kdgroup,kdsubgroup,stockcode,qtybbmkecil,qtybbm from sc_tmp.stbbm_dtlref where nodok='1115.184' order by fromcode asc
				--select * from sc_tmp.stbbm_dtlref
					LOOP
					--update sc_tmp.stbbm_dtl set qtybbm=2,status=''
					--select * from sc_trx.stgblco
					--select * from sc_tmp.stbbm_dtl
					--select * from sc_tmp.stbbm_dtlref
					--select *,qtyreceipt,qtyreceiptkecil,status from sc_trx.po_dtl where nodok='PO1711010003'
					--select *,qtyterima,qtyterima_kecil from sc_trx.po_dtlref  where nodok='PO1711010003'
					------update sc_tmp.stbbm_dtlref set qtybbm=0,qtybbmkecil=0 
					------update sc_trx.po_dtlref set qtyterima=0,qtyterima_kecil=0 where nodok='PO1711010003' 
					------update sc_trx.po_dtl set qtyreceipt=0,qtyreceiptkecil=0 where nodok='PO1711010003'
					--vr_sum_qtybbmkecil_dtl:=coalesce(sum(qtybbmkecil),0) from sc_tmp.stbbm_dtl where nodok=new.nodok and nodokref=new.nodokref and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and id=new.id;

					if (vr_qtybbmkecil<vr_sum_qtybbmkecil_dtl) then
						vr_sum_qtybbmkecil_koreksi:=vr_qtybbmkecil;	
						vr_sum_qtybbmkecil_dtl:=vr_sum_qtybbmkecil_dtl-vr_qtybbmkecil;
					else 				
						vr_sum_qtybbmkecil_koreksi:=vr_sum_qtybbmkecil_dtl;
						vr_sum_qtybbmkecil_dtl:=0; 
					end if;

					
					---vr_sum_qtybbmkecil_dtlref:=coalesce(sum(qtybbmkecil),0) from sc_tmp.stbbm_dtlref where nodok=new.nodok and kdgroup=vr_kdgroup and kdsubgroup=vr_kdsubgroup and stockcode=vr_stockcode ;
					--vr_sum_qtybbmkecil_koreksi:=vr_sum_qtybbmkecil_dtl-vr_sum_qtybbmkecil_dtlref;
					
					
					update sc_tmp.stbbm_dtlref a set 
					qtybbmkecil=vr_sum_qtybbmkecil_koreksi,
					status=''
				/*	qtybbmkecil=case 
					when vr_sum_qtybbmkecil_koreksi>=vr_sum_qtybbmkecil_dtlref then coalesce(b.qtyreckecil,0)
					when vr_sum_qtybbmkecil_koreksi<vr_sum_qtybbmkecil_dtlref and vr_sum_qtybbmkecil_koreksi>0 then vr_sum_qtybbmkecil_koreksi
					else 0 end*/
					from sc_tmp.stbbm_dtlref b 
					where 
					a.nodok=b.nodok and a.nodokref=b.nodokref and a.fromcode=b.fromcode and a.kdgroup=b.kdgroup and a.kdsubgroup=b.kdsubgroup and a.stockcode=b.stockcode and a.id=b.id 
					and a.nodok=new.nodok and a.nodokref=vr_nodokref and a.fromcode=vr_fromcode and a.kdgroup=vr_kdgroup and a.kdsubgroup=vr_kdsubgroup and a.stockcode=vr_stockcode and a.id=vr_id_dtl;

					--RAISE NOTICE 'Calling cs_job(%)', vr_sum_qtybbmkecil_dtl;
					--RAISE NOTICE 'Calling cs_create_job(%)', vr_sum_qtybbmkecil_koreksi;

					---EXIT WHEN vr_sum_qtybbmkecil_dtl <= 0;
				
				END LOOP;
		/*
				update sc_tmp.stbbm_dtl set
				qtybbm=
				case 
				when trim(satminta)=trim(new.satminta) then round((select sum(coalesce(qtybbm,0)) from sc_tmp.stbbm_dtlref where nodok=new.nodok and nodokref=new.nodokref and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and status not in('C','D')))
				when trim(satminta)!=trim(new.satminta) then round((select sum(coalesce(qtybbm,0)) from sc_tmp.stbbm_dtlref where nodok=new.nodok and nodokref=new.nodokref and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and status not in('C','D'))/(coalesce(qtyreckecil,0)/coalesce(qtyrec,0)))	
				else 0 end,
				qtybbmkecil=(select sum(coalesce(qtybbmkecil,0)) from sc_tmp.stbbm_dtlref where nodok=new.nodok and nodokref=new.nodokref and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and status not in('C','D'))
				where 
				nodok=new.nodok and nodokref=new.nodokref and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and status not in('C','D');	
		*/
				--select * from sc_trx.po_dtl where nodok=new.nodokref
				--select * from sc_tmp.stbbm_mst
				--select * from sc_tmp.stbbm_dtl
				--select * from sc_tmp.stbbm_dtlref order by fromcode asc
				--select * from sc_trx.po_dtlref
				update sc_tmp.stbbm_mst set 
				ttlbrutto=(select sum(coalesce(nbrutto,0)) from sc_tmp.stbbm_dtl where nodok=new.nodok),
				ttldiskon=(select sum(coalesce(ndiskon,0)) from sc_tmp.stbbm_dtl where nodok=new.nodok),
				ttldpp=(select sum(coalesce(ndpp,0)) from sc_tmp.stbbm_dtl where nodok=new.nodok),
				ttlppn=(select sum(coalesce(nppn,0)) from sc_tmp.stbbm_dtl where nodok=new.nodok),
				ttlnetto=(select sum(coalesce(nnetto,0)) from sc_tmp.stbbm_dtl where nodok=new.nodok)
				where nodok=new.nodok;

				
				delete from sc_mst.trxerror where userid=new.nodok and modul='TMPSTBBM';
				insert into sc_mst.trxerror
				(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
				(new.nodok,0,new.nodok,'','TMPSTBBM');

				END IF;

				vr_qtybbm_v:=coalesce(sum(qtybbm),0) from sc_tmp.stbbm_dtl where nodok=new.nodok and nodokref=new.nodokref and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and id=new.id;
				vr_sum_qtybbmkecil_test:=coalesce(sum(qtybbmkecil),0) from sc_tmp.stbbm_dtl where nodok=new.nodok and nodokref=new.nodokref and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and id=new.id;


				update sc_trx.po_dtl set 
				qtyreceipt=round(coalesce(qtyreceipt,0)-coalesce(old.qtybbm,0)+coalesce(vr_qtybbm_v,0)), 
				qtyreceiptkecil=round(coalesce(qtyreceiptkecil,0)-coalesce(old.qtybbmkecil,0)+coalesce(new.qtybbmkecil,0))
				where nodok=new.nodokref and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode;
				RAISE NOTICE 'Calling cs_create_job(%)', vr_sum_qtybbmkecil_test;
		ELSEIF (vr_nodoktypemst='TRG') THEN
				--select * from sc_tmp.stbbm_mst
				--select * from sc_tmp.stbbm_dtl
				--select * from sc_trx.itemtrans_mst
				--select * from sc_trx.itemtrans_dtl
				/* WARNING LOKASI GUDANG YANG MELOAD HARUS LOCCODE DESTINATION !!!!*/
				IF (OLD.STATUS!='' AND NEW.STATUS='') THEN
				update sc_tmp.stbbm_dtl set 
				--qtybbm=(coalesce(old.qtybbm,0)-coalesce(old.qtybbm,0))+coalesce(new.qtybbm,0),
				qtybbmkecil=(coalesce(old.qtybbm,0)-coalesce(old.qtybbm,0))+coalesce(new.qtybbm,0), 
				status=old.status
				where nodok=new.nodok and nodokref=new.nodokref and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and id=new.id;
				/* UPDATE KE TRANSFER GUDANG */
				update sc_tmp.itemtrans_dtl set
				qtybbm=(coalesce(old.qtybbm,0)-coalesce(old.qtybbm,0))+coalesce(new.qtybbm,0) 
				where nodok=new.nodokref and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and loccode_destination=new.loccode;
				
				END IF;

		END IF;

		RETURN NEW;
	ELSEIF tg_op = 'DELETE' THEN

			IF ( old.status='C') THEN
				update sc_trx.po_dtl set 
				qtyreceipt=coalesce(qtyreceipt,0)-coalesce(old.qtybbm,0), 
				qtyreceiptkecil=coalesce(qtyreceiptkecil,0)-coalesce(old.qtybbmkecil,0)
				where nodok=old.nodokref and kdgroup=old.kdgroup and kdsubgroup=old.kdsubgroup and stockcode=old.stockcode;


				delete from sc_mst.trxerror where userid=old.nodok and modul='TMPSTBBM';
				insert into sc_mst.trxerror
				(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
				(old.nodok,0,old.nodok,'','TMPSTBBM');
			
			END IF;
	/*	update sc_trx.po_dtl set 
		qtyreceipt=coalesce(qtyreceipt,0)-coalesce(old.qtybbm,0), 
		qtyreceiptkecil=coalesce(qtyreceiptkecil,0)-coalesce(old.qtybbmkecil,0)
		where nodok=old.nodok and nodokref=old.nodokref and kdgroup=old.kdgroup and kdsubgroup=old.kdsubgroup and stockcode=old.stockcode;

		delete from sc_mst.trxerror where userid=old.nodok and modul='TMPSTBBM';
		insert into sc_mst.trxerror
		(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
		(old.nodok,0,old.nodok,'','TMPSTBBM');
	*/	
		RETURN old;	
	END IF;
	
END;
$$;

alter function tr_tmp_stbbm_dtl() owner to postgres;

