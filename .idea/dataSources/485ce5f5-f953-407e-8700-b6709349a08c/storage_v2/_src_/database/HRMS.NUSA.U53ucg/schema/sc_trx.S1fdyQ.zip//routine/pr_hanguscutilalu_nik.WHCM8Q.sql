create function pr_hanguscutilalu_nik(nike character) returns SETOF void
    language plpgsql
as
$$
--author by : Fiky Ashariza 15-06-2016
--update by : --
DECLARE vr_sisacuti integer;
DECLARE vr_nik character(12);

--DECLARE vr_out integer;


BEGIN

update sc_trx.cuti_lalu a set sisacuti=b.balance
		from (select *,sum("in_cuti"-"out_cuti") over(partition by nik order by nik,tanggal,no_dokumen,doctype) as balance
		from sc_trx.cuti_lalu) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen and a.doctype=b.doctype;
		
		
 FOR vr_nik in select a.nik from sc_trx.cuti_lalu a,
		(select a.nik,a.tanggal,a.no_dokumen,max(a.doctype) as doctype from sc_trx.cuti_lalu a,
		(select a.nik,a.tanggal,max(a.no_dokumen) as no_dokumen from sc_trx.cuti_lalu a,
		(select nik,max(tanggal) as tanggal from sc_trx.cuti_lalu 
		group by nik) as b
		where a.nik=b.nik and a.tanggal=b.tanggal
		group by a.nik,a.tanggal) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen
		group by a.nik,a.tanggal,a.no_dokumen) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen and a.doctype=b.doctype and a.nik=coalesce(nike,'')


	LOOP	

	vr_sisacuti:=coalesce(sisacuti,'0')from sc_trx.cuti_lalu a,
		(select a.nik,a.tanggal,a.no_dokumen,max(a.doctype) as doctype from sc_trx.cuti_lalu a,
		(select a.nik,a.tanggal,max(a.no_dokumen) as no_dokumen from sc_trx.cuti_lalu a,
		(select nik,max(tanggal) as tanggal from sc_trx.cuti_lalu where nik=vr_nik
		group by nik) as b
		where a.nik=b.nik and a.tanggal=b.tanggal
		group by a.nik,a.tanggal) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen
		group by a.nik,a.tanggal,a.no_dokumen) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen and a.doctype=b.doctype and a.nik=coalesce(nike,'');



	
		IF coalesce(vr_sisacuti,0)>0 THEN --cek global jika tak mendapat cuti/cuti minus
		
		insert into sc_trx.cuti_lalu
		select a.nik,cast(to_char(now(),'yyyy-mm-dd HH24:MM:SS')as timestamp),a.no_dokumen,0,vr_sisacuti,0,'HGS','HANGUS' from sc_trx.cuti_lalu a,
		(select a.nik,a.tanggal,a.no_dokumen,max(a.doctype) as doctype from sc_trx.cuti_lalu a,
		(select a.nik,a.tanggal,max(a.no_dokumen) as no_dokumen from sc_trx.cuti_lalu a,
		(select nik,max(tanggal) as tanggal from sc_trx.cuti_lalu 
		group by nik) as b
		where a.nik=b.nik and a.tanggal=b.tanggal
		group by a.nik,a.tanggal) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen
		group by a.nik,a.tanggal,a.no_dokumen) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen and a.doctype=b.doctype and a.nik=coalesce(nike,'');

		insert into sc_trx.cuti_blc
		select a.nik,cast(to_char(now(),'yyyy-mm-dd HH24:MM:SS')as timestamp),a.no_dokumen,0,vr_sisacuti,0,'HGS','HANGUS' from sc_trx.cuti_lalu a,
		(select a.nik,a.tanggal,a.no_dokumen,max(a.doctype) as doctype from sc_trx.cuti_lalu a,
		(select a.nik,a.tanggal,max(a.no_dokumen) as no_dokumen from sc_trx.cuti_lalu a,
		(select nik,max(tanggal) as tanggal from sc_trx.cuti_lalu 
		group by nik) as b
		where a.nik=b.nik and a.tanggal=b.tanggal
		group by a.nik,a.tanggal) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen
		group by a.nik,a.tanggal,a.no_dokumen) b
		where a.nik=b.nik and a.tanggal=b.tanggal and a.no_dokumen=b.no_dokumen and a.doctype=b.doctype and a.nik=coalesce(nike,'');
		
		END IF;
	RETURN NEXT vr_nik;
		
END LOOP;
		
		
	RETURN;
		

	
END;
$$;

alter function pr_hanguscutilalu_nik(char) owner to postgres;

