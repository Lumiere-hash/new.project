create function tr_bbmkendaraan_mst() returns trigger
    language plpgsql
as
$$
declare
--created by Fiky ::18/05/2018
     vr_nomor char(12); 
     vr_lastdoc numeric; 
     vr_cekprefix char(4);
     vr_nowprefix char(4);
begin    

	IF TG_OP ='INSERT' THEN 

	RETURN NEW;
	ELSEIF TG_OP ='UPDATE' THEN
			
			/* NO RESOURCE UPDATE 
			select * from sc_mst.nomor	
			select * from sc_his.bbmkendaraan_mst
			*/
		if (new.status='E' and old.status='A') then

			insert into sc_tmp.bbmkendaraan_mst
			(docno,docdate,docref,kdgroup,kdsubgroup,stockcode,bahanbakar,km_awal,km_akhir,ttlvalue,description,status,
			inputdate,inputby,updatedate,updateby,approvaldate,approvalby,docnotmp)
			(select new.updateby,docdate,docref,kdgroup,kdsubgroup,stockcode,bahanbakar,km_awal,km_akhir,ttlvalue,description,'E' as status,
			inputdate,inputby,updatedate,updateby,approvaldate,approvalby,new.docno as docnotmp from sc_his.bbmkendaraan_mst where docno=new.docno);

		elseif (new.status='A1' and old.status='A') then
			insert into sc_tmp.bbmkendaraan_mst
			(docno,docdate,docref,kdgroup,kdsubgroup,stockcode,bahanbakar,km_awal,km_akhir,ttlvalue,description,status,
			inputdate,inputby,updatedate,updateby,approvaldate,approvalby,docnotmp)
			(select new.approvalby,docdate,docref,kdgroup,kdsubgroup,stockcode,bahanbakar,km_awal,km_akhir,ttlvalue,description,'A' as status,
			inputdate,inputby,updatedate,updateby,approvaldate,approvalby,new.docno as docnotmp from sc_his.bbmkendaraan_mst where docno=new.docno);
		elseif (new.status='C' and old.status='A') then
			insert into sc_tmp.bbmkendaraan_mst
			(docno,docdate,docref,kdgroup,kdsubgroup,stockcode,bahanbakar,km_awal,km_akhir,ttlvalue,description,status,
			inputdate,inputby,updatedate,updateby,approvaldate,approvalby,docnotmp)
			(select new.updateby,docdate,docref,kdgroup,kdsubgroup,stockcode,bahanbakar,km_awal,km_akhir,ttlvalue,description,'C' as status,
			inputdate,inputby,updatedate,updateby,approvaldate,approvalby,new.docno as docnotmp from sc_his.bbmkendaraan_mst where docno=new.docno);
		end if;
	
			
	RETURN NEW;
	END IF;
    
    
    return new;
        
end;
$$;

alter function tr_bbmkendaraan_mst() owner to postgres;

