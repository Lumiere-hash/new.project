create function tr_declaration_cashbon_component_before_delete() returns trigger
    language plpgsql
as
$$
DECLARE
    int_declaration numeric;
BEGIN
    UPDATE sc_tmp.declaration_cashbon SET
          totalcashbon = (
              SELECT COALESCE(b.totalcashbon, 0)
              FROM sc_tmp.declaration_cashbon a
                       LEFT OUTER JOIN sc_trx.cashbon b ON TRUE
                  AND TRIM(b.cashbonid) = TRIM(a.cashbonid)
              WHERE TRUE
                AND TRIM(a.declarationid) = TRIM(OLD.declarationid)
          ),
          totaldeclaration = (
              (SELECT SUM(a.nominal)
              FROM sc_tmp.declaration_cashbon_component a
                       LEFT OUTER JOIN sc_mst.component_cashbon b ON TRUE
                  AND TRIM(b.componentid) = TRIM(a.componentid)
              WHERE TRUE
                AND TRIM(a.declarationid) = TRIM(OLD.declarationid)
                AND b.calculated) - (SELECT COALESCE(a.nominal,0)
                                     FROM sc_tmp.declaration_cashbon_component a
                                              LEFT OUTER JOIN sc_mst.component_cashbon b ON TRUE
                                         AND TRIM(b.componentid) = TRIM(a.componentid)
                                     WHERE TRUE
                                       AND TRIM(a.declarationid) = TRIM(OLD.declarationid)
                                       AND b.calculated
                                       AND a.componentid = old.componentid
                                       AND a.dutieid = old.dutieid
                                       AND a.perday = old.perday
                                     )
          )
    WHERE TRUE
      AND declarationid = OLD.declarationid;
    UPDATE sc_tmp.declaration_cashbon SET
        returnamount = totalcashbon - totaldeclaration
    WHERE TRUE
      AND declarationid = OLD.declarationid;
    RETURN old;
END;
$$;

alter function tr_declaration_cashbon_component_before_delete() owner to postgres;

