create function tr_cashbon_after_update() returns trigger
    language plpgsql
as
$$
DECLARE
number VARCHAR;
BEGIN
    IF ( NEW.status = 'F' and OLD.status <> 'F' ) THEN
DELETE FROM sc_mst.penomoran WHERE TRUE AND userid = NEW.cashbonid;
IF NOT EXISTS ( SELECT TRUE FROM sc_mst.nomor WHERE TRUE AND dokumen = 'CASHBON' ) THEN
            INSERT INTO sc_mst.nomor (
                dokumen,
                part,
                count3,
                prefix,
                sufix,
                docno,
                userid,
                modul,
                periode,
                cekclose
            ) VALUES (
                         'CASHBON',
                         '',
                         4,
                         CONCAT('CB', TO_CHAR(NOW(), 'YY')),
                         '',
                         0,
                         NEW.inputby,
                         '',
                         TO_CHAR(NOW(), 'YYYY'),
                         'T'
                     );
END IF;

INSERT INTO sc_mst.penomoran (
    userid,
    dokumen,
    nomor,
    errorid,
    partid,
    counterid,
    xno
) VALUES (
             NEW.cashbonid,
             'CASHBON',
             '',
             0,
             '',
             1,
             0
         );

SELECT COALESCE(TRIM(nomor), '') INTO number
FROM sc_mst.penomoran WHERE TRUE
                        AND userid = new.cashbonid;

if (COALESCE(TRIM(number), '') <> '') THEN
DELETE FROM sc_trx.cashbon WHERE TRUE
                             AND cashbonid = NEW.cashbonid;

INSERT INTO sc_trx.cashbon (
    branch,
    cashbonid,
    dutieid,
    superior,
    status,
    paymenttype,
    totalcashbon,
    inputby,
    inputdate,
    updateby,
    updatedate,
    approveby,
    approvedate,
    type
) SELECT
      branch,
      number AS cashbonid,
      dutieid,
      superior,
      OLD.status AS status,
      paymenttype,
      totalcashbon,
      inputby,
      inputdate,
      updateby,
      updatedate,
      approveby,
      approvedate,
      type
FROM sc_tmp.cashbon WHERE TRUE
                      AND cashbonid = NEW.cashbonid;

DELETE FROM sc_trx.cashbon_component WHERE TRUE
                                       AND cashbonid = NEW.cashbonid;

INSERT INTO sc_trx.cashbon_component (
    branch,
    cashbonid,
    componentid,
    nominal,
    quantityday,
    totalcashbon,
    description,
    inputby,
    inputdate,
    updateby,
    updatedate
) SELECT
      branch,
      number AS cashbonid,
      componentid,
      nominal,
      quantityday,
      totalcashbon,
      description,
      inputby,
      inputdate,
      updateby,
      updatedate
FROM sc_tmp.cashbon_component WHERE TRUE
                                AND cashbonid = NEW.cashbonid;

DELETE FROM sc_trx.cashbon_component WHERE TRUE
                                       AND cashbonid = NEW.cashbonid;

INSERT INTO sc_trx.cashbon_component_po (
    branch,
    cashbonid,
    pono,
    nomor,
    stockcode,
    stockname,
    qty,
    pricelist,
    brutto,
    netto,
    dpp,
    ppn,
    inputby,
    inputdate,
    updateby,
    updatedate
) SELECT
      branch,
      number AS cashbonid,
      pono,
      nomor,
      stockcode,
      stockname,
      qty,
      pricelist,
      brutto,
      netto,
      dpp,
      ppn,
      inputby,
      inputdate,
      updateby,
      updatedate
FROM sc_tmp.cashbon_component_po WHERE TRUE
                                   AND cashbonid = NEW.cashbonid;

DELETE FROM sc_tmp.cashbon WHERE TRUE
                             AND cashbonid = NEW.cashbonid;

DELETE FROM sc_tmp.cashbon_component WHERE TRUE
                                       AND cashbonid = NEW.cashbonid;

DELETE FROM sc_tmp.cashbon_component_po WHERE TRUE
                                          AND cashbonid = NEW.cashbonid;

END IF;
END IF;

    IF ( NEW.status = 'U' and OLD.status <> 'U' ) THEN
DELETE FROM sc_trx.cashbon WHERE TRUE
                             AND cashbonid = NEW.cashbonid;

INSERT INTO sc_trx.cashbon (
    branch,
    cashbonid,
    dutieid,
    superior,
    status,
    paymenttype,
    type,
    totalcashbon,
    inputby,
    inputdate,
    updateby,
    updatedate,
    approveby,
    approvedate
) SELECT
      branch,
      cashbonid,
      dutieid,
      superior,
      OLD.status AS status,
      paymenttype,
      type,
      totalcashbon,
      inputby,
      inputdate,
      updateby,
      updatedate,
      approveby,
      approvedate
FROM sc_tmp.cashbon WHERE TRUE
                      AND cashbonid = NEW.cashbonid;

DELETE FROM sc_trx.cashbon_component WHERE TRUE
                                       AND cashbonid = NEW.cashbonid;

INSERT INTO sc_trx.cashbon_component (
    branch,
    cashbonid,
    componentid,
    nominal,
    quantityday,
    totalcashbon,
    description,
    inputby,
    inputdate,
    updateby,
    updatedate
) SELECT
      branch,
      cashbonid,
      componentid,
      nominal,
      quantityday,
      totalcashbon,
      description,
      inputby,
      inputdate,
      updateby,
      updatedate
FROM sc_tmp.cashbon_component WHERE TRUE
                                AND cashbonid = NEW.cashbonid;

DELETE FROM sc_trx.cashbon_component_po WHERE TRUE
                                          AND cashbonid = NEW.cashbonid;
INSERT INTO sc_trx.cashbon_component_po (
    branch,
    cashbonid,
    pono,
    nomor,
    stockcode,
    stockname,
    qty,
    pricelist,
    brutto,
    netto,
    dpp,
    ppn,
    inputby,
    inputdate,
    updateby,
    updatedate
) SELECT
      branch,
      cashbonid,
      pono,
      nomor,
      stockcode,
      stockname,
      qty,
      pricelist,
      brutto,
      netto,
      dpp,
      ppn,
      inputby,
      inputdate,
      updateby,
      updatedate
FROM sc_tmp.cashbon_component_po WHERE TRUE
                                   AND cashbonid = NEW.cashbonid;

DELETE FROM sc_tmp.cashbon WHERE TRUE
                             AND cashbonid = NEW.cashbonid;

DELETE FROM sc_tmp.cashbon_component WHERE TRUE
                                       AND cashbonid = NEW.cashbonid;

DELETE FROM sc_tmp.cashbon_component_po WHERE TRUE
                                          AND cashbonid = NEW.cashbonid;
END IF;
RETURN NEW;
END;
$$;

alter function tr_cashbon_after_update() owner to postgres;

