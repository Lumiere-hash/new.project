create function pr_reminder_hrd() returns SETOF void
    language plpgsql
as
$$
DECLARE 
/*PROSEDUR UNTUK REMINDER KARYAWAN*/
/* AUTHOR : FIKY*/

vr_duit numeric(18,2):=0;
vr_nik char(12);
vr_tglreminder date;
vr_nik_peg char(12);vr_kdkepegawaian_peg char(12);vr_nodok_peg char(12);vr_tgl_mulai_peg date;vr_tgl_selesai_peg date;vr_nosk_peg char(12);vr_tglreminder_peg date;vr_noremind integer;vr_actreminder integer; /*DEKLARASI STATUS KEPEGAWAIAN*/


BEGIN		

FOR vr_nik in select trim(nik) from sc_mst.karyawan where tglkeluarkerja is null
	loop 
		/*REMINDER STATUS KONTRAK*/
		select nik,nodok,kdkepegawaian,tgl_mulai,tgl_selesai,nosk,tglreminder,sum(noremind)noremind,coalesce(sum(actremind),0) as actremind into vr_nik_peg,vr_nodok_peg,vr_kdkepegawaian_peg, vr_tgl_mulai_peg, vr_tgl_selesai_peg, vr_nosk_peg,vr_tglreminder_peg,vr_noremind,vr_actreminder from (
			select *,cast(to_char(tgl_selesai - interval '1 day' * (select value3 from sc_mst.option where group_option='REMINDER' and kdoption='REMB1'),'yyyy-mm-dd') as date) as tglreminder,1 as noremind,actremind as noact  from sc_trx.status_kepegawaian 
			where input_date in (select max(input_date) from sc_trx.status_kepegawaian where nik=vr_nik) and nik=vr_nik
			union all
			select *,cast(to_char(tgl_selesai - interval '1 day' * (select value3 from sc_mst.option where group_option='REMINDER' and kdoption='REMB2'),'yyyy-mm-dd') as date) as tglreminder,2 as noremind,actremind as noact   from sc_trx.status_kepegawaian 
			where input_date in (select max(input_date) from sc_trx.status_kepegawaian where nik=vr_nik) and nik=vr_nik
			union all
			select *,cast(to_char(tgl_selesai - interval '1 day' * (select value3 from sc_mst.option where group_option='REMINDER' and kdoption='REMB3'),'yyyy-mm-dd') as date) as tglreminder,3 as noremind,actremind as noact   from sc_trx.status_kepegawaian 
			where input_date in (select max(input_date) from sc_trx.status_kepegawaian where nik=vr_nik) and nik=vr_nik
			union all
			select *,cast(to_char(tgl_selesai - interval '1 day' * (select value3 from sc_mst.option where group_option='REMINDER' and kdoption='REMB4'),'yyyy-mm-dd') as date) as tglreminder,4 as noremind,actremind as noact   from sc_trx.status_kepegawaian 
			where input_date in (select max(input_date) from sc_trx.status_kepegawaian where nik=vr_nik) and nik=vr_nik
			union all
			select *,cast(to_char(tgl_selesai + interval '1 day' * (select value3 from sc_mst.option where group_option='REMINDER' and kdoption='REMB5'),'yyyy-mm-dd') as date) as tglreminder,5 as noremind,actremind as noact   from sc_trx.status_kepegawaian 
			where input_date in (select max(input_date) from sc_trx.status_kepegawaian where nik=vr_nik) and nik=vr_nik
			union all
			select *,cast(to_char(tgl_selesai + interval '1 day' * (select value3 from sc_mst.option where group_option='REMINDER' and kdoption='REMB6'),'yyyy-mm-dd') as date) as tglreminder,6 as noremind,actremind as noact from sc_trx.status_kepegawaian 
			where input_date in (select max(input_date) from sc_trx.status_kepegawaian where nik=vr_nik) and nik=vr_nik) as x
			where to_char(x.tglreminder,'yyyy-mm-dd')=to_char(now(),'yyyy-mm-dd')
			group by  nik,nodok,kdkepegawaian,tgl_mulai,tgl_selesai,nosk,tglreminder;

			--insert into sc_his.dummy_data (nik) values (vr_nik);

		if (vr_tglreminder_peg is not null and vr_noremind>vr_actreminder) then
			insert into outbox ("DestinationNumber","TextDecoded","CreatorID") select nohp1,left(isi_sms,160),'SISTEM' from --karyawan
					(select replace(trim(b.nohp1),'_','') as nohp1,(select trim(nmkepegawaian) from sc_mst.status_kepegawaian where kdkepegawaian=vr_kdkepegawaian_peg)||' Anda berakhir tgl: '||vr_tgl_selesai_peg as isi_sms,'SYSTEM'
						 from sc_trx.status_kepegawaian a 
						 left outer join sc_mst.karyawan b on a.nik=b.nik
					where a.nodok=vr_nodok_peg and coalesce(b.nohp1,'')<>'')AS X;

			insert into outbox ("DestinationNumber","TextDecoded","CreatorID") select nohp1,left(isi_sms,160),'SISTEM' from --atasan1
					(select replace(trim(c.nohp1),'_','') as nohp1,(select trim(nmkepegawaian) from sc_mst.status_kepegawaian where kdkepegawaian=vr_kdkepegawaian_peg)||' '||b.nmlengkap||' berakhir tgl: '||vr_tgl_selesai_peg as isi_sms,'SYSTEM'
						 from sc_trx.status_kepegawaian a 
						 left outer join sc_mst.karyawan b on a.nik=b.nik
						 left outer join sc_mst.karyawan c on b.nik_atasan=c.nik
					where a.nodok=vr_nodok_peg  and coalesce(c.nohp1,'')<>'')AS X;

			insert into outbox ("DestinationNumber","TextDecoded","CreatorID") select nohp1,left(isi_sms,160),'SISTEM' from --atasan2
					(select replace(trim(c.nohp1),'_','') as nohp1,(select trim(nmkepegawaian) from sc_mst.status_kepegawaian where kdkepegawaian=vr_kdkepegawaian_peg)||' '||b.nmlengkap||' berakhir tgl: '||vr_tgl_selesai_peg as isi_sms,'SYSTEM'
						 from sc_trx.status_kepegawaian a 
						 left outer join sc_mst.karyawan b on a.nik=b.nik
						 left outer join sc_mst.karyawan c on b.nik_atasan2=c.nik
					where a.nodok=vr_nodok_peg  and coalesce(c.nohp2,'')<>'')AS X;	

			insert into outbox ("DestinationNumber","TextDecoded","CreatorID") select nohp1,left(isi_sms,160),'SISTEM' from --hr
					(select replace(trim(c.nohp1),'_','') as nohp1,(select trim(nmkepegawaian) from sc_mst.status_kepegawaian where kdkepegawaian=vr_kdkepegawaian_peg)||' '||b.nmlengkap||' berakhir tgl: '||vr_tgl_selesai_peg as isi_sms,'SYSTEM'
						 from sc_trx.status_kepegawaian a 
						 left outer join sc_mst.karyawan b on a.nik=b.nik
						 left outer join sc_mst.karyawan c on c.nik=c.nik
					where  c.nik in (select trim(nik) from sc_mst.notif_sms where dinas='Y'  and coalesce(c.nohp1,'')<>'')  and a.nodok=vr_nodok_peg)AS X;				

			update sc_trx.status_kepegawaian set actremind=vr_noremind where nodok=vr_nodok_peg and nik=vr_nik_peg;		
		end if; 




	return next vr_nik;
	end loop;
	
END;
$$;

alter function pr_reminder_hrd() owner to postgres;

