create function pr_pph21nr_21(id character, nomor integer, userid character, periode integer) returns numeric
    language plpgsql
as
$$
DECLARE 

--vr_pkp numeric(18,2):=0;
vr_periodesebelum integer;
vr_ratio numeric(18,2):=0;
vr_pph5 numeric(18,2):=0;
vr_pph15 numeric(18,2):=0;
vr_pphsetahun numeric(18,2):=0;
BEGIN		

	--select besaranptkp into vr_duit from sc_mst.karyawan where nik=id;
	vr_periodesebelum=periode-1;
	select nominal into vr_ratio from sc_tmp.p21_detail where nik=id  and no_urut=49 and periode_mulai=periode;	
	select nominal into vr_pph5 from sc_tmp.p21_detail where nik=id  and no_urut=48 and periode_mulai=periode;	
	
	
	vr_pphsetahun=vr_pph5-vr_ratio;	
	
	delete from sc_tmp.p21_detail where nodok=userid and nik=id and no_urut=nomor and periode_mulai=periode;

	insert into sc_tmp.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select userid as nodok,id as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_pphsetahun as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,
	periode as periode_mulai,periode as periode_akhir from sc_mst.detail_formula
	where no_urut=nomor and kdrumus='P21';

	--insert into dumy(nominal) values (vr_pph5);
	
	RETURN vr_pphsetahun;	
END;
$$;

alter function pr_pph21nr_21(char, integer, char, integer) owner to postgres;

