create function tr_cashbon_component_after_insert_update() returns trigger
    language plpgsql
as
$$
DECLARE
BEGIN
    UPDATE sc_tmp.cashbon SET
        totalcashbon = ( SELECT SUM(a.totalcashbon) FROM sc_tmp.cashbon_component a WHERE TRUE AND a.cashbonid = NEW.cashbonid )
    WHERE TRUE
    AND cashbonid = NEW.cashbonid;
    RETURN NEW;
END;
$$;

alter function tr_cashbon_component_after_insert_update() owner to postgres;

