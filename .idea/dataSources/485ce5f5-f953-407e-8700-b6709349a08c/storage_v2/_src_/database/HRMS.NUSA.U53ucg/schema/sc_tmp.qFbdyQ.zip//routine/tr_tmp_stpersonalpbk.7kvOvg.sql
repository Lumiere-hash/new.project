create function tr_tmp_stpersonalpbk() returns trigger
    language plpgsql
as
$$
declare
--created by Fiky ::26/07/2017
--triger penomoran mutasi asset referensi mutasi
     vr_nomor char(12); 
     vr_cekprefix char(4);
     vr_nowprefix char(4);
begin    

	IF TG_OP ='INSERT' THEN 
		delete from sc_mst.penomoran where userid=new.nodok;
		delete from sc_mst.trxerror where userid=new.nodok;    

		select trim(split_part(trim(prefix),'PSBK',2)) as cekprefix into vr_cekprefix from sc_mst.nomor where dokumen='STG_PSBK';
		select to_char(now(),'YYMM') as cekbulan into vr_nowprefix;
		if(vr_nowprefix<>vr_cekprefix) then 
			update sc_mst.nomor set prefix='PSBK'||vr_nowprefix,docno=0 where dokumen='STG_PSBK';
		end if;
		insert into sc_mst.penomoran 
		(userid,dokumen,nomor,errorid,partid,counterid,xno)
		values(new.nodok,'STG_PSBK',' ',0,' ',1,0);
		vr_nomor:=trim(coalesce(nomor,'')) from sc_mst.penomoran where userid=new.nodok;
		
		insert into sc_trx.stpersonalpbk
		(branch,nodok,nik,kdgroup,kdsubgroup,stockcode,loccode,desc_barang,qty,status,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby)
		(select branch,vr_nomor,nik,kdgroup,kdsubgroup,stockcode,loccode,desc_barang,qty,'A',keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby
		from sc_tmp.stpersonalpbk where nodok=new.nodok);
		
		delete from sc_tmp.stpersonalpbk where nodok=new.nodok;
		
		
	RETURN NEW;
	ELSEIF TG_OP ='UPDATE' THEN
	
	RETURN NEW;
	END IF;
/*
select * from sc_tmp.stpersonalpbk
select * from sc_trx.stpersonalpbk

select * from sc_mst.nomor 
insert into sc_mst.nomor VALUES
('STG_PSBK','',4,'PSBK1706','',0,'66666','','201606','T')
--delete from sc_mst.nomor where dokumen='STG_PSBK';
*/
    return new;
        
end;
$$;

alter function tr_tmp_stpersonalpbk() owner to postgres;

