create function tr_legal_master() returns trigger
    language plpgsql
as
$$
DECLARE 
	--author by fiky: 12/08/2020
	--update by fiky: 12/08/2020
     vr_nomor char(20); 
     vr_lastdoc numeric; 
BEGIN		
	IF tg_op = 'UPDATE' THEN
		IF (new.status='E' and old.status='A') THEN
		--select * from sc_mst.nomor;
		--select * from sc_his.legal_master;
			
			insert into sc_tmp.legal_master
			(docno,docname,doctype,docdate,docref,docrefname,coperator,coperatorname,idbu,namebu,status,
			progress,description,inputdate,inputby,updatedate,updateby,finishdate,finishby,docnokeep,docnotmp,attachment,attachment_dir)
			(select new.updateby as docno,docname,doctype,docdate,docref,docrefname,coperator,coperatorname,idbu,namebu,'E' as status,
			progress,description,inputdate,inputby,updatedate,updateby,finishdate,finishby,docnokeep,new.docno as docnotmp,attachment,attachment_dir from sc_his.legal_master where docno=new.docno);

			insert into sc_tmp.legal_detail
			(docno,sort,docname,doctype,docdate,docref,docrefname,coperator,coperatorname,dateoperation,operationcategory,idbu,namebu,
			status,progress,description,inputdate,inputby,updatedate,updateby,finishdate,finishby,docnokeep,docnotmp,attachment,attachment_dir)
			(select new.updateby as docno,sort,docname,doctype,docdate,docref,docrefname,coperator,coperatorname,dateoperation,operationcategory,idbu,namebu,
			status,progress,description,inputdate,inputby,updatedate,updateby,finishdate,finishby,docnokeep,new.docno as docnotmp,attachment,attachment_dir from sc_his.legal_detail where docno=new.docno);

		END IF;
		RETURN NEW;	
	END IF;
	
END;
$$;

alter function tr_legal_master() owner to postgres;

