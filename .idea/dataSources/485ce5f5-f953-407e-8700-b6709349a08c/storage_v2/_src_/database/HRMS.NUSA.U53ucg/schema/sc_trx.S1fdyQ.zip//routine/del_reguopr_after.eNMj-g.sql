create function del_reguopr_after() returns trigger
    language plpgsql
as
$$
declare
   
begin

	delete from sc_tmp.regu_opr where nik=new.nik and kdregu=new.kdregu;
	return new;
end;

$$;

alter function del_reguopr_after() owner to postgres;

