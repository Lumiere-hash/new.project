create function m_grade_jabatan() returns trigger
    language plpgsql
as
$$
declare
     /*
     CREATE	: FIKY ASHARIZA
     CASE	: TRIGGER PENOMORAN SUB

     alter table sc_mst.m_grade_jabatan add column status character(4);
     */
   	vr_nomor character(20);
	vr_lastdoc numeric; 
begin
			IF TG_OP='INSERT' THEN
			--update sc_mst.m_grade_jabatan set status=null
				--select * from sc_mst.m_grade_jabatan;
				update sc_mst.m_grade_jabatan set 
				n_a = coalesce(fx_a,0) * coalesce(sn_a,0),
				n_b = coalesce(fx_b,0) * coalesce(sn_b,0),
				n_c = coalesce(fx_c,0) * coalesce(sn_c,0),
				n_d = coalesce(fx_d,0) * coalesce(sn_d,0),
				n_e = coalesce(fx_e,0) * coalesce(sn_e,0)
				where kdgradejabatan = new.kdgradejabatan;

				update sc_mst.m_grade_jabatan set 
				status = 'U'
				where kdgradejabatan = new.kdgradejabatan;
			ELSEIF TG_OP='UPDATE' THEN
				if (new.status='U' and coalesce(old.status,'')!='U') then
					update sc_mst.m_grade_jabatan set 
					n_a = coalesce(fx_a,0) * coalesce(sn_a,0),
					n_b = coalesce(fx_b,0) * coalesce(sn_b,0),
					n_c = coalesce(fx_c,0) * coalesce(sn_c,0),
					n_d = coalesce(fx_d,0) * coalesce(sn_d,0),
					n_e = coalesce(fx_e,0) * coalesce(sn_e,0)
					where kdgradejabatan = new.kdgradejabatan;

					update sc_mst.m_grade_jabatan set 
					nominal = coalesce(n_a,0) + coalesce(n_b,0) + coalesce(n_c,0) + coalesce(n_d,0) + coalesce(n_e,0),
					status=old.status
					where kdgradejabatan = new.kdgradejabatan;

				end if;				
			END IF;
			

return new;

end;
$$;

alter function m_grade_jabatan() owner to postgres;

