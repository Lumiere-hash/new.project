create function pr_template_jadwalkerja_ins(vr_bulan character, vr_tahun character, vr_kdregu character, vr_inputdate date, vr_inputby character) returns SETOF void
    language plpgsql
as
$$

DECLARE vr_tgl date;
DECLARE vr_jam character(10);
DECLARE vr_jamrev character(10);
DECLARE vr_inisial character(10);
DECLARE vr_cek_jadwal bigint;
DECLARE vr_hari_libur bigint;
BEGIN

	
		FOR vr_inisial,vr_jamrev in select x.inisial,x.jam_rev from 
				(select tahun,bulan,kdregu,m01_1 as jam,m01_1_rev as jam_rev,'01' as inisial from sc_mst.template_jadwal 
				union all
				select tahun,bulan,kdregu,m01_2 as jam,m01_2_rev as jam_rev,'02' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m01_3 as jam,m01_3_rev as jam_rev,'03' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m01_4 as jam,m01_4_rev as jam_rev,'04' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m01_5 as jam,m01_5_rev as jam_rev,'05' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m01_6 as jam,m01_6_rev as jam_rev,'06' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m01_7 as jam,m01_7_rev as jam_rev,'07' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m02_8 as jam,m02_8_rev as jam_rev,'08' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m02_9 as jam,m02_9_rev as jam_rev,'09' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m02_10 as jam,m02_10_rev as jam_rev,'10' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m02_11 as jam,m02_11_rev as jam_rev,'11' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m02_12 as jam,m02_12_rev as jam_rev,'12' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m02_13 as jam,m02_13_rev as jam_rev,'13' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m02_14 as jam,m02_14_rev as jam_rev,'14' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m03_15 as jam,m03_15_rev as jam_rev,'15' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m03_16 as jam,m03_16_rev as jam_rev,'16' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m03_17 as jam,m03_17_rev as jam_rev,'17' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m03_18 as jam,m03_18_rev as jam_rev,'18' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m03_19 as jam,m03_19_rev as jam_rev,'19' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m03_20 as jam,m03_20_rev as jam_rev,'20' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m03_21 as jam,m03_21_rev as jam_rev,'21' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m04_22 as jam,m04_22_rev as jam_rev,'22' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m04_23 as jam,m04_23_rev as jam_rev,'23' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m04_24 as jam,m04_24_rev as jam_rev,'24' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m04_25 as jam,m04_25_rev as jam_rev,'25' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m04_26 as jam,m04_26_rev as jam_rev,'26' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m04_27 as jam,m04_27_rev as jam_rev,'27' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m04_28 as jam,m04_28_rev as jam_rev,'28' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m05_29 as jam,m05_29_rev as jam_rev,'29' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m05_30 as jam,m05_30_rev as jam_rev,'30' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m05_31 as jam,m05_31_rev as jam_rev,'31' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m05_32 as jam,m05_32_rev as jam_rev,'32' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m05_33 as jam,m05_33_rev as jam_rev,'33' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m05_34 as jam,m05_34_rev as jam_rev,'34' as inisial from sc_mst.template_jadwal
				union all
				select tahun,bulan,kdregu,m05_35 as jam,m05_35_rev as jam_rev,'35' as inisial from sc_mst.template_jadwal
				) as x
				where kdregu=vr_kdregu and bulan=vr_bulan and tahun=vr_tahun and x.jam_rev is not null 
							
				LOOP	
						vr_tgl:=to_char(cast((vr_tahun||'-'||vr_bulan||'-'||vr_inisial)as date),'yyyy-mm-dd');
						vr_cek_jadwal:=count(*) from sc_trx.jadwalkerja where tgl=vr_tgl and kdregu=vr_kdregu;
						--vr_hari_libur:=count(tgl_libur) from sc_mst.libur where tgl_libur=vr_tgl; 
						vr_hari_libur:=0; --buka bloking insert hari libur
						if( vr_cek_jadwal=0 and vr_hari_libur=0 and vr_jamrev is not null and vr_jamrev<>'OFF') then
							insert into sc_trx.jadwalkerja (kdregu,kodejamkerja,inputdate,inputby,tgl)
							values (vr_kdregu,vr_jamrev,vr_inputdate,vr_inputby,vr_tgl);
						end if;

				RETURN NEXT vr_inisial;
				END LOOP;

	
END;
$$;

alter function pr_template_jadwalkerja_ins(char, char, char, date, char) owner to postgres;

