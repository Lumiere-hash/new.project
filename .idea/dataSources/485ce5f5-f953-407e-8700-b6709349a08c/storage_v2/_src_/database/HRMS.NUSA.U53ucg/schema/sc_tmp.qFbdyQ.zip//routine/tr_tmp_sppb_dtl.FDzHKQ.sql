create function tr_tmp_sppb_dtl() returns trigger
    language plpgsql
as
$$
DECLARE 
	--author by fiky: 12/08/2017
	--update by fiky: 12/08/2017
     vr_nomor char(12); 
     vr_cekprefix char(4);
     vr_nowprefix char(4);  
     vr_qtypbk numeric;  
     vr_qtybbk numeric;  
     vr_qtyonhand numeric;  
       
     vr_onhand_stkgdw numeric; 
     vr_tmpalloca_stkgdw numeric; 
     vr_alloca_stkgdw numeric; 
     vr_onhandtemp_stkgdw numeric; 
BEGIN		
	IF tg_op = 'INSERT' THEN
		--alter table sc_tmp.sppb_dtl alter column id type int;
		--select * from  sc_tmp.sppb_dtl
		
		update  sc_tmp.sppb_dtl a set id=a1.urutnya
		from (select a1.*,row_number() over(partition by nodok order by inputdate asc) as urutnya
		from sc_tmp.sppb_dtl a1) a1
		where a.id=a1.id and a.inputdate>=a1.inputdate and  a.branch=a1.branch and a.nodok=a1.nodok and a.nik=a1.nik and a.nodok=new.nodok and a.nik=new.nik;


		RETURN new;
	ELSEIF tg_op = 'UPDATE' THEN
		--select * from sc_tmp.sppb_dtl
		--update sc_tmp.sppb_dtl set status='A'
		IF (NEW.STATUS='' and old.status<>'') THEN
		update sc_tmp.sppb_dtl a set qtysppbkecil=coalesce(a.qtysppbminta,0)*coalesce(b.qty,0) from sc_mst.mapping_satuan_brg b
		where b.satbesar=a.satminta and b.satkecil=a.satkecil and b.kdgroup=new.kdgroup and b.kdsubgroup=new.kdsubgroup and b.stockcode=new.stockcode
		and a.nodok=new.nodok and a.id=new.id;

		update sc_tmp.sppb_dtl set status=old.status where desc_barang=new.desc_barang and nodok=new.nodok and id=new.id;
		
		END IF; 

		IF (OLD.STATUS='I' AND NEW.STATUS='I') THEN
	
		ELSEIF (OLD.STATUS='A' AND NEW.STATUS='A') THEN

		
		ELSEIF (OLD.STATUS='A' AND NEW.STATUS='C') THEN

		ELSEIF (OLD.STATUS='C' AND NEW.STATUS='A') THEN

		END IF;

		/* TRIGER PEMBATALAN STATUS MASTER KETIKA DIREJECT SEMUA ITEM 
		IF NOT EXISTS (SELECT * FROM SC_TMP.sppb_DTL WHERE NODOK=NEW.NODOK AND (STATUS='A' OR STATUS='P' OR STATUS='I')) THEN
			UPDATE SC_TMP.sppb_MST SET STATUS='C' WHERE NODOK=NEW.NODOK;
		ELSEIF EXISTS (SELECT * FROM SC_TMP.sppb_MST WHERE NODOK=NEW.NODOK AND STATUS='A') THEN
			UPDATE SC_TMP.sppb_MST SET STATUS='A' WHERE NODOK=NEW.NODOK;
			
		END IF;
		*/
		RETURN NEW;
	ELSEIF tg_op = 'DELETE' THEN
		/*if not exists (select * from sc_tmp.stpbk_dtl where nodok=old.nodok) then
			delete from sc_tmp.stpbk_mst where nodok=old.nodok;
		end if; 

		--if (old.status='I' or old.status='E') then
			select coalesce(onhand,0),coalesce(tmpalloca,0),coalesce(onhand,0)-coalesce(tmpalloca,0),coalesce(allocated,0) from sc_mst.stkgdw 
			into vr_onhand_stkgdw,vr_tmpalloca_stkgdw,vr_onhandtemp_stkgdw,vr_alloca_stkgdw where 
			KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE FOR UPDATE;

			update sc_mst.stkgdw set tmpalloca=vr_tmpalloca_stkgdw-old.qtybbk where 
			KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE;
		---end if;
	*/
	/*
			ALTER TABLE sc_tmp.sppb_dtl
			  ADD CONSTRAINT sppb_dtl_pkey PRIMARY KEY(branch, nodok, id);
			ALTER TABLE sc_tmp.sppb_dtl DROP CONSTRAINT sppb_dtl_pkey;
	*/
		update  sc_tmp.sppb_dtl a set id=a1.urutnya
		from (select a1.*,row_number() over(partition by nodok order by inputdate asc) as urutnya
		from sc_tmp.sppb_dtl a1) a1
		where a.id=a1.id and a.inputdate=a1.inputdate and  a.branch=a1.branch and a.nodok=a1.nodok and a.nik=a1.nik ;
		RETURN old;	
	END IF;
	
END;
$$;

alter function tr_tmp_sppb_dtl() owner to postgres;

