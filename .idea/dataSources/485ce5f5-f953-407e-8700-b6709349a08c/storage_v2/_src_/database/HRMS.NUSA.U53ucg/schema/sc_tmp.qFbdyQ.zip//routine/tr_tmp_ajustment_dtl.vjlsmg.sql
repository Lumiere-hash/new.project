create function tr_tmp_ajustment_dtl() returns trigger
    language plpgsql
as
$$
DECLARE 
	--author by fiky: 12/08/2017
	--update by fiky: 16/10/2017
     vr_nomor char(12); 
     vr_cekprefix char(4);
     vr_nowprefix char(4);  
     vr_qtypbk numeric;  
     vr_qtybbk numeric;  
     vr_qtyonhand numeric;  

BEGIN		
	IF tg_op = 'INSERT' THEN

		update  sc_tmp.ajustment_dtl a set id=a1.urutnya
		from (select a1.*,row_number() over(partition by nodok order by stockcode,inputdate asc) as urutnya
		from sc_tmp.ajustment_dtl a1) a1
		where a.nodok=a1.nodok and a.kdgroup=a1.kdgroup and a.kdsubgroup=a1.kdsubgroup and a.stockcode=a1.stockcode
		and a.nodok=new.nodok ;
			
		RETURN new;
	ELSEIF tg_op = 'UPDATE' THEN
	
		RETURN new;
	ELSEIF tg_op = 'DELETE' THEN
		update  sc_tmp.ajustment_dtl a set id=a1.urutnya
		from (select a1.*,row_number() over(partition by nodok order by stockcode,inputdate asc) as urutnya
		from sc_tmp.ajustment_dtl a1) a1
		where a.nodok=a1.nodok and a.kdgroup=a1.kdgroup and a.kdsubgroup=a1.kdsubgroup and a.stockcode=a1.stockcode
		and a.nodok=old.nodok ;

		RETURN old;	
	END IF;
	
END;
$$;

alter function tr_tmp_ajustment_dtl() owner to postgres;

