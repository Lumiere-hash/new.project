create function tr_asnkendaraan_mst() returns trigger
    language plpgsql
as
$$
declare
--created by Fiky ::18/05/2018
     vr_nomor char(12); 
     vr_lastdoc numeric; 
     vr_cekprefix char(4);
     vr_nowprefix char(4);
begin    

	IF TG_OP ='INSERT' THEN 

	RETURN NEW;
	ELSEIF TG_OP ='UPDATE' THEN
			
			/* NO RESOURCE UPDATE 
			select * from sc_mst.nomor	
			select * from sc_mst.penomoran	
			select * from sc_his.asnkendaraan_mst
			select * from sc_mst.mbarang
			*/
		if (new.status='F' and old.status='I') then
			delete from sc_mst.penomoran where userid=new.docno;
			delete from sc_mst.trxerror where userid=new.docno;  

			vr_lastdoc:= case 
			when max((right(trim(docno),4))) is null or max((right(trim(docno),4)))='' then '0'::numeric
			else max((right(trim(docno),4)))::numeric end lastdoc
			from sc_his.asnkendaraan_mst
			where to_char(docdate,'yyyymm')=to_char(new.docdate,'yyyymm');

			update sc_mst.nomor set  prefix='BC'||to_char(new.docdate,'YYMM') ,docno=vr_lastdoc where dokumen='BC_ASN_K';

			insert into sc_mst.penomoran 
			(userid,dokumen,nomor,errorid,partid,counterid,xno)
			values(new.docno,'BC_ASN_K',' ',0,' ',1,0);
			vr_nomor:=trim(coalesce(nomor,'')) from sc_mst.penomoran where userid=new.docno and dokumen='BC_ASN_K';
		
			insert into sc_his.asnkendaraan_mst
			(docno,docdate,docref,kdgroup,kdsubgroup,stockcode,kdsubasuransi,old_kdsubasuransi,expasuransi,old_expasuransi,
			ttlvalue,description,status,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,docnotmp)
			(select vr_nomor,docdate,docref,kdgroup,kdsubgroup,stockcode,kdsubasuransi,old_kdsubasuransi,expasuransi,old_expasuransi,
			ttlvalue,description,'A' as status,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,docnotmp from sc_tmp.asnkendaraan_mst where docno=new.docno);

			delete from sc_tmp.asnkendaraan_mst where docno=new.docno;
		elseif (new.status='F' and old.status='E') then
			delete from sc_his.asnkendaraan_mst where docno=new.docnotmp;
			
			insert into sc_his.asnkendaraan_mst
			(docno,docdate,docref,kdgroup,kdsubgroup,stockcode,kdsubasuransi,old_kdsubasuransi,expasuransi,old_expasuransi,
			ttlvalue,description,status,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,docnotmp)
			(select docnotmp,docdate,docref,kdgroup,kdsubgroup,stockcode,kdsubasuransi,old_kdsubasuransi,expasuransi,old_expasuransi,
			ttlvalue,description,'A' as status,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,docnotmp from sc_tmp.asnkendaraan_mst where docno=new.docno);

			delete from sc_tmp.asnkendaraan_mst where docno=new.docno;
		elseif (new.status='F' and old.status='A') then
			delete from sc_his.asnkendaraan_mst where docno=new.docnotmp;
			
			insert into sc_his.asnkendaraan_mst
			(docno,docdate,docref,kdgroup,kdsubgroup,stockcode,kdsubasuransi,old_kdsubasuransi,expasuransi,old_expasuransi,
			ttlvalue,description,status,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,docnotmp)
			(select docnotmp,docdate,docref,kdgroup,kdsubgroup,stockcode,kdsubasuransi,old_kdsubasuransi,expasuransi,old_expasuransi,
			ttlvalue,description,'P' as status,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,docnotmp from sc_tmp.asnkendaraan_mst where docno=new.docno);

			update sc_mst.mbarang set kdsubasuransi=new.kdsubasuransi,expasuransi=new.expasuransi where nodok=new.stockcode;
			
			delete from sc_tmp.asnkendaraan_mst where docno=new.docno;
		elseif (new.status='F' and old.status='C') then
			delete from sc_his.asnkendaraan_mst where docno=new.docnotmp;
			
			insert into sc_his.asnkendaraan_mst
			(docno,docdate,docref,kdgroup,kdsubgroup,stockcode,kdsubasuransi,old_kdsubasuransi,expasuransi,old_expasuransi,
			ttlvalue,description,status,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,docnotmp)
			(select docnotmp,docdate,docref,kdgroup,kdsubgroup,stockcode,kdsubasuransi,old_kdsubasuransi,expasuransi,old_expasuransi,
			ttlvalue,description,'C' as status,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,docnotmp from sc_tmp.asnkendaraan_mst where docno=new.docno);

			delete from sc_tmp.asnkendaraan_mst where docno=new.docno;			
		end if;
	
			
	RETURN NEW;
	END IF;
    
    
    return new;
        
end;
$$;

alter function tr_asnkendaraan_mst() owner to postgres;

