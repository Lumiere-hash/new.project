create function pr_lembur_after_update() returns trigger
    language plpgsql
as
$$
declare
     
     --vr_nomor char(30);
     --vr_status char(10);
     --05/08/2017
begin


--select old.status;
if (new.status='P')and(old.status='A') then 

--select * from sc_trx.lembur

	/*---SELF SMS----*/
	insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
	select b.nohp1,			
	'Sdr/i '||b.nmlengkap||' Lembur no. '||a.nodok||' Telah Di Setujui,Tgl: '||to_char(tgl_kerja,'dd-mm-yyyy')
	,nmlengkap
	from sc_trx.lembur a
	left outer join sc_mst.karyawan b on a.nik=b.nik
	where a.nodok=new.nodok and b.nohp1 is not null;
	
	/*---SMS KE HRD----*/	
	insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
	select telepon,isi,textdecoded from (
	select telepon,'Lembur no : '||nodok||' '||nmlengkap||' tgl: '||to_char(tgl_kerja,'dd-mm-yyyy')||' Telah Di setujui' as isi,'OSIN' as textdecoded  from
	(select t0.*,trim(t3.nohp1) as telepon,t1.nodok,t1.nik,t1.nmlengkap,t1.tgl_kerja,t1.tgl_jam_mulai,t1.tgl_jam_selesai,t1.nik as nik from sc_mst.notif_sms t0
	left outer join (select	case b.kdcabang	when 'SBYMRG' then 'Y'	end as kanwil_sby,
				case b.kdcabang	when 'SMGDMK' then 'Y'	end as kanwil_dmk,
				case b.kdcabang	when 'SMGCND' then 'Y'	end as kanwil_smg,
				case b.kdcabang	when 'JKTKPK' then 'Y'	end as kanwil_jkt,
				a.*,b.nmlengkap from sc_trx.lembur a
			left outer join sc_mst.karyawan b on a.nik=b.nik
			where nodok=new.nodok 
			) as t1
			on t0.kanwil_sby=t1.kanwil_sby or
			t0.kanwil_smg=t1.kanwil_smg or
			t0.kanwil_dmk=t1.kanwil_dmk or
			t0.kanwil_jkt=t1.kanwil_jkt
	left outer join sc_mst.karyawan t3 on t0.nik=t3.nik		
	where lembur='Y') as t2 ) as t3
	where telepon is not null and isi is not null and textdecoded is not null;

	/* SMS KE ATASAN 1&2 */
	insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
	select telepon,textdecoded,nmlengkap from 
	(select c.nohp1 as telepon,			
	'Sdr/i '||a.nmlengkap||' Lembur no. '||b.nodok||' Di Setujui,TGL :'||to_char(b.tgl_kerja,'dd-mm-yyyy') as textdecoded
	,a.nmlengkap,a.nik,b.nodok
	from sc_mst.karyawan a  
	left outer join  sc_trx.lembur b on b.nik=a.nik
	left outer join  sc_mst.karyawan c on a.nik_atasan=c.nik
	left outer join  sc_mst.karyawan d on a.nik_atasan2=d.nik where b.nodok is not null
	union all
	select d.nohp1 as telepon,			
	'Sdr/i '||a.nmlengkap||' Lembur no. '||b.nodok||' Di Setujui,TGL :'||to_char(b.tgl_kerja,'dd-mm-yyyy') as textdecoded
	,a.nmlengkap,a.nik,b.nodok
	from sc_mst.karyawan a  
	left outer join  sc_trx.lembur b on b.nik=a.nik
	left outer join  sc_mst.karyawan c on a.nik_atasan=c.nik
	left outer join  sc_mst.karyawan d on a.nik_atasan2=d.nik where b.nodok is not null) as x
	where nodok=new.nodok and telepon is not null and textdecoded is not null;
	
	update sc_trx.approvals_system set status='U',asstatus='P' where docno = new.nodok and status!='U';
	
elseif (new.status='C')and(old.status='P') then 
	/*---SELF SMS----*/
	insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
	select nohp1 as nohp,sms,nama from (
	select b.nohp1,			
	'Sdr/i '||b.nmlengkap||' Lembur no. '||a.nodok||' Dibatalkan,Tgl: '||to_char(tgl_kerja,'dd-mm-yyyy') as sms
	,nmlengkap as nama
	from sc_trx.lembur a
	left outer join sc_mst.karyawan b on a.nik=b.nik
	where a.nodok=new.nodok ) as x1
	where  nohp1 is not null and sms is not null and nama is not null;
	
	/*---SMS KE HRD----*/	
	insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
	select telepon,isi,textdecoded from (
	select telepon,'Lembur no : '||nodok||' '||nmlengkap||' tgl: '||to_char(tgl_kerja,'dd-mm-yyyy')||' Dibatalkan' as isi,'OSIN' as textdecoded from
	(select t0.*,trim(t3.nohp1) as telepon,t1.nodok,t1.nik,t1.nmlengkap,t1.tgl_kerja,t1.tgl_jam_mulai,t1.tgl_jam_selesai,t1.nik as nik from sc_mst.notif_sms t0
	left outer join (select	case b.kdcabang	when 'SBYMRG' then 'Y'	end as kanwil_sby,
				case b.kdcabang	when 'SMGDMK' then 'Y'	end as kanwil_dmk,
				case b.kdcabang	when 'SMGCND' then 'Y'	end as kanwil_smg,
				case b.kdcabang	when 'JKTKPK' then 'Y'	end as kanwil_jkt,
				a.*,b.nmlengkap from sc_trx.lembur a
			left outer join sc_mst.karyawan b on a.nik=b.nik
			where nodok=new.nodok 
			) as t1
			on t0.kanwil_sby=t1.kanwil_sby or
			t0.kanwil_smg=t1.kanwil_smg or
			t0.kanwil_dmk=t1.kanwil_dmk or
			t0.kanwil_jkt=t1.kanwil_jkt
	left outer join sc_mst.karyawan t3 on t0.nik=t3.nik		
	where lembur='Y') as t2 ) as t3
	where telepon is not null and isi is not null and textdecoded is not null;

	/* SMS KE ATASAN 1&2 */
	insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
	select telepon,textdecoded,nmlengkap from 
	(select c.nohp1 as telepon,			
	'Sdr/i '||a.nmlengkap||' Lembur no. '||b.nodok||' Dibatalkan,TGL :'||to_char(b.tgl_kerja,'dd-mm-yyyy') as textdecoded
	,a.nmlengkap,a.nik,b.nodok
	from sc_mst.karyawan a  
	left outer join  sc_trx.lembur b on b.nik=a.nik
	left outer join  sc_mst.karyawan c on a.nik_atasan=c.nik
	left outer join  sc_mst.karyawan d on a.nik_atasan2=d.nik where b.nodok is not null
	union all
	select d.nohp1 as telepon,			
	'Sdr/i '||a.nmlengkap||' Lembur no. '||b.nodok||' Dibatalkan,TGL :'||to_char(b.tgl_kerja,'dd-mm-yyyy') as textdecoded
	,a.nmlengkap,a.nik,b.nodok
	from sc_mst.karyawan a  
	left outer join  sc_trx.lembur b on b.nik=a.nik
	left outer join  sc_mst.karyawan c on a.nik_atasan=c.nik
	left outer join  sc_mst.karyawan d on a.nik_atasan2=d.nik where b.nodok is not null) as x
	where  telepon is not null and textdecoded is not null and nmlengkap is not null and nodok=new.nodok ;

	update sc_trx.approvals_system set status='C',asstatus='C' where docno = new.nodok and status!='C';
	
elseif ((new.status='C')and(old.status='A')) or ((new.status='D')and(old.status='A')) then
	/*---SELF SMS----*/
	insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
	select nohp1,sms,nmlengkap from (
	select b.nohp1,			
	'Sdr/i '||b.nmlengkap||' Lembur no. '||a.nodok||' Di Tolak,Tgl: '||to_char(tgl_kerja,'dd-mm-yyyy') sms
	,nmlengkap
	from sc_trx.lembur a
	left outer join sc_mst.karyawan b on a.nik=b.nik 
	where a.nodok=new.nodok 
	) as x1
	where nohp1 is not null and sms is not null and nmlengkap is not null;

	update sc_trx.approvals_system set status='C',asstatus='C' where docno = new.nodok and status!='C';
elseif (new.status='A' AND old.status='I') then

	delete from sc_mst.trxerror where modul='LEMBUR' and userid=new.input_by;
	insert into sc_mst.trxerror
	(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
	(new.input_by,0,new.nodok,'','LEMBUR');

	perform sc_trx.pr_capture_approvals_system();

end if;
return new;

end;
$$;

alter function pr_lembur_after_update() owner to postgres;

