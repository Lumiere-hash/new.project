create function payroll_resign() returns trigger
    language plpgsql
as
$$
declare
     
     vr_nik char(12);
     vr_nomor char(16);
     vr_tgldok date;
    
     
begin
	if (new.status='F')and(old.status='I') then 
	vr_nik:=nik from sc_tmp.payroll_resign where nik=new.nik and nodok=new.nodok;
	vr_nomor:='PR'||vr_nik; 
	vr_tgldok:=to_char(now(),'YYYY-MM-DD');	
		
		insert into sc_trx.payroll_resign (nodok,nik,gajitetap,tj_pesangon,tj_masakerja,tj_penggantianhak,tj_cuti,tj_absen,tj_lain,
		kom_pesangon,kom_masakerja,kom_penggantianhak,kom_cuti,kom_absen,total_upah,tgl_dok)
		select vr_nomor,nik,gajitetap,tj_pesangon,tj_masakerja,tj_penggantianhak,tj_cuti,tj_absen,tj_lain,
		kom_pesangon,kom_masakerja,kom_penggantianhak,kom_cuti,kom_absen,total_upah,vr_tgldok from sc_tmp.payroll_resign
		where nodok=new.nodok and nik=new.nik;

		delete from sc_tmp.payroll_resign where nodok=new.nodok and nik=new.nik;
	end if;
return new;

end;
$$;

alter function payroll_resign() owner to postgres;

