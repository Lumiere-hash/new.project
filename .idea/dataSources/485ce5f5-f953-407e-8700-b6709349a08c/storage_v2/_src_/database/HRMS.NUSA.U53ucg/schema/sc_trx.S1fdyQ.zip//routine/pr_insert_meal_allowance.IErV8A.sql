create function pr_insert_meal_allowance(start_date date, end_date date) returns character varying
    language plpgsql
as
$$
DECLARE 
	/*UPDATE BY RKM::20240228*/
BEGIN		
	INSERT INTO sc_trx.meal_allowance
        (branch, nik, tgl, checkin, checkout, nominal, keterangan, tgl_dok, dok_ref, rencanacallplan, realisasicallplan, bbm, sewa_kendaraan)
    SELECT branch, nik, tgl, checkin, checkout, nominal, keterangan, tgl_dok, dok_ref, rencanacallplan, realisasicallplan, bbm, sewa_kendaraan
    FROM sc_trx.uangmakan a
    WHERE a.tgl BETWEEN start_date AND end_date
    ON CONFLICT (nik, tgl)
    DO UPDATE SET
        checkin = EXCLUDED.checkin,
        checkout = EXCLUDED.checkout,
        nominal = EXCLUDED.nominal,
        keterangan = EXCLUDED.keterangan,
        tgl_dok = EXCLUDED.tgl_dok,
        dok_ref = EXCLUDED.dok_ref,
        rencanacallplan = EXCLUDED.rencanacallplan,
        realisasicallplan = EXCLUDED.realisasicallplan,
        bbm = EXCLUDED.bbm,
        sewa_kendaraan = EXCLUDED.sewa_kendaraan;
    RETURN 'SUKSES';	
END;
$$;

alter function pr_insert_meal_allowance(date, date) owner to postgres;

