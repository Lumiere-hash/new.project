create function convert_pph21(xnodok character, xperiode integer, xdate character) returns timestamp without time zone
    language plpgsql
as
$$
DECLARE
    listNik RECORD;
    listJadwal RECORD;
    vr_tgl timestamp;
    vr_gaji numeric(18,2);
    vr_tjgrade numeric(18,2);
    vr_tjtetap numeric(18,2);
    vr_lembur numeric(18,2);
    vr_jkk numeric(18,2);
    vr_jkm numeric(18,2);
    vr_bpjs numeric(18,2);
    vr_subtotalreg numeric(18,2);
    vr_pengnonreg numeric(18,2);
    vr_bruto numeric(18,2);
    vr_patokan numeric(18,2);
    vr_biaya numeric(18,2);
    vr_biayajabatan numeric(18,2);
    vr_jht numeric(18,2);
    vr_jp numeric(18,2);
    vr_potongan numeric(18,2);
    vr_netto numeric(18,2);
    vr_pengregblnjln numeric(18,2);
    vr_prosisareg numeric(18,2);
    vr_totalpro numeric(18,2);
    vr_pengnonregblnjln numeric(18,2);
    vr_totalbruto numeric(18,2);
    vr_patokan2 numeric(18,2);
    vr_patokan3 numeric(18,2);
    vr_totalbruto5 numeric(18,2);
    vr_biayajabatansetahun numeric(18,2);
    vr_biayajabatansetahunreg numeric(18,2);
    vr_jhtsetahun numeric(18,2);
    vr_jhtsetahunreg numeric(18,2);
    vr_jpsetahun numeric(18,2);
    vr_jpsetahunreg numeric(18,2);
    vr_sisajht1 numeric(18,2);
    vr_sisajht1reg numeric(18,2);
    vr_sisajht numeric(18,2);
    vr_sisajhtreg numeric(18,2);
    vr_sisajp1 numeric(18,2);
    vr_sisajp1reg numeric(18,2);
    vr_sisajp numeric(18,2);
    vr_sisajpreg numeric(18,2);
    vr_potongansetahun numeric(18,2);
    vr_potongansetahunreg numeric(18,2);
    vr_nettosetahun numeric(18,2);
    vr_nettosetahunreg numeric(18,2);
    vr_ptkp numeric(18,2);
    vr_pkp1 numeric(18,2);
    vr_pkp1reg numeric(18,2);
    vr_pkp2 numeric(18,2);
    vr_pkp2reg numeric(18,2);
    vr_pkp numeric(18,2);
    vr_pkpreg numeric(18,2);
    vr_pph5 numeric(18,2);
    vr_pph5reg numeric(18,2);
    vr_pphsetahun numeric(18,2);
    vr_pphsetahunreg numeric(18,2);
    vr_totalpro5 numeric(18,2);
    vr_ratio numeric(18,2);
    vr_ratio1 numeric(18,2);
    vr_ratio2 numeric(18,2);
      vr_ratiosum numeric(18,2);
    vr_ratiosum1 numeric(18,2);
    vr_ratiosum2 numeric(18,2);
    vr_pphblnjln numeric(18,2);
    vr_sumratio1 numeric(18,2);
    vr_sumratio2 numeric(18,2);
    vr_pphblnsd numeric(18,2);
    vr_pphtn1 numeric(18,2);
    vr_pphtn2 numeric(18,2);
    vr_pphtn numeric(18,2);
    vr_sumpphsetahun numeric(18,2);
    vr_pphnr1 numeric(18,2);
    vr_pphnr2 numeric(18,2);
    vr_pphnr numeric(18,2);
    vr_totalpph numeric(18,2);
    vr_tjshift numeric(18,2);
    
    vr_periodesebelum integer;
 
    
   
    
BEGIN

    vr_periodesebelum=xperiode-1;
    
	
	--select besaranperusahaan into vr_jkk from sc_mst.komponen_bpjs where kode_bpjs='BPJSTK' and kodekomponen='JKK';
	--insert into dumy(tgl) values (vr_tglakhirfix);
	
     
   --FOR listNik IN select distinct nik from sc_trx.dtljadwalkerja where to_char(tgl,'YYYYMM')=$1 and case when xnik<>'' then nik=xnik else nik<>'' end order by nik
    FOR listNik IN select distinct nik from sc_tmp.convertpph21 where periode=xdate  and nik in (select nik from sc_mst.karyawan) order by nik
    LOOP
	--gajipokok
	 select gaji_pokok into vr_gaji from sc_tmp.convertpph21 where nik=listNik.nik and periode=xdate;

	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_gaji as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=1 and kdrumus='P21';

	 --tj jabatan   
	select tunjangan_grade into vr_tjgrade from sc_tmp.convertpph21 where nik=listNik.nik and periode=xdate;

	
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_tjgrade as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=2 and kdrumus='P21';

	--tj tetap

	select tunjangan_tetap into vr_tjtetap from sc_tmp.convertpph21 where nik=listNik.nik and periode=xdate;

	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_tjtetap as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=3 and kdrumus='P21';

        --tj shift          

        select tunjangan_shift into vr_tjshift from sc_tmp.convertpph21 where nik=listNik.nik and periode=xdate;    

	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_tjshift as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=4 and kdrumus='P21';

	--lembur	       
	select lembur into vr_lembur from sc_tmp.convertpph21 where nik=listNik.nik and periode=xdate;

	                 
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_lembur as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=5 and kdrumus='P21';	

	--pengobatan
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,0 as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=6 and kdrumus='P21';


	--jkk
	vr_jkk=(0.89/100.00) * vr_gaji;

	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_jkk as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=7 and kdrumus='P21';

	--jkm
	vr_jkm=(0.30/100.00) * vr_gaji;

	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_jkm as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=8 and kdrumus='P21';
	--bpjskes
	vr_bpjs=(4/100.00) * vr_gaji;
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_bpjs as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=9 and kdrumus='P21'; 

	--subtotal reguler
	select sum(nominal) into vr_subtotalreg from sc_trx.p21_detail where nik=listNik.nik and aksi='A' and periode_mulai=xperiode;

	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_subtotalreg as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=10 and kdrumus='P21';

	--penghasilan nonreg
	  select non_reguler into vr_pengnonreg from sc_tmp.convertpph21 where nik=listNik.nik and periode=xdate;
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_pengnonreg as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=11 and kdrumus='P21';


	 --total bruto
	 vr_bruto=vr_subtotalreg+vr_pengnonreg;
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_bruto as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=12 and kdrumus='P21';
	 
	--biaya jabatan

		

	vr_patokan=500000;
	vr_biaya=vr_subtotalreg * 5/100.00;
	if vr_biaya>vr_patokan then 
		vr_biayajabatan=vr_patokan; 
	else vr_biayajabatan=vr_biaya;
	end if;

	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_biayajabatan as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=13 and kdrumus='P21';

	--jht
	vr_jht=2/100.00 * vr_gaji;
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_jht as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=14 and kdrumus='P21';

	--jp
	vr_jp=1/100.00 * vr_gaji;
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_jp as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=15 and kdrumus='P21';
	--subtotal potongan
	select sum(nominal) into vr_potongan from sc_trx.p21_detail where nik=listNik.nik and aksi='B' and periode_mulai=xperiode;
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_potongan as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=16 and kdrumus='P21';

	--total peng netto

	vr_netto=vr_bruto-vr_potongan;
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_netto as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=17 and kdrumus='P21';

	--reguler bln jln 

	select coalesce(sum(nominal),0) into vr_pengregblnjln from sc_trx.p21_detail where nik=listNik.nik and periode_mulai between 1 and xperiode and aksi='A';	
		
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_pengregblnjln as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=18 and kdrumus='P21';
	--proyeksi sisa reguler
	vr_prosisareg=vr_subtotalreg*(12-xperiode);
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_prosisareg as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=19 and kdrumus='P21';

	--total perkiraan reguler setahun

	vr_totalpro=vr_pengregblnjln+vr_prosisareg;
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_totalpro as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=20 and kdrumus='P21';

	---penghasilan non reg di setahunkan
	select coalesce(sum(nominal),0) into vr_pengnonregblnjln from sc_trx.p21_detail where nik=ListNik.nik and periode_mulai between 1 and xperiode and no_urut='11'; 

	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_pengnonregblnjln as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=21 and kdrumus='P21';
	--total bruto
	vr_totalbruto=vr_totalpro+vr_pengnonregblnjln;
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_totalbruto as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=22 and kdrumus='P21';
	--biaya jabatan setahun
	vr_patokan2=6000000;
	
	vr_totalbruto5=vr_totalbruto*5/100.00;
	
	if (vr_totalbruto5<vr_patokan2) then 
	vr_biayajabatansetahun=vr_totalbruto5;
	else vr_biayajabatansetahun=vr_patokan2;
	end if;

	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_biayajabatansetahun as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=23 and kdrumus='P21';

	--jht setahun 
	select coalesce(sum(nominal),0) into vr_jhtsetahun from sc_trx.p21_detail where nik=ListNik.nik and periode_mulai between 1 and xperiode and no_urut='14'; 
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_jhtsetahun as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=24 and kdrumus='P21';	

	--sisa potong jth
	select coalesce(sum(nominal),0) into vr_sisajht1 from sc_trx.p21_detail where nik=ListNik.nik and periode_mulai=xperiode  and no_urut='14'; 
	vr_sisajht=vr_sisajht1*(12-xperiode);
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_sisajht as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=25 and kdrumus='P21';
	
	--jp setahun 
	select coalesce(sum(nominal),0) into vr_jpsetahun from sc_trx.p21_detail where nik=ListNik.nik and periode_mulai between 1 and xperiode and no_urut='15'; 
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_jpsetahun as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=26 and kdrumus='P21';

	--sisa potong jp
	select coalesce(sum(nominal),0) into vr_sisajp1 from sc_trx.p21_detail where nik=ListNik.nik and periode_mulai=xperiode  and no_urut='15'; 
	vr_sisajp=vr_sisajp1*(12-xperiode);
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_sisajp as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=27 and kdrumus='P21';

	--total potongan setahun
	vr_potongansetahun=vr_biayajabatansetahun+vr_jhtsetahun+vr_sisajht+vr_jpsetahun+vr_sisajp;
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_potongansetahun as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=28 and kdrumus='P21';
	--total gaji netto setahun
	vr_nettosetahun=vr_totalbruto-vr_potongansetahun;
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_nettosetahun as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=29 and kdrumus='P21';
	--besaran ptkp
	select besaranptkp into vr_ptkp from sc_mst.karyawan where nik=ListNik.nik;
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_ptkp as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=30 and kdrumus='P21';

	--pkp
	if (vr_nettosetahun<vr_ptkp) then 
		vr_pkp1=0; 
	else vr_pkp1=vr_nettosetahun-vr_ptkp;
	end if;
	vr_pkp2=round(vr_pkp1,-3);
	
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_pkp2 as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=31 and kdrumus='P21';	

	--pph setahun 

	select coalesce(nominal,0) into vr_pkp from sc_trx.p21_detail where nik=ListNik.nik  and no_urut=31 and periode_mulai=xperiode;	
	--select nominal into vr_pph15 from sc_tmp.p21_detail where nik=id  and no_urut=31 and keterangan='PPH15';	
	if (vr_pkp<=50000000) then 
	vr_pph5=vr_pkp*5/100.00;
	elseif (vr_pkp<=250000000) then
	vr_pph5=(vr_pkp-50000000)*15/100.00+2500000;
	elseif (vr_pkp<=500000000) then
	vr_pph5=(vr_pkp-250000000)*25/100.00+32500000;
	else vr_pph5=(vr_pkp-500000000)*30/100.00+95000000;
	end if;
	vr_pphsetahun=vr_pph5;

	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_pphsetahun as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=32 and kdrumus='P21';
	
	--biaya jabatan setahun reg
	
	--biaya jabatan setahun
	vr_patokan3=6000000;
	
	vr_totalpro5=vr_totalpro*5/100.00;
	
	if (vr_totalbruto5<vr_patokan2) then 
	vr_biayajabatansetahunreg=vr_totalpro5;
	else vr_biayajabatansetahunreg=vr_patokan3;
	end if;

	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_biayajabatansetahunreg as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=33 and kdrumus='P21';

	--jht setahun reg 
	select coalesce(sum(nominal),0) into vr_jhtsetahunreg from sc_trx.p21_detail where nik=ListNik.nik and periode_mulai between 1 and xperiode and no_urut='14'; 
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_jhtsetahunreg as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=34 and kdrumus='P21';	

	--sisa potong jht
	select coalesce(sum(nominal),0) into vr_sisajht1reg from sc_trx.p21_detail where nik=ListNik.nik and periode_mulai=xperiode  and no_urut='14'; 
	vr_sisajhtreg=vr_sisajht1reg*(12-xperiode);
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_sisajhtreg as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=35 and kdrumus='P21';
	

	--jp setahun 
	select coalesce(sum(nominal),0) into vr_jpsetahunreg from sc_trx.p21_detail where nik=ListNik.nik and periode_mulai between 1 and xperiode and no_urut='15'; 
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_jpsetahunreg as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=36 and kdrumus='P21';

	--sisa potong jp
	select coalesce(sum(nominal),0) into vr_sisajp1reg from sc_trx.p21_detail where nik=ListNik.nik and periode_mulai=xperiode  and no_urut='15'; 
	vr_sisajpreg=vr_sisajp1reg*(12-xperiode);
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_sisajpreg as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=37 and kdrumus='P21';

	--total potongan setahun
	vr_potongansetahunreg=vr_biayajabatansetahunreg+vr_jhtsetahunreg+vr_sisajhtreg+vr_jpsetahunreg+vr_sisajpreg;
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_potongansetahunreg as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=38 and kdrumus='P21';

	--total gaji netto setahun
	vr_nettosetahunreg=vr_totalpro-vr_potongansetahunreg;
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_nettosetahunreg as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=39 and kdrumus='P21';
	--besaran ptkp
	--select besaranptkp into vr_ptkp from sc_mst.karyawan where nik=ListNik.nik;
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_ptkp as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=40 and kdrumus='P21';

	--pkp reg
	if (vr_nettosetahunreg<vr_ptkp) then 
		vr_pkp1reg=0; 
	else vr_pkp1reg=vr_nettosetahunreg-vr_ptkp;
	end if;
	vr_pkp2reg=round(vr_pkp1reg,-3);
	
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_pkp2reg as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=41 and kdrumus='P21';

	--pph setahun reg

	select coalesce(nominal,0) into vr_pkpreg from sc_trx.p21_detail where nik=ListNik.nik  and no_urut=41 and periode_mulai=xperiode;	
	--select nominal into vr_pph15 from sc_tmp.p21_detail where nik=id  and no_urut=31 and keterangan='PPH15';	
	if (vr_pkpreg<=50000000) then 
	vr_pph5reg=vr_pkpreg*5/100.00;
	elseif (vr_pkpreg<=250000000) then
	vr_pph5reg=(vr_pkpreg-50000000)*15/100.00+2500000;
	elseif (vr_pkpreg<=500000000) then
	vr_pph5reg=(vr_pkpreg-250000000)*25/100.00+32500000;
	else vr_pph5reg=(vr_pkpreg-500000000)*30/100.00+95000000;
	end if;
	vr_pphsetahunreg=vr_pph5reg;

	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_pphsetahunreg as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=42 and kdrumus='P21';

	--ratio bln jln
	select coalesce(nominal,0) into vr_ratio1 from sc_trx.p21_detail where nik=ListNik.nik  and no_urut=10 and periode_mulai=xperiode;	
	select coalesce(nominal,0) into vr_ratio2 from sc_trx.p21_detail where nik=ListNik.nik  and no_urut=20 and periode_mulai=xperiode;

	if (vr_ratio2<=0) then 
		vr_ratio=0;
	else vr_ratio=round(vr_ratio1/vr_ratio2,3)*100; 
	end if;	

	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_ratio as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=43 and kdrumus='P21';	

	--ratio bulan sd

	select coalesce(sum(nominal),0) into vr_ratiosum1 from sc_trx.p21_detail where nik=ListNik.nik  and no_urut=10  and periode_mulai between 1 and xperiode;	
	select coalesce(nominal,0) into vr_ratiosum2 from sc_trx.p21_detail where nik=ListNik.nik  and no_urut=20 and periode_mulai=xperiode;	

	
	if (vr_ratiosum2<=0) then 
		vr_ratiosum=0;
	else vr_ratiosum=round(vr_ratiosum1/vr_ratiosum2,3)*100; 
	end if;

	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_ratiosum as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=44 and kdrumus='P21';

	--pph 21 bln jalan 

	if (vr_ratio2=0) then 
	vr_pphblnjln=0;
	else
	vr_pphblnjln=round((vr_ratio1/vr_ratio2)*vr_pphsetahunreg);	
	end if;

	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_pphblnjln as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=45 and kdrumus='P21';

	--pph 21 bln sd
	select coalesce(sum(nominal),0) into vr_sumratio1 from sc_trx.p21_detail where nik=ListNik.nik  and no_urut=10 and periode_mulai between 1 and xperiode;	
	select coalesce(nominal,0) into vr_sumratio2 from sc_trx.p21_detail where nik=ListNik.nik  and no_urut=20 and periode_mulai=xperiode;

	if (vr_sumratio2=0) then 
	vr_pphblnsd=0;
	else
	vr_pphblnsd=round((vr_sumratio1/vr_sumratio2)*vr_pphsetahunreg);	
	end if;

	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_pphblnsd as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=46 and kdrumus='P21';

	--pph setahun tanpa normalisasi
	
	
	select coalesce(sum(nominal),0) into vr_pphtn1 from sc_trx.p21_detail where nik=ListNik.nik  and no_urut=46 and periode_mulai=vr_periodesebelum;	
	select coalesce(sum(nominal),0) into vr_pphtn2 from sc_trx.p21_detail where nik=ListNik.nik  and no_urut=46 and periode_mulai=xperiode;	
	
	vr_pphtn=vr_pphtn2-vr_pphtn1;

	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_pphtn as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=47 and kdrumus='P21';


	--pph setahun all

	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_pphsetahun as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=48 and kdrumus='P21';
	--pph setahun reg

	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_pphsetahunreg as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=49 and kdrumus='P21';


	
	vr_sumpphsetahun=vr_pphsetahun-vr_pphsetahunreg;

	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_sumpphsetahun as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=50 and kdrumus='P21';

	--pph non reg bln jalan
	select coalesce(sum(nominal),0) into vr_pphnr1 from sc_trx.p21_detail where nik=ListNik.nik  and no_urut=50 and periode_mulai=vr_periodesebelum;
	select coalesce(sum(nominal),0) into vr_pphnr2 from sc_trx.p21_detail where nik=ListNik.nik  and no_urut=50 and periode_mulai=xperiode;
	vr_pphnr=vr_pphnr2-vr_pphnr1;

	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_pphnr as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=51 and kdrumus='P21';
	--pph reg bulan jalan

	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_pphtn as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=52 and kdrumus='P21';

	-- pph non reg 
	
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_pphnr as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=53 and kdrumus='P21';

	vr_totalpph=vr_pphtn+vr_pphnr;
	insert into sc_trx.p21_detail(
	nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
	approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
	select xnodok as nodok,listNik.nik as nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'I' as status,keterangan,vr_totalpph as nominal,input_date,null as approval_date,input_by,
	null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,xperiode as periode_mulai,xperiode as periode_akhir from sc_mst.detail_formula
	where no_urut=54 and kdrumus='P21';

	
	
    END LOOP;
    
    RETURN vr_tgl;
END;
$$;

alter function convert_pph21(char, integer, char) owner to postgres;

