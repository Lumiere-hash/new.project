create function tr_tmp_po_order() returns trigger
    language plpgsql
as
$$
declare
--created by Fiky ::26/07/2017
--triger penomoran purchasing order 
     vr_nomor char(12); 
     vr_cekprefix char(12);
     vr_nowprefix char(12);
begin    

	IF TG_OP ='INSERT' THEN 
		delete from sc_mst.penomoran where userid=new.nodok;
		delete from sc_mst.trxerror where userid=new.nodok;    

		update sc_tmp.po_order set qtytotalprice=(coalesce(qtyunitprice,0)*coalesce(qtypo,0)) where nodok=new.nodok;
		
		select trim(split_part(trim(prefix),'PO',2))as cekprefix into vr_cekprefix from sc_mst.nomor where dokumen='PO_ATK';
		---select trim(split_part(trim(prefix),'PO',2)) as cekprefix from sc_mst.nomor where dokumen='PO_ATK';
		select to_char(now(),'YYMMDD') as cekbulan into vr_nowprefix;
		if(vr_nowprefix<>vr_cekprefix) then 
			update sc_mst.nomor set prefix='PO'||vr_nowprefix,docno=0 where dokumen='PO_ATK';
		end if;
		insert into sc_mst.penomoran 
		(userid,dokumen,nomor,errorid,partid,counterid,xno)
		values(new.nodok,'PO_ATK',' ',0,' ',1,0);
		vr_nomor:=trim(coalesce(nomor,'')) from sc_mst.penomoran where userid=new.nodok;
		

		insert into sc_trx.po_order (branch,nodok,nodokref,kdgroup,kdsubgroup,stockcode,loccode,desc_barang,qtyunitprice,qtytotalprice,qtypo,qtyreceipt,qtyunit,kdgroupsup,kdsupplier,kdsubsupplier,status,
		keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby)
		(select branch,vr_nomor,nodokref,kdgroup,kdsubgroup,stockcode,loccode,desc_barang,qtyunitprice,qtytotalprice,qtypo,qtyreceipt,qtyunit,kdgroupsup,kdsupplier,kdsubsupplier,'A',
		keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby from sc_tmp.po_order where nodok=new.nodok);
		
		delete from sc_tmp.po_order where nodok=new.nodok;
		
		
	RETURN NEW;
	ELSEIF TG_OP ='UPDATE' THEN
	
			
		
	RETURN NEW;
	END IF;
/*
select * from sc_tmp.po_order
select * from sc_trx.po_order
--truncate sc_tmp.po_order,sc_trx.po_order
select * from sc_mst.nomor
select * from sc_mst.penomoran
insert into sc_mst.nomor VALUES
('PO_ATK','',4,'PO170618','',0,'66666','','201706','T')
--delete from sc_mst.nomor where dokumen='PO_ATK';
*/
     
    
    return new;
        
end;
$$;

alter function tr_tmp_po_order() owner to postgres;

