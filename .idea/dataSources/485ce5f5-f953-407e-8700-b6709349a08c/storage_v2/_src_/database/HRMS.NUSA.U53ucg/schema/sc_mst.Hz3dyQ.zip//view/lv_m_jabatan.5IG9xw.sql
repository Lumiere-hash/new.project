create view lv_m_jabatan
            (branch, kdjabatan, nmjabatan, kddept, kdsubdept, kdgrade, costcenter, uraian, shift, lembur, input_date,
             input_by, update_date, update_by, kdlvl, nominal, nmdept, nmsubdept, nmlvljabatan, nmgrade)
as
SELECT x.branch,
       x.kdjabatan,
       x.nmjabatan,
       x.kddept,
       x.kdsubdept,
       x.kdgrade,
       x.costcenter,
       x.uraian,
       x.shift,
       x.lembur,
       x.input_date,
       x.input_by,
       x.update_date,
       x.update_by,
       x.kdlvl,
       x.nominal,
       x.nmdept,
       x.nmsubdept,
       x.nmlvljabatan,
       x.nmgrade
FROM (SELECT a.branch,
             a.kdjabatan,
             a.nmjabatan,
             a.kddept,
             a.kdsubdept,
             a.kdgrade,
             a.costcenter,
             a.uraian,
             a.shift,
             a.lembur,
             a.input_date,
             a.input_by,
             a.update_date,
             a.update_by,
             a.kdlvl,
             a.nominal,
             b.nmdept,
             c.nmsubdept,
             d.nmlvljabatan,
             e.nmgrade
      FROM sc_mst.jabatan a
               LEFT JOIN sc_mst.departmen b ON a.kddept = b.kddept
               LEFT JOIN sc_mst.subdepartmen c ON a.kddept = c.kddept AND a.kdsubdept = c.kdsubdept
               LEFT JOIN sc_mst.lvljabatan d ON a.kdlvl = d.kdlvl
               LEFT JOIN sc_mst.jobgrade e ON a.kdgrade = e.kdgrade) x;

comment on view lv_m_jabatan is '
  Create By :Fiky Ashariza
  Update Clue
  ALTER VIEW a_view ALTER COLUMN ts SET DEFAULT now();
  INSERT INTO a_view(id) VALUES(2);  -- ts will receive the current time
  ';

alter table lv_m_jabatan
    owner to postgres;

