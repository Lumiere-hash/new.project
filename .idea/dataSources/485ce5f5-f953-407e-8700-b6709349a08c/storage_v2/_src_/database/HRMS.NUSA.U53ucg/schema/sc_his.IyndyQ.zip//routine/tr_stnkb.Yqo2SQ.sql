create function tr_stnkb() returns trigger
    language plpgsql
as
$$
declare
--created by Fiky ::14/07/2017
     vr_nomor char(12); 
     vr_cekprefix char(4);
     vr_nowprefix char(4);
begin    

	IF TG_OP ='UPDATE' THEN 
		IF (new.status='E' and old.status='A')	THEN
			insert into sc_tmp.stnkb
				(nodok,tgldok,dokref,kdrangka,kdmesin,nopol,kdgroup,nmkendaraan,nmpemilik,addpemilik,hppemilik,typeid,jenisid,modelid,tahunpembuatan,silinder,warna,bahanbakar,
				warnatnkb,tahunreg,nobpkb,kdlokasi,expstnkb,exppkbstnkb,nopkb,nominalpkb,noskum,nokohir,old_nopol,old_kdgroup,old_nmkendaraan,old_nmpemilik,old_addpemilik,old_hppemilik,
				old_typeid,old_jenisid,old_modelid,old_tahunpembuatan,old_silinder,old_warna,old_bahanbakar,old_warnatnkb,old_tahunreg,old_nobpkb,old_kdlokasi,old_expstnkb,old_exppkbstnkb,old_nopkb,old_nominalpkb,old_noskum,old_nokohir,
				keterangan,status,inputdate,inputby,updatedate,updateby,jenispengurusan,nodoktmp)
				(select new.UPDATEBY,tgldok,dokref,kdrangka,kdmesin,nopol,kdgroup,nmkendaraan,nmpemilik,addpemilik,hppemilik,typeid,jenisid,modelid,tahunpembuatan,silinder,warna,bahanbakar,
				warnatnkb,tahunreg,nobpkb,kdlokasi,expstnkb,exppkbstnkb,nopkb,nominalpkb,noskum,nokohir,old_nopol,old_kdgroup,old_nmkendaraan,old_nmpemilik,old_addpemilik,old_hppemilik,
				old_typeid,old_jenisid,old_modelid,old_tahunpembuatan,old_silinder,old_warna,old_bahanbakar,old_warnatnkb,old_tahunreg,old_nobpkb,old_kdlokasi,old_expstnkb,old_exppkbstnkb,old_nopkb,old_nominalpkb,old_noskum,old_nokohir,
				keterangan,'E',inputdate,inputby,updatedate,updateby,jenispengurusan,new.nodok from sc_his.stnkb where nodok=new.nodok and kdrangka=new.kdrangka and kdmesin=new.kdmesin);
		ELSEIF (new.status='A1' and old.status='A') THEN
			insert into sc_tmp.stnkb
				(nodok,tgldok,dokref,kdrangka,kdmesin,nopol,kdgroup,nmkendaraan,nmpemilik,addpemilik,hppemilik,typeid,jenisid,modelid,tahunpembuatan,silinder,warna,bahanbakar,
				warnatnkb,tahunreg,nobpkb,kdlokasi,expstnkb,exppkbstnkb,nopkb,nominalpkb,noskum,nokohir,old_nopol,old_kdgroup,old_nmkendaraan,old_nmpemilik,old_addpemilik,old_hppemilik,
				old_typeid,old_jenisid,old_modelid,old_tahunpembuatan,old_silinder,old_warna,old_bahanbakar,old_warnatnkb,old_tahunreg,old_nobpkb,old_kdlokasi,old_expstnkb,old_exppkbstnkb,old_nopkb,old_nominalpkb,old_noskum,old_nokohir,
				keterangan,status,inputdate,inputby,updatedate,updateby,jenispengurusan,nodoktmp)
				(select new.UPDATEBY,tgldok,dokref,kdrangka,kdmesin,nopol,kdgroup,nmkendaraan,nmpemilik,addpemilik,hppemilik,typeid,jenisid,modelid,tahunpembuatan,silinder,warna,bahanbakar,
				warnatnkb,tahunreg,nobpkb,kdlokasi,expstnkb,exppkbstnkb,nopkb,nominalpkb,noskum,nokohir,old_nopol,old_kdgroup,old_nmkendaraan,old_nmpemilik,old_addpemilik,old_hppemilik,
				old_typeid,old_jenisid,old_modelid,old_tahunpembuatan,old_silinder,old_warna,old_bahanbakar,old_warnatnkb,old_tahunreg,old_nobpkb,old_kdlokasi,old_expstnkb,old_exppkbstnkb,old_nopkb,old_nominalpkb,old_noskum,old_nokohir,
				keterangan,'A',inputdate,inputby,updatedate,updateby,jenispengurusan,new.nodok from sc_his.stnkb where nodok=new.nodok and kdrangka=new.kdrangka and kdmesin=new.kdmesin);
		ELSEIF (new.status='C' and old.status='A') THEN
			insert into sc_tmp.stnkb
				(nodok,tgldok,dokref,kdrangka,kdmesin,nopol,kdgroup,nmkendaraan,nmpemilik,addpemilik,hppemilik,typeid,jenisid,modelid,tahunpembuatan,silinder,warna,bahanbakar,
				warnatnkb,tahunreg,nobpkb,kdlokasi,expstnkb,exppkbstnkb,nopkb,nominalpkb,noskum,nokohir,old_nopol,old_kdgroup,old_nmkendaraan,old_nmpemilik,old_addpemilik,old_hppemilik,
				old_typeid,old_jenisid,old_modelid,old_tahunpembuatan,old_silinder,old_warna,old_bahanbakar,old_warnatnkb,old_tahunreg,old_nobpkb,old_kdlokasi,old_expstnkb,old_exppkbstnkb,old_nopkb,old_nominalpkb,old_noskum,old_nokohir,
				keterangan,status,inputdate,inputby,updatedate,updateby,jenispengurusan,nodoktmp)
				(select new.UPDATEBY,tgldok,dokref,kdrangka,kdmesin,nopol,kdgroup,nmkendaraan,nmpemilik,addpemilik,hppemilik,typeid,jenisid,modelid,tahunpembuatan,silinder,warna,bahanbakar,
				warnatnkb,tahunreg,nobpkb,kdlokasi,expstnkb,exppkbstnkb,nopkb,nominalpkb,noskum,nokohir,old_nopol,old_kdgroup,old_nmkendaraan,old_nmpemilik,old_addpemilik,old_hppemilik,
				old_typeid,old_jenisid,old_modelid,old_tahunpembuatan,old_silinder,old_warna,old_bahanbakar,old_warnatnkb,old_tahunreg,old_nobpkb,old_kdlokasi,old_expstnkb,old_exppkbstnkb,old_nopkb,old_nominalpkb,old_noskum,old_nokohir,
				keterangan,'C',inputdate,inputby,updatedate,updateby,jenispengurusan,new.nodok from sc_his.stnkb where nodok=new.nodok and kdrangka=new.kdrangka and kdmesin=new.kdmesin);						
		END IF;
	RETURN NEW;
	END IF;

    
    return new;
        
end;
$$;

alter function tr_stnkb() owner to postgres;

