create function pr_upah_borong_mst_after() returns trigger
    language plpgsql
as
$$
declare
     
     vr_nomor char(30);
     vr_status char(10);
     
begin

--select old.status;

vr_status:=trim(coalesce(status,'')) from sc_tmp.upah_borong_mst where nik=new.nik and nodok=new.nodok for update;
if (new.status='F')or(old.status='I') then 

	delete from sc_mst.penomoran where userid=new.nodok; 
	delete from sc_mst.trxerror where userid=new.nik; 
	insert into sc_mst.penomoran 
        (userid,dokumen,nomor,errorid,partid,counterid,xno)
        values(new.nodok,'UPAH-BORONG',' ',0,' ',1,0);

	vr_nomor:=trim(coalesce(nomor,'')) from sc_mst.penomoran where userid=new.nodok;
	if (trim(vr_nomor)!='') or (not vr_nomor is null) then
		INSERT INTO sc_trx.upah_borong_mst(
			nodok,nik,kddept,kdsubdept,kdlvljabatan,kdjabatan,tgl_dok,tgl_kerja,periode,
			total_upah,keterangan,input_by,update_by,nmatasan,
			input_date,update_date,status,approval_date,approval_by,delete_by,delete_date,cancel_by,cancel_date
		    )
		SELECT vr_nomor,nik,kddept,kdsubdept,kdlvljabatan,kdjabatan,tgl_dok,tgl_kerja,periode,
			total_upah,keterangan,input_by,update_by,nmatasan,
			input_date,update_date,'P' as status,approval_date,approval_by,delete_by,delete_date,cancel_by,cancel_date

		from sc_tmp.upah_borong_mst where nodok=new.nodok and nik=new.nik;

		
	       INSERT INTO sc_trx.upah_borong_dtl(
			nodok,nik,no_urut,kdborong,kdsub_borong,metrix,satuan,tarif_satuan,upah_borong,total_target,pencapaian,catatan

	       )
	       SELECT vr_nomor,nik,no_urut,kdborong,kdsub_borong,metrix,satuan,tarif_satuan,upah_borong,total_target,pencapaian,catatan
	       from sc_tmp.upah_borong_dtl where nodok=new.nodok and nik=new.nik;
	       
		delete from sc_tmp.upah_borong_mst where nodok=new.nodok and nik=new.nik;
		delete from sc_tmp.upah_borong_dtl where nodok=new.nodok and nik=new.nik;
		
		insert into sc_mst.trxerror
			(userid,errorcode,nomorakhir1,nomorakhir2)
			values(new.nodok,'0',vr_nomor,vr_nomor);
		delete from sc_mst.trxerror where userid=new.nodok and errorcode='0';	
	else 
		insert into sc_mst.trxerror
				(userid,errorcode,nomorakhir1,nomorakhir2)
				values(new.nodok,'1','','');
	end if;

end if;
return new;

end;
$$;

alter function pr_upah_borong_mst_after() owner to postgres;

