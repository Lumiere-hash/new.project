create view masterkaryawan
            (nik, nmlengkap, bag_dept, subbag_dept, jabatan, lvl_jabatan, nik_atasan, nik_atasan2, nmdept, nmsubdept,
             nmlvljabatan, nmjabatan, nmatasan, nmatasan2)
as
SELECT a.nik,
       a.nmlengkap,
       a.bag_dept,
       a.subbag_dept,
       a.jabatan,
       a.lvl_jabatan,
       a.nik_atasan,
       a.nik_atasan2,
       b.nmdept,
       c.nmsubdept,
       d.nmlvljabatan,
       e.nmjabatan,
       f.nmlengkap AS nmatasan,
       g.nmlengkap AS nmatasan2
FROM sc_mst.karyawan a
         LEFT JOIN sc_mst.departmen b ON a.bag_dept = b.kddept
         LEFT JOIN sc_mst.subdepartmen c ON a.subbag_dept = c.kdsubdept AND c.kddept = a.bag_dept
         LEFT JOIN sc_mst.lvljabatan d ON a.lvl_jabatan = d.kdlvl
         LEFT JOIN sc_mst.jabatan e ON a.jabatan = e.kdjabatan AND e.kdsubdept = a.subbag_dept AND e.kddept = a.bag_dept
         LEFT JOIN sc_mst.karyawan f ON a.nik_atasan = f.nik
         LEFT JOIN sc_mst.karyawan g ON a.nik_atasan2 = g.nik
WHERE a.statuskepegawaian <> 'KO'::bpchar;

alter table masterkaryawan
    owner to postgres;

