create function tr_legal_detail() returns trigger
    language plpgsql
as
$$
DECLARE 
	--author by fiky: 12/08/2017
	--update by fiky: 12/08/2017
     vr_nomor char(20); 
     vr_maxinputdate  timestamp;
BEGIN		
	IF tg_op = 'INSERT' THEN

		--select * from sc_his.legal_detail;
		update  sc_his.legal_detail a set sort=a1.urutnya,status='A'
		from (select a1.*,row_number() over(partition by docno order by inputdate asc) as urutnya
		from sc_his.legal_detail a1) a1
		where a.sort=a1.sort and a.inputdate=a1.inputdate and  a.docref=a1.docref and a.docno=new.docno and a.docref=new.docref;

		update sc_his.legal_master a set 
			docname=b.operationcategory,
				progress=b.progress,
				description=b.description
		from sc_his.legal_detail b where a.docno=b.docno and a.docno=new.docno and b.inputby=new.inputby and b.inputdate=new.inputdate;

		update sc_his.legal_detail set status='N' where docno=new.docno and inputby = new.inputby and inputdate != new.inputdate;

		RETURN new;
	ELSEIF tg_op = 'UPDATE' THEN

		IF (new.status='F' and old.status='I') THEN
			update sc_his.legal_master a set 
				docname=b.operationcategory,
				progress=b.progress,
				description=b.description
			from sc_his.legal_detail b where a.docno=b.docno and a.docno=new.docno and b.sort=new.sort;
		END IF;
		
		RETURN NEW;
	ELSEIF tg_op = 'DELETE' THEN
	
		update  sc_his.legal_detail a set sort=a1.urutnya
		from (select a1.*,row_number() over(partition by docno order by inputdate asc) as urutnya
		from sc_his.legal_detail a1) a1
		where a.sort=a1.sort and a.inputdate=a1.inputdate and  a.docref=a1.docref and a.docno=old.docno and a.docref=old.docref;

		select max(inputdate) from sc_his.legal_detail into vr_maxinputdate where docno=old.docno;
		
		update sc_his.legal_master a set 
			docname=b.operationcategory,
			progress=b.progress,
			description=b.description
		from sc_his.legal_detail b where a.docno=b.docno and a.docno=old.docno and b.inputdate=vr_maxinputdate;

		update  sc_his.legal_detail set status='A' where  docno=old.docno and inputdate=vr_maxinputdate;
		
		RETURN old;	
	END IF;
	
END;
$$;

alter function tr_legal_detail() owner to postgres;

