create function tr_tmp_itemtrans_dtl() returns trigger
    language plpgsql
as
$$
DECLARE 
	--author by fiky: 12/10/2017
	--update by fiky: 12/11/2017
     vr_nomor char(12); 
     vr_cekprefix char(4);
     vr_nowprefix char(4);  
	vr_id_dtl numeric;
	vr_qtybbm numeric;
	vr_qtybbm_v numeric;
	vr_qtybbmkecil numeric;
     vr_kdgroup char(100);
     vr_kdsubgroup char(100);
     vr_stockcode char(100);
     vr_nodok char(100);
     vr_nodokref char(100);
     vr_fromcode char(100);
     vr_statusmst char(12);
BEGIN		
	IF tg_op = 'INSERT' THEN
		/*branch,nodok,kdgroup,kdsubgroup,stockcode,id,nodokref,loccode,loccode_destination,itemtrans_type,itemtrans_category,qty,qtybbm,satkecil,
		description,qtyonhand,inputby,inputdate,qtyunitprice,qtytotalprice,nodoktmp,status*/

		update  sc_tmp.itemtrans_dtl a set id=a1.urutnya
		from (select a1.*,row_number() over(partition by nodok order by stockcode,inputdate asc) as urutnya
		from sc_tmp.itemtrans_dtl a1) a1
		where a.nodok=a1.nodok and a.kdgroup=a1.kdgroup and a.kdsubgroup=a1.kdsubgroup and a.stockcode=a1.stockcode
		and a.nodok=new.nodok ;

		
		update sc_mst.stkgdw set onhand=onhand-new.qty where
		loccode=new.loccode and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and new.status in ('I');
		
		RETURN new;
	ELSEIF tg_op = 'UPDATE' THEN
		--vr_statusmst:=coalesce(status,'') from sc_tmp.itemtrans_mst where nodok=new.nodok;
		if(new.status='F' and old.status IN ('A')) then
			/*STATUS DARI A KE F MENGUBAH STOCK ONHAND DI WILAYAH */
			/*STATUS DARI ALL KE '' TIDAK MENGUBAH STOCK ONHAND*/	
		update sc_mst.stkgdw a set onhand=(coalesce(a.onhand,0)+coalesce(b.qty_tmp,0))-coalesce(b.qty,0)
		from sc_tmp.itemtrans_dtl b where
		a.loccode=b.loccode and a.kdgroup=b.kdgroup and a.kdsubgroup=b.kdsubgroup and a.stockcode=b.stockcode	
		and a.loccode=new.loccode and a.kdgroup=new.kdgroup and a.kdsubgroup=new.kdsubgroup and a.stockcode=new.stockcode;
		elseif(new.status='F' and old.status IN ('C')) then
			/*STATUS DARI A KE F MENGUBAH STOCK ONHAND DI WILAYAH */
			/*STATUS DARI ALL KE '' TIDAK MENGUBAH STOCK ONHAND*/	
		update sc_mst.stkgdw a set onhand=coalesce(a.onhand,0)+coalesce(b.qty,0)
		from sc_tmp.itemtrans_dtl b where
		a.loccode=b.loccode and a.kdgroup=b.kdgroup and a.kdsubgroup=b.kdsubgroup and a.stockcode=b.stockcode	
		and a.loccode=new.loccode and a.kdgroup=new.kdgroup and a.kdsubgroup=new.kdsubgroup and a.stockcode=new.stockcode;
		end if;
		--RAISE NOTICE 'NOTICE (%)', 'HALO';

		RETURN NEW;
	ELSEIF tg_op = 'DELETE' THEN
		update  sc_tmp.itemtrans_dtl a set id=a1.urutnya
		from (select a1.*,row_number() over(partition by nodok order by stockcode,inputdate asc) as urutnya
		from sc_tmp.itemtrans_dtl a1) a1
		where a.nodok=a1.nodok and a.kdgroup=a1.kdgroup and a.kdsubgroup=a1.kdsubgroup and a.stockcode=a1.stockcode
		and a.nodok=old.nodok ;

		update sc_mst.stkgdw set onhand=onhand+old.qty where
		loccode=old.loccode and kdgroup=old.kdgroup and kdsubgroup=old.kdsubgroup and stockcode=old.stockcode and old.status in ('I');
		
		RETURN old;	
	END IF;
	
END;
$$;

alter function tr_tmp_itemtrans_dtl() owner to postgres;

