create function pr_notifhrms() returns SETOF void
    language plpgsql
as
$$
--create by Fiky Ashariza
--19-04-2017
--12-06-2020 PENAMBAHAN LEMBUR
--FUNGSI PROSEDUR UNTUK MELAKUKAN NOTIF MENGENAI HRMS 
DECLARE vr_loopnik_atasan char(12);
DECLARE vr_loopnik char(12);
DECLARE vr_nik_cuti char(12);
DECLARE vr_dok_cuti char(12);
DECLARE vr_expirecuti numeric;
DECLARE vr_temp_min numeric;
DECLARE vr_temp_max numeric;
DECLARE vr_temp_count numeric;
DECLARE vr_temp_count2 numeric;
--ijin
DECLARE vr_dok_ijin char(12);
DECLARE vr_expireijin numeric;	
--dinas
DECLARE vr_dok_dinas char(12);
DECLARE vr_dok_lembur char(12);
DECLARE vr_expiredinas numeric;
--date now
DECLARE vr_day character(15);
DECLARE vr_dayyear character(15);
DECLARE vr_datenow date;
DECLARE vr_datesms1monthcuti date;
DECLARE vr_textsms1monthcuti text;


BEGIN

/* OPTION PENGHANGUSAN SKALA MENIT STANDART 180 MENIT/3JAM*/
vr_expirecuti:=coalesce(value3,0) from sc_mst.option where kdoption='NFCT01' and group_option='CUTI';
vr_expireijin:=coalesce(value3,0) from sc_mst.option where kdoption='NFIK01' and group_option='IJIN';
vr_expiredinas:=coalesce(value3,0) from sc_mst.option where kdoption='NFDL01' and group_option='DINAS';
vr_datesms1monthcuti:=to_char(update_date,'yyyy-mm-dd')::date from sc_mst.option where kdoption='NFCT02' and group_option='CUTI';
vr_textsms1monthcuti:=trim(to_char(update_date,'yyyymm')) from sc_mst.option where kdoption='NFCT02' and group_option='CUTI';


/*
--select * from sc_mst.option
--insert into sc_mst.option 
(kdoption,nmoption,value1,value2,value3,status,keterangan,input_by,update_by,input_date,update_date,group_option)
values
('NFCT02','NOTIF BULANAN KIRIM SMS CUTI',NULL,NULL,NULL,'T','NOTIF SEND CUTI BULANAN',NULL,NULL,NULL,NULL,'CUTI');
*/

/* PROSEDUR NOTIF DAN PENGHANGUSAN CUTI JIKA SUDAH BERAKHIR */
FOR vr_dok_cuti in select coalesce(trim(nodok),'') from sc_trx.cuti_karyawan where status='A' and to_char(input_date   + interval '1 minute' * vr_expirecuti,'yyyy-mm-dd hh24:mi:ss')<to_char(now(),'yyyy-mm-dd hh24:mi:ss') 
and to_char(input_date,'yyyy-mm-dd hh24:mi:ss') >= to_char(now() - interval '1 days' * 7,'yyyy-mm-dd hh24:mi:ss')

	LOOP	
		/*---SELF SMS----*/
		
		/*
		insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
		select b.nohp1,			
		'Sdr/i '||b.nmlengkap||' Cuti dengan no. '||a.nodok||' Di Batalkan'||', Batas persetujuan 180 menit untuk atasan telah berakhir,Silahkan input ulang untuk pengajuan cuti'
		,nmlengkap
		from sc_trx.cuti_karyawan a
		left outer join sc_mst.karyawan b on a.nik=b.nik
		where a.nodok=vr_dok_cuti;
		*/
		
		update sc_trx.cuti_karyawan set status='C',cancel_by='SYSTEM3H',cancel_date=to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp where nodok=vr_dok_cuti ;
		--select * from sc_trx.cuti_karyawan 
	RETURN NEXT vr_dok_cuti;
END LOOP;



/* PROSEDUR NOTIF DAN PENGHANGUSAN IJIN JIKA SUDAH BERAKHIR */
--select * from sc_trx.ijin_karyawan where status='A'

FOR vr_dok_ijin in select coalesce(trim(nodok),'') from sc_trx.ijin_karyawan where status='A' and to_char(input_date   + interval '1 minute' * vr_expireijin,'yyyy-mm-dd hh24:mi:ss')<to_char(now(),'yyyy-mm-dd hh24:mi:ss') 
and to_char(input_date,'yyyy-mm-dd hh24:mi:ss') >= to_char(now() - interval '1 days' * 7,'yyyy-mm-dd hh24:mi:ss')


	LOOP	
		/*---SELF SMS----
		insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
		select b.nohp1,			
		'Sdr/i '||b.nmlengkap||' Ijin dengan no. '||a.nodok||' Di Batalkan'||', Batas persetujuan 180 menit untuk atasan telah berakhir,Silahkan input ulang untuk pengajuan ijin'
		,nmlengkap
		from sc_trx.ijin_karyawan a
		left outer join sc_mst.karyawan b on a.nik=b.nik
		where a.nodok=vr_dok_ijin;
*/
		update sc_trx.ijin_karyawan set status='C',cancel_by='SYSTEM3H',cancel_date=to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp where nodok=vr_dok_ijin;
		
	RETURN NEXT vr_dok_ijin;
END LOOP;


/* PROSEDUR NOTIF DAN PENGHANGUSAN DINAS JIKA SUDAH TEMPO BERAKHIR */
--select * from sc_trx.dinas

FOR vr_dok_dinas in select coalesce(trim(nodok),'') from sc_trx.dinas where status='A' and to_char(input_date   + interval '1 minute' * vr_expiredinas,'yyyy-mm-dd hh24:mi:ss')<to_char(now(),'yyyy-mm-dd hh24:mi:ss') 
and to_char(input_date,'yyyy-mm-dd hh24:mi:ss') >= to_char(now() - interval '1 days' * 7,'yyyy-mm-dd hh24:mi:ss')

	LOOP	
		/*---SELF SMS----
		insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
		select b.nohp1,			
		'Sdr/i '||b.nmlengkap||' DINAS dengan no. '||a.nodok||' Di Batalkan'||', Batas persetujuan 180 menit untuk atasan telah berakhir,Silahkan input ulang untuk pengajuan dinas'
		,nmlengkap
		from sc_trx.dinas a
		left outer join sc_mst.karyawan b on a.nik=b.nik
		where a.nodok=vr_dok_dinas;
*/
		update sc_trx.dinas set status='C',cancel_by='SYSTEM3H',cancel_date=to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp where nodok=vr_dok_dinas;
	RETURN NEXT vr_dok_dinas;
END LOOP;

/* PROSEDUR NOTIF DAN PENGHANGUSAN LEMBUR JIKA SUDAH TEMPO BERAKHIR */
--select * from sc_trx.lembur

FOR vr_dok_lembur in select coalesce(trim(nodok),'') from sc_trx.lembur where status='A' and to_char(input_date   + interval '1 minute' * vr_expiredinas,'yyyy-mm-dd hh24:mi:ss')<to_char(now(),'yyyy-mm-dd hh24:mi:ss') 
and to_char(input_date,'yyyy-mm-dd hh24:mi:ss') >= to_char(now() - interval '1 days' * 7,'yyyy-mm-dd hh24:mi:ss')

	LOOP	
		
		update sc_trx.lembur set status='C',cancel_by='SYSTEM3H',cancel_date=to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp where nodok=vr_dok_lembur;
	RETURN NEXT vr_dok_lembur;
END LOOP;


/* PROSEDUR NOTIF SMS KE MASING - MASING ATASAN SISA CUTI KARYAWAN 

vr_day:=to_char(now(),'dd');
vr_dayyear:=to_char(now(),'yyyymm');
			
IF (vr_day='01' and vr_textsms1monthcuti<>vr_dayyear) then
		FOR vr_loopnik_atasan IN select trim(nik_atasan) from sc_mst.karyawan where statuskepegawaian<>'KO' and tglkeluarkerja is null
		--and nik_atasan='0112.002'
		group by nik_atasan
		LOOP
		---select array_to_string(array(select '*'||nmlengkap||' Sisa Cuti: '||coalesce(sisacuti,0)||' *' from sc_mst.karyawan where nik_atasan='0112.017' and statuskepegawaian<>'KO' and tglkeluarkerja is null and coalesce(nohp1,'')<>''), chr(10));
			vr_temp_min:=0;
			vr_temp_max:=3;
			vr_temp_count2:=0;
			vr_temp_count:=ceil(count(nomor)/3::numeric(18,2)) from 
				(select ''||nmlengkap||'
				Sisa Cuti: '||coalesce(sisacuti,0)||'
				',row_number() over() as nomor from sc_mst.karyawan where nik_atasan=vr_loopnik_atasan and statuskepegawaian<>'KO' and tglkeluarkerja is null and coalesce(nohp1,'')<>'' 
				order by nomor asc) as x;

			LOOP
			
			
insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
---select replace(trim(nohp1),'08','+62') as nohp1, 
select replace(trim(nohp1),'08','+628') as nohp1, 
'SISA CUTI PER TGL '||to_char(now(),'dd/mm/yyyy')||'
'||(select array_to_string(array(
select isi from 
(select ''||nmlengkap||'
Sisa Cuti: '||coalesce(sisacuti,0)||'
' as isi,row_number() over() as nomor from sc_mst.karyawan where (nik_atasan=vr_loopnik_atasan or nik=vr_loopnik_atasan) and statuskepegawaian<>'KO' and tglkeluarkerja is null and coalesce(nohp1,'')<>'' 
order by nomor asc) as x
where nomor>vr_temp_min and nomor<=vr_temp_max
), chr(10))),'OSIN'
from sc_mst.karyawan where nik=vr_loopnik_atasan;
			

			vr_temp_count2=vr_temp_count2+1;
			vr_temp_min:=vr_temp_min+3;
			vr_temp_max:=vr_temp_max+3;

			EXIT WHEN vr_temp_count2 >= vr_temp_count;

			--RAISE NOTICE 'Campur(%)', vr_temp_count2;
			--RAISE NOTICE 'Campur2(%)', vr_temp_count;

			END LOOP;

		RETURN NEXT vr_loopnik_atasan;
		END LOOP;

			FOR vr_loopnik IN select trim(nik) from sc_mst.karyawan where statuskepegawaian<>'KO' and tglkeluarkerja is null 
			and nik not in (select trim(nik_atasan) from sc_mst.karyawan where statuskepegawaian<>'KO' and tglkeluarkerja is null group by nik_atasan)
			group by nik
			LOOP
			
insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
select replace(trim(nohp1),'08','+628') as nohp1, 
'SISA CUTI PER TGL '||to_char(now(),'dd/mm/yyyy')||'
'||(select array_to_string(array(
select isi from 
(select ''||nmlengkap||'
Sisa Cuti: '||coalesce(sisacuti,0)||'
' as isi,row_number() over() as nomor from sc_mst.karyawan where nik=vr_loopnik and statuskepegawaian<>'KO' and tglkeluarkerja is null and coalesce(nohp1,'')<>'' 
order by nomor asc) as x
), chr(10))),'OSIN'
from sc_mst.karyawan where nik=vr_loopnik;

			RETURN NEXT vr_loopnik;
			END LOOP;
		

update sc_mst.option set update_by='OSIN',update_date=to_char(now(),'yyyy-mm-dd hh24:mi:ss')::timestamp where kdoption='NFCT02' and group_option='CUTI';
end if;
*/

PERFORM sc_tmp.pr_reminder_hrd(); /*----- REMINDER STATUS KEPEGAWAIAN ------*/
	RETURN;
	

	
END;
$$;

alter function pr_notifhrms() owner to postgres;

