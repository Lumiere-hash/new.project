create function tr_hps_sms() returns trigger
    language plpgsql
as
$$ 
BEGIN  

	update sc_log.trash_sms set no_pengirim=t1."SenderNumber", isi_sms=t1."TextDecoded", tanggal_masuk=t1."ReceivingDateTime" from
	(select "SenderNumber", "TextDecoded", "ReceivingDateTime" from inbox where "ID"=NEW.id) as t1			
	where id=NEW.id;

	delete from inbox where "ID" = NEW.id; 
	
	RETURN NEW;  

END; 

    $$;

alter function tr_hps_sms() owner to postgres;

