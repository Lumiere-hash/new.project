create function pr_listdtljadwalkerja(vr_bulan character, vr_tahun character) returns SETOF void
    language plpgsql
as
$$
DECLARE vr_maxtgl date;
DECLARE vr_nik character(12);
DECLARE vr_cekdouble integer;
DECLARE vr_kdregu character(12);
BEGIN

--select * from sc_trx.dtljadwalkerja where to_char(tgl,'mm')='06' and nik=vr_nik order by tgl
--select * from sc_trx.listjadwalkerja
	delete from sc_trx.listjadwalkerja where bulan=vr_bulan and tahun=vr_tahun; 
 FOR vr_nik in select nik from sc_mst.karyawan where tglkeluarkerja is null
		LOOP

			vr_maxtgl:=max(tgl) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'mm')=vr_bulan and to_char(tgl,'yyyy')=vr_tahun;
			vr_kdregu:=max(trim(kdregu)) from sc_trx.dtljadwalkerja where nik=vr_nik;
			vr_cekdouble=count(*) from sc_trx.listjadwalkerja where nik=vr_nik and bulan=vr_bulan and tahun=vr_tahun;

			IF vr_cekdouble=0 THEN
			
				insert into sc_trx.listjadwalkerja 
				select trim(nik),trim(kdregu),trim(to_char(tgl,'mm'))as bulan,trim(to_char(tgl,'yyyy'))as tahun,
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-01'),'OFF')as tgl1, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-02'),'OFF')as tgl2, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-03'),'OFF')as tgl3, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-04'),'OFF')as tgl4, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-05'),'OFF')as tgl5, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-06'),'OFF')as tgl6, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-07'),'OFF')as tgl7, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-08'),'OFF')as tgl8, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-09'),'OFF')as tgl9, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-10'),'OFF')as tgl10, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-11'),'OFF')as tgl11, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-12'),'OFF')as tgl12, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-13'),'OFF')as tgl13, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-14'),'OFF')as tgl14, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-15'),'OFF')as tgl15, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-16'),'OFF')as tgl16, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-17'),'OFF')as tgl17, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-18'),'OFF')as tgl18, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-19'),'OFF')as tgl19, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-20'),'OFF')as tgl20, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-21'),'OFF')as tgl21, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-22'),'OFF')as tgl22, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-23'),'OFF')as tgl23, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-24'),'OFF')as tgl24, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-25'),'OFF')as tgl25, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-26'),'OFF')as tgl26, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-27'),'OFF')as tgl27, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-28'),'OFF')as tgl28, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-29'),'OFF')as tgl29, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-30'),'OFF')as tgl30, 
				coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-31'),'OFF')as tgl31 
				from sc_trx.dtljadwalkerja where nik=vr_nik and tgl=vr_maxtgl;

			ELSE	
				update sc_trx.listjadwalkerja set
				  kdregu=vr_kdregu,
				  tgl1=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-01'),'OFF'),
				  tgl2=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-02'),'OFF'),
				  tgl3=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-03'),'OFF'),
				  tgl4=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-04'),'OFF'),
				  tgl5=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-05'),'OFF'),
				  tgl6=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-06'),'OFF'),
				  tgl7=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-07'),'OFF'),
				  tgl8=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-08'),'OFF'),
				  tgl9=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-09'),'OFF'), 
				  tgl10=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-10'),'OFF'),
				  tgl11=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-11'),'OFF'),
				  tgl12=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-12'),'OFF'),
				  tgl13=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-13'),'OFF'),
				  tgl14=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-14'),'OFF'),
				  tgl15=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-15'),'OFF'),
				  tgl16=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-16'),'OFF'), 
				  tgl17=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-17'),'OFF'), 
				  tgl18=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-18'),'OFF'),
				  tgl19=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-19'),'OFF'),
				  tgl20=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-20'),'OFF'), 
				  tgl21=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-21'),'OFF'),
				  tgl22=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-22'),'OFF'),
				  tgl23=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-23'),'OFF'), 
				  tgl24=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-24'),'OFF'),
				  tgl25=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-25'),'OFF'), 
				  tgl26=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-26'),'OFF'), 
				  tgl27=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-27'),'OFF'), 
				  tgl28=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-28'),'OFF'),
				  tgl29=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-29'),'OFF'), 
				  tgl30=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-30'),'OFF'), 
				  tgl31=coalesce((select trim(kdjamkerja) from sc_trx.dtljadwalkerja where nik=vr_nik and to_char(tgl,'yyyy-mm-dd')=vr_tahun||'-'||vr_bulan||'-31'),'OFF') 
				  where nik=vr_nik and bulan=vr_bulan and tahun=vr_tahun;
			END IF;
	RETURN NEXT vr_nik;	
END LOOP;		
	RETURN;
	
END;
$$;

alter function pr_listdtljadwalkerja(char, char) owner to postgres;

