create function tr_tmp_stpbk_dtl() returns trigger
    language plpgsql
as
$$
DECLARE 
	--author by fiky: 12/08/2017
	--update by fiky: 12/08/2017
     vr_nomor char(12); 
     vr_cekprefix char(4);
     vr_nowprefix char(4);  
BEGIN		
	IF tg_op = 'INSERT' THEN
		--select * from sc_tmp.stpbk_mst where nodok is null
		/*IF NOT EXISTS(select * from sc_tmp.stpbk_mst where nodok=new.nodok and nik=new.nik) THEN
			insert into sc_tmp.stpbk_mst 
			(branch,nodok,nodokref,nik,loccode,status,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby)
			(select branch,nodok,nodokref,nik,loccode,status,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby
			from sc_tmp.stpbk_dtl where nodok=new.nodok and nik=new.nik);
		END IF; */

		update  sc_tmp.stpbk_dtl a set id=a1.urutnya
		from (select a1.*,row_number() over(partition by nodok order by inputdate asc) as urutnya
		from sc_tmp.stpbk_dtl a1) a1
		where a.inputdate=a1.inputdate and  a.branch=a1.branch and a.nodok=a1.nodok and a.nik=a1.nik ;
		
		RETURN new;
	ELSEIF tg_op = 'UPDATE' THEN
		--select * from sc_trx.stpbk_dtl
		--select * from sc_tmp.stpbk_dtl

		IF (OLD.STATUS='A' AND NEW.STATUS='P') THEN
			/*UPDATE sc_trx.stpbk_dtl SET STATUS='P' WHERE
			NODOK=NEW.NODOKTMP AND NIK=NEW.NIK AND KDGROUP=NEW.KDGROUP AND KDSUBGROUP=NEW.KDSUBGROUP AND STOCKCODE=NEW.STOCKCODE; */
		ELSEIF (OLD.STATUS='P' AND NEW.STATUS='A') THEN
			/*UPDATE sc_trx.stpbk_dtl SET STATUS='A' WHERE
			NODOK=NEW.NODOKTMP AND NIK=NEW.NIK AND KDGROUP=NEW.KDGROUP AND KDSUBGROUP=NEW.KDSUBGROUP AND STOCKCODE=NEW.STOCKCODE;*/
		END IF;

				/* TRIGER PEMBATALAN STATUS MASTER KETIKA DIREJECT SEMUA ITEM */
		IF EXISTS(SELECT * FROM SC_TRX.STPBK_MST WHERE STATUS='A' AND NODOK=NEW.NODOKTMP) THEN
			IF NOT EXISTS (SELECT * FROM SC_TMP.STPBK_DTL WHERE NODOK=NEW.NODOK AND (STATUS='A' OR STATUS='P' OR STATUS='I')) THEN
				UPDATE SC_TMP.STPBK_MST SET STATUS='C' WHERE NODOK=NEW.NODOK;
			ELSEIF EXISTS (SELECT * FROM SC_TMP.STPBK_DTL WHERE NODOK=NEW.NODOK AND STATUS='A') THEN
				UPDATE SC_TMP.STPBK_MST SET STATUS='A' WHERE NODOK=NEW.NODOK;
				
			END IF;
		END IF;
		
		RETURN NEW;
	ELSEIF tg_op = 'DELETE' THEN
		/*if not exists (select * from sc_tmp.stpbk_dtl where nodok=old.nodok) then
			delete from sc_tmp.stpbk_mst where nodok=old.nodok;
		end if; */

		update  sc_tmp.stpbk_dtl a set id=a1.urutnya
		from (select a1.*,row_number() over(partition by nodok order by inputdate asc) as urutnya
		from sc_tmp.stpbk_dtl a1) a1
		where a.id=a1.id and a.inputdate=a1.inputdate and  a.branch=a1.branch and a.nodok=a1.nodok and a.nik=a1.nik ;
		RETURN old;	
	END IF;
	
END;
$$;

alter function tr_tmp_stpbk_dtl() owner to postgres;

