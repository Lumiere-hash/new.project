create function tr_cashbon_after_update() returns trigger
    language plpgsql
as
$$
DECLARE
    number VARCHAR;
BEGIN
    IF ( NEW.status = 'U' and OLD.status <> 'U' ) THEN
        DELETE FROM sc_tmp.cashbon WHERE TRUE
        AND cashbonid = NEW.cashbonid;

        INSERT INTO sc_tmp.cashbon (
            branch,
            cashbonid,
            dutieid,
            superior,
            status,
            paymenttype,
            totalcashbon,
            inputby,
            inputdate,
            updateby,
            updatedate,
            approveby,
            approvedate
        ) SELECT
            branch,
            cashbonid,
            dutieid,
            superior,
            OLD.status AS status,
            paymenttype,
            totalcashbon,
            inputby,
            inputdate,
            updateby,
            updatedate,
            approveby,
            approvedate
        FROM sc_trx.cashbon WHERE TRUE
        AND cashbonid = NEW.cashbonid;

        DELETE FROM sc_tmp.cashbon_component WHERE TRUE
        AND cashbonid = NEW.cashbonid;

        INSERT INTO sc_tmp.cashbon_component (
            branch,
            cashbonid,
            componentid,
            nominal,
            quantityday,
            totalcashbon,
            description,
            inputby,
            inputdate,
            updateby,
            updatedate
        ) SELECT
            branch,
            cashbonid,
            componentid,
            nominal,
            quantityday,
            totalcashbon,
            description,
            inputby,
            inputdate,
            updateby,
            updatedate
        FROM sc_trx.cashbon_component WHERE TRUE
        AND cashbonid = NEW.cashbonid;

        UPDATE sc_trx.cashbon SET
            status = OLD.status,
            updateby = OLD.updateby,
            updatedate = OLD.updatedate
        WHERE TRUE
        AND cashbonid = NEW.cashbonid;
    END IF;
    RETURN NEW;
END;
$$;

alter function tr_cashbon_after_update() owner to postgres;

