create function tr_trx_stbbm_mst() returns trigger
    language plpgsql
as
$$
DECLARE 
	--author by fiky: 12/08/2017
	--update by fiky: 12/08/2017
     vr_nomor char(12); 
     vr_cekprefix char(4);
     vr_nowprefix char(4);  
BEGIN		
	IF tg_op = 'INSERT' THEN

		RETURN new;
	ELSEIF tg_op = 'UPDATE' THEN

		
		IF (new.status='P' and old.status='A') THEN
			--update sc_trx.stbbk_dtl set status='P' where nodok=new.nodok;
		ELSEIF (new.status='E'  and old.status='A') THEN
			if not exists(select * from sc_tmp.stbbm_mst where  nodokref in (select trim(nodokref) from sc_tmp.stbbm_mst where nodokref=new.nodokref)) then
				insert into sc_tmp.stbbm_mst
				(branch,nodok,nodokref,loccode,nodokopr,nodokdate,nodoktype,disc1,disc2,disc3,disc4,exppn,ttlbrutto,ttldiskon,ttldpp,ttlppn,ttlnetto,pkp,keterangan,inputdate,
				inputby,updatedate,updateby,approvaldate,approvalby,nodoktmp,status,nodokfrom)
				(select branch,new.updateby,nodokref,loccode,nodokopr,nodokdate,nodoktype,disc1,disc2,disc3,disc4,exppn,ttlbrutto,ttldiskon,ttldpp,ttlppn,ttlnetto,pkp,keterangan,inputdate,
				inputby,updatedate,updateby,approvaldate,approvalby,nodok,'E' as status,nodokfrom from sc_trx.stbbm_mst where nodok=new.nodok);


				insert into sc_tmp.stbbm_dtl
				(branch,nodok,nodokref,loccode,kdgroup,kdsubgroup,stockcode,id,desc_barang,qtyrec,qtyreckecil,qtybbm,qtybbmkecil,qtyonhand,satminta,satkecil,disc1,disc2,disc3,disc4,
				exppn,nbrutto,ndiskon,ndpp,nppn,nnetto,pkp,unitprice,pricelist,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodoktmp,qtybbm_tmp,qtybbmkecil_tmp,status)
				(select branch,new.updateby,nodokref,loccode,kdgroup,kdsubgroup,stockcode,id,desc_barang,qtyrec,qtyreckecil,qtybbm,qtybbmkecil,qtyonhand,satminta,satkecil,disc1,disc2,disc3,disc4,
				exppn,nbrutto,ndiskon,ndpp,nppn,nnetto,pkp,unitprice,pricelist,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodok,qtybbm,qtybbmkecil,'E' as status from sc_trx.stbbm_dtl where nodok=new.nodok);

				insert into sc_tmp.stbbm_dtlref
				(branch,nodok,nodokref,fromcode,loccode,kdgroup,kdsubgroup,stockcode,id,desc_barang,qtyrec,qtyreckecil,qtybbm,qtybbmkecil,satminta,satkecil,keterangan,inputdate,
				inputby,updatedate,updateby,approvaldate,approvalby,nodoktmp,qtybbm_tmp,qtybbmkecil_tmp,status)
				(select branch,new.updateby,nodokref,fromcode,loccode,kdgroup,kdsubgroup,stockcode,id,desc_barang,qtyrec,qtyreckecil,qtybbm,qtybbmkecil,satminta,satkecil,keterangan,inputdate,
				inputby,updatedate,updateby,approvaldate,approvalby,nodok,qtybbm,qtybbmkecil,'E' as status from sc_trx.stbbm_dtlref where nodok=new.nodok);
			else

				
				delete from sc_mst.trxerror where userid=new.nodok and modul='STBBM';
				insert into sc_mst.trxerror
				(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
				(new.updateby,1,new.nodok,'','STBBM');
				
				update sc_trx.stbbm_mst set status='A' where nodok=new.nodok;
			end if;
		ELSEIF (new.status='C'  and old.status='A') THEN
			if not exists(select * from sc_tmp.stbbm_mst where  nodokref in (select trim(nodokref) from sc_tmp.stbbm_mst where nodokref=new.nodokref)) then
				insert into sc_tmp.stbbm_mst
				(branch,nodok,nodokref,loccode,nodokopr,nodokdate,nodoktype,disc1,disc2,disc3,disc4,exppn,ttlbrutto,ttldiskon,ttldpp,ttlppn,ttlnetto,pkp,keterangan,inputdate,
				inputby,updatedate,updateby,approvaldate,approvalby,nodoktmp,status,nodokfrom)
				(select branch,new.updateby,nodokref,loccode,nodokopr,nodokdate,nodoktype,disc1,disc2,disc3,disc4,exppn,ttlbrutto,ttldiskon,ttldpp,ttlppn,ttlnetto,pkp,keterangan,inputdate,
				inputby,updatedate,updateby,approvaldate,approvalby,nodok,'C' as status,nodokfrom from sc_trx.stbbm_mst where nodok=new.nodok);


				insert into sc_tmp.stbbm_dtl
				(branch,nodok,nodokref,loccode,kdgroup,kdsubgroup,stockcode,id,desc_barang,qtyrec,qtyreckecil,qtybbm,qtybbmkecil,qtyonhand,satminta,satkecil,disc1,disc2,disc3,disc4,
				exppn,nbrutto,ndiskon,ndpp,nppn,nnetto,pkp,unitprice,pricelist,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodoktmp,qtybbm_tmp,qtybbmkecil_tmp,status)
				(select branch,new.updateby,nodokref,loccode,kdgroup,kdsubgroup,stockcode,id,desc_barang,qtyrec,qtyreckecil,qtybbm,qtybbmkecil,qtyonhand,satminta,satkecil,disc1,disc2,disc3,disc4,
				exppn,nbrutto,ndiskon,ndpp,nppn,nnetto,pkp,unitprice,pricelist,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodok,qtybbm,qtybbmkecil,'C' as status from sc_trx.stbbm_dtl where nodok=new.nodok);

				insert into sc_tmp.stbbm_dtlref
				(branch,nodok,nodokref,fromcode,loccode,kdgroup,kdsubgroup,stockcode,id,desc_barang,qtyrec,qtyreckecil,qtybbm,qtybbmkecil,satminta,satkecil,keterangan,inputdate,
				inputby,updatedate,updateby,approvaldate,approvalby,nodoktmp,qtybbm_tmp,qtybbmkecil_tmp,status)
				(select branch,new.updateby,nodokref,fromcode,loccode,kdgroup,kdsubgroup,stockcode,id,desc_barang,qtyrec,qtyreckecil,qtybbm,qtybbmkecil,satminta,satkecil,keterangan,inputdate,
				inputby,updatedate,updateby,approvaldate,approvalby,nodok,qtybbm,qtybbmkecil,'C' as status from sc_trx.stbbm_dtlref where nodok=new.nodok);
			else

				
				delete from sc_mst.trxerror where userid=new.nodok and modul='STBBM';
				insert into sc_mst.trxerror
				(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
				(new.updateby,1,new.nodok,'','STBBM');
				
				update sc_trx.stbbm_mst set status='A' where nodok=new.nodok;
			end if;
		ELSEIF (new.status='AP' and old.status='A') THEN /* TARIKAN APPROVAL KE TEMPORARY */
			if not exists(select * from sc_tmp.stbbm_mst where  nodokref in (select trim(nodokref) from sc_tmp.stbbm_mst where nodokref=new.nodokref)) then
				insert into sc_tmp.stbbm_mst
				(branch,nodok,nodokref,loccode,nodokopr,nodokdate,nodoktype,disc1,disc2,disc3,disc4,exppn,ttlbrutto,ttldiskon,ttldpp,ttlppn,ttlnetto,pkp,keterangan,inputdate,
				inputby,updatedate,updateby,approvaldate,approvalby,nodoktmp,status,nodokfrom)
				(select branch,new.updateby,nodokref,loccode,nodokopr,nodokdate,nodoktype,disc1,disc2,disc3,disc4,exppn,ttlbrutto,ttldiskon,ttldpp,ttlppn,ttlnetto,pkp,keterangan,inputdate,
				inputby,updatedate,updateby,approvaldate,approvalby,nodok,'A' as status,nodokfrom from sc_trx.stbbm_mst where nodok=new.nodok);


				insert into sc_tmp.stbbm_dtl
				(branch,nodok,nodokref,loccode,kdgroup,kdsubgroup,stockcode,id,desc_barang,qtyrec,qtyreckecil,qtybbm,qtybbmkecil,qtyonhand,satminta,satkecil,disc1,disc2,disc3,disc4,
				exppn,nbrutto,ndiskon,ndpp,nppn,nnetto,pkp,unitprice,pricelist,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodoktmp,qtybbm_tmp,qtybbmkecil_tmp,status)
				(select branch,new.updateby,nodokref,loccode,kdgroup,kdsubgroup,stockcode,id,desc_barang,qtyrec,qtyreckecil,qtybbm,qtybbmkecil,qtyonhand,satminta,satkecil,disc1,disc2,disc3,disc4,
				exppn,nbrutto,ndiskon,ndpp,nppn,nnetto,pkp,unitprice,pricelist,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodok,qtybbm,qtybbmkecil,'A' as status from sc_trx.stbbm_dtl where nodok=new.nodok);

				insert into sc_tmp.stbbm_dtlref
				(branch,nodok,nodokref,fromcode,loccode,kdgroup,kdsubgroup,stockcode,id,desc_barang,qtyrec,qtyreckecil,qtybbm,qtybbmkecil,satminta,satkecil,keterangan,inputdate,
				inputby,updatedate,updateby,approvaldate,approvalby,nodoktmp,qtybbm_tmp,qtybbmkecil_tmp,status)
				(select branch,new.updateby,nodokref,fromcode,loccode,kdgroup,kdsubgroup,stockcode,id,desc_barang,qtyrec,qtyreckecil,qtybbm,qtybbmkecil,satminta,satkecil,keterangan,inputdate,
				inputby,updatedate,updateby,approvaldate,approvalby,nodok,qtybbm,qtybbmkecil,'A' as status from sc_trx.stbbm_dtlref where nodok=new.nodok);
			else

				
				delete from sc_mst.trxerror where  modul='STBBM';
				insert into sc_mst.trxerror
				(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
				(new.updateby,1,new.nodok,'','STBBM');
				
				update sc_trx.stbbm_mst set status='A' where nodok=new.nodok;
			end if;
			----select * from sc_trx.stbbk_dtl;
		/*EDIT SETELAH FINAL */
		ELSEIF (new.status='E' and old.status='P') THEN
			if not exists(select * from sc_tmp.stbbm_mst where  nodokref in (select trim(nodokref) from sc_tmp.stbbm_mst where nodokref=new.nodokref)) then
				/* delete stgblco mengembalikan stock */
				--select * from sc_trx.stgblco where doctype='BBK'
				delete from sc_trx.stgblco where branch=new.branch and loccode=new.loccode and doctype='BBK' and docno=new.nodok and docref=new.nodokref
				and stockcode in (select trim(stockcode) from sc_trx.stbbk_dtl where nodok=new.nodok and nodokref=new.nodokref and status='P');

				/* update ke pbk */
				update sc_trx.stpbk_dtl a set status='P',qtybbk=coalesce(a.qtybbk,0)-coalesce(b.qtybbk,0)
				from sc_tmp.stbbk_dtl b where a.branch=b.branch and a.loccode=b.loccode and a.kdgroup=b.kdgroup and a.kdsubgroup=b.kdsubgroup
				and a.stockcode=b.stockcode and b.status='P' and b.nodok=new.nodok and  b.nodokref=new.nodokref;

				insert into sc_tmp.stbbm_mst 
				(branch,nodok,nodokref,nik,loccode,status,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodoktmp,nodokfrom)
				(select branch,new.updateby,nodokref,nik,loccode,'E',keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodok,nodokfrom
				from sc_trx.stbbm_mst where nodok=new.nodok and nik=new.nik);
				
				insert into sc_tmp.stbbk_dtl 
				(branch,nodok,nik,kdgroup,kdsubgroup,stockcode,loccode,desc_barang,qtypbk,qtybbk,qtyonhand,status,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodokref,nodoktmp,qtybbk_tmp)
				(select branch,new.updateby,nik,kdgroup,kdsubgroup,stockcode,loccode,desc_barang,qtypbk,qtybbk,qtyonhand,'E',keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodokref,nodok,qtybbk
				from sc_trx.stbbk_dtl where nodok=new.nodok and nik=new.nik);
				--select * from sc_mst.stkgdw
				update sc_mst.stkgdw a set allocated=allocated+b.qtybbk from sc_trx.stbbk_dtl b where nodok=new.nodok and a.stockcode=b.stockcode
				and a.kdgroup=b.kdgroup and a.kdsubgroup=b.kdsubgroup and a.loccode=b.loccode;
			end if;
		ELSEIF (new.status='C' and old.status='P') THEN
			update sc_trx.stbbk_dtl set status='C' where nodok=new.nodok;
		ELSEIF (new.status='H' /* and old.status='A'*/) THEN   
			if not exists(select * from sc_tmp.stbbm_mst where  nodokref in (select trim(nodokref) from sc_tmp.stbbm_mst where nodokref=new.nodokref)) then
				insert into sc_tmp.stbbm_mst 
				(branch,nodok,nodokref,nik,loccode,status,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodoktmp)
				(select branch,new.approvalby,nodokref,nik,loccode,'P',keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodok
				from sc_trx.stbbm_mst where nodok=new.nodok and nik=new.nik);
				
				insert into sc_tmp.stbbk_dtl 
				(branch,nodok,nik,kdgroup,kdsubgroup,stockcode,loccode,desc_barang,qtypbk,qtybbk,qtyonhand,status,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodokref,nodoktmp,qtybbk_tmp)
				(select branch,new.approvalby,nik,kdgroup,kdsubgroup,stockcode,loccode,desc_barang,qtypbk,qtybbk,qtyonhand,status,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodokref,nodok,qtybbk
				from sc_trx.stbbk_dtl where nodok=new.nodok and nik=new.nik);
			else
				update sc_trx.stbbm_mst set status='A' where nodok=new.nodok;
			end if;
		ELSEIF (new.status='C' and old.status='A') THEN
			update sc_trx.stbbk_dtl set status='C' where nodok=new.nodok;
		END IF; 
		RETURN NEW;
	ELSEIF tg_op = 'DELETE' THEN

		RETURN old;	
	END IF;
	
END;
$$;

alter function tr_trx_stbbm_mst() owner to postgres;

