create function tr_perawatanasset() returns trigger
    language plpgsql
as
$$
declare
--created by Fiky ::18/07/2017
--update by Fiky ::03/01/2018
--UPDATE PENAMBAHAN SMS
     vr_nomor char(12); 
     vr_cekprefix char(4);
     vr_nowprefix char(4);
begin    

	IF TG_OP ='INSERT' THEN 
		
	RETURN NEW;
	ELSEIF TG_OP ='UPDATE' THEN
		/* NO RESOURCE UPDATE */
		if (new.status='E' and old.status='A') then
			insert into sc_tmp.perawatanasset 
			(nodok,dokref,kdgroup,kdsubgroup,stockcode,descbarang,nikpakai,nikmohon,jnsperawatan,tgldok,keterangan,laporanpk,laporanpsp,laporanksp,
			inputdate,inputby,updatedate,updateby,approvaldate,approvalby,canceldate,cancelby,nodoktmp,status,km_awal,km_akhir)
			(select updateby,dokref,kdgroup,kdsubgroup,stockcode,descbarang,nikpakai,nikmohon,jnsperawatan,tgldok,keterangan,laporanpk,laporanpsp,laporanksp,
			inputdate,inputby,updatedate,updateby,approvaldate,approvalby,canceldate,cancelby,new.nodok,'E' AS status,km_awal,km_akhir from sc_his.perawatanasset where nodok=new.nodok
			and nodok not in (select trim(nodoktmp) from sc_tmp.perawatanasset ));
		elseif (new.status='C' and old.status='A') then
			insert into sc_tmp.perawatanasset 
			(nodok,dokref,kdgroup,kdsubgroup,stockcode,descbarang,nikpakai,nikmohon,jnsperawatan,tgldok,keterangan,laporanpk,laporanpsp,laporanksp,
			inputdate,inputby,updatedate,updateby,approvaldate,approvalby,canceldate,cancelby,nodoktmp,status,km_awal,km_akhir)
			(select cancelby,dokref,kdgroup,kdsubgroup,stockcode,descbarang,nikpakai,nikmohon,jnsperawatan,tgldok,keterangan,laporanpk,laporanpsp,laporanksp,
			inputdate,inputby,updatedate,updateby,approvaldate,approvalby,canceldate,cancelby,new.nodok,'C' AS status,km_awal,km_akhir from sc_his.perawatanasset where nodok=new.nodok
			and nodok not in (select trim(nodoktmp) from sc_tmp.perawatanasset ));
		elseif (new.status='A' and old.status='A') then
			insert into sc_tmp.perawatanasset 
			(nodok,dokref,kdgroup,kdsubgroup,stockcode,descbarang,nikpakai,nikmohon,jnsperawatan,tgldok,keterangan,laporanpk,laporanpsp,laporanksp,
			inputdate,inputby,updatedate,updateby,approvaldate,approvalby,canceldate,cancelby,nodoktmp,status,km_awal,km_akhir)
			(select approvalby,dokref,kdgroup,kdsubgroup,stockcode,descbarang,nikpakai,nikmohon,jnsperawatan,tgldok,keterangan,laporanpk,laporanpsp,laporanksp,
			inputdate,inputby,updatedate,updateby,approvaldate,approvalby,canceldate,cancelby,new.nodok,'A' AS status,km_awal,km_akhir from sc_his.perawatanasset where nodok=new.nodok
			and nodok not in (select trim(nodoktmp) from sc_tmp.perawatanasset ));
		elseif (new.status='A1' and old.status='A1') then
			insert into sc_tmp.perawatanasset 
			(nodok,dokref,kdgroup,kdsubgroup,stockcode,descbarang,nikpakai,nikmohon,jnsperawatan,tgldok,keterangan,laporanpk,laporanpsp,laporanksp,
			inputdate,inputby,updatedate,updateby,approvaldate,approvalby,canceldate,cancelby,nodoktmp,status,km_awal,km_akhir)
			(select approvalby,dokref,kdgroup,kdsubgroup,stockcode,descbarang,nikpakai,nikmohon,jnsperawatan,tgldok,keterangan,laporanpk,laporanpsp,laporanksp,
			inputdate,inputby,updatedate,updateby,approvaldate,approvalby,canceldate,cancelby,new.nodok,'A1' AS status,km_awal,km_akhir from sc_his.perawatanasset where nodok=new.nodok
			and nodok not in (select trim(nodoktmp) from sc_tmp.perawatanasset ));
		elseif (new.status='P' and old.status='F') then
			update sc_his.perawatanspk set status='P' where nodok = new.nodok;
		elseif (new.status='A1' and old.status='') then

insert into outbox ("DestinationNumber","TextDecoded","CreatorID")
select nohp1,LEFT(
'No. PAS: '||nodok||'
Sdr/i '||coalesce(trim(nmnikmohon),'')||'
Pengajuan Perawatan: '||nmbarang||'
Nopol: '||nopol||'
Telah Disetujui Atasan,
Cek Via Web http://hrd.nusaboard.co.id',160) as textdecoded,'OSIN' as creator from (
select a.*,b.nodok,b.nmnikpakai,b.nmbarang,b.nopol,b.nmnikmohon from 
(select a.nik,b.nmlengkap,b.bag_dept,b.subbag_dept,b.jabatan,b.nohp1 from sc_mst.notif_sms a
left outer join sc_mst.karyawan b on a.nik=b.nik where a.dll='Y' and b.bag_dept='PG') a 
left outer join 
(select a.*,a1.nmlengkap as nmnikpakai,
trim(a1.nohp1) as hpnikpakai,
a2.nmlengkap as nmnikmohon,trim(a2.nohp1) as hpnikmohon,
a3.nik as nikatasanmohon,a3.nmlengkap as nmatasanmohon,trim(a3.nohp1) as hpatasanmohon,b1.nmbarang,b1.nopol from sc_his.perawatanasset a
left outer join sc_mst.karyawan a1 on a1.nik=a.nikpakai
left outer join sc_mst.karyawan a2 on a2.nik=a.nikmohon
left outer join sc_mst.karyawan a3 on a3.nik=a2.nik_atasan
left outer join sc_mst.mbarang b1 on b1.nodok=a.stockcode) as b on a.nik!=b.nikmohon) as x
where nodok=new.nodok;
			
		end if;



		
	RETURN NEW;
	END IF;
    
    return new;
        
end;
$$;

alter function tr_perawatanasset() owner to postgres;

