create function pr_stspeg_after() returns trigger
    language plpgsql
as
$$

DECLARE
    -- Created By FIKY : 28/04/2016
    -- Update By Bagos : 16/01/2023
    -- Tambah status kepegawaian PKWT 1 sampai 5
BEGIN
	IF(new.kdkepegawaian = 'KO') THEN --KELUAR KERJA
		UPDATE sc_mst.karyawan SET statuskepegawaian = new.kdkepegawaian, tglkeluarkerja = new.tgl_selesai WHERE nik = new.nik;

        DELETE FROM sc_mst.user WHERE nik = new.nik;
		DELETE FROM sc_mst.regu_opr WHERE nik = new.nik;
		DELETE FROM sc_trx.dtljadwalkerja WHERE nik = new.nik AND tgl > new.tgl_selesai;
		DELETE FROM sc_trx.uangmakan WHERE nik = new.nik AND tgl > new.tgl_selesai;
	ELSEIF(new.kdkepegawaian = 'HL') THEN --HARIAN LEPAS
		UPDATE sc_mst.karyawan SET statuskepegawaian = new.kdkepegawaian, tglkeluarkerja = NULL WHERE nik = new.nik;
		UPDATE sc_mst.user SET hold_id = 'N' WHERE nik = new.nik;
	ELSEIF(new.kdkepegawaian = 'KK') THEN --KONTRAK
		UPDATE sc_mst.karyawan SET statuskepegawaian = new.kdkepegawaian, tglkeluarkerja = NULL WHERE nik = new.nik;
		UPDATE sc_mst.user SET hold_id = 'N' WHERE nik = new.nik;
	ELSEIF(new.kdkepegawaian = 'KT') THEN --KARYAWAN TETAP
		UPDATE sc_mst.karyawan SET statuskepegawaian = new.kdkepegawaian, tglkeluarkerja = NULL WHERE nik = new.nik;
		UPDATE sc_mst.user SET hold_id = 'N' WHERE nik = new.nik;
	ELSEIF(new.kdkepegawaian = 'MG') THEN --MAGANG
		UPDATE sc_mst.karyawan SET statuskepegawaian = new.kdkepegawaian, tglkeluarkerja = NULL WHERE nik = new.nik;
		UPDATE sc_mst.user SET hold_id = 'N' WHERE nik = new.nik;
	ELSEIF(new.kdkepegawaian = 'KP') THEN --PENSIUN
		UPDATE sc_mst.karyawan SET statuskepegawaian = new.kdkepegawaian, tglkeluarkerja = NULL WHERE nik = new.nik;
		UPDATE sc_mst.user SET hold_id = 'Y' WHERE nik = new.nik;
	ELSEIF(new.kdkepegawaian = 'PK') THEN --PKWT PERCOBAAN
		UPDATE sc_mst.karyawan SET statuskepegawaian = new.kdkepegawaian, tglkeluarkerja = NULL WHERE nik = new.nik;
		UPDATE sc_mst.user SET hold_id = 'Y' WHERE nik = new.nik;
	ELSEIF(new.kdkepegawaian = 'P1') THEN --PKWT 1
		UPDATE sc_mst.karyawan SET statuskepegawaian = new.kdkepegawaian, tglkeluarkerja = NULL WHERE nik = new.nik;
	ELSEIF(new.kdkepegawaian = 'P2') THEN --PKWT 2
		UPDATE sc_mst.karyawan SET statuskepegawaian = new.kdkepegawaian, tglkeluarkerja = NULL WHERE nik = new.nik;
	ELSEIF(new.kdkepegawaian = 'P3') THEN --PKWT 3
		UPDATE sc_mst.karyawan SET statuskepegawaian = new.kdkepegawaian, tglkeluarkerja = NULL WHERE nik = new.nik;
	ELSEIF(new.kdkepegawaian = 'P4') THEN --PKWT 4
		UPDATE sc_mst.karyawan SET statuskepegawaian = new.kdkepegawaian, tglkeluarkerja = NULL WHERE nik = new.nik;
	ELSEIF(new.kdkepegawaian = 'P5') THEN --PKWT 5
		UPDATE sc_mst.karyawan SET statuskepegawaian = new.kdkepegawaian, tglkeluarkerja = NULL WHERE nik = new.nik;
	ELSEIF(new.kdkepegawaian = 'H1') THEN --HONORER
		UPDATE sc_mst.karyawan SET statuskepegawaian = new.kdkepegawaian, tglkeluarkerja = NULL WHERE nik = new.nik;
	ELSEIF(new.kdkepegawaian = 'H2') THEN --PELAKSANA
		UPDATE sc_mst.karyawan SET statuskepegawaian = new.kdkepegawaian, tglkeluarkerja = NULL WHERE nik = new.nik;
	END IF;

	RETURN new;
END;
$$;

alter function pr_stspeg_after() owner to postgres;

