create function tr_mbarang_hps() returns trigger
    language plpgsql
as
$$
declare
--created by Fiky ::26/07/2017
--triger delete master barang 
     vr_nomor char(12); 
     vr_cekprefix char(4);
     vr_nowprefix char(4);
begin    

	IF TG_OP ='INSERT' THEN 
	
		
	RETURN NEW;
	ELSEIF TG_OP ='UPDATE' THEN
		IF (old.status='A' and new.status='P') THEN
			delete from sc_mst.mbarang where nodok=new.kdbarang;
		ELSEIF (old.status='P' and new.status='A') THEN
			insert into sc_mst.mbarang
			(branch,nodok,nodokref,nmbarang,kdgroup,kdsubgroup,kdgudang,nmpemilik,addpemilik,kdasuransi,kdrangka,kdmesin,nopol,hppemilik,typeid,jenisid,modelid,tahunpembuatan,
			silinder,warna,bahanbakar,warnatnkb,tahunreg,nobpkb,kdlokasi,expstnkb,exppkbstnkb,nopkb,nominalpkb,pprogresif,brand,hold_item,typebarang,qty,expdate,expasuransi,userpakai,
			kddept,kdsubdept,kdjabatan,startpakai,endpakai,keterangan,inputdate,inputby,updatedate,updateby)
			(select branch,kdbarang,nodokref,nmbarang,kdgroup,kdsubgroup,kdgudang,nmpemilik,addpemilik,kdasuransi,kdrangka,kdmesin,nopol,hppemilik,typeid,jenisid,modelid,tahunpembuatan,
			silinder,warna,bahanbakar,warnatnkb,tahunreg,nobpkb,kdlokasi,expstnkb,exppkbstnkb,nopkb,nominalpkb,pprogresif,brand,hold_item,typebarang,qty,expdate,expasuransi,userpakai,
			kddept,kdsubdept,kdjabatan,startpakai,endpakai,keterangan,inputdate,inputby,updatedate,updateby
			from sc_his.mbarang_hps where nodok=new.nodok);
		END IF;
				
	RETURN NEW;
	END IF;
/*
select * from sc_tmp.mtsasset
select * from sc_his.mtsasset
--truncate sc_tmp.sk_mtsasset,sc_his.mtsasset
select * from sc_mst.nomor
insert into sc_mst.nomor VALUES
('MTAS_HPSAST','',4,'SHPS1706','',0,'66666','','201606','T')
--delete from sc_mst.nomor where dokumen='MTAS_HPSAST';
*/
  return new;
        
end;
$$;

alter function tr_mbarang_hps() owner to postgres;

