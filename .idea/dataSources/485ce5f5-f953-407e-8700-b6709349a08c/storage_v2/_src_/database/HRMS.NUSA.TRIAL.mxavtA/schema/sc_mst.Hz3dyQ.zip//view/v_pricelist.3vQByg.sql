create view v_pricelist
            (branch, jenisprice, kdgroup, kdsubgroup, stockcode, kdgroupsupplier, kdsupplier, kdsubsupplier,
             kdcabangsupplier, pricedate, satkecil, qtykecil, payterm, unitprice, disc1, disc2, disc3, disc4, updateby,
             updatedate, nodokref, pkp, exppn, status, id, nmbarang, nmsatkecil, nmsupplier)
as
SELECT a.branch,
       a.jenisprice,
       a.kdgroup,
       a.kdsubgroup,
       a.stockcode,
       a.kdgroupsupplier,
       a.kdsupplier,
       a.kdsubsupplier,
       a.kdcabangsupplier,
       a.pricedate,
       a.satkecil,
       a.qtykecil,
       a.payterm,
       round(a.unitprice) AS unitprice,
       round(a.disc1)     AS disc1,
       round(a.disc2)     AS disc2,
       round(a.disc3)     AS disc3,
       round(a.disc4)     AS disc4,
       a.updateby,
       a.updatedate,
       a.nodokref,
       a.pkp,
       a.exppn,
       a.status,
       a.id,
       b.nmbarang,
       c.uraian           AS nmsatkecil,
       d.nmsubsupplier    AS nmsupplier
FROM sc_mst.pricelst a
         LEFT JOIN sc_mst.mbarang b ON a.kdgroup = b.kdgroup AND a.kdsubgroup = b.kdsubgroup AND a.stockcode = b.nodok
         LEFT JOIN sc_mst.trxtype c ON a.satkecil = c.kdtrx AND c.jenistrx::text = 'QTYUNIT'::text
         LEFT JOIN sc_mst.msubsupplier d ON a.kdsupplier = d.kdsupplier AND a.kdsubsupplier = d.kdsubsupplier AND
                                            a.kdcabangsupplier = d.kdcabang
ORDER BY a.pricedate DESC;

alter table v_pricelist
    owner to postgres;

