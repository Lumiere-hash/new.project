create function pdca_master_plan_daily() returns trigger
    language plpgsql
as
$$
declare
--created by Fiky ::18/07/2017
     vr_nomor char(12); 
     vr_cekprefix char(4);
     vr_nowprefix char(4);
begin    

	IF TG_OP ='INSERT' THEN 
		--select * from sc_his.pdca_master_plan_daily
		--DELETE from sc_his.pdca_master_plan_daily
		update sc_his.pdca_master_plan_daily a set nomor=a1.urutnya
		from (select a1.*,row_number() over(partition by nik order by inputdate asc ) as urutnya
		from sc_his.pdca_master_plan_daily a1) a1
		where a.nik=a1.nik and a.branch=a1.branch and a.inputdate=a1.inputdate and a.nomor=a1.nomor
		and a.nik=new.nik;
		update sc_his.pdca_master_plan_daily set docno='DOC/'||nomor||'/'||trim(nik) where nik=new.nik and nomor=nomor;
	return new;
	END IF;
    
    
    return new;
        
end;
$$;

alter function pdca_master_plan_daily() owner to postgres;

