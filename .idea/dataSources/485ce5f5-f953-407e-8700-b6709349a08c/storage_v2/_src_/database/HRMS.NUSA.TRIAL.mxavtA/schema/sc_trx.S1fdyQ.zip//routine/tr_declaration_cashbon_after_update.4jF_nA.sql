create function tr_declaration_cashbon_after_update() returns trigger
    language plpgsql
as
$$
DECLARE
    number VARCHAR;
BEGIN
    IF ( UPPER(NEW.status) = 'U' AND UPPER(OLD.status) <> 'U' ) THEN
        IF ( NEW.updateby = OLD.updateby AND NEW.updatedate = OLD.updatedate ) THEN
            RAISE EXCEPTION 'Update data harus merubah nilai updateby dan updatedate';
        END IF;

        IF EXISTS ( SELECT TRUE FROM sc_tmp.declaration_cashbon WHERE TRUE AND declarationid = NEW.declarationid AND updateby <> NEW.updateby ) THEN
            RAISE EXCEPTION 'Data % sedang diupdate oleh %', NEW.declarationid, NEW.updateby;
        END IF;

        DELETE FROM sc_tmp.declaration_cashbon WHERE TRUE
        AND declarationid = NEW.declarationid
        AND updateby = NEW.updateby;

        INSERT INTO sc_tmp.declaration_cashbon (
            branch,
            declarationid,
            cashbonid,
            dutieid,
            superior,
            status,
            paymenttype,
            totalcashbon,
            totaldeclaration,
            returnamount,
            inputby,
            inputdate,
            updateby,
            updatedate,
            approveby,
            approvedate
        ) SELECT
            branch,
            declarationid,
            cashbonid,
            dutieid,
            superior,
            OLD.status AS status,
            paymenttype,
            totalcashbon,
            totaldeclaration,
            returnamount,
            inputby,
            inputdate,
            updateby,
            updatedate,
            approveby,
            approvedate
        FROM sc_trx.declaration_cashbon WHERE TRUE
        AND declarationid = NEW.declarationid;

        DELETE FROM sc_tmp.declaration_cashbon_component WHERE TRUE
        AND declarationid = NEW.declarationid;

        INSERT INTO sc_tmp.declaration_cashbon_component (
            branch,
            declarationid,
            componentid,
            perday,
            nominal,
            description,
            inputby,
            inputdate,
            updateby,
            updatedate
        ) SELECT
            branch,
            declarationid,
            componentid,
            perday,
            nominal,
            description,
            inputby,
            inputdate,
            updateby,
            updatedate
        FROM sc_trx.declaration_cashbon_component WHERE TRUE
        AND declarationid = NEW.declarationid;

        UPDATE sc_trx.declaration_cashbon SET
            status = OLD.status,
            updateby = OLD.updateby,
            updatedate = OLD.updatedate
        WHERE TRUE
        AND declarationid = NEW.declarationid;
    END IF;
    RETURN NEW;
END;
$$;

alter function tr_declaration_cashbon_after_update() owner to postgres;

