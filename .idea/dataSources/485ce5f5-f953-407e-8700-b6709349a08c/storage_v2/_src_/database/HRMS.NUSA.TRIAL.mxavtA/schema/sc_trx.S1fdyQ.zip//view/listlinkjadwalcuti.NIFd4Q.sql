create view listlinkjadwalcuti (nik, tgl, kdjamkerja, kdregu, nodok, tgl_mulai, tgl_selesai, kdpokok, masuk, keluar) as
SELECT t3.nik,
       t3.tgl,
       t3.kdjamkerja,
       t3.kdregu,
       CASE
           WHEN t3.dokcuti IS NOT NULL THEN t3.dokcuti
           WHEN t3.dokcutiptggaji IS NOT NULL THEN t3.dokcutiptggaji
           WHEN t3.dokcutikhusus IS NOT NULL THEN t3.dokcutikhusus
           WHEN t3.dokdinas IS NOT NULL THEN t3.dokdinas
           WHEN t3.dokcb IS NOT NULL THEN t3.dokcb
           WHEN t3.dokik IS NOT NULL THEN t3.dokik
           WHEN t3.dokpa IS NOT NULL THEN t3.dokpa
           WHEN t3.dokdt IS NOT NULL THEN t3.dokdt
           WHEN t3.dokskd IS NOT NULL THEN t3.dokskd
           ELSE NULL::bpchar
           END AS nodok,
       t3.tgl_mulai,
       t3.tgl_selesai,
       t3.kdpokok,
       t3.masuk,
       t3.keluar
FROM (SELECT a.nik,
             a.tgl,
             a.kdjamkerja,
             a.kdregu,
             t2.dokcuti,
             t2.dokcutiptggaji,
             t2.dokcutikhusus,
             t2.dokdinas,
             t2.dokcb,
             t2.dokik,
             t2.dokpa,
             t2.dokdt,
             t2.dokskd,
             t2.tgl_mulai,
             t2.tgl_selesai,
             CASE
                 WHEN a.kdjamkerja IS NOT NULL AND t1.masuk IS NULL AND t1.keluar IS NULL AND
                      (t2.dokcuti = ''::bpchar OR t2.dokcuti IS NULL) AND
                      (t2.dokcutiptggaji = ''::bpchar OR t2.dokcutiptggaji IS NULL) AND
                      (t2.dokcutikhusus = ''::bpchar OR t2.dokcutikhusus IS NULL) AND
                      (t2.dokdinas = ''::bpchar OR t2.dokdinas IS NULL) AND (t2.dokcb = ''::bpchar OR
                                                                             t2.dokcb IS NULL AND
                                                                             (t2.dokik = ''::bpchar OR t2.dokik IS NULL) AND
                                                                             (t2.dokpa = ''::bpchar OR t2.dokpa IS NULL) AND
                                                                             (t2.dokdt = ''::bpchar OR t2.dokdt IS NULL) AND
                                                                             (t2.dokskd = ''::bpchar OR t2.dokskd IS NULL))
                     THEN 'AL'::bpchar
                 WHEN t2.dokcuti IS NOT NULL THEN 'CT'::bpchar
                 WHEN t2.dokcutiptggaji IS NOT NULL THEN 'PG'::bpchar
                 WHEN t2.dokcutikhusus IS NOT NULL THEN 'CK'::bpchar
                 WHEN t2.dokdinas IS NOT NULL THEN 'DN'::bpchar
                 WHEN t2.dokcb IS NOT NULL THEN 'CB'::bpchar
                 WHEN t2.dokik IS NOT NULL THEN 'IK'::bpchar
                 WHEN t2.dokpa IS NOT NULL THEN 'PA'::bpchar
                 WHEN t2.dokdt IS NOT NULL THEN 'DT'::bpchar
                 WHEN t2.dokdt IS NOT NULL AND t2.dokpa IS NOT NULL THEN 'DT'::bpchar
                 WHEN t2.dokskd IS NOT NULL THEN 'SKD'::bpchar
                 ELSE a.kdjamkerja
                 END AS kdpokok,
             t1.masuk,
             t1.keluar
      FROM sc_trx.dtljadwalkerja a
               LEFT JOIN (SELECT transready.nik,
                                 transready.tgl,
                                 min(transready.jam_masuk_absen)  AS masuk,
                                 max(transready.jam_pulang_absen) AS keluar
                          FROM sc_trx.transready
                          GROUP BY transready.nik, transready.tgl
                          ORDER BY transready.tgl) t1 ON t1.nik = a.nik AND t1.tgl = a.tgl
               LEFT JOIN (SELECT a_1.nik,
                                 a_1.tgl,
                                 a_1.kdjamkerja,
                                 a_1.kdregu,
                                 a_1.kdmesin,
                                 a_1.inputby,
                                 a_1.inputdate,
                                 a_1.updateby,
                                 a_1.updatedate,
                                 a_1.shift,
                                 a_1.id,
                                 CASE
                                     WHEN b.tgl_mulai IS NOT NULL THEN b.tgl_mulai::timestamp without time zone
                                     WHEN b_1.tgl_mulai IS NOT NULL THEN b_1.tgl_mulai::timestamp without time zone
                                     WHEN b_2.tgl_mulai IS NOT NULL THEN b_2.tgl_mulai::timestamp without time zone
                                     WHEN c.tgl_mulai IS NOT NULL THEN c.tgl_mulai::timestamp without time zone
                                     WHEN d.tgl_mulai IS NOT NULL THEN d.tgl_mulai
                                     WHEN e.tgl_kerja IS NOT NULL THEN e.tgl_kerja::timestamp without time zone
                                     WHEN f.tgl_kerja IS NOT NULL THEN f.tgl_kerja::timestamp without time zone
                                     WHEN f_1.tgl_kerja IS NOT NULL THEN f_1.tgl_kerja::timestamp without time zone
                                     WHEN f_2.tgl_kerja IS NOT NULL THEN f_2.tgl_kerja::timestamp without time zone
                                     WHEN f_2.tgl_kerja IS NOT NULL AND f_1.tgl_kerja IS NOT NULL
                                         THEN f_2.tgl_kerja::timestamp without time zone
                                     ELSE NULL::timestamp without time zone
                                     END           AS tgl_mulai,
                                 CASE
                                     WHEN b.tgl_selesai IS NOT NULL THEN b.tgl_selesai::timestamp without time zone
                                     WHEN b_1.tgl_selesai IS NOT NULL THEN b_1.tgl_selesai::timestamp without time zone
                                     WHEN b_2.tgl_selesai IS NOT NULL THEN b_2.tgl_selesai::timestamp without time zone
                                     WHEN c.tgl_selesai IS NOT NULL THEN c.tgl_selesai::timestamp without time zone
                                     WHEN d.tgl_selesai IS NOT NULL THEN d.tgl_selesai
                                     WHEN e.tgl_kerja IS NOT NULL THEN e.tgl_kerja::timestamp without time zone
                                     WHEN f.tgl_kerja IS NOT NULL THEN f.tgl_kerja::timestamp without time zone
                                     WHEN f_1.tgl_kerja IS NOT NULL THEN f_1.tgl_kerja::timestamp without time zone
                                     WHEN f_2.tgl_kerja IS NOT NULL THEN f_2.tgl_kerja::timestamp without time zone
                                     WHEN f_2.tgl_kerja IS NOT NULL AND f_1.tgl_kerja IS NOT NULL
                                         THEN f_2.tgl_kerja::timestamp without time zone
                                     ELSE NULL::timestamp without time zone
                                     END           AS tgl_selesai,
                                 e.tgl_jam_mulai   AS jam_mulai,
                                 e.tgl_jam_selesai AS jam_selesai,
                                 CASE
                                     WHEN b.tpcuti IS NOT NULL THEN b.tpcuti
                                     WHEN b_1.tpcuti IS NOT NULL THEN b_1.tpcuti
                                     WHEN b_2.tpcuti IS NOT NULL THEN b_2.tpcuti
                                     ELSE NULL::bpchar
                                     END           AS tpcuti,
                                 b.nodok           AS dokcuti,
                                 b_1.nodok         AS dokcutiptggaji,
                                 b_2.nodok         AS dokcutikhusus,
                                 c.nodok           AS dokdinas,
                                 d.nodok           AS dokcb,
                                 e.nodok           AS dokik,
                                 f.nodok           AS dokskd,
                                 f_1.nodok         AS dokpa,
                                 f_2.nodok         AS dokdt
                          FROM sc_trx.dtljadwalkerja a_1
                                   LEFT JOIN sc_trx.cuti_karyawan b ON a_1.nik = b.nik AND a_1.tgl >= b.tgl_mulai AND
                                                                       a_1.tgl <= b.tgl_selesai AND
                                                                       b.status = 'P'::bpchar AND
                                                                       b.tpcuti = 'A'::bpchar AND b.status_ptg = 'A1'::bpchar
                                   LEFT JOIN sc_trx.cuti_karyawan b_1
                                             ON a_1.nik = b_1.nik AND a_1.tgl >= b_1.tgl_mulai AND
                                                a_1.tgl <= b_1.tgl_selesai AND b_1.status = 'P'::bpchar AND
                                                b_1.tpcuti = 'A'::bpchar AND b_1.status_ptg = 'A2'::bpchar
                                   LEFT JOIN sc_trx.cuti_karyawan b_2
                                             ON a_1.nik = b_2.nik AND a_1.tgl >= b_2.tgl_mulai AND
                                                a_1.tgl <= b_2.tgl_selesai AND b_2.status = 'P'::bpchar AND
                                                b_2.tpcuti = 'B'::bpchar
                                   LEFT JOIN sc_trx.dinas c ON a_1.nik = c.nik AND a_1.tgl >= c.tgl_mulai AND
                                                               a_1.tgl <= c.tgl_selesai AND c.status::bpchar = 'P'::bpchar
                                   LEFT JOIN sc_trx.ijin_karyawan f ON a_1.nik = f.nik AND a_1.tgl = f.tgl_kerja AND
                                                                       f.kdijin_absensi = 'KD'::bpchar AND
                                                                       f.status = 'P'::bpchar
                                   LEFT JOIN sc_trx.ijin_karyawan f_1
                                             ON a_1.nik = f_1.nik AND a_1.tgl = f_1.tgl_kerja AND
                                                f_1.kdijin_absensi = 'PA'::bpchar AND f_1.status = 'P'::bpchar AND
                                                f_1.type_ijin = 'DN'::bpchar
                                   LEFT JOIN sc_trx.ijin_karyawan f_2
                                             ON a_1.nik = f_2.nik AND a_1.tgl = f_2.tgl_kerja AND
                                                f_2.kdijin_absensi = 'DT'::bpchar AND f_2.status = 'P'::bpchar AND
                                                f_2.type_ijin = 'DN'::bpchar
                                   LEFT JOIN (SELECT a_2.nik,
                                                     b_1_1.nodok,
                                                     b_1_1.tgl_dok,
                                                     b_1_1.status,
                                                     b_1_1.tgl_awal  AS tgl_mulai,
                                                     b_1_1.tgl_akhir AS tgl_selesai,
                                                     b_1_1.input_by,
                                                     b_1_1.input_date,
                                                     b_1_1.update_by,
                                                     b_1_1.update_date,
                                                     b_1_1.jumlahcuti,
                                                     b_1_1.keterangan
                                              FROM sc_trx.cuti_blc a_2
                                                       LEFT JOIN sc_trx.cutibersama b_1_1
                                                                 ON a_2.no_dokumen::bpchar = b_1_1.nodok AND
                                                                    b_1_1.status = 'P'::bpchar AND
                                                                    a_2.status::text = 'F'::text) d
                                             ON a_1.nik = d.nik AND
                                                a_1.tgl >= to_char(d.tgl_selesai, 'yyyy-mm-dd'::text)::date AND
                                                a_1.tgl <= to_char(d.tgl_selesai, 'yyyy-mm-dd'::text)::date AND
                                                d.status = 'P'::bpchar
                                   LEFT JOIN (SELECT a_2.nik,
                                                     a_2.nodok,
                                                     a_2.tgl_kerja,
                                                     a_2.tgl_jam_mulai,
                                                     a_2.tgl_jam_selesai,
                                                     a_2.durasi,
                                                     a_2.keterangan,
                                                     a_2.type_ijin,
                                                     a_2.status,
                                                     a_2.input_by,
                                                     a_2.input_date,
                                                     a_2.approval_by,
                                                     a_2.approval_date,
                                                     CASE
                                                         WHEN a_2.tgl_jam_mulai <= c_1.jam_masuk AND
                                                              a_2.tgl_jam_selesai >= c_1.jam_pulang THEN 'IKD'::text
                                                         ELSE NULL::text
                                                         END AS kdpokok
                                              FROM sc_trx.ijin_karyawan a_2
                                                       LEFT JOIN sc_trx.dtljadwalkerja b_1_1
                                                                 ON a_2.nik = b_1_1.nik AND a_2.tgl_kerja = b_1_1.tgl
                                                       LEFT JOIN sc_mst.jam_kerja c_1 ON b_1_1.kdjamkerja = c_1.kdjam_kerja
                                              WHERE a_2.type_ijin = 'DN'::bpchar
                                                AND a_2.status = 'P'::bpchar) e
                                             ON a_1.nik = e.nik AND a_1.tgl = e.tgl_kerja AND e.kdpokok IS NOT NULL) t2
                         ON a.nik = t2.nik AND a.tgl = t2.tgl
      GROUP BY a.nik, a.tgl, a.kdjamkerja, a.kdregu, t2.dokcuti, t2.tgl_mulai, t2.tgl_selesai, t1.masuk, t1.keluar,
               t2.tpcuti, t2.dokdinas, t2.dokcb, t2.dokik, t2.dokskd, t2.dokcutiptggaji, t2.dokcutikhusus, t2.dokdt,
               t2.dokpa) t3
ORDER BY t3.tgl;

comment on view listlinkjadwalcuti is 'LIST VIEW INI HANYA UNTUK ABSENSI BUKAN UNTUK MEMOTONG HARI KERJA!!!!';

alter table listlinkjadwalcuti
    owner to postgres;

