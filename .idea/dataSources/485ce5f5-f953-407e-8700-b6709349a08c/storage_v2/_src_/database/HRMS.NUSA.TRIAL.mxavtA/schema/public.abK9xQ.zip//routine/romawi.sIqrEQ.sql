create function romawi(vr_in integer) returns character
    language plpgsql
as
$$
DECLARE 
	--author by fiky: 12/08/2017
	--update by fiky: 12/08/2017
     vr_tmp char(10); 
     vr_digitx char(10); 
     vr_i integer; 
     vr_digitz integer; 
     vr_angka integer; 
BEGIN		
	vr_angka := vr_in;
	vr_i := 1;
	vr_digitx := 'IVXLCDM';
	vr_tmp := '';

	While vr_angka > 0 Loop
		vr_digitz := Mod(vr_angka,10);
		vr_angka := vr_angka/10;

			if vr_digitz = 1 then
				vr_tmp := trim(substr(vr_digitx,vr_i,1) || vr_tmp);
			elseif vr_digitz = 2 then
				vr_tmp := trim(substr(vr_digitx,vr_i,1) || substr(vr_digitx,vr_i,1) || vr_tmp);
			elseif vr_digitz = 3 then
				vr_tmp := trim(substr(vr_digitx,vr_i,1) || substr(vr_digitx,vr_i,1) || substr(vr_digitx,vr_i,1) || vr_tmp);
			elseif vr_digitz = 4 then
				vr_tmp := trim(substr(vr_digitx,vr_i,2) || vr_tmp);
			elseif vr_digitz = 5 then
				vr_tmp := trim(substr(vr_digitx,vr_i + 1,1) || vr_tmp);
			elseif vr_digitz = 6 then
				vr_tmp := trim(substr(vr_digitx,vr_i + 1,1) ||  substr(vr_digitx,vr_i,1) || vr_tmp);
			elseif vr_digitz = 7 then
				vr_tmp := trim(substr(vr_digitx,vr_i + 1,1) ||  substr(vr_digitx,vr_i,1) ||  substr(vr_digitx,vr_i,1) || vr_tmp);
			elseif vr_digitz = 8 then
				vr_tmp := trim(substr(vr_digitx,vr_i + 1,1) ||  substr(vr_digitx,vr_i,1) ||  substr(vr_digitx,vr_i,1) ||  substr(vr_digitx,vr_i,1) || vr_tmp);
			elseif vr_digitz = 9 then
				vr_tmp := trim(substr(vr_digitx,vr_i,1) ||  substr(vr_digitx,vr_i + 2,1) || vr_tmp);
			end if;

			vr_i := vr_i + 2;
	End Loop;

	return vr_tmp;
END;
$$;

alter function romawi(integer) owner to postgres;

