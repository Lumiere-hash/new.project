create function tr_tmp_stbbk_dtl() returns trigger
    language plpgsql
as
$$
DECLARE 
	--author by fiky: 12/08/2017
	--update by fiky: 12/08/2017
     vr_nomor char(12); 
     vr_cekprefix char(4);
     vr_nowprefix char(4);  
     vr_qtypbk numeric;  
     vr_qtybbk numeric;  
     vr_qtyonhand numeric;  
       
     vr_onhand_stkgdw numeric; 
     vr_tmpalloca_stkgdw numeric; 
     vr_alloca_stkgdw numeric; 
     vr_onhandtemp_stkgdw numeric; 
     vr_trxerror numeric;
BEGIN		
	IF tg_op = 'INSERT' THEN
		update  sc_tmp.stbbk_dtl a set id=a1.urutnya
		from (select a1.*,row_number() over(partition by nodok order by inputdate asc) as urutnya
		from sc_tmp.stbbk_dtl a1) a1
		where a.nodok=a1.nodok and a.kdgroup=a1.kdgroup and a.kdsubgroup=a1.kdsubgroup and a.stockcode=a1.stockcode
		and a.nodok=new.nodok;

		IF (NEW.NODOKTYPE='PBK') THEN
		/* RESET STKGDW BERDASAR ITEM YG MASUK TMP*/
			IF (NEW.STATUS<>'') THEN
				update sc_mst.stkgdw a set 
				onhand=coalesce(a.onhand,0)+coalesce(b.qtybbk,0) , 
				allocated=coalesce(a.allocated,0)-coalesce(b.qtybbk,0) , 
				tmpalloca=coalesce(a.tmpalloca,0)+coalesce(b.qtybbk,0)
				from sc_tmp.stbbk_dtl b where a.branch=b.branch and a.loccode=b.loccode and a.kdgroup=b.kdgroup and a.kdsubgroup=b.kdsubgroup
				and a.stockcode=b.stockcode and 
				a.loccode=new.loccode and a.kdgroup=new.kdgroup and a.kdsubgroup=new.kdsubgroup and a.stockcode=new.stockcode and b.nodok=new.nodok and b.nodokref=new.nodokref ;

				update sc_tmp.stbbk_dtl set status='C'
				where nodok=new.nodok and nik=new.nik and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and loccode=new.loccode
				and qtybbk=0 and status='A';

			END IF;	
		ELSEIF (NEW.NODOKTYPE='AJS') THEN /* AJUSTMENT TYPE */
			IF (NEW.STATUS='I') THEN
				update sc_mst.stkgdw a set 
				tmpalloca=coalesce(a.tmpalloca,0)+coalesce(b.qtybbk,0)
				from sc_tmp.stbbk_dtl b where a.branch=b.branch and a.loccode=b.loccode and a.kdgroup=b.kdgroup and a.kdsubgroup=b.kdsubgroup
				and a.stockcode=b.stockcode and 
				a.loccode=new.loccode and a.kdgroup=new.kdgroup and a.kdsubgroup=new.kdsubgroup and a.stockcode=new.stockcode and b.nodok=new.nodok and b.nodokref=new.nodokref ;
			ELSEIF (NEW.STATUS in ('E')) THEN
				update sc_mst.stkgdw a set 
				onhand=coalesce(a.onhand,0)+coalesce(b.qtybbk,0) ,  
				allocated=coalesce(a.allocated,0)-coalesce(b.qtybbk,0) , 
				tmpalloca=coalesce(a.tmpalloca,0)+coalesce(b.qtybbk,0)
				from sc_tmp.stbbk_dtl b where a.branch=b.branch and a.loccode=b.loccode and a.kdgroup=b.kdgroup and a.kdsubgroup=b.kdsubgroup
				and a.stockcode=b.stockcode and 
				a.loccode=new.loccode and a.kdgroup=new.kdgroup and a.kdsubgroup=new.kdsubgroup and a.stockcode=new.stockcode and b.nodok=new.nodok and b.nodokref=new.nodokref ;

			END IF;	
				
		END IF;
		RETURN new;
	ELSEIF tg_op = 'UPDATE' THEN                /*-------------------------------------- UPDATE ----------------------------------------------*/
		IF (NEW.NODOKTYPE='PBK') THEN
			if (new.status='' and old.status='E') then
				select coalesce(onhand,0),coalesce(tmpalloca,0),coalesce(onhand,0)-coalesce(tmpalloca,0),coalesce(allocated,0) from sc_mst.stkgdw 
				into vr_onhand_stkgdw,vr_tmpalloca_stkgdw,vr_onhandtemp_stkgdw,vr_alloca_stkgdw where 
				KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE FOR UPDATE;

				----if ((vr_onhandtemp_stkgdw<(old.qtybbk-old.qtybbk+new.qtybbk) or (new.qtypbk<new.qtybbk)) ) then
					if ((vr_onhandtemp_stkgdw+old.qtybbk-new.qtybbk)<0) then
				
						delete from sc_mst.trxerror where userid=new.nodok and modul='TMPSTBBK';
						insert into sc_mst.trxerror
						(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
						(new.nodok,1,new.nodokref,'','TMPSTBBK');
						
						update sc_tmp.stbbk_dtl set status='E',qtybbk=old.qtybbk
						where branch=new.branch and loccode=new.loccode and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup
						and stockcode=new.stockcode and nodok=new.nodok  and nik=new.nik;

					else

						update sc_mst.stkgdw set tmpalloca=(tmpalloca-old.qtybbk)+new.qtybbk where 
						KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE;

						delete from sc_mst.trxerror where userid=new.nodok and modul='TMPSTBBK';
						insert into sc_mst.trxerror
						(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
						(new.nodok,0,new.nodokref,'','TMPSTBBK');

						update sc_trx.stpbk_dtl set qtybbk=coalesce(qtybbk,0)-coalesce(old.qtybbk,0)+coalesce(new.qtybbk,0)
						where branch=new.branch and loccode=new.loccode and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup
						and stockcode=new.stockcode and nodok=new.nodokref  and nik=new.nik; 
						
						update sc_tmp.stbbk_dtl set status='E'
						where branch=new.branch and loccode=new.loccode and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup
						and stockcode=new.stockcode and nodok=new.nodok  and nik=new.nik; 
					
					end if;
			elseif (new.status='' and old.status='I') then
			
				select coalesce(onhand,0),coalesce(tmpalloca,0),coalesce(onhand,0)-coalesce(tmpalloca,0),coalesce(allocated,0) from sc_mst.stkgdw 
				into vr_onhand_stkgdw,vr_tmpalloca_stkgdw,vr_onhandtemp_stkgdw,vr_alloca_stkgdw where 
				KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE FOR UPDATE;

					if ((vr_onhandtemp_stkgdw+old.qtybbk-new.qtybbk)<0) then
				
						delete from sc_mst.trxerror where userid=new.nodok and modul='TMPSTBBK';
						insert into sc_mst.trxerror
						(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
						(new.nodok,1,new.nodokref,'','TMPSTBBK');
						
						update sc_tmp.stbbk_dtl set status='I',qtybbk=old.qtybbk
						where branch=new.branch and loccode=new.loccode and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup
						and stockcode=new.stockcode and nodok=new.nodok  and nik=new.nik;

					else
	
						update sc_mst.stkgdw set tmpalloca=(tmpalloca-old.qtybbk)+new.qtybbk where 
						KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE;

						delete from sc_mst.trxerror where userid=new.nodok and modul='TMPSTBBK';
						insert into sc_mst.trxerror
						(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
						(new.nodok,0,new.nodokref,'','TMPSTBBK');

						update sc_tmp.stbbk_dtl set status='I'
						where branch=new.branch and loccode=new.loccode and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup
						and stockcode=new.stockcode and nodok=new.nodok  and nik=new.nik; 
					
					end if;

			end if;
		ELSEIF (NEW.NODOKTYPE='AJS') THEN  /* ------------------ AJUSTMENT TYPE --------------------------*/
				if (new.status='' and old.status='E') then
				select coalesce(onhand,0),coalesce(tmpalloca,0),coalesce(onhand,0)-coalesce(tmpalloca,0),coalesce(allocated,0) from sc_mst.stkgdw 
				into vr_onhand_stkgdw,vr_tmpalloca_stkgdw,vr_onhandtemp_stkgdw,vr_alloca_stkgdw where 
				KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE FOR UPDATE;

					if ((vr_onhandtemp_stkgdw+old.qtybbk-new.qtybbk)<0) then
				
						delete from sc_mst.trxerror where userid=new.nodok and modul='TMPSTBBK';
						insert into sc_mst.trxerror
						(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
						(new.nodok,1,new.nodokref,'','TMPSTBBK');

						
						update sc_tmp.stbbk_dtl set status='E',qtybbk=old.qtybbk
						where branch=new.branch and loccode=new.loccode and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup
						and stockcode=new.stockcode and nodok=new.nodok  and nik=new.nik;

					else
				
						update sc_mst.stkgdw set tmpalloca=(tmpalloca-old.qtybbk)+new.qtybbk where 
						KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE;

						delete from sc_mst.trxerror where userid=new.nodok and modul='TMPSTBBK';
						insert into sc_mst.trxerror
						(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
						(new.nodok,0,new.nodokref,'','TMPSTBBK');

						update sc_trx.stpbk_dtl set qtybbk=coalesce(qtybbk,0)-coalesce(old.qtybbk,0)+coalesce(new.qtybbk,0)
						where branch=new.branch and loccode=new.loccode and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup
						and stockcode=new.stockcode and nodok=new.nodokref  and nik=new.nik; 
						
						update sc_tmp.stbbk_dtl set status='E'
						where branch=new.branch and loccode=new.loccode and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup
						and stockcode=new.stockcode and nodok=new.nodok  and nik=new.nik; 
					
					end if;
			elseif (new.status='' and old.status='I') then
			
				select coalesce(onhand,0),coalesce(tmpalloca,0),coalesce(onhand,0)-coalesce(tmpalloca,0),coalesce(allocated,0) from sc_mst.stkgdw 
				into vr_onhand_stkgdw,vr_tmpalloca_stkgdw,vr_onhandtemp_stkgdw,vr_alloca_stkgdw where 
				KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE FOR UPDATE;

					if ((vr_onhandtemp_stkgdw+old.qtybbk-new.qtybbk)<0) then
				
						delete from sc_mst.trxerror where userid=new.nodok and modul='TMPSTBBK';
						insert into sc_mst.trxerror
						(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
						(new.nodok,1,new.nodokref,'','TMPSTBBK');
						
						update sc_tmp.stbbk_dtl set status='I',qtybbk=old.qtybbk
						where branch=new.branch and loccode=new.loccode and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup
						and stockcode=new.stockcode and nodok=new.nodok  and nik=new.nik;

					else
				
						update sc_mst.stkgdw set tmpalloca=(tmpalloca-old.qtybbk)+new.qtybbk where 
						KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE;

						delete from sc_mst.trxerror where userid=new.nodok and modul='TMPSTBBK';
						insert into sc_mst.trxerror
						(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
						(new.nodok,0,new.nodokref,'','TMPSTBBK');

						update sc_tmp.stbbk_dtl set status='I'
						where branch=new.branch and loccode=new.loccode and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup
						and stockcode=new.stockcode and nodok=new.nodok  and nik=new.nik; 
					
					end if;
			elseif (new.status='F' and old.status='I') then
				update sc_mst.stkgdw set 
					tmpalloca=coalesce(tmpalloca,0)-coalesce(new.qtybbk,0),
					allocated=coalesce(allocated,0)+coalesce(new.qtybbk,0),
					onhand=coalesce(onhand,0)-coalesce(new.qtybbk,0)
					where 
					KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE;
			elseif (new.status='F' and old.status='E') then
					update sc_mst.stkgdw set 
					tmpalloca=coalesce(tmpalloca,0)-coalesce(new.qtybbk,0),
					allocated=coalesce(allocated,0)+coalesce(new.qtybbk,0),
					onhand=coalesce(onhand,0)-coalesce(new.qtybbk,0)
					where 
					KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE;	
			elseif (new.status='F' and old.status='P') then
					update sc_mst.stkgdw set 
					allocated=coalesce(allocated,0)-coalesce(new.qtybbk,0)
					where 
					KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE;			
			elseif (new.status='F' and old.status='C') then
					update sc_mst.stkgdw set 
					allocated=coalesce(allocated,0)-coalesce(new.qtybbk,0),
					onhand=coalesce(onhand,0)+coalesce(new.qtybbk,0)
					where 
					KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE;			
			end if;
		END IF;
		RETURN NEW;
	ELSEIF tg_op = 'DELETE' THEN
		IF (OLD.NODOKTYPE='PBK') THEN
			/* UNTUK STATUS PERESETAN */
			if (old.status='E') then
				select coalesce(onhand,0),coalesce(tmpalloca,0),coalesce(onhand,0)-coalesce(tmpalloca,0),coalesce(allocated,0) from sc_mst.stkgdw 
				into vr_onhand_stkgdw,vr_tmpalloca_stkgdw,vr_onhandtemp_stkgdw,vr_alloca_stkgdw where 
				KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE FOR UPDATE;

				update sc_mst.stkgdw set 
				tmpalloca=vr_tmpalloca_stkgdw-old.qtybbk,
				allocated=vr_alloca_stkgdw+old.qtybbk_tmp,
				onhand=vr_onhand_stkgdw-old.qtybbk_tmp
				where 
				KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE;
			elseif(old.status='A' OR old.status='P') then
				select coalesce(onhand,0),coalesce(tmpalloca,0),coalesce(onhand,0)-coalesce(tmpalloca,0),coalesce(allocated,0) from sc_mst.stkgdw 
				into vr_onhand_stkgdw,vr_tmpalloca_stkgdw,vr_onhandtemp_stkgdw,vr_alloca_stkgdw where 
				KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE FOR UPDATE;

				RAISE NOTICE 'OLD(%)',cast(old.qtybbk as character);
				RAISE NOTICE 'NEW(%)',cast(old.qtybbk as character);
				RAISE NOTICE 'vr_onhand_stkgdw(%)',cast(old.qtybbk as character);

				update sc_mst.stkgdw set 
				tmpalloca=vr_tmpalloca_stkgdw-old.qtybbk,
				--allocated=vr_alloca_stkgdw+old.qtybbk
				allocated=vr_alloca_stkgdw+old.qtybbk,
				onhand=vr_onhand_stkgdw-old.qtybbk
				where 
				KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE;
			elseif(old.status='AE') then
				select coalesce(onhand,0),coalesce(tmpalloca,0),coalesce(onhand,0)-coalesce(tmpalloca,0),coalesce(allocated,0) from sc_mst.stkgdw 
				into vr_onhand_stkgdw,vr_tmpalloca_stkgdw,vr_onhandtemp_stkgdw,vr_alloca_stkgdw where 
				KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE FOR UPDATE;

				RAISE NOTICE 'OLD(%)',cast(old.qtybbk as character);
				RAISE NOTICE 'NEW(%)',cast(old.qtybbk as character);
				RAISE NOTICE 'vr_onhand_stkgdw(%)',cast(old.qtybbk as character);

				update sc_mst.stkgdw set 
				tmpalloca=vr_tmpalloca_stkgdw-old.qtybbk,
				allocated=vr_alloca_stkgdw+old.qtybbk_tmp,
				onhand=vr_onhand_stkgdw-old.qtybbk_tmp
				where 
				KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE;
			elseif(old.status='C') then
				select coalesce(onhand,0),coalesce(tmpalloca,0),coalesce(onhand,0)-coalesce(tmpalloca,0),coalesce(allocated,0) from sc_mst.stkgdw 
				into vr_onhand_stkgdw,vr_tmpalloca_stkgdw,vr_onhandtemp_stkgdw,vr_alloca_stkgdw where 
				KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE FOR UPDATE;
				
				update sc_mst.stkgdw set 
				tmpalloca=vr_tmpalloca_stkgdw-old.qtybbk
				where 
				KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE;
			elseif(old.status='I') then
				select coalesce(onhand,0),coalesce(tmpalloca,0),coalesce(onhand,0)-coalesce(tmpalloca,0),coalesce(allocated,0) from sc_mst.stkgdw 
				into vr_onhand_stkgdw,vr_tmpalloca_stkgdw,vr_onhandtemp_stkgdw,vr_alloca_stkgdw where 
				KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE FOR UPDATE;

				RAISE NOTICE 'OLD(%)',cast(old.qtybbk as character);
				RAISE NOTICE 'NEW(%)',cast(old.qtybbk as character);
				RAISE NOTICE 'vr_onhand_stkgdw(%)',cast(old.qtybbk as character);

				update sc_mst.stkgdw set 
				tmpalloca=vr_tmpalloca_stkgdw-old.qtybbk,
				--allocated=vr_alloca_stkgdw+old.qtybbk
				allocated=vr_alloca_stkgdw+old.qtybbk,
				onhand=vr_onhand_stkgdw-old.qtybbk
				where 
				KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE;
			else
				select coalesce(onhand,0),coalesce(tmpalloca,0),coalesce(onhand,0)-coalesce(tmpalloca,0),coalesce(allocated,0) from sc_mst.stkgdw 
				into vr_onhand_stkgdw,vr_tmpalloca_stkgdw,vr_onhandtemp_stkgdw,vr_alloca_stkgdw where 
				KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE FOR UPDATE;

				update sc_mst.stkgdw set tmpalloca=vr_tmpalloca_stkgdw-coalesce(old.qtybbk,0) where 
				KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE;
		
			end if;
		ELSEIF (OLD.NODOKTYPE='AJS') THEN  /* AJUSTMENT TYPE */
			if(old.status='I') then
				select coalesce(onhand,0),coalesce(tmpalloca,0),coalesce(onhand,0)-coalesce(tmpalloca,0),coalesce(allocated,0) from sc_mst.stkgdw 
				into vr_onhand_stkgdw,vr_tmpalloca_stkgdw,vr_onhandtemp_stkgdw,vr_alloca_stkgdw where 
				KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE FOR UPDATE;

				update sc_mst.stkgdw set 
				tmpalloca=coalesce(tmpalloca,0)-coalesce(old.qtybbk,0)
				where 
				KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE;

			elseif(old.status='E') then
				select coalesce(onhand,0),coalesce(tmpalloca,0),coalesce(onhand,0)-coalesce(tmpalloca,0),coalesce(allocated,0) from sc_mst.stkgdw 
				into vr_onhand_stkgdw,vr_tmpalloca_stkgdw,vr_onhandtemp_stkgdw,vr_alloca_stkgdw where 
				KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE FOR UPDATE;

			--	RAISE NOTICE 'OLD(%)',cast(old.qtybbk as character);
				update sc_mst.stkgdw set 
				tmpalloca=(coalesce(vr_tmpalloca_stkgdw,0)-coalesce(old.qtybbk,0)),
				allocated=(coalesce(allocated,0)+coalesce(old.qtybbk_tmp,0)),
				onhand=(coalesce(onhand,0)-coalesce(old.qtybbk_tmp,0))
				where 
				KDGROUP=OLD.KDGROUP AND KDSUBGROUP=OLD.KDSUBGROUP AND STOCKCODE=OLD.STOCKCODE AND LOCCODE=OLD.LOCCODE;

			elseif(old.status='X') then
				/* NULL TAK MERUBAH QTY STATUS */
			end if;
		END IF;
		RETURN old;	
	END IF;
	
END;
$$;

alter function tr_tmp_stbbk_dtl() owner to postgres;

