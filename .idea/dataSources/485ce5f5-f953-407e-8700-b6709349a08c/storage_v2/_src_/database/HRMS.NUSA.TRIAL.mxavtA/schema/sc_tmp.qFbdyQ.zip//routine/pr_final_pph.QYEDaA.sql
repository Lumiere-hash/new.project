create function pr_final_pph() returns trigger
    language plpgsql
as
$$
declare
     /* 2019-08-09 
	restruktural tabel
     */
	vr_nomor char(30);
	vr_nomor2 char(30);
	vr_nomor3 char(30);
	vr_statussetup char(30);
     
begin


IF (new.status='P' and old.status='F') then

vr_statussetup:=coalesce(trim(status),'') from sc_mst.option where kdoption='PAYROL01';
vr_nomor:=trim(kddept) from sc_tmp.p21_rekap where nodok=new.nodok and kddept=new.kddept;

	if (trim(vr_nomor)!='') or (not vr_nomor is null) then

		vr_nomor2:=to_char(now(),'YY')||case when length(periode_akhir::text)=1 then ('0'||periode_akhir::text)::text else periode_akhir::text end as periode_akhir from sc_tmp.p21_rekap where nodok=new.nodok and kddept=new.kddept;
		vr_nomor3='PPH'||vr_nomor||vr_nomor2;

		/*PERUBAHAN PENAMBAHAN DELETE MASTER DETAIL P21 JIKA EXIST KETIKA GENERATE FINAL 25-02-2017*/
		delete from sc_trx.p21_rekap where nodok=vr_nomor3;
		delete from sc_trx.p21_detail where nodok=vr_nomor3;
		delete from sc_trx.p21_master where nodok=vr_nomor3;

	end if;

			insert into sc_trx.p21_rekap(
				nodok,total_pajak,total_pendapatan,total_potongan,
				input_date,update_date,status,approval_date,approval_by,delete_by,delete_date,cancel_by,cancel_date,periode_mulai,periode_akhir
			    )
			select vr_nomor3,total_pajak,total_pendapatan,total_potongan,
				input_date,update_date,status,approval_date,approval_by,delete_by,delete_date,cancel_by,cancel_date,periode_mulai,periode_akhir

			from sc_tmp.p21_rekap where nodok=new.nodok;

			insert into sc_trx.p21_master (nodok,nik,total_pajak,total_pendapatan,total_potongan,input_date,approval_date,input_by,approval_by,delete_by,cancel_by,
				update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir,status) 
			select vr_nomor3,nik,total_pajak,total_pendapatan,total_potongan,input_date,approval_date,input_by,approval_by,delete_by,cancel_by,
				update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir,new.status as status
				from sc_tmp.p21_master
			where nodok=new.nodok ;
			
			insert into sc_trx.p21_detail(
				nodok,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,status,keterangan,nominal,input_date,approval_date,input_by,
				approval_by,delete_by,cancel_by,update_date,delete_date,cancel_date,update_by,periode_mulai,periode_akhir)
			select vr_nomor3,nik,no_urut,tipe,aksi_tipe,aksi,taxable,tetap,deductible,regular,cash,'P' as status,keterangan,nominal,input_date,null as approval_date,input_by,
				null as approval_by,null as delete_by,null as cancel_by,update_date,null as delete_date,null as cancel_date,update_by,periode_mulai,periode_akhir from sc_tmp.p21_detail
			where nodok=new.nodok ;

			delete from sc_tmp.p21_rekap where nodok=new.nodok and kddept=new.kddept;
			delete from sc_tmp.p21_master where nodok=new.nodok and kddept=new.kddept;
			delete from sc_tmp.p21_detail where nodok=new.nodok;
		
	
end if;

return new;

end;
$$;

alter function pr_final_pph() owner to postgres;

