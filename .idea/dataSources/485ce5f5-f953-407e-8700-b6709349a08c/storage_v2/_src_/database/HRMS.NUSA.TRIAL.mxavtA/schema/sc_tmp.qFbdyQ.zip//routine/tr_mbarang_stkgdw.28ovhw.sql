create function tr_mbarang_stkgdw() returns trigger
    language plpgsql
as
$$
declare
--created by Fiky ::26/07/2017
--triger penomoran mutasi asset referensi mutasi
     vr_nomor char(12); 
     vr_cekprefix char(4);
     vr_nowprefix char(4);
     vr_kdcabang char(12);
     vr_lastdoc numeric;
begin    

	IF TG_OP ='INSERT' THEN 
		/*	
select * from sc_mst.mbarang where kdgroup='BRG'
select * from sc_mst.nomor
insert into sc_mst.nomor VALUES
('MST-MBRG','',4,'','',0,'66666','','201606','T')
--delete from sc_mst.nomor where dokumen='MST-MBRG';
			*/
			delete from sc_mst.penomoran where userid=new.nodok;
			delete from sc_mst.trxerror where userid=new.nodok;  
			--select max(coalesce(trim(split_part(split_part(nodok,kdsubgroup,2),'-',2))::numeric,0)) FROM SC_MST.MBARANG where kdgroup='BRG' and kdsubgroup='RTG';
			vr_lastdoc:=case 
			when max(coalesce(trim(split_part(split_part(nodok,kdsubgroup,2),'-',2))::numeric,0))=0 then 0
			else max(coalesce(trim(split_part(split_part(nodok,kdsubgroup,2),'-',2))::numeric,0)) end lastdoc
			from sc_mst.mbarang 
			---where kdgroup='BRG' and kdsubgroup='ELK';
			where kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup;
		
			----select * from sc_mst.mbarang 
			----where kdgroup='BRG' and kdsubgroup='ELK';
			
			update sc_mst.nomor set docno=vr_lastdoc where dokumen='MST-MBRG';
				
			delete from sc_mst.penomoran where userid=new.inputby and dokumen='MST-MBRG';	
			insert into sc_mst.penomoran 
			(userid,dokumen,nomor,errorid,partid,counterid,xno)
			values(new.inputby,'MST-MBRG',' ',0,' ',1,0);

			vr_nomor:=trim(coalesce(nomor,'')) from sc_mst.penomoran where userid=new.nodok and dokumen='MST-MBRG';			
			
			update sc_mst.mbarang set nodok=trim(kdgroup)||'-'||trim(kdsubgroup)||'-'||vr_nomor
			where nodok=new.nodok;

			insert into sc_mst.mbarang 
			(branch,nodok,nodokref,nmbarang,kdgroup,kdsubgroup,kdgudang,nmpemilik,addpemilik,kdasuransi,kdrangka,kdmesin,nopol,hppemilik,typeid,jenisid,modelid,tahunpembuatan,silinder,
			warna,bahanbakar,warnatnkb,tahunreg,nobpkb,kdlokasi,expstnkb,exppkbstnkb,nopkb,nominalpkb,pprogresif,brand,hold_item,typebarang,qty,expdate,expasuransi,userpakai,kddept,
			kdsubdept,kdjabatan,startpakai,endpakai,keterangan,inputdate,inputby,updatedate,updateby,onhand,allocated,uninvoiced,tmpalloca,satkecil,kdsubasuransi,lasttrxdate,lasttrxdoc)
			(select branch,trim(kdgroup)||'-'||trim(kdsubgroup)||'-'||vr_nomor,nodokref,nmbarang,kdgroup,kdsubgroup,kdgudang,nmpemilik,addpemilik,kdasuransi,kdrangka,kdmesin,nopol,hppemilik,typeid,jenisid,modelid,tahunpembuatan,silinder,
			warna,bahanbakar,warnatnkb,tahunreg,nobpkb,kdlokasi,expstnkb,exppkbstnkb,nopkb,nominalpkb,pprogresif,brand,hold_item,typebarang,qty,expdate,expasuransi,userpakai,kddept,
			kdsubdept,kdjabatan,startpakai,endpakai,keterangan,inputdate,inputby,updatedate,updateby,onhand,allocated,uninvoiced,tmpalloca,satkecil,kdsubasuransi,lasttrxdate,lasttrxdoc
			from sc_tmp.mbarang where nodok=new.nodok);

			delete from sc_tmp.mbarang where nodok=new.nodok;
	RETURN NEW;
	ELSEIF TG_OP ='UPDATE' THEN
	
			
		
	RETURN NEW;
	
	END IF;
    
    return new;
        
end;
$$;

alter function tr_mbarang_stkgdw() owner to postgres;

