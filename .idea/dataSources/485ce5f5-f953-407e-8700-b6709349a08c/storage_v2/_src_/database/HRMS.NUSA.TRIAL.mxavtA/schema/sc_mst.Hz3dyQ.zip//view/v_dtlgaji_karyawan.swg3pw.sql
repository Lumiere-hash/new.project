create view v_dtlgaji_karyawan
            (branch, nik, nmlengkap, callname, jk, neglahir, provlahir, kotalahir, tgllahir, kd_agama, stswn, stsfisik,
             ketfisik, noktp, ktp_seumurhdp, ktpdikeluarkan, tgldikeluarkan, status_pernikahan, gol_darah, negktp,
             provktp, kotaktp, kecktp, kelktp, alamatktp, negtinggal, provtinggal, kotatinggal, kectinggal, keltinggal,
             alamattinggal, nohp1, nohp2, npwp, tglnpwp, bag_dept, subbag_dept, jabatan, lvl_jabatan, grade_golongan,
             nik_atasan, nik_atasan2, status_ptkp, besaranptkp, tglmasukkerja, tglkeluarkerja, masakerja,
             statuskepegawaian, kdcabang, branchaktif, grouppenggajian, gajipokok, gajibpjs, namabank,
             namapemilikrekening, norek, tjshift, idabsen, email, bolehcuti, sisacuti, inputdate, inputby, updatedate,
             updateby, image, idmesin, cardnumber, status, tgl_ktp, costcenter, tj_tetap, gajitetap, gajinaker,
             tjlembur, tjborong, nokk, kdwilayahnominal, kdgradejabatan, gaji, tj_prestasi, tj_jabatan, tj_masakerja,
             nmdept, nmsubdept, nmlvljabatan, nmjabatan, nmatasan, nmatasan2, gajibpjs1, gajinaker1, nmwilayahnominal,
             kdlvlgp, nmgradejabatan)
as
SELECT a.branch,
       a.nik,
       a.nmlengkap,
       a.callname,
       a.jk,
       a.neglahir,
       a.provlahir,
       a.kotalahir,
       a.tgllahir,
       a.kd_agama,
       a.stswn,
       a.stsfisik,
       a.ketfisik,
       a.noktp,
       a.ktp_seumurhdp,
       a.ktpdikeluarkan,
       a.tgldikeluarkan,
       a.status_pernikahan,
       a.gol_darah,
       a.negktp,
       a.provktp,
       a.kotaktp,
       a.kecktp,
       a.kelktp,
       a.alamatktp,
       a.negtinggal,
       a.provtinggal,
       a.kotatinggal,
       a.kectinggal,
       a.keltinggal,
       a.alamattinggal,
       a.nohp1,
       a.nohp2,
       a.npwp,
       a.tglnpwp,
       a.bag_dept,
       a.subbag_dept,
       a.jabatan,
       a.lvl_jabatan,
       a.grade_golongan,
       a.nik_atasan,
       a.nik_atasan2,
       a.status_ptkp,
       a.besaranptkp,
       a.tglmasukkerja,
       a.tglkeluarkerja,
       a.masakerja,
       a.statuskepegawaian,
       a.kdcabang,
       a.branchaktif,
       a.grouppenggajian,
       a.gajipokok,
       a.gajibpjs,
       a.namabank,
       a.namapemilikrekening,
       a.norek,
       a.tjshift,
       a.idabsen,
       a.email,
       a.bolehcuti,
       a.sisacuti,
       a.inputdate,
       a.inputby,
       a.updatedate,
       a.updateby,
       a.image,
       a.idmesin,
       a.cardnumber,
       a.status,
       a.tgl_ktp,
       a.costcenter,
       round(a.tj_tetap)                                        AS tj_tetap,
       round(a.gajitetap)                                       AS gajitetap,
       round(a.gajinaker)                                       AS gajinaker,
       a.tjlembur,
       a.tjborong,
       a.nokk,
       a.kdwilayahnominal,
       a.kdgradejabatan,
       b.gaji,
       b.tj_prestasi,
       b.tj_jabatan,
       b.tj_masakerja,
       b1.nmdept,
       c.nmsubdept,
       d.nmlvljabatan,
       e.nmjabatan,
       f.nmlengkap                                              AS nmatasan,
       g.nmlengkap                                              AS nmatasan2,
       to_char(round(a.gajibpjs, 0), '999G999G999G990D'::text)  AS gajibpjs1,
       to_char(round(a.gajinaker, 0), '999G999G999G990D'::text) AS gajinaker1,
       h.nmwilayahnominal,
       i.kdlvlgp,
       j.nmgradejabatan
FROM sc_mst.karyawan a
         LEFT JOIN (SELECT x.nik,
                           to_char(round(sum(x.gaji), 0), '999G999G999G990D'::text)         AS gaji,
                           to_char(round(sum(x.tj_prestasi), 0), '999G999G999G990D'::text)  AS tj_prestasi,
                           to_char(round(sum(x.tj_jabatan), 0), '999G999G999G990D'::text)   AS tj_jabatan,
                           to_char(round(sum(x.tj_masakerja), 0), '999G999G999G990D'::text) AS tj_masakerja
                    FROM (SELECT dtlgaji_karyawan.nik,
                                 dtlgaji_karyawan.nominal AS gaji,
                                 0.00                     AS tj_prestasi,
                                 0.00                     AS tj_jabatan,
                                 0.00                     AS tj_masakerja
                          FROM sc_mst.dtlgaji_karyawan
                          WHERE dtlgaji_karyawan.no_urut = 1
                          UNION ALL
                          SELECT dtlgaji_karyawan.nik,
                                 0.00                     AS gaji,
                                 dtlgaji_karyawan.nominal AS tj_prestasi,
                                 0.00                     AS tj_jabatan,
                                 0.00                     AS tj_masakerja
                          FROM sc_mst.dtlgaji_karyawan
                          WHERE dtlgaji_karyawan.no_urut = 9
                          UNION ALL
                          SELECT dtlgaji_karyawan.nik,
                                 0.00                     AS gaji,
                                 0.00                     AS tj_prestasi,
                                 dtlgaji_karyawan.nominal AS tj_jabatan,
                                 0.00                     AS tj_masakerja
                          FROM sc_mst.dtlgaji_karyawan
                          WHERE dtlgaji_karyawan.no_urut = 7
                          UNION ALL
                          SELECT dtlgaji_karyawan.nik,
                                 0.00                     AS gaji,
                                 0.00                     AS tj_prestasi,
                                 0.00                     AS tj_jabatan,
                                 dtlgaji_karyawan.nominal AS tj_masakerja
                          FROM sc_mst.dtlgaji_karyawan
                          WHERE dtlgaji_karyawan.no_urut = 8) x
                    GROUP BY x.nik) b ON a.nik = b.nik
         LEFT JOIN sc_mst.departmen b1 ON a.bag_dept = b1.kddept
         LEFT JOIN sc_mst.subdepartmen c ON a.subbag_dept = c.kdsubdept AND c.kddept = a.bag_dept
         LEFT JOIN sc_mst.lvljabatan d ON a.lvl_jabatan = d.kdlvl
         LEFT JOIN sc_mst.jabatan e ON a.jabatan = e.kdjabatan AND e.kdsubdept = a.subbag_dept AND e.kddept = a.bag_dept
         LEFT JOIN sc_mst.karyawan f ON a.nik_atasan = f.nik
         LEFT JOIN sc_mst.karyawan g ON a.nik_atasan2 = g.nik
         LEFT JOIN sc_mst.m_wilayah_nominal h ON a.kdwilayahnominal = h.kdwilayahnominal
         LEFT JOIN sc_mst.m_lvlgp i ON a.kdlvlgp = i.kdlvlgp
         LEFT JOIN sc_mst.m_grade_jabatan j ON a.kdgradejabatan = j.kdgradejabatan
WHERE COALESCE(a.statuskepegawaian, ''::bpchar) <> 'KO'::bpchar
  AND a.nik IS NOT NULL;

alter table v_dtlgaji_karyawan
    owner to postgres;

