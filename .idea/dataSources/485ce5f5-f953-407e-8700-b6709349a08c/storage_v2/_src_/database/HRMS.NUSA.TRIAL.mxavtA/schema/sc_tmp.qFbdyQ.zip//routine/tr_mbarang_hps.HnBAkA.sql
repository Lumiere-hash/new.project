create function tr_mbarang_hps() returns trigger
    language plpgsql
as
$$
declare
--created by Fiky ::26/07/2017
--triger penomoran penghapusan asset
     vr_nomor char(12); 
     vr_cekprefix char(4);
     vr_nowprefix char(4);
begin    

	IF TG_OP ='INSERT' THEN 
		update sc_tmp.mbarang_hps a set 
		nodokref=b.nodokref,nmbarang=b.nmbarang,kdgroup=b.kdgroup,kdsubgroup=b.kdsubgroup,kdgudang=b.kdgudang,nmpemilik=b.nmpemilik,
		addpemilik=b.addpemilik,kdasuransi=b.kdasuransi,kdrangka=b.kdrangka,kdmesin=b.kdmesin,nopol=b.nopol,hppemilik=b.hppemilik,
		typeid=b.typeid,jenisid=b.jenisid,modelid=b.modelid,tahunpembuatan=b.tahunpembuatan,silinder=b.silinder,warna=b.warna,
		bahanbakar=b.bahanbakar,warnatnkb=b.warnatnkb,tahunreg=b.tahunreg,nobpkb=b.nobpkb,kdlokasi=b.kdlokasi,expstnkb=b.expstnkb,exppkbstnkb=b.exppkbstnkb,
		nopkb=b.nopkb,nominalpkb=b.nominalpkb,pprogresif=b.pprogresif,brand=b.brand,hold_item=b.hold_item,typebarang=b.typebarang,qty=b.qty,expdate=b.expdate,expasuransi=b.expasuransi,
		userpakai=b.userpakai,kddept=b.kddept,kdsubdept=b.kdsubdept,kdjabatan=b.kdjabatan,startpakai=b.startpakai,endpakai=b.endpakai,keterangan=b.keterangan 
		from sc_mst.mbarang b where b.nodok=a.kdbarang;

			delete from sc_mst.penomoran where userid=new.nodok;
			delete from sc_mst.trxerror where userid=new.nodok;    

			select trim(split_part(trim(prefix),'SHPS',2)) as cekprefix into vr_cekprefix from sc_mst.nomor where dokumen='MTAS_HPSAST';
			select to_char(now(),'YYMM') as cekbulan into vr_nowprefix;
			if(vr_nowprefix<>vr_cekprefix) then 
				update sc_mst.nomor set prefix='SHPS'||vr_nowprefix,docno=0 where dokumen='MTAS_HPSAST';
			end if;
			insert into sc_mst.penomoran 
			(userid,dokumen,nomor,errorid,partid,counterid,xno)
			values(new.nodok,'MTAS_HPSAST',' ',0,' ',1,0);
			vr_nomor:=trim(coalesce(nomor,'')) from sc_mst.penomoran where userid=new.nodok;
			
			insert into sc_his.mbarang_hps
			(branch,nodok,kdbarang,nodokref,nmbarang,kdgroup,kdsubgroup,kdgudang,nmpemilik,addpemilik,kdasuransi,kdrangka,kdmesin,nopol,hppemilik,typeid,jenisid,modelid,tahunpembuatan,
			silinder,warna,bahanbakar,warnatnkb,tahunreg,nobpkb,kdlokasi,expstnkb,exppkbstnkb,nopkb,nominalpkb,pprogresif,brand,hold_item,typebarang,qty,expdate,expasuransi,userpakai,
			kddept,kdsubdept,kdjabatan,startpakai,endpakai,keterangan,keterangan_hps,usertau,status,inputdate,inputby,updatedate,updateby,deletedate,deleteby)
			(select branch,vr_nomor,kdbarang,nodokref,nmbarang,kdgroup,kdsubgroup,kdgudang,nmpemilik,addpemilik,kdasuransi,kdrangka,kdmesin,nopol,hppemilik,typeid,jenisid,modelid,tahunpembuatan,
			silinder,warna,bahanbakar,warnatnkb,tahunreg,nobpkb,kdlokasi,expstnkb,exppkbstnkb,nopkb,nominalpkb,pprogresif,brand,hold_item,typebarang,qty,expdate,expasuransi,userpakai,
			kddept,kdsubdept,kdjabatan,startpakai,endpakai,keterangan,keterangan_hps,usertau,status,inputdate,inputby,updatedate,updateby,deletedate,deleteby
			from sc_tmp.mbarang_hps where nodok=new.nodok);
			delete from sc_tmp.mbarang_hps where nodok=new.nodok;
		
	RETURN NEW;
	ELSEIF TG_OP ='UPDATE' THEN

				
	RETURN NEW;
	END IF;
/*
select * from sc_tmp.mtsasset
select * from sc_his.mtsasset
--truncate sc_tmp.sk_mtsasset,sc_his.mtsasset
select * from sc_mst.nomor
insert into sc_mst.nomor VALUES
('MTAS_HPSAST','',4,'SHPS1706','',0,'66666','','201606','T')
--delete from sc_mst.nomor where dokumen='MTAS_HPSAST';
*/
     
    
    return new;
        
end;
$$;

alter function tr_mbarang_hps() owner to postgres;

