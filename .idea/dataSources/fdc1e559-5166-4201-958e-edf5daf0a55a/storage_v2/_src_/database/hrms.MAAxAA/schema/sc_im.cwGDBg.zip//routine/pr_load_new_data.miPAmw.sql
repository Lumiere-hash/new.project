create function pr_load_new_data(vr_userid character) returns character
    language plpgsql
as
$$
DECLARE 
/*PROSEDUR UNTUK REMINDER KARYAWAN*/
/* AUTHOR : FIKY*/
vr_nik char(12);

BEGIN	
--karyawan 	
	/* not exist */
	insert into sc_mst.karyawan
	(select * from sc_im.karyawan where nik not in (select nik from sc_mst.karyawan));
	/* if exist */
	update sc_mst.karyawan a SET 
					branch             = b.branch                ,    
					nik                = b.nik                   ,    
					nmlengkap          = b.nmlengkap             ,    
					callname           = b.callname              ,    
					jk                 = b.jk                    ,    
					neglahir           = b.neglahir              ,    
					provlahir          = b.provlahir             ,    
					kotalahir          = b.kotalahir             ,    
					tgllahir           = b.tgllahir              ,    
					kd_agama           = b.kd_agama              ,    
					stswn              = b.stswn                 ,    
					stsfisik           = b.stsfisik              ,    
					ketfisik           = b.ketfisik              ,    
					noktp              = b.noktp                 ,    
					ktp_seumurhdp      = b.ktp_seumurhdp         ,    
					ktpdikeluarkan     = b.ktpdikeluarkan        ,    
					tgldikeluarkan     = b.tgldikeluarkan        ,    
					status_pernikahan  = b.status_pernikahan     ,    
					gol_darah          = b.gol_darah             ,    
					negktp             = b.negktp                ,    
					provktp            = b.provktp               ,    
					kotaktp            = b.kotaktp               ,    
					kecktp             = b.kecktp                ,    
					kelktp             = b.kelktp                ,    
					alamatktp          = b.alamatktp             ,    
					negtinggal         = b.negtinggal            ,    
					provtinggal        = b.provtinggal           ,    
					kotatinggal        = b.kotatinggal           ,    
					kectinggal         = b.kectinggal            ,    
					keltinggal         = b.keltinggal            ,    
					alamattinggal      = b.alamattinggal         ,    
					nohp1              = b.nohp1                 ,    
					nohp2              = b.nohp2                 ,    
					npwp               = b.npwp                  ,    
					tglnpwp            = b.tglnpwp               ,    
					bag_dept           = b.bag_dept              ,    
					subbag_dept        = b.subbag_dept           ,    
					jabatan            = b.jabatan               ,    
					lvl_jabatan        = b.lvl_jabatan           ,    
					grade_golongan     = b.grade_golongan        ,    
					nik_atasan         = b.nik_atasan            ,    
					nik_atasan2        = b.nik_atasan2           ,    
					status_ptkp        = b.status_ptkp           ,    
					besaranptkp        = b.besaranptkp           ,    
					tglmasukkerja      = b.tglmasukkerja         ,    
					tglkeluarkerja     = b.tglkeluarkerja        ,    
					masakerja          = b.masakerja             ,    
					statuskepegawaian  = b.statuskepegawaian     ,    
					kdcabang           = b.kdcabang              ,    
					branchaktif        = b.branchaktif           ,    
					grouppenggajian    = b.grouppenggajian       ,    
					--gajipokok          = b.gajipokok             ,    
					--gajibpjs           = b.gajibpjs              ,    
					namabank           = b.namabank              ,    
					namapemilikrekening= b.namapemilikrekening   ,    
					norek              = b.norek                 ,    
					tjshift            = b.tjshift               ,    
					idabsen            = b.idabsen               ,    
					email              = b.email                 ,    
					bolehcuti          = b.bolehcuti             ,    
					sisacuti           = b.sisacuti              ,    
					inputdate          = b.inputdate             ,    
					inputby            = b.inputby               ,    
					updatedate         = b.updatedate            ,    
					updateby           = b.updateby              ,    
					image              = b.image                 ,    
					idmesin            = b.idmesin               ,    
					cardnumber         = b.cardnumber            ,    
					status             = b.status                ,    
					tgl_ktp            = b.tgl_ktp               ,    
					costcenter         = b.costcenter            ,    
					tj_tetap           = b.tj_tetap              ,    
					--gajitetap          = b.gajitetap             ,    
					--gajinaker          = b.gajinaker             ,    
					--tjlembur           = b.tjlembur              ,    
					--tjborong           = b.tjborong              ,    
					nokk               = b.nokk                  ,    
					kdwilayahnominal   = b.kdwilayahnominal      ,    
					kdlvlgp            = b.kdlvlgp               ,    
					pinjaman           = b.pinjaman                  
	from sc_im.karyawan b where a.nik=b.nik; 
--status_kepegawaian 	
	/* not exist */
	insert into sc_trx.status_kepegawaian
	(select * from sc_im.status_kepegawaian where nodok not in (select nodok from sc_trx.status_kepegawaian));
--sc_trx.bpjs_karyawan	
	/* not exist */
	insert into sc_trx.bpjs_karyawan
	(select * from sc_im.bpjs_karyawan where trim(coalesce(kode_bpjs,''))||trim(coalesce(nik,'')) not in (select  trim(coalesce(kode_bpjs,''))||trim(coalesce(nik,'')) from sc_trx.bpjs_karyawan));
--sc_im.riwayat_keluarga	
	/* not exist */
	insert into sc_trx.riwayat_keluarga
	(select * from sc_im.riwayat_keluarga where trim(coalesce(kdkeluarga,''))||trim(coalesce(nik,'')) not in (select  trim(coalesce(kdkeluarga,''))||trim(coalesce(nik,'')) from sc_trx.riwayat_keluarga));
--sc_im.riwayat_kesehatan	
	/* not exist */
	insert into sc_trx.riwayat_kesehatan
	(select * from sc_im.riwayat_kesehatan where trim(periode)||trim(kdpenyakit)||trim(nik) not in (select  trim(periode)||trim(kdpenyakit)||trim(nik) from sc_trx.riwayat_kesehatan));
--sc_im.riwayat_kompetensi	
	/* not exist */
	insert into sc_trx.riwayat_kompetensi
	(select * from sc_im.riwayat_kompetensi where trim(lvl_indikator)||trim(kdkom)||trim(nik) not in (select  trim(lvl_indikator)||trim(kdkom)||trim(nik) from sc_trx.riwayat_kompetensi));
--sc_im.riwayat_pendidikan	
	/* not exist */
	insert into sc_trx.riwayat_pendidikan
	(select * from sc_im.riwayat_pendidikan where trim(coalesce(kdpendidikan,''))||trim(coalesce(nik,'')) not in (select  trim(kdpendidikan)||trim(nik) from sc_trx.riwayat_pendidikan));
--sc_im.riwayat_pendidikan_nf	
	/* not exist */
	insert into sc_trx.riwayat_pendidikan_nf
	(select * from sc_im.riwayat_pendidikan_nf where trim(kdkeahlian)||trim(nik) not in (select  trim(kdkeahlian)||trim(nik) from sc_trx.riwayat_pendidikan_nf));
--sc_im.riwayat_pengalaman	
	/* not exist */
	insert into sc_trx.riwayat_pengalaman
	(select * from sc_im.riwayat_pengalaman where trim(no_urut::text)||trim(nik) not in (select  trim(no_urut::text)||trim(nik) from sc_trx.riwayat_pengalaman));
--sc_im.riwayat_rekam_medis	
	/* not exist */
	insert into sc_trx.riwayat_rekam_medis
	(select * from sc_im.riwayat_rekam_medis where trim(kdrekam_medis)||trim(nik) not in (select  trim(kdrekam_medis)||trim(nik) from sc_trx.riwayat_rekam_medis));
--sc_im.cek_absen
	/* not exist */
	insert into sc_tmp.cek_absen
	(select * from sc_im.cek_absen where trim(nodok_ref)||trim(nik) not in (select  trim(nodok_ref)||trim(nik) from sc_tmp.cek_absen));
--sc_im.cek_lembur
	/* not exist */
	insert into sc_tmp.cek_lembur
	(select * from sc_im.cek_lembur where trim(nodok_ref)||trim(nik) not in (select  trim(nodok_ref)||trim(nik) from sc_tmp.cek_lembur));	
--sc_im.cek_borong
	/* not exist */
	insert into sc_tmp.cek_borong
	(select * from sc_im.cek_borong where trim(nodok_ref)||trim(nik) not in (select  trim(nodok_ref)||trim(nik) from sc_tmp.cek_borong));	
--sc_im.cek_shift
	/* not exist */
	insert into sc_tmp.cek_shift
	(select * from sc_im.cek_shift where  trim(tgl_kerja::text)||trim(tpshift)||trim(nik) not in (select  trim(tgl_kerja::text)||trim(tpshift)||trim(nik) from sc_tmp.cek_shift));	
--sc_im.jadwalkerja
	/* not exist */
	insert into sc_trx.jadwalkerja
	(select * from sc_im.jadwalkerja where trim(tgl::text)||trim(kdregu)||trim(kodejamkerja) not in (select  trim(tgl::text)||trim(kdregu)||trim(kodejamkerja) from sc_trx.jadwalkerja));	
--sc_im.transready
	/* not exist */
	ALTER TABLE sc_trx.transready DISABLE TRIGGER tr_transready_uangmkn;
	insert into sc_trx.transready	
	(select * from sc_im.transready where trim(coalesce(tgl::text,''))||trim(coalesce(kdregu,''))||trim(coalesce(kdjamkerja,''))||trim(coalesce(nik,'')) not in 
	(select  trim(coalesce(tgl::text,''))||trim(coalesce(kdregu,''))||trim(coalesce(kdjamkerja,''))||trim(coalesce(nik,'')) from sc_trx.transready where to_char(tgl,'yyyymm')=to_char(now(),'yyyymm')) and to_char(tgl,'yyyymm')=to_char(now(),'yyyymm'));	
	ALTER TABLE sc_trx.transready ENABLE TRIGGER tr_transready_uangmkn;
--sc_im.m_lvlgp
	/* not exist */	
	insert into sc_mst.m_lvlgp
	(select * from sc_im.m_lvlgp where trim(coalesce(kdlvlgp,'')) not in (select trim(coalesce(kdlvlgp,'')) from sc_mst.m_lvlgp));

	update sc_mst.m_lvlgp a set 
	c_hold=b.c_hold, 
	inputby=b.inputby, 
	inputdate=b.inputdate
	from sc_im.m_lvlgp b where a.kdlvlgp=b.kdlvlgp;
--sc_im.kdmasakerja
	/* not exist */	
	insert into sc_mst.m_masakerja
	(select * from sc_im.m_masakerja where trim(coalesce(kdmasakerja,'')) not in (select trim(coalesce(kdmasakerja,'')) from sc_mst.m_masakerja));

	update sc_mst.m_masakerja a set
	nmmasakerja = b.nmmasakerja,
	awal = b.awal,
	akhir = b.akhir,
	c_hold = b.c_hold,
	inputby=b.inputby, 
	inputdate=b.inputdate
	from sc_im.m_masakerja b where a.kdmasakerja=b.kdmasakerja;			
--sc_im.m_wilayah
	/* not exist */	
	insert into sc_mst.m_wilayah
	(select * from sc_im.m_wilayah where trim(coalesce(kdwilayah,'')) not in (select trim(coalesce(kdwilayah,'')) from sc_mst.m_wilayah));
	
	update sc_mst.m_wilayah a set 
	nmwilayah=b.nmwilayah, 
	c_hold=b.c_hold, 
	inputby=b.inputby, 
	inputdate=b.inputdate
	from sc_im.m_wilayah b where a.kdwilayah=b.kdwilayah;
--sc_im.m_wilayah_nominal
	/* not exist */	
	ALTER TABLE sc_mst.m_wilayah_nominal DISABLE TRIGGER tr_m_wilayah_nominal;
	
	insert into sc_mst.m_wilayah_nominal
	(select * from sc_im.m_wilayah_nominal where trim(coalesce(kdwilayahnominal,'')) not in (select trim(coalesce(kdwilayahnominal,'')) from sc_mst.m_wilayah_nominal));		

	update sc_mst.m_wilayah_nominal a set 
	nmwilayahnominal=b.nmwilayahnominal,
	golongan=b.golongan, 
	c_hold=b.c_hold, 
	inputby=b.inputby, 
	inputdate=b.inputdate
	from sc_im.m_wilayah_nominal b where a.kdwilayahnominal=b.kdwilayahnominal;
--sc_im.jobgrade
	/* not exist */	
	insert into sc_mst.jobgrade
	(select * from sc_im.jobgrade where trim(coalesce(kdgrade,'')) not in (select trim(coalesce(kdgrade,'')) from sc_mst.jobgrade));

	update sc_mst.jobgrade a set
	nmgrade = b.nmgrade,
	golongan = b.golongan,
	bobot1 = b.bobot1,
	bobot2 = b.bobot2,
	keterangan = b.keterangan,
	input_date = b.input_date,
	input_by = b.input_by,
	update_date = b.update_date,
	update_by = b.update_by,
	kdlvl = b.kdlvl,
	kdlvlgpmin = b.kdlvlgpmin,
	kdlvlgpmax = b.kdlvlgpmax
	from sc_im.jobgrade b where a.kdgrade=b.kdgrade;	
--sc_im.jabatan
	/* not exist */	
	insert into sc_mst.jabatan
	(select * from sc_im.jabatan where trim(coalesce(kdjabatan,'')) not in (select trim(coalesce(kdjabatan,'')) from sc_mst.jabatan));

	update sc_mst.jabatan a set 
	nmjabatan = b.nmjabatan,
	kddept = b.kddept,
	kdsubdept = b.kdsubdept,
	kdgrade = b.kdgrade,
	costcenter = b.costcenter,
	uraian = b.uraian,
	shift = b.lembur,
	input_date = b.input_date,
	input_by = b.input_by,
	update_date = b.update_date,
	update_by = b.update_by,
	kdlvl = b.kdlvl
	from sc_im.jabatan b where 
	a.kdjabatan = b.kdjabatan and a.kddept = b.kddept and a.kdsubdept = b.kdsubdept;


	update sc_tmp.cek_lembur set nodok=vr_userid;	
	update sc_tmp.cek_borong set nodok=vr_userid;	
	update sc_tmp.cek_shift set nodok=vr_userid;	
	update sc_tmp.cek_absen set nodok=vr_userid;	
	RETURN vr_userid;
END;
$$;

alter function pr_load_new_data(char) owner to postgres;

