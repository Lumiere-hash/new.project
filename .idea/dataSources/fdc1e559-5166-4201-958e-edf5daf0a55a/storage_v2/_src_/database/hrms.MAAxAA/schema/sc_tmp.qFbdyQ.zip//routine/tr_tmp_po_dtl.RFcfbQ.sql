create function tr_tmp_po_dtl() returns trigger
    language plpgsql
as
$$
DECLARE 
	--author by fiky: 12/08/2017
	--update by fiky: 02/05/2018
	--update cari ppn netto - dpp
     vr_nomor char(12); 
     vr_cekprefix char(4);
     vr_nowprefix char(4);  
     vr_qtypbk numeric;  
     vr_qtybbk numeric;  
     vr_qtyonhand numeric;  

BEGIN		
	IF tg_op = 'INSERT' THEN
		--select * from sc_tmp.po_mst;
		--select * from sc_tmp.po_dtl;
		
		--select sum(coalesce(qtytotalprice,0)) from sc_tmp.po_dtl where nodok='1115.184';
		--alter table sc_tmp.po_dtl add column id_nomor integer;
		--alter table sc_trx.po_dtl add column id_nomor integer;
		update  sc_tmp.po_dtl a set id=a1.urutnya
		from (select a1.*,row_number() over(partition by nodok order by id asc) as urutnya
		from sc_tmp.po_dtl a1) a1
		where a.id=a1.id and a.nodok=a1.nodok and a.kdgroup=a1.kdgroup and a.kdsubgroup=a1.kdsubgroup and a.stockcode=a1.stockcode
		and a.nodok=new.nodok and a.id>=new.id ;
			
		update sc_tmp.po_mst set ttlbrutto=(select sum(coalesce(ttlbrutto,0)) from sc_tmp.po_dtl where nodok=new.nodok) 
		where nodok=new.nodok;

		--select * from sc_tmp.po_dtl
		/* UPDATE REBALANCE */
		update sc_tmp.po_dtl set status='' where id=new.id and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode;
		
		delete from sc_mst.trxerror where userid=new.nodok and modul='TMPPO';
		insert into sc_mst.trxerror
		(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
		(new.nodok,0,new.nodok,'','TMPPO');
		RETURN new;
	ELSEIF tg_op = 'UPDATE' THEN
	

		--select *,ttlbrutto from sc_tmp.po_dtl
		
		--update sc_tmp.po_dtl set status='I'
		
		IF (new.status='' and old.status!='') then
		update sc_tmp.po_dtl set 
		qtyminta=round(coalesce(qtykecil,0)/(select coalesce(qty,0) from sc_mst.mapping_satuan_brg where kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and satkecil=new.satkecil and satbesar=new.satminta))
		where nodok=new.nodok and stockcode=new.stockcode and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and id=new.id;
		
		update sc_tmp.po_dtl a 
		set 
		ttlbrutto=coalesce(b.qtyminta,0)*coalesce(b.unitprice,0)
		from sc_tmp.po_dtl b
		where a.nodok=b.nodok and a.stockcode=b.stockcode and a.kdgroup=b.kdgroup and a.kdsubgroup=b.kdsubgroup and a.id=b.id and
		a.nodok=new.nodok and a.stockcode=new.stockcode and a.kdgroup=new.kdgroup and a.kdsubgroup=new.kdsubgroup and a.id=new.id;



		
		update sc_tmp.po_dtl a 	set 
			ttldiskon=b.ttldiskon,
			ttldpp=b.ttldpp,
			ttlppn=b.ttlppn,
			ttlnetto=b.ttlnetto, 
			status=old.status from 
			(select	b.branch,b.nodok,b.kdgroup,b.kdsubgroup,b.stockcode,b.loccode,b.nodokref,b.desc_barang,b.id,b.pkp,b.exppn,ttlbrutto,round(qtyminta*(unitprice-(unitprice*(1-(disc1/100))*(1-(disc2/100))*(1-(disc3/100)))),0) as ttldiskon,
				case when coalesce(b.pkp,'')='YES' and coalesce(b.exppn,'')='EXC' then
				round(b.ttlbrutto-round(qtyminta*(unitprice-(unitprice*(1-(disc1/100))*(1-(disc2/100))*(1-(disc3/100)))),0))
				when coalesce(b.pkp,'')='YES' and coalesce(b.exppn,'')='INC' then
				round(round(b.ttlbrutto-round(qtyminta*(unitprice-(unitprice*(1-(disc1/100))*(1-(disc2/100))*(1-(disc3/100)))),0))/1.1)
				else 0 end as ttldpp,
				case 
				when coalesce(b.pkp,'')='YES' and coalesce(b.exppn,'')='EXC' then
				round(round(round(b.ttlbrutto-round(qtyminta*(unitprice-(unitprice*(1-(disc1/100))*(1-(disc2/100))*(1-(disc3/100)))),0)))*(10::numeric/100))
				when coalesce(b.pkp,'')='YES' and coalesce(b.exppn,'')='INC' then
				coalesce(ttlbrutto,0)-round(round(b.ttlbrutto-round(qtyminta*(unitprice-(unitprice*(1-(disc1/100))*(1-(disc2/100))*(1-(disc3/100)))),0))/1.1)
				else 0 end ttlppn,
				case 
					when coalesce(b.pkp,'')='YES' and coalesce(b.exppn,'')='EXC' then
					round(b.ttlbrutto-round(qtyminta*(unitprice-(unitprice*(1-(disc1/100))*(1-(disc2/100))*(1-(disc3/100)))),0)) +
					round(round(round(b.ttlbrutto-round(qtyminta*(unitprice-(unitprice*(1-(disc1/100))*(1-(disc2/100))*(1-(disc3/100)))),0)))*(10::numeric/100))
					when coalesce(b.pkp,'')='YES' and coalesce(b.exppn,'')='INC' then
					round(round(b.ttlbrutto-round(qtyminta*(unitprice-(unitprice*(1-(disc1/100))*(1-(disc2/100))*(1-(disc3/100)))),0))/1.1) +
					coalesce(ttlbrutto,0)-round(round(b.ttlbrutto-round(qtyminta*(unitprice-(unitprice*(1-(disc1/100))*(1-(disc2/100))*(1-(disc3/100)))),0))/1.1)
					else round(coalesce(b.ttlbrutto,0)-round(qtyminta*(unitprice-(unitprice*(1-(disc1/100))*(1-(disc2/100))*(1-(disc3/100)))),0))
					end as ttlnetto
				from sc_tmp.po_dtl b) b
		where a.nodok=b.nodok and a.stockcode=b.stockcode and a.kdgroup=b.kdgroup and a.kdsubgroup=b.kdsubgroup and a.id=b.id and
		a.nodok=new.nodok and a.stockcode=new.stockcode and a.kdgroup=new.kdgroup and a.kdsubgroup=new.kdsubgroup and a.id=new.id;


		update sc_tmp.po_mst set 
		ttlbrutto=(select sum(coalesce(ttlbrutto,0)) from sc_tmp.po_dtl where nodok=new.nodok),
		ttldiskon=(select sum(coalesce(ttldiskon,0)) from sc_tmp.po_dtl where nodok=new.nodok),
		ttldpp=(select sum(coalesce(ttldpp,0)) from sc_tmp.po_dtl where nodok=new.nodok),
		ttlppn=(select sum(coalesce(ttlppn,0)) from sc_tmp.po_dtl where nodok=new.nodok),
		ttlnetto=(select sum(coalesce(ttlnetto,0)) from sc_tmp.po_dtl where nodok=new.nodok)
		where nodok=new.nodok;
		end if;
/*
		if(paramcheckdiskon=='YES'){
			var totaldiskon=Math.round((param1*(paramdisc1/100))+((param1*(paramdisc1/100))*(paramdisc2/100))+(((param1*(paramdisc1/100))*(paramdisc2/100))*(paramdisc3/100)));
		} else {
			var totaldiskon=Math.round((param1*(0/100))+(param1*(0/100))+(param1*(0/100)));
		}
			
		if(paramcheckppn=='YES'){
			if(paramcheckexppn=='EXC'){
				var totaldpp=Math.round((param1-totaldiskon)/1.1);
				var totalppn=Math.round(((param1-totaldiskon)/1.1)*(10/100));
				var vattlnetto=totaldpp+totalppn;
			} else if (paramcheckexppn=='INC') {
				var totaldpp=Math.round((param1-totaldiskon)/1.1);;
				var totalppn=Math.round(((param1-totaldiskon)/1.1)*(10/100));
				var vattlnetto=(param1-totaldiskon);
			}
				
		} else if (paramcheckppn=='NO') {
				var totaldpp=0;
				var totalppn=0;
				var vattlnetto=(param1-totaldiskon);
		}

*/

		--update sc_tmp.po_mst a set a.ttlbrutto=(select sum(coalesce(b.ttlbrutto,0)),a.status='' from sc_tmp.po_dtl b where a.nodok=new.nodok) 
		--where b.nodok=new.nodok ;


		
		delete from sc_mst.trxerror where userid=new.nodok and modul='TMPPO';
		insert into sc_mst.trxerror
		(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
		(new.nodok,0,new.nodok,'','TMPPO');
		RETURN new;
	ELSEIF tg_op = 'DELETE' THEN


		update  sc_tmp.po_dtl a set id=a1.urutnya
		from (select a1.*,row_number() over(partition by nodok order by id asc) as urutnya
		from sc_tmp.po_dtl a1) a1
		where a.id=a1.id and a.nodok=a1.nodok and a.kdgroup=a1.kdgroup and a.kdsubgroup=a1.kdsubgroup and a.stockcode=a1.stockcode
		and a.nodok=old.nodok and a.id>=old.id ;
	
		update sc_tmp.po_mst set 
		ttlbrutto=(select sum(coalesce(ttlbrutto,0)) from sc_tmp.po_dtl where nodok=old.nodok),
		ttldiskon=(select sum(coalesce(ttldiskon,0)) from sc_tmp.po_dtl where nodok=old.nodok) ,
		ttldpp=(select sum(coalesce(ttldpp,0)) from sc_tmp.po_dtl where nodok=old.nodok) ,
		ttlppn=(select sum(coalesce(ttlppn,0)) from sc_tmp.po_dtl where nodok=old.nodok) ,
		ttlnetto=(select sum(coalesce(ttlnetto,0)) from sc_tmp.po_dtl where nodok=old.nodok) 
		where nodok=old.nodok;	

/*
		delete from sc_tmp.po_dtlref where 
		branch=old.branch and nodok=old.nodok and kdgroup=old.kdgroup and kdsubgroup=old.kdsubgroup and stockcode=old.stockcode;
*/		
		--select * from sc_tmp.po_mst
		--select * from sc_tmp.po_dtl
		--select * from sc_tmp.po_dtlref
		
		delete from sc_mst.trxerror where userid=old.nodok and modul='TMPPO';
		insert into sc_mst.trxerror
		(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
		(old.nodok,0,old.nodok,'','TMPPO');
		RETURN old;	
	END IF;
	
END;
$$;

alter function tr_tmp_po_dtl() owner to postgres;

