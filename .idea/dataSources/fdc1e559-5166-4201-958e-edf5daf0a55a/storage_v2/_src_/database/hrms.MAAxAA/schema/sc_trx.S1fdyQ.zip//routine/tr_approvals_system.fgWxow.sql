create function tr_approvals_system() returns trigger
    language plpgsql
as
$$
DECLARE 
	--author by fiky: 12/08/2017
	--update by fiky: 23/01/2019
	--update pembenahan dpp
	--select * from sc_mst.trxtype
/*
INSERT INTO SC_MST.TRXTYPE
VALUES
('PSPB','mob_approvals','PERMINTAAN PEMBELIAN'),
('PMST','mob_approvals','PO MST OSIN'),
('BBMP','mob_approvals','BBM PO'),
('UMMK','mob_approvals','UANG MAKAN'),
('PSAS','mob_approvals','PERAWATAN ASSET'),
('ASKD','mob_approvals','ASURANSI KENDARAAN'),
('STNK','mob_approvals','PERPANJANGAN STNKB'),
('SIMX','mob_approvals','PERPANJANGAN SIM'),
('BBMK','mob_approvals','BAHAN BAKAR KENDARAAN'),
('SWKB','mob_approvals','SEWA KENDARAAN'),
('MCTI','mob_approvals','CUTI KARYAWAN'),
('MIJN','mob_approvals','IJIN KARYAWAN'),
('MLBR','mob_approvals','LEMBUR KARYAWAN'),
('MDNS','mob_approvals','DINAS KARYAWAN');

*/
BEGIN		
	if (new.doctype='MCTI' and new.status = 'U' and old.status!='U') then
		update sc_trx.cuti_karyawan set status='P',approval_date=new.approvaldate,approval_by=new.approvalby where nodok=new.docno and status not in ('P','C','D');
	elseif (new.doctype='MCTI' and new.status = 'C' and old.status!='C') then
		update sc_trx.cuti_karyawan set status='C',cancel_date=new.canceldate,cancel_by=new.cancelby where nodok=new.docno and status not in ('P','C','D');	
	end if;
	/* IJIN KARYAWAN */
	if (new.doctype='MIJN' and new.status = 'U' and old.status!='U') then
		update sc_trx.ijin_karyawan set status='P',approval_date=new.approvaldate,approval_by=new.approvalby where nodok=new.docno and status not in ('P','C','D');
	elseif (new.doctype='MIJN' and new.status = 'C' and old.status!='C') then
		update sc_trx.ijin_karyawan set status='C',cancel_date=new.canceldate,cancel_by=new.cancelby where nodok=new.docno and status not in ('P','C','D');	
	end if;
	/* DINAS KARYAWAN */
	if (new.doctype='MDNS' and new.status = 'U' and old.status!='U') then
		update sc_trx.dinas set status='P',approval_date=new.approvaldate,approval_by=new.approvalby where nodok=new.docno and status not in ('P','C','D');
	elseif (new.doctype='MDNS' and new.status = 'C' and old.status!='C') then
		update sc_trx.dinas set status='C',cancel_date=new.canceldate,cancel_by=new.cancelby where nodok=new.docno and status not in ('P','C','D');	
	end if;
	/* LEMBUR KARYAWAN */
	if (new.doctype='MLBR' and new.status = 'U' and old.status!='U') then
		update sc_trx.lembur set status='P',approval_date=new.approvaldate,approval_by=new.approvalby where nodok=new.docno and status not in ('P','C','D');
	elseif (new.doctype='MLBR' and new.status = 'C' and old.status!='C') then
		update sc_trx.lembur set status='C',cancel_date=new.canceldate,cancel_by=new.cancelby where nodok=new.docno and status not in ('P','C','D');	
	end if;
	/* PERMINTAAN PEMBELIAN */
	if (new.doctype='PSPB' and new.status = 'U' and old.status!='U') then
		update sc_trx.sppb_mst set status='P',approvaldate=new.approvaldate,approvalby=new.approvalby where nodok=new.docno and status not in ('P','C','D');
	elseif (new.doctype='PSPB' and new.status = 'C' and old.status!='C') then
		update sc_trx.sppb_mst set status='C1',canceldate=new.canceldate,cancelby=new.cancelby where nodok=new.docno and status not in ('P','C1','C','D');	
	end if;
	
return new;
END;
$$;

alter function tr_approvals_system() owner to postgres;

