create function tr_tmp_stbbk_dtl_tmp() returns trigger
    language plpgsql
as
$$
DECLARE 
	--author by fiky: 12/08/2017
	--update by fiky: 12/08/2017
	--update by fiky: TRIGER TEMPORARI INSERT UNTUK TMP STBBK

     vr_onhand_stkgdw numeric; 
     vr_tmpalloca_stkgdw numeric; 
     vr_alloca_stkgdw numeric; 
     vr_onhandtemp_stkgdw numeric; 
     vr_trxerror numeric;
BEGIN		
	IF tg_op = 'INSERT' THEN
	
			/* RESET STKGDW BERDASAR ITEM YG MASUK TMP*/
			---IF (NEW.STATUS='I') THEN

					IF EXISTS (select * from sc_tmp.stbbk_dtl where branch=new.branch and loccode=new.loccode and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and nodok=new.nodok  and nik=new.nik) THEN
						delete from sc_tmp.stbbk_dtl
						where branch=new.branch and loccode=new.loccode and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup
						and stockcode=new.stockcode and nodok=new.nodok  and nik=new.nik;
					END IF;
					

					INSERT INTO sc_tmp.stbbk_dtl (branch,nodok,nik,kdgroup,kdsubgroup,stockcode,loccode,desc_barang,qtypbk,qtybbk,qtyonhand,status,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodokref,nodoktmp,qtybbk_tmp) 
					(select branch,nodok,nik,kdgroup,kdsubgroup,stockcode,loccode,desc_barang,qtypbk,qtybbk,qtyonhand,status,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby,nodokref,nodoktmp,qtybbk_tmp
					from sc_tmp.stbbk_dtl_tmp where branch=new.branch);
					
					IF EXISTS (select * from sc_tmp.stbbk_dtl_tmp where branch=new.branch and loccode=new.loccode and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and nodok=new.nodok  and nik=new.nik) THEN
						delete from sc_tmp.stbbk_dtl_tmp
						where branch=new.branch and loccode=new.loccode and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup
						and stockcode=new.stockcode and nodok=new.nodok  and nik=new.nik;
					END IF;
			----END IF;

		RETURN new;
		
	END IF;
	
END;
$$;

alter function tr_tmp_stbbk_dtl_tmp() owner to postgres;

