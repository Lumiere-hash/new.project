create function pr_stspeg_after() returns trigger
    language plpgsql
as
$$
declare
--created by: Fiky Ashariza 28-04-2016 
--update by :
begin

	IF (new.kdkepegawaian='KO') THEN --keluar kerja
		update sc_mst.karyawan set statuskepegawaian=new.kdkepegawaian, tglkeluarkerja=new.tgl_selesai where nik=new.nik ;
		delete from sc_mst.regu_opr where nik=new.nik;
		delete from sc_trx.dtljadwalkerja where nik=new.nik and tgl>new.tgl_selesai;
		delete from sc_trx.uangmakan where nik=new.nik and tgl>new.tgl_selesai;
	ELSEIF (new.kdkepegawaian='HL') THEN--HARIAN LEPAS
		update sc_mst.karyawan set statuskepegawaian=new.kdkepegawaian,tglkeluarkerja=null where nik=new.nik ;
	ELSEIF (new.kdkepegawaian='KK') THEN --KONTRAK
		update sc_mst.karyawan set statuskepegawaian=new.kdkepegawaian,tglkeluarkerja=null where nik=new.nik ;
	ELSEIF (new.kdkepegawaian='KT') THEN --KARYAWAN TETAP
		update sc_mst.karyawan set statuskepegawaian=new.kdkepegawaian,tglkeluarkerja=null where nik=new.nik ;
	ELSEIF (new.kdkepegawaian='MG') THEN --MAGANG
		update sc_mst.karyawan set statuskepegawaian=new.kdkepegawaian,tglkeluarkerja=null where nik=new.nik ;
	ELSEIF (new.kdkepegawaian='KP') THEN --PENSIUN
		update sc_mst.karyawan set statuskepegawaian=new.kdkepegawaian,tglkeluarkerja=null where nik=new.nik ;	
	END IF;
		
	return new;
end;
$$;

alter function pr_stspeg_after() owner to postgres;

