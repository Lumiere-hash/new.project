create function pr_cutikaryawanbaru() returns SETOF void
    language plpgsql
as
$$
    --create by Fiky Ashariza
--08-04-2016
DECLARE vr_ceknik char(12);
--DECLARE ngeluping char(12);
--DECLARE variabele integer;
--DECLARE vr_ceknik record;	

BEGIN

--vr_ceknik:=trim(coalesce(nik,'')) from sc_mst.karyawan where tglmasukkerja=cast(to_char(now()+interval '1 year','yyyy-mm-dd')as date );
--ngeluping:=count(nik) from sc_mst.karyawan where tglmasukkerja=cast(to_char(now()+interval '1 year','yyyy-mm-dd')as date );
--variabele:= 1;

 FOR vr_ceknik in select trim(nik) from sc_mst.karyawan where 
			(tglmasukkerja<=cast(to_char(now()-interval '1 year','yyyy-mm-dd')as date) or 
			tglmasukkerja<=cast(to_char((now()+interval '1 day')-interval '1 year','yyyy-mm-dd')as date) or 
			tglmasukkerja<=cast(to_char((now()+interval '2 day')-interval '1 year','yyyy-mm-dd')as date) or 
			tglmasukkerja<=cast(to_char((now()+interval '3 day')-interval '1 year','yyyy-mm-dd')as date) or 
			tglmasukkerja<=cast(to_char((now()+interval '4 day')-interval '1 year','yyyy-mm-dd')as date) )
			and (tglmasukkerja=to_char(now()-interval '1 year','yyyy-mm-dd')::date)
			
	LOOP	
	    insert into sc_trx.cuti_blc
		(select NIK as nik,cast(to_char(tglmasukkerja+ interval'1 year','YYYY-MM-DD HH24:05:05')as timestamp) as tanggal,
		'CA'||to_char(now(),'yyyy') as no_dokumen,
		case when cast(to_char(tglmasukkerja,'dd') as numeric)<=15 then 13-to_number(to_char(tglmasukkerja,'MM'),'99')
		when cast(to_char(tglmasukkerja,'dd') as numeric)>15 then 12-to_number(to_char(tglmasukkerja,'MM'),'99')
		end in_cuti,0 as out_cuti, 0 as sisacuti,'IN' as doctype, 'CA'||to_char(now(),'yyyy') as status from sc_mst.karyawan where 
		nik=vr_ceknik) ; 

		 
	RETURN NEXT vr_ceknik;
END LOOP;
	RETURN;
	

	
END;
$$;

alter function pr_cutikaryawanbaru() owner to postgres;

