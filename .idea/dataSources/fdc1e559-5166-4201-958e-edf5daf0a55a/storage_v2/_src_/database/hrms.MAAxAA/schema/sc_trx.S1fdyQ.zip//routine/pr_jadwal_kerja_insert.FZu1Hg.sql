create function pr_jadwal_kerja_insert() returns trigger
    language plpgsql
as
$$
declare
     
     --vr_nomor char(30);
     --vr_status char(10);
     
begin
	
	insert into sc_trx.dtljadwalkerja (nik,shift,tgl,kdjamkerja,kdregu,kdmesin)
	select b.nik,e.shift,tgl,kodejamkerja,a.kdregu,kdmesin from sc_trx.jadwalkerja a
	left outer join sc_mst.regu d on a.kdregu=d.kdregu
	left outer join sc_mst.regu_opr b on a.kdregu=b.kdregu
	left outer join sc_mst.karyawan c on c.nik=b.nik
	left outer join sc_mst.jabatan e on c.jabatan=e.kdjabatan and e.kddept=c.bag_dept and e.kdsubdept=c.subbag_dept
	where a.kdregu=new.kdregu and a.tgl=new.tgl --and kodejamkerja='NSB'
	and trim(c.nik)::char(6)||a.tgl::char(20) not in (select trim(nik)::char(6)||tgl::char(20) from sc_trx.dtljadwalkerja where updatedate is not null and tgl=new.tgl) and b.nik is not null;  

return new;

end;
$$;

alter function pr_jadwal_kerja_insert() owner to postgres;

