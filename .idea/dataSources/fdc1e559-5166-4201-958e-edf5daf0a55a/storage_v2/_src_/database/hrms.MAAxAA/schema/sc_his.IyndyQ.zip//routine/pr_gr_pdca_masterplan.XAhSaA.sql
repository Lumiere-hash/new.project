create function pr_gr_pdca_masterplan(vr_nik character, vr_periode character) returns SETOF void
    language plpgsql
as
$$
    --Author : Fiky Ashariza
--Update Date: 17/12/2017
--Update By :
DECLARE vr_kdopt character(20);
DECLARE vr_nmopt character(20);
DECLARE vr_hr_aktif numeric;
DECLARE vr_temp_ritme numeric;
DECLARE vr_hr_libur numeric;
DECLARE vr_kon_1 numeric;
DECLARE vr_kon_2 numeric;
DECLARE vr_maxweek numeric;
DECLARE vr_ritme_1 numeric;
DECLARE vr_ritme_2 numeric;
DECLARE vr_ritme_3 numeric;
DECLARE vr_ritme character(10);
DECLARE vr_operatorlist character(20);
DECLARE vr_sdom character(10);
DECLARE vr_sdom1 character(10);
DECLARE vr_initsdom1 numeric;
DECLARE vr_edom character(10);
DECLARE vr_edom1 character(10);
DECLARE vr_bulan_bef character(10);
DECLARE vr_tahun_bef character(10);
DECLARE vr_kategori_kdjam character(10);
DECLARE vr_mst_regu_eosf_val character(10);
DECLARE vr_mst_regu_eosf_index character(10);
DECLARE vr_eor_val character(10);
DECLARE vr_jam_kerja character(10);
DECLARE vr_inisial character(10);
DECLARE vr_cek_jadwal bigint;
DECLARE vr_hari_libur bigint;
DECLARE vr_sf1_all character(10); DECLARE vr_sf1_jumat character(10); DECLARE vr_sf1_sabtu character(10);
DECLARE vr_sf2_all character(10); DECLARE vr_sf2_jumat character(10); DECLARE vr_sf2_sabtu character(10);
DECLARE vr_sf3_all character(10); DECLARE vr_sf3_jumat character(10); DECLARE vr_sf3_sabtu character(10);
DECLARE vr_nama_hari character(20);
DECLARE vr_noindex numeric;
DECLARE vr_kategori character(20);
DECLARE vr_urutkategori character(20);

BEGIN
	---vr_periode kasih periode sekarang dan kedepan yg ikut proses

	--vr_sdom:=trim(to_char(date_trunc('month', cast(to_char(now(),vr_tahun_awal||'-'||vr_bulan_awal||'-'||'dd')as date)),'dd'));
	--vr_edom:=trim(to_char(date_trunc('month', cast(to_char(now(),vr_tahun_awal||'-'||vr_bulan_awal||'-'||'dd')as date))+interval '1 month'-interval '1 day','dd'));
	---alter table sc_his.pdca_master_plan_daily add column qtytime character(12), add column do_c character(12), add column percentage character(12);
	---select * from sc_his.pdca_master_plan_daily
	---select * from sc_his.pdca_list_gen
	--select sc_his.pr_gr_pdca_masterplan('1115.184', '201712')
	/* 
	   select task1 from (
		   select 'QTY/TIME :'||coalesce(qtytime,'') as task1,nik,nomor,doctype,holdplan from sc_his.pdca_master_plan_daily
			union all
		   select 'DO :'||coalesce(do_c,'') as task2,nik,nomor,doctype,holdplan from sc_his.pdca_master_plan_daily
			union all
		   select '% :'||coalesce(percentage,'') as task3,nik,nomor,doctype,holdplan from sc_his.pdca_master_plan_daily) as x
	   where nik='1115.184' and doctype='BRK' AND holdplan='NO' order by nomor asc

		--ALTER TABLE sc_his.pdca_list_gen DROP CONSTRAINT pdca_list_gen_pkey;
		ALTER TABLE sc_his.pdca_list_gen
		  ADD CONSTRAINT pdca_list_gen_pkey PRIMARY KEY(nik, nomor, periode, doctype,category);

	 */
	
	FOR vr_kon_1 in select nomor from sc_his.pdca_master_plan_daily where nik=vr_nik and doctype='BRK' AND holdplan='NO' and status='F' order by nomor asc
	loop

		FOR vr_kategori,vr_urutkategori in select task1,urutcategory from (
			select 'QTY/TIME :'||coalesce(qtytime,'') as task1,nik,nomor,doctype,holdplan,1 as urutcategory from sc_his.pdca_master_plan_daily
			union all
			select 'DO :'||coalesce(do_c,'') as task2,nik,nomor,doctype,holdplan,2 as urutcategory from sc_his.pdca_master_plan_daily
			union all
			select '% :'||coalesce(percentage,'') as task3,nik,nomor,doctype,holdplan,3 as urutcategory from sc_his.pdca_master_plan_daily) as x
			where nik=vr_nik and nomor=vr_kon_1 and doctype='BRK' AND holdplan='NO' order by nomor asc
		loop
			IF NOT EXISTS(select * from sc_his.pdca_list_gen where nik=vr_nik and nomor::NUMERIC=vr_kon_1 and planperiod=vr_periode and doctype='BRK' and urutcategory=vr_urutkategori) THEN
			insert into  sc_his.pdca_list_gen 
			(nik,nomor,planperiod,doctype,category,urutcategory) values
			(vr_nik,vr_kon_1,vr_periode,'BRK',vr_kategori,vr_urutkategori);
			END IF;
			
			IF NOT EXISTS(select * from sc_his.pdca_list_gen where nik=vr_nik and nomor::NUMERIC=999 and planperiod=vr_periode and doctype='BRK' and urutcategory='1') THEN
			insert into  sc_his.pdca_list_gen 
			(nik,nomor,planperiod,doctype,category,urutcategory) values
			(vr_nik,999,vr_periode,'BRK','TOTAL %',1);
			END IF;

			IF NOT EXISTS(select * from sc_his.pdca_list_gen where nik=vr_nik and nomor::NUMERIC=999 and planperiod=vr_periode and doctype='BRK' and urutcategory='2') THEN
			insert into  sc_his.pdca_list_gen 
			(nik,nomor,planperiod,doctype,category,urutcategory) values
			(vr_nik,999,vr_periode,'BRK','TOTAL PLAN',2);
			END IF;

			
			IF NOT EXISTS(select * from sc_his.pdca_list_gen where nik=vr_nik and nomor::NUMERIC=999 and planperiod=vr_periode and doctype='BRK' and urutcategory='3') THEN
			insert into  sc_his.pdca_list_gen 
			(nik,nomor,planperiod,doctype,category,urutcategory) values
			(vr_nik,999,vr_periode,'BRK','AVERAGE',3);
			END IF;

			IF NOT EXISTS(select * from sc_his.pdca_list_gen where nik=vr_nik and nomor::NUMERIC=999 and planperiod=vr_periode and doctype='BRK' and urutcategory='4') THEN
			insert into  sc_his.pdca_list_gen 
			(nik,nomor,planperiod,doctype,category,urutcategory) values
			(vr_nik,999,vr_periode,'BRK','D REMARK',4);
			END IF;

			IF NOT EXISTS(select * from sc_his.pdca_list_gen where nik=vr_nik and nomor::NUMERIC=999 and planperiod=vr_periode and doctype='BRK' and urutcategory='10') THEN
			insert into  sc_his.pdca_list_gen 
			(nik,nomor,planperiod,doctype,category,urutcategory) values
			(vr_nik,999,vr_periode,'BRK','STATUS',10);
			END IF;
			
			/*vr_inisial:=vr_sdom;
			loop		
					if (vr_inisial='01') then
						update sc_tmp.template_jadwal_v2 set m01_1=vr_jam_kerja,noindex_start=vr_noindex,noindex_end=vr_kon_1 where tahun=vr_tahun_awal and bulan=vr_bulan_awal and kdregu=vr_kdregu and kd_opt=vr_kdtemplate;
					end if;
				exit when vr_inisial::integer>vr_edom::integer;
				select * from sc_his.pdca_master_plan_daily
			END LOOP;*/

			update sc_his.pdca_master_plan_daily set planperiod=vr_periode where nik=vr_nik and nomor=vr_kon_1;
		return next vr_kategori;				
		END LOOP;
	return next vr_kon_1;				
	END LOOP;				

END;
$$;

alter function pr_gr_pdca_masterplan(char, char) owner to postgres;

