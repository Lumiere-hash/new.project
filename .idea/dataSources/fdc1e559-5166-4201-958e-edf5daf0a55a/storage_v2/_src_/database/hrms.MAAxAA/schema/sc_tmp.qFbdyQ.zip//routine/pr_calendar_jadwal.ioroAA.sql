create function pr_calendar_jadwal(vr_bulan_awal numeric, vr_tahun_awal numeric, vr_bulan_akhir numeric, vr_tahun_akhir numeric, vr_kdregu character) returns SETOF void
    language plpgsql
as
$$
DECLARE vr_tgl_calendar date;
DECLARE vr_tgl_calendar2 date;
DECLARE vr_tgl_calendar2tmp date;
DECLARE vr_tgl_calendar3 date;
DECLARE vr_tgl_calendar4 date;
DECLARE vr_end_d_month date;
DECLARE vr_tahun_calendar numeric;
DECLARE vr_bulan_calendar numeric;
DECLARE vr_tahun3 numeric;
DECLARE vr_bulan3 numeric;
DECLARE vr_dayweek_calendar numeric;
DECLARE vr_dayweek_calendar4 numeric;

DECLARE vr_dayweek_calendar3 numeric;
DECLARE vr_cek_tgl character(6);
DECLARE vr_cek_tgl2 numeric;
DECLARE vr_cek_ganda numeric;
DECLARE nmcolumn character(6);
DECLARE vr_temp numeric;
DECLARE vr_temp_bef numeric;
DECLARE vr_temp_aft numeric;
--DECLARE vr_initialdate_next numeric;

BEGIN
--vr_tahun_calendar:=2012;
--vr_bulan_calendar:=1;
		

FOR vr_tahun_calendar in 2012 .. 2036   --INISIAL TAHUNin vr_tahun_awal .. vr_tahun_akhir--
LOOP
	FOR vr_bulan_calendar in 1 .. 12 --INISIAL BULANin vr_bulan_awal .. vr_bulan_akhir --
	LOOP	
		FOR vr_tgl_calendar in select tgl from sc_mst.calendar where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar order by tgl --INSERT TANGGAL PADA BULAN DAN TAHUN
			LOOP
				vr_dayweek_calendar:=day_of_week from sc_mst.calendar where tgl=vr_tgl_calendar;
				vr_cek_tgl:=to_char(vr_tgl_calendar,'dd');
				
				if(vr_cek_tgl='01') then	
					vr_cek_ganda:=count(*) from sc_tmp.calendar_jadwal where tahun=vr_tahun_calendar and bulan=vr_bulan_calendar and kdregu=vr_kdregu;
						if(vr_cek_ganda=0) then
						insert into sc_tmp.calendar_jadwal (tahun,bulan,kdregu) values (vr_tahun_calendar,vr_bulan_calendar,vr_kdregu);
						--update sc_tmp.calendar_jadwal set kdregu=vr_kdregu where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
						end if;
					if (vr_dayweek_calendar=0)then
						update sc_tmp.calendar_jadwal set m01_1=vr_tgl_calendar where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
						vr_temp:=0;
					elseif (vr_dayweek_calendar=1)then
						update sc_tmp.calendar_jadwal set m01_2=vr_tgl_calendar where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
						vr_temp:=1;
					elseif (vr_dayweek_calendar=2)then
						update sc_tmp.calendar_jadwal set m01_3=vr_tgl_calendar where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
						vr_temp:=2;
					elseif (vr_dayweek_calendar=3)then
						update sc_tmp.calendar_jadwal set m01_4=vr_tgl_calendar where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
						vr_temp:=3;
					elseif (vr_dayweek_calendar=4)then
						update sc_tmp.calendar_jadwal set m01_5=vr_tgl_calendar where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
						vr_temp:=4;
					elseif (vr_dayweek_calendar=5)then
						update sc_tmp.calendar_jadwal set m01_6=vr_tgl_calendar where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
						vr_temp:=5;
					else 	
						update sc_tmp.calendar_jadwal set m01_7=vr_tgl_calendar where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
						vr_temp:=6;
					end if;	

					
							/* UPDATE DI DEPAN */
							if(vr_temp>0) then
							
								--FOR vr_tgl_calendar3 in select cast((to_char(tgl- interval '1 day' *vr_temp_bef,'yyyy-mm-dd'))as date)as tgl from sc_mst.calendar where tgl=vr_tgl_calendar order by tgl
								vr_temp_bef:=vr_temp;				
								LOOP
											vr_tgl_calendar3:=cast((to_char(tgl- interval '1 day' *(vr_temp_bef),'yyyy-mm-dd'))as date)as tgl from sc_mst.calendar where tgl=vr_tgl_calendar;
											vr_bulan3:=cast((to_char(tgl,'mm'))as numeric) from sc_mst.calendar where tgl=vr_tgl_calendar3;
											vr_tahun3:=cast((to_char(tgl,'yyyy'))as numeric) from sc_mst.calendar where tgl=vr_tgl_calendar3;
											vr_dayweek_calendar3:=day_of_week from sc_mst.calendar where tgl=vr_tgl_calendar3;

								--insert into sc_tmp.calendar_jadwal (m01_1,tahun,bulan) values (vr_tgl_calendar3,vr_bulan3,vr_tahun3);

									if(vr_dayweek_calendar3=0)then
									update sc_tmp.calendar_jadwal set m01_1=vr_tgl_calendar3 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
									elseif(vr_dayweek_calendar3=1)then
									update sc_tmp.calendar_jadwal set m01_2=vr_tgl_calendar3 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
									elseif(vr_dayweek_calendar3=2)then
									update sc_tmp.calendar_jadwal set m01_3=vr_tgl_calendar3 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
									elseif(vr_dayweek_calendar3=3)then
									update sc_tmp.calendar_jadwal set m01_4=vr_tgl_calendar3 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
									elseif(vr_dayweek_calendar3=4)then
									update sc_tmp.calendar_jadwal set m01_5=vr_tgl_calendar3 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
									elseif(vr_dayweek_calendar3=5)then
									update sc_tmp.calendar_jadwal set m01_6=vr_tgl_calendar3 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
									else
									update sc_tmp.calendar_jadwal set m01_7=vr_tgl_calendar3 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
									end if;	

									vr_temp_bef:= vr_temp_bef-1;
									EXIT WHEN vr_temp_bef=0;
										RETURN NEXT vr_tgl_calendar3;
								END LOOP;
							
							
							end if;
			



					/* UPDATE TENGAH */

						--vr_temp:= vr_temp + 1;
						FOR vr_tgl_calendar2 in select tgl from sc_mst.calendar where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar order by tgl		
						
						LOOP
						--insert into sc_tmp.calendar_jadwal (m05_35) values (vr_tgl_calendar2);
								
						
							
							--nmcolumn:='tgl'||vr_temp;
	
							if((vr_temp=0) )then
							update sc_tmp.calendar_jadwal set m01_1=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							elseif(vr_temp=1 )then
							update sc_tmp.calendar_jadwal set m01_2=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							elseif(vr_temp=2  )then
							update sc_tmp.calendar_jadwal set m01_3=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							elseif(vr_temp=3 )then
							update sc_tmp.calendar_jadwal set m01_4=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							elseif(vr_temp=4 )then
							update sc_tmp.calendar_jadwal set m01_5=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							elseif(vr_temp=5 )then
							update sc_tmp.calendar_jadwal set m01_6=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							elseif(vr_temp=6 )then
							update sc_tmp.calendar_jadwal set m01_7=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							elseif(vr_temp=7 )then
							update sc_tmp.calendar_jadwal set m02_8=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							elseif(vr_temp=8 )then
							update sc_tmp.calendar_jadwal set m02_9=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							elseif(vr_temp=9 )then
							update sc_tmp.calendar_jadwal set m02_10=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							elseif(vr_temp=10 )then
							update sc_tmp.calendar_jadwal set m02_11=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							elseif(vr_temp=11 )then
							update sc_tmp.calendar_jadwal set m02_12=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							elseif(vr_temp=12 )then
							update sc_tmp.calendar_jadwal set m02_13=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							elseif(vr_temp=13 )then
							update sc_tmp.calendar_jadwal set m02_14=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							elseif(vr_temp=14 )then
							update sc_tmp.calendar_jadwal set m03_15=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							elseif(vr_temp=15 )then
							update sc_tmp.calendar_jadwal set m03_16=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							elseif(vr_temp=16 )then
							update sc_tmp.calendar_jadwal set m03_17=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							elseif(vr_temp=17 )then
							update sc_tmp.calendar_jadwal set m03_18=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							elseif(vr_temp=18 )then
							update sc_tmp.calendar_jadwal set m03_19=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							elseif(vr_temp=19 )then
							update sc_tmp.calendar_jadwal set m03_20=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							elseif(vr_temp=20 )then
							update sc_tmp.calendar_jadwal set m03_21=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							elseif(vr_temp=21 )then
							update sc_tmp.calendar_jadwal set m04_22=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							elseif(vr_temp=22 )then
							update sc_tmp.calendar_jadwal set m04_23=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							elseif(vr_temp=23 )then
							update sc_tmp.calendar_jadwal set m04_24=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							elseif(vr_temp=24 )then
							update sc_tmp.calendar_jadwal set m04_25=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							elseif(vr_temp=25 )then
							update sc_tmp.calendar_jadwal set m04_26=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							elseif(vr_temp=26 )then
							update sc_tmp.calendar_jadwal set m04_27=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							elseif(vr_temp=27 )then
							update sc_tmp.calendar_jadwal set m04_28=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							vr_temp_aft:=0;	
							elseif(vr_temp=28 )then
							update sc_tmp.calendar_jadwal set m05_29=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							vr_temp_aft:=1;	
							elseif(vr_temp=29 )then
							update sc_tmp.calendar_jadwal set m05_30=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							vr_temp_aft:=2;
							elseif(vr_temp=30 )then
							update sc_tmp.calendar_jadwal set m05_31=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							vr_temp_aft:=3;
							elseif(vr_temp=31 )then
							update sc_tmp.calendar_jadwal set m05_32=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							vr_temp_aft:=4;
							elseif(vr_temp=32 )then
							update sc_tmp.calendar_jadwal set m05_33=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							vr_temp_aft:=5;
							elseif(vr_temp=33 )then
							update sc_tmp.calendar_jadwal set m05_34=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							vr_temp_aft:=6;
							elseif(vr_temp=34 )then
							update sc_tmp.calendar_jadwal set m05_35=vr_tgl_calendar2 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
							vr_temp_aft:=7;
							else
								EXIT;
							end if;
									
							vr_temp:= vr_temp + 1;

							RETURN NEXT vr_tgl_calendar2;
	
						END LOOP;

									
							
							/* insert into sc_tmp.calendar_jadwal (bulan) values (vr_temp_aft) ;*/

							if(vr_temp_aft<7)then
							vr_end_d_month:=(date_trunc('MONTH', cast((vr_tahun_calendar||'-'||vr_bulan_calendar||'-'||'01')as date)) + INTERVAL '1 MONTH - 1 day')::date; --end of month
							
							vr_temp_aft:=7-vr_temp_aft;
								LOOP
													
											--vr_temp_aft:=
											vr_tgl_calendar4:=cast((to_char(tgl+ interval '1 day' *(vr_temp_aft),'yyyy-mm-dd'))as date)as tgl from sc_mst.calendar where tgl=vr_end_d_month;
											vr_dayweek_calendar4:=day_of_week from sc_mst.calendar where tgl=vr_tgl_calendar4;
											--update sc_tmp.calendar_jadwal set m05_35=(vr_tgl_calendar2- interval '1 day') where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
											--insert into sc_tmp.calendar_jadwal (m05_35) values (vr_tgl_calendar3);

										if(vr_dayweek_calendar4=0)then
											update sc_tmp.calendar_jadwal set m05_29=vr_tgl_calendar4 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
											elseif(vr_dayweek_calendar4=1)then
											update sc_tmp.calendar_jadwal set m05_30=vr_tgl_calendar4 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
											elseif(vr_dayweek_calendar4=2)then
											update sc_tmp.calendar_jadwal set m05_31=vr_tgl_calendar4 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
											elseif(vr_dayweek_calendar4=3)then
											update sc_tmp.calendar_jadwal set m05_32=vr_tgl_calendar4 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
											elseif(vr_dayweek_calendar4=4)then
											update sc_tmp.calendar_jadwal set m05_33=vr_tgl_calendar4 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
											elseif(vr_dayweek_calendar4=5)then
											update sc_tmp.calendar_jadwal set m05_34=vr_tgl_calendar4 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
											elseif(vr_dayweek_calendar4=6)then
											update sc_tmp.calendar_jadwal set m05_35=vr_tgl_calendar4 where bulan=vr_bulan_calendar and tahun=vr_tahun_calendar;
											else
												EXIT WHEN vr_temp_aft<=0;
											end if;	
											RETURN NEXT vr_tgl_calendar4;
											vr_temp_aft:=vr_temp_aft-1;
											
											EXIT WHEN vr_temp_aft<=0;
										
								END LOOP;

								
							end if;

							


				end if;	


						

			RETURN NEXT vr_tgl_calendar;	
			END LOOP;
	END LOOP;
END LOOP;	
					
		RETURN;
	
END;
$$;

alter function pr_calendar_jadwal(numeric, numeric, numeric, numeric, char) owner to postgres;

