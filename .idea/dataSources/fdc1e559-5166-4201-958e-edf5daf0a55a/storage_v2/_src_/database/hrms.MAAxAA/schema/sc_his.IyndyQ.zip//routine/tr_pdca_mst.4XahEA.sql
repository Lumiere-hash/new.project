create function tr_pdca_mst() returns trigger
    language plpgsql
as
$$
declare
--created by Fiky ::18/07/2017
     vr_nomor char(12); 
     vr_cekprefix char(4);
     vr_nowprefix char(4);
begin    

	IF TG_OP ='INSERT' THEN 

	RETURN NEW;
	ELSEIF TG_OP ='UPDATE' THEN
			/* NO RESOURCE UPDATE */
		if (new.status='E' and old.status='A') then
		
			insert into sc_tmp.pdca_mst
			(branch,nik,docno,docdate,docref,doctype,docpage,revision,tglawal,tglakhir,global_desc,planperiod,ttlpercent,ttlplan,avgvalue,inputdate,
			inputby,updatedate,updateby,canceldate,cancelby,approvdate,approvby,status,realisasidate,realisasiby,chec)
			(select branch,nik,NEW.UPDATEBY,docdate,docref,doctype,docpage,revision,tglawal,tglakhir,global_desc,planperiod,ttlpercent,ttlplan,avgvalue,inputdate,
			inputby,updatedate,updateby,canceldate,cancelby,approvdate,approvby,'E' as status,realisasidate,realisasiby,chec from sc_his.pdca_mst where docno=new.docno and docdate=new.docdate and doctype=new.doctype and nik=new.nik);

			insert into sc_tmp.pdca_dtl
			(nik,docno,nomor,doctype,docref,docdate,docpage,revision,planperiod,descplan,idbu,qtytime,do_c,percentage,remark,
			inputdate,inputby,updatedate,updateby,canceldate,cancelby,approvdate,approvby,status,realisasidate,realisasiby,chec)
			(select nik,NEW.UPDATEBY,nomor,doctype,docref,docdate,docpage,revision,planperiod,descplan,idbu,qtytime,do_c,percentage,remark,
			inputdate,inputby,updatedate,updateby,canceldate,cancelby,approvdate,approvby,'E1' as status,realisasidate,realisasiby,chec from sc_his.pdca_dtl where docno=new.docno and docdate=new.docdate and doctype=new.doctype and nik=new.nik);
		elseif (new.status='R' and old.status='A') then
		
			insert into sc_tmp.pdca_mst
			(branch,nik,docno,docdate,docref,doctype,docpage,revision,tglawal,tglakhir,global_desc,planperiod,ttlpercent,ttlplan,avgvalue,inputdate,
			inputby,updatedate,updateby,canceldate,cancelby,approvdate,approvby,status,realisasidate,realisasiby,chec)
			(select branch,nik,NEW.REALISASIBY,docdate,docref,doctype,docpage,revision,tglawal,tglakhir,global_desc,planperiod,ttlpercent,ttlplan,avgvalue,inputdate,
			inputby,updatedate,updateby,canceldate,cancelby,approvdate,approvby,'R' as status,realisasidate,realisasiby,chec from sc_his.pdca_mst where docno=new.docno and docdate=new.docdate and doctype=new.doctype and nik=new.nik);

			insert into sc_tmp.pdca_dtl
			(nik,docno,nomor,doctype,docref,docdate,docpage,revision,planperiod,descplan,idbu,qtytime,do_c,percentage,remark,
			inputdate,inputby,updatedate,updateby,canceldate,cancelby,approvdate,approvby,status,realisasidate,realisasiby,chec)
			(select nik,NEW.REALISASIBY,nomor,doctype,docref,docdate,docpage,revision,planperiod,descplan,idbu,qtytime,do_c,percentage,remark,
			inputdate,inputby,updatedate,updateby,canceldate,cancelby,approvdate,approvby,'R1' as status,realisasidate,realisasiby,chec from sc_his.pdca_dtl where docno=new.docno and docdate=new.docdate and doctype=new.doctype and nik=new.nik);

		elseif (new.status='A1' and old.status='R') then
		--UPDATE "sc_his"."pdca_mst" SET "status" = 'A1', "approvdate" = '2017-12-20 13:17:07', "approvby" = '1115.184' WHERE "nik" = '1115.184' AND "doctype" = 'ISD' AND "docdate" = '2017-12-18'
			insert into sc_tmp.pdca_mst
			(branch,nik,docno,docdate,docref,doctype,docpage,revision,tglawal,tglakhir,global_desc,planperiod,ttlpercent,ttlplan,avgvalue,inputdate,
			inputby,updatedate,updateby,canceldate,cancelby,approvdate,approvby,status,realisasidate,realisasiby,chec)
			(select branch,nik,NEW.approvby,docdate,docref,doctype,docpage,revision,tglawal,tglakhir,global_desc,planperiod,ttlpercent,ttlplan,avgvalue,inputdate,
			inputby,updatedate,updateby,canceldate,cancelby,approvdate,approvby,'O' as status,realisasidate,realisasiby,chec from sc_his.pdca_mst where docno=new.docno and docdate=new.docdate and doctype=new.doctype and nik=new.nik);

			insert into sc_tmp.pdca_dtl
			(nik,docno,nomor,doctype,docref,docdate,docpage,revision,planperiod,descplan,idbu,qtytime,do_c,percentage,remark,
			inputdate,inputby,updatedate,updateby,canceldate,cancelby,approvdate,approvby,status,realisasidate,realisasiby,chec)
			(select nik,NEW.approvby,nomor,doctype,docref,docdate,docpage,revision,planperiod,descplan,idbu,qtytime,do_c,percentage,remark,
			inputdate,inputby,updatedate,updateby,canceldate,cancelby,approvdate,approvby,'O1' as status,realisasidate,realisasiby,chec from sc_his.pdca_dtl where docno=new.docno and docdate=new.docdate and doctype=new.doctype and nik=new.nik);

			update sc_his.pdca_mst set status='O' where docno=new.docno and docdate=new.docdate and doctype=new.doctype and nik=new.nik;
		elseif (new.status='F' and old.status='I') then

		
		end if;
	
			
	RETURN NEW;
	END IF;
    
    
    return new;
        
end;
$$;

alter function tr_pdca_mst() owner to postgres;

