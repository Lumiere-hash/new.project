create function pr_cutoff_prefix_years() returns void
    language plpgsql
as
$$
    --author by : Fiky Ashariza 11-12-2017
--update by : - -
BEGIN	
--select * from sc_mst.nomor
--PROSEDUR RESET PREFIX

update sc_mst.nomor set prefix='CB'||to_char(now(),'yy') , docno=0,periode=to_char(now(),'yyyy') where dokumen='CUTI-BERSAMA' and periode!=to_char(now(),'yyyy');
update sc_mst.nomor set prefix='DL'||to_char(now(),'yy') , docno=0,periode=to_char(now(),'yyyy') where dokumen='DINAS-LUAR' and periode!=to_char(now(),'yyyy');
update sc_mst.nomor set prefix='IK'||to_char(now(),'yy') , docno=0,periode=to_char(now(),'yyyy') where dokumen='IJIN-KARYAWAN' and periode!=to_char(now(),'yyyy');
update sc_mst.nomor set prefix='LBR'||to_char(now(),'yy') , docno=0,periode=to_char(now(),'yyyy') where dokumen='LEMBUR' and periode!=to_char(now(),'yyyy');
update sc_mst.nomor set prefix='CT'||to_char(now(),'yy') , docno=0,periode=to_char(now(),'yyyy') where dokumen='CUTI-KARYAWAN' and periode!=to_char(now(),'yyyy');


	RETURN;	
END;
$$;

alter function pr_cutoff_prefix_years() owner to postgres;

