create function pr_update_nohp() returns trigger
    language plpgsql
as
$$
declare 
vr_nohp char(20);
begin
vr_nohp :=trim(both '_' from t1.telepon) from (select case when left("DestinationNumber",1)='0' then '+62' || right("DestinationNumber",-1)
	else "DestinationNumber"
	end as telepon  from outbox where "ID"=new."ID") as t1; 
update outbox set 
"DestinationNumber"=vr_nohp where "ID"=new."ID";    
	
     return new;
        end;
$$;

alter function pr_update_nohp() owner to postgres;

