create function pr_generate_p1721(vr_tahun character, vr_kddept character, vr_nodok character, vr_gp character) returns timestamp without time zone
    language plpgsql
as
$$
DECLARE
	
    vr_nik char(12);
    vr_tglkeluarkerja character(20);
    vr_periode_awal integer;
    vr_periode_akhir integer;
    vr_doktemp character(20);
    vr_doktemp2 character(20);
    vr_urut integer;
    vr_tglmasukkerja character(20);
    vr_return timestamp without time zone;
    
    
    
BEGIN


	  --delete from sc_tmp.p1721_rekap where kddept=vr_kddept and grouppenggajian=vr_gp and tgl_dok;
	IF NOT EXISTS (select nodok from sc_tmp.p1721_rekap where kddept=vr_kddept and grouppenggajian=vr_gp) THEN
		insert into sc_tmp.p1721_rekap
		(select  vr_nodok as nodok,cast(to_char(now(),vr_tahun||'-'||'12'||'-'||'01')as date) as tgl_dok,sum(total_pajak)as total_pajak,sum(total_pendapatan)as total_pendapatan,sum(total_potongan)as total_potongan,cast(to_char(now(),'yyyy-mm-dd HH24:MI:SS')as timestamp) as input_date,null as approval_date,'666666' as input_by,'' as approval_by,'' as delete_by,'' as cancel_by,null as update_date,
		null as delete_date,null as cancel_date,'' as update_by,'I' as status,1 as periode_mulai,12 as periode_akhir,vr_kddept as kddept,b.grouppenggajian from sc_trx.p21_master a 
		left outer join sc_mst.karyawan b on a.nik=b.nik
		where a.nodok like '%'||vr_tahun||'%' and a.nodok like '%'||vr_kddept||'%' and b.grouppenggajian=vr_gp
		group by b.grouppenggajian);

	END IF;
	

vr_doktemp=vr_nodok;
	--select nik from sc_mst.karyawan where (nik in (select nik from sc_trx.p21_detail where nodok like '%'||'2016'||'%')) and grouppenggajian='P1' and bag_dept='PRD'

    FOR vr_nik in select trim(nik) from sc_mst.karyawan where (nik in (select nik from sc_trx.p21_detail where nodok like '%'||vr_tahun||'%')) and grouppenggajian=vr_gp and bag_dept=vr_kddept
    LOOP

		vr_periode_awal:=cast(min(periode_mulai)as integer) from sc_trx.p21_detail 
		where no_urut=1 and nik=vr_nik;

		vr_periode_akhir:=cast(max(periode_akhir)as integer) from sc_trx.p21_detail 
		where no_urut=1 and nik=vr_nik;

			perform sc_trx.pr_1721_ambil_gp(vr_nik,1,vr_doktemp,vr_periode_awal,vr_periode_akhir,vr_tahun);
			perform sc_trx.pr_1721_ambil_tj(vr_nik,2,vr_doktemp,vr_periode_awal,vr_periode_akhir,vr_tahun);
			perform sc_trx.pr_1721_ambil_tj_lain(vr_nik,3,vr_doktemp,vr_periode_awal,vr_periode_akhir,vr_tahun);
			perform sc_trx.pr_1721_ambil_honorarium(vr_nik,4,vr_doktemp,vr_periode_awal,vr_periode_akhir,vr_tahun);
			perform sc_trx.pr_1721_ambil_premiasuransi(vr_nik,5,vr_doktemp,vr_periode_awal,vr_periode_akhir,vr_tahun);
			perform sc_trx.pr_1721_ambil_penerimaan_natuna(vr_nik,6,vr_doktemp,vr_periode_awal,vr_periode_akhir,vr_tahun);
			perform sc_trx.pr_1721_ambil_bonus(vr_nik,7,vr_doktemp,vr_periode_awal,vr_periode_akhir,vr_tahun);
			perform sc_trx.pr_1721_subtotal_bruto(vr_nik,8,vr_doktemp,vr_periode_awal,vr_periode_akhir,vr_tahun);
			perform sc_trx.pr_1721_biaya_jabatan(vr_nik,9,vr_doktemp,vr_periode_awal,vr_periode_akhir,vr_tahun);
			perform sc_trx.pr_1721_jht_tht(vr_nik,10,vr_doktemp,vr_periode_awal,vr_periode_akhir,vr_tahun);
			perform sc_trx.pr_1721_subtotal_potongan(vr_nik,11,vr_doktemp,vr_periode_awal,vr_periode_akhir,vr_tahun);
			perform sc_trx.pr_1721_penghasilan_netto(vr_nik,12,vr_doktemp,vr_periode_awal,vr_periode_akhir,vr_tahun);
			perform sc_trx.pr_1721_penghasilan_netto_masa_sebelumnya(vr_nik,13,vr_doktemp,vr_periode_awal,vr_periode_akhir,vr_tahun);
			perform sc_trx.pr_1721_penghasilan_netto_perhitungan_pph21(vr_nik,14,vr_doktemp,vr_periode_awal,vr_periode_akhir,vr_tahun);
			perform sc_trx.pr_1721_ptkp(vr_nik,15,vr_doktemp,vr_periode_awal,vr_periode_akhir,vr_tahun);
			perform sc_trx.pr_1721_pkp_setahun(vr_nik,16,vr_doktemp,vr_periode_awal,vr_periode_akhir,vr_tahun);
			perform sc_trx.pr_1721_pph21_setahun(vr_nik,17,vr_doktemp,vr_periode_awal,vr_periode_akhir,vr_tahun);
			perform sc_trx.pr_1721_pph21_setahun_masa_sebelumnya(vr_nik,18,vr_doktemp,vr_periode_awal,vr_periode_akhir,vr_tahun);
			perform sc_trx.pr_1721_pph21_terutang(vr_nik,19,vr_doktemp,vr_periode_awal,vr_periode_akhir,vr_tahun);
			perform sc_trx.pr_1721_pph21_dipotong_lunas(vr_nik,20,vr_doktemp,vr_periode_awal,vr_periode_akhir,vr_tahun); 
			perform sc_trx.pr_1721_penomoran_buktipotong(vr_nik,99,vr_doktemp,vr_periode_awal,vr_periode_akhir,vr_tahun); 
					     
	    
    END LOOP;
    
    RETURN vr_return;
END;
$$;

alter function pr_generate_p1721(char, char, char, char) owner to postgres;

