create function jadwalkerja_after() returns trigger
    language plpgsql
as
$$
begin


if (new.status='F') then


	INSERT INTO sc_trx.jadwalkerja(kdregu,kodejamkerja,inputdate,inputby,id,tgl) 
	select kdregu,kodejamkerja,inputdate,inputby,id,tgl  from sc_his.jadwalkerja where status='F';

	delete from sc_his.jadwalkerja;
	
end if;
return new;

end;
$$;

alter function jadwalkerja_after() owner to postgres;

