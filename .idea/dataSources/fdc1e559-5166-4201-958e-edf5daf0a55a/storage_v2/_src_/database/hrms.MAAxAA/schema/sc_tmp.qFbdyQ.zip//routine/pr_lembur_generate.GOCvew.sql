create function pr_lembur_generate(vr_param text) returns text
    language plpgsql
as
$$
DECLARE
	/*
		author 		: Fiky Ashariza
		create date	: 2019/01/01
		update date	: 
		update case	: Perubahan dari generate program ke store procedure
		jenis lembur	: D1 DURASI/ D2 NON DURASI
		param using	: select sc_tmp.pr_lembur_generate('2019-02-01'||'|'||'2019-02-28'||'|'||'P1'||'|'||'P2'||'|'||'NIK'||'|'||'66666');
	*/
	vr_jam_masuk timestamp;
	vr_jam_pulang timestamp;
    vr_hisgp numeric;	
    vr_hisperiode char(20);	
    vr_split text;	
    vr_branch text :=coalesce(branch,'') from sc_mst.branch where cdefault='YES';
    vr_tglawal date; vrs_tglawal date;	
    vr_tglakhir date; vrs_tglakhir date;	 
    vr_kddept char(30);	vrs_kddept char(30);
    vr_grouppenggajian char(30); vrs_grouppenggajian char(30);	
    vr_nik char(30); vrs_nik char(30);	vrs_user char(30);vrs_nikmap char(30);
    vr_param1 text; vr_param2 text; vr_param3 text; vr_opsigaji text;
    	vq_karyawan text := 'select nik from sc_mst.karyawan where coalesce(statuskepegawaian,'''')!=''KO''';
    	vq_txlembur text := 'select * from 
				(select a.nik,a.nodok,a.tgl_kerja,a.tgl_dok,a.kdlembur,a.tgl_jam_mulai,a.tgl_jam_selesai,
				a.durasi,a.jenis_lembur,a.status,b.bag_dept as kddept,b.grouppenggajian,b.nmlengkap
				from sc_trx.lembur a
				left outer join sc_mst.karyawan b on a.nik=b.nik
				) as x where status=''P''';
    	vr_rec record;
BEGIN

    vrs_tglawal:=trim(split_part(vr_param, '|', 1));
    vrs_tglakhir:=trim(split_part(vr_param, '|', 2));
    vrs_kddept:=trim(split_part(vr_param, '|', 3));
    vrs_grouppenggajian:=trim(split_part(vr_param, '|', 4));
    vrs_nik:=trim(split_part(vr_param, '|', 5));
    vrs_user:=trim(split_part(vr_param, '|', 6));
    
	
	vr_param1 := ' and nik is not null and nik =''18186''';
	vr_param2 := ' and to_char(tgl_kerja,''YYYY-MM-DD'') between '''||vrs_tglawal||''' and '''||vrs_tglakhir||'''';
	vr_param3 := ' and grouppenggajian ='''||vrs_grouppenggajian||'''';
	
    	RAISE NOTICE 'Calling 1(%)', vrs_tglawal;
		
	--delete from dummy
	--select * from sc_tmp.cek_lembur
	--select * from sc_mst.mapping_karyawan 
	--select * from sc_trx.transready limit 10
	delete from sc_tmp.cek_lembur;-- where nodok=vrs_user;
	
    FOR vr_rec IN EXECUTE vq_txlembur||vr_param2-- USING n 
    
    LOOP
		IF EXISTS(select * from sc_mst.mapping_karyawan where nikmap=vr_rec.nik and status='P') then 
			vrs_nikmap := coalesce(nik,'') from sc_mst.mapping_karyawan where nikmap=vr_rec.nik and status='P';
		end if;
		/* kurang checkinout maximum date*/

  /* PENAMBAHAN OPTION SETTING UNTUK PERHITUNGAN GAJIPOKOK DAN TETAP*/
  /* PAYROL04  A: GAJIPOKOK , B: GAJITETAP*/
		vr_opsigaji:=coalesce(value1,'') from sc_mst.option where kdoption='PAYROL04';
  		if (vr_opsigaji='A') then 
			select gajipokok,periode from sc_his.history_gaji into vr_hisgp,vr_hisperiode where nik=vr_rec.nik and periode=to_char(vr_rec.tgl_kerja,'yyyymm');
		elseif(vr_opsigaji='B') then
			select nominal,periode from sc_his.history_gaji into vr_hisgp,vr_hisperiode where nik=vr_rec.nik and periode=to_char(vr_rec.tgl_kerja,'yyyymm');
		end if;
  
		
		select min(a.checktime)as jam_masuk_absen,max(a.checktime) as jam_pulang_absen into vr_jam_masuk,vr_jam_pulang from sc_tmp.checkinout a
								left outer join sc_mst.karyawan b on a.badgenumber=b.nik
								where to_char(checktime,'YYYY-MM-DD')::date=vr_rec.tgl_kerja and b.nik=vr_rec.nik
								group by badgenumber,nik;
		IF (vr_rec.jenis_lembur='D1') THEN
		
			insert into sc_tmp.cek_lembur
			(nik,nodok,nodok_ref,tgl_nodok_ref,tplembur,jam_mulai,jam_selesai,jumlah_jam,tgl_kerja,
			jam_selesai_absen,jam_mulai_absen,status,jenis_lembur,gajipokok,periode_gaji,nikmap)
			(select vr_rec.nik,vrs_user,vr_rec.nodok,vr_rec.tgl_dok,vr_rec.kdlembur,vr_rec.tgl_jam_mulai,vr_rec.tgl_jam_selesai,vr_rec.durasi,vr_rec.tgl_kerja,
			vr_jam_pulang,vr_jam_masuk,'I',vr_rec.jenis_lembur,vr_hisgp,vr_hisperiode,vrs_nikmap);
			
		ELSE
			insert into sc_tmp.cek_lembur
			(nik,nodok,nodok_ref,tgl_nodok_ref,tplembur,jam_mulai,jam_selesai,jumlah_jam,tgl_kerja,
			jam_selesai_absen,jam_mulai_absen,status,jenis_lembur,gajipokok,periode_gaji,nikmap)
			(select vr_rec.nik,vrs_user,vr_rec.nodok,vr_rec.tgl_dok,vr_rec.kdlembur,vr_rec.tgl_jam_mulai,vr_rec.tgl_jam_selesai,vr_rec.durasi,vr_rec.tgl_kerja,
			NULL,NULL,'I',vr_rec.jenis_lembur,vr_hisgp,vr_hisperiode,vrs_nikmap);
			
		END IF;
		update sc_tmp.cek_lembur set status='P' where nodok_ref=vr_rec.nodok;
	   RAISE NOTICE 'Under Loop(%)', vr_rec.nik; 
    END LOOP;
    
    RETURN vr_rec.nik;
END;
$$;

alter function pr_lembur_generate(text) owner to postgres;

