create function pr_1721_penomoran_buktipotong_final(xnik character, nomor_urut integer, vr_nodok character) returns SETOF void
    language plpgsql
as
$$
DECLARE 
vr_duit numeric(18,2):=0;
vr_nomor_pelaporan character(20);
vr_group_pg character(10);
BEGIN		

	
	delete from sc_mst.penomoran where userid=vr_nodok and dokumen='P1721'; 
	    insert into sc_mst.penomoran 
	    (userid,dokumen,nomor,errorid,partid,counterid,xno)
	    values(vr_nodok,'P1721',' ',0,' ',1,0);
	vr_nomor_pelaporan:=trim(coalesce(nomor,'')) from sc_mst.penomoran where userid=vr_nodok and dokumen='P1721';

	--select * from sc_mst.penomoran where dokumen='P1721'

	update sc_tmp.p1721_detail set nomor_pelaporan=vr_nomor_pelaporan where nik=xnik and no_urut=nomor_urut;
	--SELECT * FROM SC_TMP.P1721_DETAIL LIMIT 10

	RETURN;	
END;
$$;

alter function pr_1721_penomoran_buktipotong_final(char, integer, char) owner to postgres;

