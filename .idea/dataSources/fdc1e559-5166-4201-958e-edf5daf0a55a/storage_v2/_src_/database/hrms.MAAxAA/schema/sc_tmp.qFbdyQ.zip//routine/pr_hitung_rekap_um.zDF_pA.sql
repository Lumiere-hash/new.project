create function pr_hitung_rekap_um(vr_kdcabang character, vr_tglawal date, vr_tglakhir date) returns SETOF void
    language plpgsql
as
$$
    --author by : Fiky Ashariza 02-02-2017
--update by : --
DECLARE vr_tglapproval date;
DECLARE vr_tgl_act date;
DECLARE vr_tgl_dok date;
DECLARE vr_nodok_ref character(12);
DECLARE vr_nominal_um numeric;
DECLARE vr_cek_nominal_um numeric;
DECLARE vr_nik character(12);

--DECLARE vr_out integer;


BEGIN
	--select * from sc_mst.kantin
	--select * from sc_mst.uangmakan
	--select * from sc_mst.karyawan where nmlengkap like '%TINO%'
FOR vr_nik in select trim(nik) from sc_mst.karyawan where tglkeluarkerja is null and kdcabang=vr_kdcabang
	LOOP
	vr_nominal_um:=case 
	when a.kdcabang='SMGDMK' then b.besaran-c.besaran 
	else b.besaran
	end as nominal from sc_mst.karyawan a left outer join
	sc_mst.uangmakan b on a.lvl_jabatan=b.kdlvl left outer join
	sc_mst.kantin c on a.kdcabang=c.kdcabang
	where a.nik=vr_nik;

	for vr_nodok_ref in select trim(dok_ref) from sc_trx.uangmakan 
		where nik=vr_nik and dok_ref is not null and (left(dok_ref,2)='IK' or left(dok_ref,2)='PA' or left(dok_ref,2)='DT') and 
		(to_char(tgl,'yyyy-mm-dd') between to_char(vr_tglawal - interval'1 week','yyyy-mm-dd') and to_char(vr_tglakhir,'yyyy-mm-dd'))
	loop	
		select cast(to_char(approval_date,'yyyy-mm-dd')as date) into vr_tglapproval from sc_trx.ijin_karyawan where nodok=vr_nodok_ref;
		select nominal into vr_cek_nominal_um from sc_trx.uangmakan where dok_ref=vr_nodok_ref and nik=vr_nik;
		
		IF (vr_cek_nominal_um=0 or vr_cek_nominal_um is null) THEN 
			update sc_trx.uangmakan set nominal=vr_nominal_um,keterangan='+ PERSETUJUAN NO IJIN : '||vr_nodok_ref where tgl=vr_tglapproval and nik=vr_nik;
		END IF;
	
	return next vr_nodok_ref;	
	end loop;
	
return next vr_nik;
end loop;	

	
END;
$$;

alter function pr_hitung_rekap_um(char, date, date) owner to postgres;

