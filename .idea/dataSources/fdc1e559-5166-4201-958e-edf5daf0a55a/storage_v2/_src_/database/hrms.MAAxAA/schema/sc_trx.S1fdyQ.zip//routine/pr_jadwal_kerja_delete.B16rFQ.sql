create function pr_jadwal_kerja_delete() returns trigger
    language plpgsql
as
$$
declare
     
begin
	delete from sc_trx.dtljadwalkerja
	where kdregu=old.kdregu and tgl=old.tgl and updatedate is null;	

return old;

end;
$$;

alter function pr_jadwal_kerja_delete() owner to postgres;

