create view v_anajab_mst
            (docno, docdate, docref, kddept, kdsubdept, kdjabatan, kdlvljabatan, file_dir, file_name, file_patch,
             description, status, inputdate, inputby, updatedate, updateby, approvaldate, approvalby, docnotmp, nmdept,
             nmsubdept, nmjabatan, nmlvljabatan, docdate1)
as
SELECT a.docno,
       a.docdate,
       a.docref,
       a.kddept,
       a.kdsubdept,
       a.kdjabatan,
       a.kdlvljabatan,
       a.file_dir,
       a.file_name,
       a.file_patch,
       a.description,
       a.status,
       a.inputdate,
       a.inputby,
       a.updatedate,
       a.updateby,
       a.approvaldate,
       a.approvalby,
       a.docnotmp,
       b.nmdept,
       c.nmsubdept,
       d.nmjabatan,
       e.nmlvljabatan,
       to_char(a.docdate::timestamp with time zone, 'dd-mm-yyyy'::text) AS docdate1
FROM sc_his.anajab_mst a
         LEFT JOIN sc_mst.departmen b ON a.kddept = b.kddept
         LEFT JOIN sc_mst.subdepartmen c ON a.kddept = c.kddept AND a.kdsubdept = c.kdsubdept
         LEFT JOIN sc_mst.jabatan d ON a.kddept = d.kddept AND a.kdsubdept = d.kdsubdept AND a.kdjabatan = d.kdjabatan
         LEFT JOIN sc_mst.lvljabatan e ON a.kdlvljabatan = e.kdlvl;

alter table v_anajab_mst
    owner to postgres;

