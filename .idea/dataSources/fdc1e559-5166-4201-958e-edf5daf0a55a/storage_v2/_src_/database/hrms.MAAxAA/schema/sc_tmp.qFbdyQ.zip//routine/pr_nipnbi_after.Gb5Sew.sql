create function pr_nipnbi_after() returns trigger
    language plpgsql
as
$$
declare
--created by Fiky ::03/04/2016
     vr_idabsen char(12);
     vr_nik char(12);
     vr_nomor char(12);
     vr_tglmasukkerja char(4);
begin    
    vr_idabsen:=trim(coalesce(idabsen,'')) from sc_tmp.karyawan where idabsen=new.idabsen and nik=new.nik;
    vr_nik:=trim(coalesce(nik,'')) from sc_tmp.karyawan where idabsen=new.idabsen and nik=new.nik;
            
    delete from sc_mst.penomoran where userid=vr_nik;
    delete from sc_mst.trxerror where userid=vr_nik;    
        
    insert into sc_mst.penomoran 
    (userid,dokumen,nomor,errorid,partid,counterid,xno)
    values(vr_nik,'NIP-PEGAWAI',' ',0,' ',1,0);

        vr_nomor:=trim(coalesce(nomor,'')) from sc_mst.penomoran where userid=vr_nik;
        --ngambil dari yang baru menyisipkan ke sc_mst.karyawan dari tmp
        if (trim(vr_nomor)!='') or (not vr_nomor is null) then
            insert into sc_mst.karyawan (branch,nik,nmlengkap,callname,jk,neglahir,provlahir,kotalahir,tgllahir,kd_agama,stswn,stsfisik,ketfisik,noktp,ktp_seumurhdp,ktpdikeluarkan,tgldikeluarkan,status_pernikahan,gol_darah,
					negktp,provktp,kotaktp,kecktp,kelktp,alamatktp,negtinggal,provtinggal,kotatinggal,kectinggal,keltinggal,alamattinggal,nohp1,nohp2,npwp,tglnpwp,bag_dept,subbag_dept,jabatan,lvl_jabatan,
					grade_golongan,nik_atasan,nik_atasan2,status_ptkp,besaranptkp,tglmasukkerja,tglkeluarkerja,masakerja,statuskepegawaian,kdcabang,branchaktif,grouppenggajian,gajipokok,gajibpjs,namabank,
					namapemilikrekening,norek,tjshift,idabsen,email,bolehcuti,sisacuti,inputdate,inputby,updatedate,updateby,image,idmesin,cardnumber,status,tgl_ktp,costcenter,tj_tetap,gajitetap,gajinaker,
					tjlembur,tjborong,nokk,kdwilayahnominal,kdlvlgp) 
		select branch,to_char(tglmasukkerja,'MMYY')||'.'||vr_nomor as nik,
					nmlengkap,callname,jk,neglahir,provlahir,kotalahir,tgllahir,kd_agama,stswn,stsfisik,ketfisik,noktp,ktp_seumurhdp,ktpdikeluarkan,tgldikeluarkan,status_pernikahan,gol_darah,
					negktp,provktp,kotaktp,kecktp,kelktp,alamatktp,negtinggal,provtinggal,kotatinggal,kectinggal,keltinggal,alamattinggal,nohp1,nohp2,npwp,tglnpwp,bag_dept,subbag_dept,jabatan,lvl_jabatan,
					grade_golongan,nik_atasan,nik_atasan2,status_ptkp,besaranptkp,tglmasukkerja,tglkeluarkerja,masakerja,statuskepegawaian,kdcabang,branchaktif,grouppenggajian,gajipokok,gajibpjs,namabank,
					namapemilikrekening,norek,tjshift,idabsen,email,bolehcuti,sisacuti,inputdate,inputby,updatedate,updateby,image,idmesin,cardnumber,status,tgl_ktp,costcenter,tj_tetap,gajitetap,gajinaker,
					tjlembur,tjborong,nokk,kdwilayahnominal,kdlvlgp
		  from sc_tmp.karyawan 
		  where nik=new.nik;
		
		---reporting karyawan baru ke cuti balance
/*
            insert into sc_trx.cuti_blc
            select vr_nomor||to_char(tglmasukkerja,'YYMM') as nik,cast(to_char(tglmasukkerja,'YYYY-MM-DD HH24:MI:SS')as date) as tanggal,
            vr_nomor||to_char(tglmasukkerja,'YYMM') as no_dokumen,0 as in_cuti,0 as out_cuti, 0 as sisacuti,'NEW' as doctype,'Jumlah Cuti:'||
            case when cast(to_char(tglmasukkerja,'dd') as numeric)<=15 then 13-to_number(to_char(tglmasukkerja,'MM'),'99')
		 when cast(to_char(tglmasukkerja,'dd') as numeric)>15 then 12-to_number(to_char(tglmasukkerja,'MM'),'99')
		 end||'||TGL:'||cast(to_char(tglmasukkerja+interval'1 YEAR','YYYY-MM-DD HH24:MI:SS')as date) as status from sc_tmp.karyawan where nik=vr_nik ;           
*/		 
	--Insert into table detail gaji
/*		select to_char(tglmasukkerja,'YYMM')  into vr_tglmasukkerja
			from sc_tmp.karyawan where nik=vr_nik ; 
		insert into sc_mst.dtlgaji_karyawan (nik,no_urut,keterangan,nominal)
		select vr_nomor||vr_tglmasukkerja as nik,no_urut,keterangan,0 as nominal from sc_mst.detail_formula where tetap='T' and kdrumus='PR' 
		and trim(vr_nomor||vr_tglmasukkerja||trim(cast(no_urut as character(3)))) not in (select trim(nik||trim(cast(no_urut as character(3)))) from sc_mst.dtlgaji_karyawan);
*/		
            delete from sc_tmp.karyawan where nik=vr_nik;    --delete dari tmp setelah insert mst.karyawan    
            insert into sc_mst.trxerror
            (userid,errorcode,nomorakhir1,nomorakhir2,modul)
            values(vr_nik,'0',vr_nomor,vr_nomor,'KARYAWAN');            

        else
        --select * from sc_trx.cuti_blc
        --select * from sc_mst.trxerror
            insert into sc_mst.trxerror
            (userid,errorcode,nomorakhir1,nomorakhir2,modul)
            values(vr_nik,'1','','','KARYAWAN');
        end if;            
    
    return new;
        
end;
$$;

alter function pr_nipnbi_after() owner to postgres;

