create function tr_transready_uangmkn() returns trigger
    language plpgsql
as
$$
declare
vr_um_max01 time without time zone;     
vr_um_max02 time without time zone;     
vr_um_min01 time without time zone;     
vr_um_min02 time without time zone;     
vr_date_now date;  
vr_dok_lembur character(25);   
--select * from sc_mst.option	
     
begin
	--select * from sc_trx.transready limit 10

	delete from sc_trx.uangmakan where nik=new.nik and tgl=new.tgl;
	vr_date_now:=cast(to_char(now() ,'yyyy-mm-dd') as date);
	--select value2 from sc_mst.option where kdoption='HRUMMAX01';
	if (trim(new.kdregu) = 'NC') then
		vr_um_max01:=value2 from sc_mst.option where kdoption='HRUMMAX01' and group_option='NC';----'13:00:00'
		vr_um_max02:=value2 from sc_mst.option where kdoption='HRUMMAX02' and group_option='NC';----'11:00:00'
		vr_um_min01:=value2 from sc_mst.option where kdoption='HRUMMIN01' and group_option='NC';--'07:55:00'
		vr_um_min02:=value2 from sc_mst.option where kdoption='HRUMMIN02' and group_option='NC'; --'07:55:00'
	else
		vr_um_max01:=value2 from sc_mst.option where kdoption='HRUMMAX01' and group_option='DEFAULT';----'13:00:00'
		vr_um_max02:=value2 from sc_mst.option where kdoption='HRUMMAX02' and group_option='DEFAULT';----'11:00:00'
		vr_um_min01:=value2 from sc_mst.option where kdoption='HRUMMIN01' and group_option='DEFAULT';--'07:55:00'
		vr_um_min02:=value2 from sc_mst.option where kdoption='HRUMMIN02' and group_option='DEFAULT'; --'07:55:00'
	end if;


	
	insert into sc_trx.uangmakan (	select 'SBYNSA',ta.nik,ta.tgl,ta.checkin,ta.checkout,
	case 	when kdcabang<>'SMGDMK' and checkin is null and td.nodok is null and tc.nodok is null  and tf.tgl_libur is null and checkout is null then null 
		when kdcabang<>'SMGDMK' and checkin<=vr_um_min01 and checkout>jam_pulang and te.nodok is null and tf.tgl_libur is null and left(td.nodok,2)='DL' then NULL
		when kdcabang<>'SMGDMK' and checkin<=vr_um_min01 and checkout>jam_pulang and te.nodok is null and tf.tgl_libur is null and left(td.nodok,2)<>'DL' then besaran
		when kdcabang<>'SMGDMK' and checkin<=vr_um_min01 and checkout>jam_pulang and te.nodok is null and tf.tgl_libur is not null then null
		when kdcabang<>'SMGDMK' and checkin<=vr_um_min01 and checkout>jam_pulang and te.nodok is not null then besaran+besaran
		when kdcabang<>'SMGDMK' and (checkin is not null or checkout is not null) and lvl_jabatan='B' then besaran
		when kdcabang<>'SMGDMK' and checkin<vr_um_min01 and checkout>=vr_um_max02 and to_char(tgl,'Dy')='Sat'  then besaran	
		when kdcabang<>'SMGDMK' and checkin>vr_um_min01 and vr_um_max01<checkout and tc.kdijin_absensi is null and te.nodok is null then null 
		when kdcabang<>'SMGDMK' and checkin>vr_um_min01 and vr_um_max01<checkout and tc.kdijin_absensi is null and te.nodok is not null then besaran 
		when kdcabang<>'SMGDMK' and checkin>vr_um_min01  and checkout>jam_pulang and tc.kdijin_absensi is null and te.nodok is null  then null 
		when kdcabang<>'SMGDMK' and checkin>vr_um_min01  and checkout>jam_pulang and tc.kdijin_absensi is null and te.nodok is not null then besaran
		when kdcabang<>'SMGDMK' and checkin is null and checkout>jam_pulang and tc.kdijin_absensi is null  then null
		when kdcabang<>'SMGDMK' and checkin<vr_um_min01 and checkout is null  and tc.kdijin_absensi is null  then null
		when kdcabang<>'SMGDMK' and checkin<vr_um_min01 and checkout<vr_um_max01  and tc.kdijin_absensi is null then null
		when kdcabang<>'SMGDMK' and checkin<vr_um_min01 and checkout>=vr_um_max01 and to_char(tgl,'Dy')<>'Sat'  and  td.nodok is null then besaran	
		when kdcabang<>'SMGDMK' and checkin<vr_um_min01 and checkout>=vr_um_max01 and to_char(tgl,'Dy')<>'Sat'  and  left(td.nodok,2)='DL' then NULL	
		when kdcabang<>'SMGDMK' and checkin<vr_um_min01 and checkout>=vr_um_max02 and to_char(tgl,'Dy')='Sat' and  left(td.nodok,2)='DL'  then NULL
		when kdcabang<>'SMGDMK' and checkin<vr_um_min01 and (checkout is null or checkout<jam_pulang)  and tc.kdijin_absensi='IK' and cast(to_char(tc.approval_date,'yyyy-mm-dd')as date)<=vr_date_now  then besaran 
		when kdcabang<>'SMGDMK' and checkin>=jam_masuk and checkout>jam_pulang and tc.kdijin_absensi is not null then besaran
		when kdcabang<>'SMGDMK' and checkin is null and checkout is null and tc.kdijin_absensi is not null then besaran
		--when kdcabang<>'SMGDMK' and cast(to_char(tc.approval_date,'yyyy-mm-dd')as date)=ta.tgl  then besaran 

		/*SEMARANG DEMAK*/
		when kdcabang='SMGDMK' and checkin is null and checkout is null and td.nodok is null and tc.nodok is null then null 
		when kdcabang='SMGDMK' and checkin<=vr_um_min01 and checkout>jam_pulang and te.nodok is null and tf.tgl_libur is null and left(td.nodok,2)='DL' then NULL
		when kdcabang='SMGDMK' and checkin<=vr_um_min01 and checkout>jam_pulang and te.nodok is null and tf.tgl_libur is null and left(td.nodok,2)<>'DL' then besaran-kantin
		when kdcabang='SMGDMK' and checkin<=vr_um_min01 and checkout>jam_pulang and te.nodok is null and tf.tgl_libur is not null then null
		when kdcabang='SMGDMK' and checkin<=vr_um_min01 and checkout>jam_pulang and te.nodok is not null then (besaran-kantin)+besaran
		when kdcabang='SMGDMK' and (checkin is not null or checkout is not null) and lvl_jabatan='B' then besaran-kantin
		when kdcabang='SMGDMK' and checkin<vr_um_min01 and checkout>=vr_um_max02 and to_char(tgl,'Dy')='Sat' then besaran-kantin
		when kdcabang='SMGDMK' and checkin>vr_um_min01 and vr_um_max01<checkout and tc.kdijin_absensi is null and te.nodok is null then null 
		when kdcabang='SMGDMK' and checkin>vr_um_min01 and vr_um_max01<checkout and tc.kdijin_absensi is null and te.nodok is not null then besaran-kantin 
		when kdcabang='SMGDMK' and checkin>vr_um_min01  and checkout>jam_pulang and tc.kdijin_absensi is null and te.nodok is null  then null 
		when kdcabang='SMGDMK' and checkin>vr_um_min01  and checkout>jam_pulang and tc.kdijin_absensi is null and te.nodok is not null then besaran-kantin
		when kdcabang='SMGDMK' and checkin is null and checkout>jam_pulang and tc.kdijin_absensi is null  then null
		when kdcabang='SMGDMK' and checkin<vr_um_min01 and checkout is null  and tc.kdijin_absensi is null  then null
		when kdcabang='SMGDMK' and checkin<vr_um_min01 and checkout<vr_um_max01  and tc.kdijin_absensi is null then null
		when kdcabang='SMGDMK' and checkin<vr_um_min01 and checkout>=vr_um_max01 and to_char(tgl,'Dy')<>'Sat'  and  td.nodok is null and tc.kdijin_absensi is null  then besaran-kantin
		when kdcabang='SMGDMK' and checkin<vr_um_min01 and checkout>=vr_um_max01 and to_char(tgl,'Dy')<>'Sat'  and  left(td.nodok,2)='DL' then NULL	
		when kdcabang='SMGDMK' and checkin<vr_um_min01 and checkout>=vr_um_max02 and to_char(tgl,'Dy')='Sat' and  left(td.nodok,2)='DL'  then NULL
		when kdcabang='SMGDMK' and checkin<vr_um_min01 and tc.kdijin_absensi='IK' and cast(to_char(tc.approval_date,'yyyy-mm-dd')as date)<=ta.tgl then besaran 
		when kdcabang='SMGDMK' and checkin is null and checkout is null and tc.kdijin_absensi='IK' and cast(to_char(tc.approval_date,'yyyy-mm-dd')as date)<=vr_date_now  then besaran 
		when kdcabang='SMGDMK' and cast(to_char(tc.approval_date,'yyyy-mm-dd')as date)=ta.tgl  then besaran-kantin 

--	else besaran 
	end as nominal,
	case 	when checkin is null and checkout is null and td.nodok is null and tc.nodok is null  and tf.tgl_libur is null  and th.nodok is null then 'TIDAK MASUK KANTOR'
		when checkin is null and checkout is null and td.nodok is null  and tf.tgl_libur is not null and th.nodok is null then tf.ket_libur  
		when td.nodok is not null then 'DINAS DENGAN NO DINAS :'||td.nodok||'|| APP TGL: '||to_char(td.approval_date,'yyyy-mm-dd')
		when th.nodok is not null then 'CUTI DENGAN NO CUTI :'||th.nodok||'|| APP TGL: '||to_char(th.approval_date,'yyyy-mm-dd')
		when checkin<jam_masuk and checkout>jam_pulang and te.nodok is null and tf.tgl_libur is null then 'TEPAT WAKTU'
		when checkin<jam_masuk and checkout>jam_pulang and te.nodok is null and tf.tgl_libur is not null then tf.ket_libur
		when checkin<jam_masuk and checkout>jam_pulang and te.nodok is not null then 'TEPAT WAKTU + Lembur :'||te.nodok
		when checkin>jam_masuk and checkout<jam_pulang then 'TELAT MASUK/PULANG AWAL'
		when checkin>=jam_masuk and checkout>jam_pulang and tc.kdijin_absensi is null and te.nodok is null and tg.kdijin_absensi is null  then 'TELAT MASUK'	
		when checkin>=jam_masuk and checkout>jam_pulang and tg.kdijin_absensi is not null and te.nodok is null then 'IJIN PRIBADI NO :'||tg.nodok
		when checkin>=jam_masuk and checkout>jam_pulang and tc.kdijin_absensi is null and te.nodok is not null then 'TELAT MASUK + Lembur :'||te.nodok	
		when checkin>=jam_masuk and checkout>jam_pulang and tc.kdijin_absensi is not null then 'IJIN DGN NO :'||tc.nodok||'|| APP TGL: '||to_char(tc.approval_date,'yyyy-mm-dd')
		when checkin is null and checkout is null and tc.kdijin_absensi is not null then 'IJIN DGN NO :'||tc.nodok||'|| APP TGL: '||to_char(tc.approval_date,'yyyy-mm-dd')
		when checkin isnull and checkout>jam_pulang then 'TIDAK CEKLOG MASUK'
		when checkin<jam_masuk and checkout is null and tc.kdijin_absensi is null then 'TIDAK CEKLOG PULANG'
				when checkin<jam_masuk and checkout<jam_pulang and tc.kdijin_absensi is null and tg.kdijin_absensi is null then 'PULANG AWAL'
		when checkin<jam_masuk and checkout<jam_pulang and tg.kdijin_absensi is not null then 'IJIN PRIBADI NO :'||tg.nodok
		when checkin<vr_um_min01  and (checkout is null or checkout<jam_pulang)  and tc.kdijin_absensi='IK' then 'IJIN DGN NO :'||tc.nodok||'|| APP TGL: '||to_char(tc.approval_date,'yyyy-mm-dd')
	end as keterangan,vr_date_now as tgl_dok,case when tc.nodok is not null then tc.nodok else td.nodok end as nodok from (
					select 'SBYNSA' as branch,a.nik,b.nmlengkap,c.kddept,c.nmdept,e.kdjabatan,e.nmjabatan,a.tgl,
					case 
					when a.jam_masuk_absen=a.jam_pulang_absen and a.jam_masuk_absen>vr_um_max01 then null
					else a.jam_masuk_absen end as checkin,
					case
					when a.jam_masuk_absen=a.jam_pulang_absen and a.jam_pulang_absen<=vr_um_max01 then null
					else a.jam_pulang_absen end as checkout,null as nominal,'' as keterangan,b.kdcabang,b.lvl_jabatan,a.jam_masuk,a.jam_pulang,f.besaran as kantin from sc_trx.transready a 
					left outer join sc_mst.karyawan b on a.nik=b.nik
					left outer join sc_mst.departmen c on b.bag_dept=c.kddept
					left outer join sc_mst.subdepartmen d on b.subbag_dept=d.kdsubdept and b.bag_dept=d.kddept
					left outer join sc_mst.jabatan e on b.jabatan=e.kdjabatan and b.subbag_dept=e.kdsubdept and b.bag_dept=e.kddept
					left outer join sc_mst.kantin f on b.kdcabang=f.kdcabang
					) as ta 
					left outer join sc_mst.uangmakan tb on tb.kdlvl=ta.lvl_jabatan 
					left outer join sc_trx.ijin_karyawan tc on tc.nik=ta.nik and tc.tgl_kerja=ta.tgl and tc.status='P' and tc.type_ijin='DN' --and to_char(tc.approval_date,'yyyy-mm-dd')<=to_char(now(),'yyyy-mm-dd')
					left outer join sc_trx.dinas td on td.nik=ta.nik and (ta.tgl between td.tgl_mulai and td.tgl_selesai) and td.status='P'
					left outer join sc_trx.lembur te on te.nik=ta.nik and te.tgl_kerja=ta.tgl and to_char(ta.checkout,'HH24:MI:SS')>='18:00:00' and (te.status='P' or te.status='F') and te.kdlembur='BIASA' and to_char(te.tgl_jam_mulai,'HH24:MI:SS')>='13:00:00'/*LEMBUR BIASA*/
					left outer join sc_mst.libur tf on tf.tgl_libur=ta.tgl 
					left outer join sc_trx.ijin_karyawan tg on tg.nik=ta.nik and tg.tgl_kerja=ta.tgl and tg.status='P' and tg.type_ijin='PB'
					left outer join sc_trx.cuti_karyawan th on th.nik=ta.nik and (ta.tgl between th.tgl_mulai and th.tgl_selesai) and th.status='P'
					where ta.lvl_jabatan<>'A' and ta.nik=new.nik and ta.tgl=new.tgl
	group by ta.nik,ta.nmlengkap,ta.tgl,ta.checkin,ta.checkout,ta.kdcabang,ta.jam_masuk,ta.jam_pulang,tb.besaran,ta.lvl_jabatan,ta.kantin,tc.kdijin_absensi,tg.kdijin_absensi,tg.nodok,tc.tgl_kerja,td.nodok,td.approval_date,tc.nodok,tc.approval_date,te.nodok,tf.tgl_libur,tf.ket_libur,th.nodok,th.approval_date				
	ORDER BY NMLENGKAP





	);

return new;

end;
$$;

alter function tr_transready_uangmkn() owner to postgres;

