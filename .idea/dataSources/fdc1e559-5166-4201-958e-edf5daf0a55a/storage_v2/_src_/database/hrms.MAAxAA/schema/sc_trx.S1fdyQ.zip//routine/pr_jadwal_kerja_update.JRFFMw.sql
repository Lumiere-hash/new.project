create function pr_jadwal_kerja_update() returns trigger
    language plpgsql
as
$$
declare
     
     --vr_nomor char(30);
     --vr_status char(10);
     
begin
	--hapus data lama
	delete from sc_trx.dtljadwalkerja	
	where kdregu=new.kdregu and tgl=new.tgl and updatedate is null;

	--input data baru
	/*
	insert into sc_trx.dtljadwalkerja (nik,tgl,kdjamkerja,kdregu,kdmesin)
	select b.nik,tgl,kodejamkerja,a.kdregu,kdmesin from sc_trx.jadwalkerja a
	left outer join sc_mst.regu d on a.kdregu=d.kdregu 
	left outer join sc_mst.regu_opr b on a.kdregu=b.kdregu and b.kdregu=new.kdregu
	left outer join sc_mst.karyawan c on c.nik=b.nik
	where a.kdregu=new.kdregu and tgl=new.tgl and kodejamkerja=new.kodejamkerja and id=old.id;
	*/
	insert into sc_trx.dtljadwalkerja (nik,shift,tgl,kdjamkerja,kdregu,kdmesin)
	select b.nik,e.shift,tgl,kodejamkerja,a.kdregu,kdmesin from sc_trx.jadwalkerja a
	left outer join sc_mst.regu d on a.kdregu=d.kdregu
	left outer join sc_mst.regu_opr b on a.kdregu=b.kdregu
	left outer join sc_mst.karyawan c on c.nik=b.nik
	left outer join sc_mst.jabatan e on c.jabatan=e.kdjabatan and e.kddept=c.bag_dept and e.kdsubdept=c.subbag_dept
	where a.kdregu=new.kdregu and a.tgl=new.tgl --and kodejamkerja='NSB'
	and trim(c.nik)::char(6)||a.tgl::char(20) not in (select trim(nik)::char(6)||tgl::char(20) from sc_trx.dtljadwalkerja where updatedate is not null and tgl=new.tgl) and b.nik is not null; 
		
return new;

end;
$$;

alter function pr_jadwal_kerja_update() owner to postgres;

