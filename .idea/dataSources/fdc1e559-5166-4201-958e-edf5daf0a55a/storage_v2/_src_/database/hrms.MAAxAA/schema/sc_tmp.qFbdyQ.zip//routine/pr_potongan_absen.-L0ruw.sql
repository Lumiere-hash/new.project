create function pr_potongan_absen() returns trigger
    language plpgsql
as
$$
declare
     
     vr_potongan numeric;
     vr_gaji money;
     vr_nominal money;
     vr_nik char(12);
     vr_tglkerja date;
     vr_stsptg char(12);
     vr_dokcuti char(12);
     vr_jenis char(12);
     
     
begin
--vr_status:=trim(coalesce(status,'')) from sc_tmp.cuti where branch=new.branch and kddokumen=new.kddokumen for update;
--vr_nomor
	if (new.status='P' and old.status='I') then
	select nik,tgl_kerja into vr_nik,vr_tglkerja from sc_tmp.potongan_absen where nik=new.nik and tgl_kerja=new.tgl_kerja and nodok=new.nodok; 
        select tpcuti,trim(nodok),trim(status_ptg) into vr_jenis,vr_dokcuti,vr_stsptg from sc_trx.cuti_karyawan where nik=vr_nik and tgl_mulai=vr_tglkerja;
	--select gajipokok into vr_gaji from sc_mst.karyawan where nik=vr_nik;
	select value3 into vr_potongan from sc_mst.option where kdoption='E';
	select gajipokok into vr_gaji from sc_mst.karyawan where nik=new.nik;	
	vr_nominal=(vr_gaji/vr_potongan);

		IF (coalesce(vr_dokcuti,'')<>'' and vr_stsptg='A1') THEN --cuti biasa
		        update sc_tmp.potongan_absen set flag_cuti='NO',cuti_nominal=0 where nik=vr_nik and tgl_kerja=vr_tglkerja;
		           --update sc_tmp.payroll_master set tmp_cuti=1,sisa_cuti=coalesce(vr_sisacuti,0) where nodok=dokno and nik=listNik.nik;
		           --select sisa_cuti into vr_sisabaru from sc_tmp.payroll_master where nodok=dokno and nik=listNik.nik;
			   /*IF trim(vr_stsptg)='A1' then	
			   update sc_tmp.potongan_absen set flag_cuti='NO',cuti_nominal=0 where nodok=dokno and nik=vr_nikand tgl_kerja=vr_tglkerja;	
			   ELSE update sc_tmp.potongan_absen set flag_cuti='YES',cuti_nominal=vr_nominalwhere nodok=dokno and nik=vr_nikand tgl_kerja=vr_tglkerja;	 	
			   END IF;*/
		           /*IF vr_sisabaru<0 THEN
				update sc_tmp.potongan_absen set flag_cuti='NO',cuti_nominal=vr_nominalwhere nodok=dokno and nik=vr_nikand tgl_kerja=vr_tglkerja;
			   ELSE update sc_tmp.potongan_absen set flag_cuti='NO',cuti_nominal=0 where nodok=dokno and nik=vr_nikand tgl_kerja=vr_tglkerja;
			   END IF;*/
			--else update sc_tmp.potongan_absen set flag_cuti='YES',cuti_nominal=vr_nominalwhere nodok=dokno and nik=vr_nikand tgl_kerja=vr_tglkerja;
                      --end if;
		     /*ELSEIF (coalesce(vr_jenis,'')='A' and coalesce(vr_dokcuti,'')<>'') THEN --cuti biasa
		        update sc_tmp.potongan_absen set flag_cuti='YES',cuti_nominal=vr_nominalwhere nodok=dokno and nik=vr_nikand tgl_kerja=vr_tglkerja;
		           
		      ELSEIF (coalesce(vr_jenis,'')='B' and vr_dokcuti <>'' and trim(vr_stsptg)='A1') THEN --ijin khusus/dinas
				update sc_tmp.potongan_absen set flag_cuti='NO',cuti_nominal=0 where nodok=dokno and nik=vr_nikand tgl_kerja=vr_tglkerja;
		          

		       ELSEIF (coalesce(vr_jenis,'')='B' and vr_dokcuti <>'' and trim(vr_stsptg)='A2') THEN --ijin khusus/dinas
				update sc_tmp.potongan_absen set flag_cuti='YES',cuti_nominal=vr_nominalwhere nodok=dokno and nik=vr_nikand tgl_kerja=vr_tglkerja;*/
		        
		    ELSEIF (coalesce(vr_dokcuti,'')<>'' and vr_stsptg='A2') THEN --cuti biasa   	
			update sc_tmp.potongan_absen set flag_cuti='YES',cuti_nominal=vr_nominal where  nik=vr_nik and tgl_kerja=vr_tglkerja;

		      ELSEIF (coalesce(vr_dokcuti,'')='') THEN --tidak ada dokumen
		      --update sc_tmp.payroll_master set tmp_cuti=1,sisa_cuti=coalesce(vr_sisacuti,0)-1 where nodok=dokno and nik=listNik.nik;
		      update sc_tmp.potongan_absen set flag_cuti='YES',cuti_nominal=vr_nominal where  nik=vr_nik and tgl_kerja=vr_tglkerja;	

		   /*ELSEIF (coalesce(vr_dokcuti,'')=null) THEN --tidak ada dokumen
		   --update sc_tmp.payroll_master set tmp_cuti=1,sisa_cuti=coalesce(vr_sisacuti,0)-1 where nodok=dokno and nik=listNik.nik;
		   update sc_tmp.potongan_absen set flag_cuti='YES',cuti_nominal=vr_nominalwhere nodok=dokno and nik=vr_nikand tgl_kerja=vr_tglkerja;*/		           		           
                      END IF;
	--update sc_tmp.potongan_absen set cuti_nominal=vr_nominal where nik=new.nik and nodok=new.nodok and tgl_kerja=new.tglkerja;
	end if;

return new;

end;
$$;

alter function pr_potongan_absen() owner to postgres;

