create function pr_payroll_detail() returns trigger
    language plpgsql
as
$$
BEGIN
		
	IF (tg_op = 'UPDATE') THEN	---(tg_op = 'INSERT') or triger ubah update
			
		if (new.status='H' and old.status='I') then --H untuk hitung ulang
			update sc_tmp.payroll_master set 
			total_pendapatan=(select sum(nominal) from sc_tmp.payroll_detail where nodok=new.nodok and nik=new.nik and aksi='A'),
			total_potongan=(select sum(nominal) from sc_tmp.payroll_detail where nodok=new.nodok and nik=new.nik and aksi='B'),
			total_deposit=(select sum(nominal) from sc_tmp.payroll_detail where nodok=new.nodok and nik=new.nik and aksi='C'),
			total_upah=(select sum(nominal) from sc_tmp.payroll_detail where nodok=new.nodok and nik=new.nik and aksi='A')
				   -(select sum(nominal) from sc_tmp.payroll_detail where nodok=new.nodok and nik=new.nik and aksi='B')
				   +(select sum(nominal) from sc_tmp.payroll_detail where nodok=new.nodok and nik=new.nik and aksi='C')
			where nodok=new.nodok and nik=new.nik;	
			update sc_tmp.payroll_detail set status='I' where nodok=new.nodok and nik=new.nik;
		elseif (new.status='D' and old.status='I') then
			update sc_tmp.payroll_master set 
			total_pendapatan=(select sum(nominal) from sc_tmp.payroll_detail where nodok=old.nodok and nik=old.nik and aksi='A'),
			total_potongan=(select sum(nominal) from sc_tmp.payroll_detail where nodok=old.nodok and  nik=old.nik and aksi='B'),
			total_deposit=(select sum(nominal) from sc_tmp.payroll_detail where nodok=old.nodok and  nik=old.nik and aksi='C'),
			total_upah=(select sum(nominal) from sc_tmp.payroll_detail where nodok=old.nodok and nik=old.nik and aksi='A')
				   -(select sum(nominal) from sc_tmp.payroll_detail where nodok=old.nodok and  nik=old.nik and aksi='B')
				   +(select sum(nominal) from sc_tmp.payroll_detail where nodok=old.nodok and nik=old.nik and aksi='C')
			where nodok=old.nodok and nik=old.nik;
		end if;
		update sc_tmp.payroll_master set status='H' where nodok=new.nodok and nik=new.nik;
		RETURN new;
		
	ELSEIF tg_op = 'DELETE' THEN
		update sc_tmp.payroll_master set 
		total_pendapatan=(select sum(nominal) from sc_tmp.payroll_detail where nodok=old.nodok and nik=old.nik and aksi='A'),
		total_potongan=(select sum(nominal) from sc_tmp.payroll_detail where nodok=old.nodok and  nik=old.nik and aksi='B'),
		total_deposit=(select sum(nominal) from sc_tmp.payroll_detail where nodok=old.nodok and  nik=old.nik and aksi='C'),
		total_upah=(select sum(nominal) from sc_tmp.payroll_detail where nodok=old.nodok and nik=old.nik and aksi='A')
			   -(select sum(nominal) from sc_tmp.payroll_detail where nodok=old.nodok and  nik=old.nik and aksi='B')
			   +(select sum(nominal) from sc_tmp.payroll_detail where nodok=old.nodok and nik=old.nik and aksi='C')
		where nodok=old.nodok and nik=old.nik;
		RETURN old;	
	END IF;
	RETURN NEW;
END;
$$;

alter function pr_payroll_detail() owner to postgres;

