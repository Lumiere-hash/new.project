create function pr_pdca_cetakpage(vr_nik character, vr_doctype character, vr_periode character, vr_nama character) returns SETOF void
    language plpgsql
as
$$
DECLARE

	vr_looperiode char(12);
	vr_loopdocdate date;
	vr_countdata numeric; 
	vr_countmod numeric; 
	vr_temp_page numeric; 
	vr_page numeric; 
	vr_nomor numeric; 
--prosedur pembagian halaman cetak PDCA	
--author by : Fiky Ashariza 13-01-2018
--update by : - -

BEGIN	
	delete from sc_his.pdca_cetakpage where nik=vr_nik and planperiod=vr_periode and userprint=vr_nama;
	--select lvl_jabatan from sc_mst.karyawan limit 10
/*
	IF EXISTS(select * from sc_mst.karyawan where nik=vr_nik and lvl_jabatan='C') then

	FOR vr_loopdocdate,vr_countdata IN select docdate,case when mod(count(*),12)=0 then count(*)
			when mod(count(*),12)>0 then count(*)+12-mod(count(*),12)
			end as countdata
				from (select ROW_NUMBER() OVER (partition by nik,doctype,planperiod,docdate  order by nik,docno,docdate,nomor,docdate) AS nomorglobal,* from sc_his.pdca_dtl where nik=vr_nik and planperiod=vr_periode
				order by nik,docno,docdate,nomor) as x
				group by nik,docdate
		vr_page:=1; vr_temp_page:=0;
			LOOP
				
			vr_countdata:=case when mod(count(*),12)=0 then count(*)
							when mod(count(*),12)>0 then count(*)+12-mod(count(*),12)
							end as countdata
				from (select ROW_NUMBER() OVER (partition by nik,doctype,planperiod  order by nik,docno,docdate,nomor) AS nomorglobal,* from sc_his.pdca_dtl where nik=vr_nik and planperiod=vr_periode
				order by nik,docno,docdate,nomor) as x;
											
				LOOP 
				
				if(vr_temp_page=12) then vr_page:=vr_page+1; vr_temp_page:=0; end if;	
				--	if not exists (select * from 
				--	(select ROW_NUMBER() OVER (order by nik,docno,docdate,nomor) AS nomorglobal,* from sc_his.pdca_dtl ) as x where nik=vr_nik and planperiod=vr_periode and nomorglobal=vr_countdata and doctype=vr_doctype order by nik,docno,docdate,nomor) then 
						
					insert into sc_his.pdca_cetakpage
					(page,nik,docno,nomor,doctype,docref,docdate,docpage,revision,planperiod,descplan,idbu,qtytime,do_c,percentage,remark,userprint,userprintdate)
					(select vr_page as page,nik,docno,nomor,doctype,docref,docdate,docpage,revision,planperiod,descplan,idbu,qtytime,do_c,percentage,remark,vr_nama as userprint,to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as userprintdate 
					from (select ROW_NUMBER() OVER (partition by nik,doctype,planperiod  order by nik,docno,docdate,nomor) AS nomorglobal,* from sc_his.pdca_dtl ) AS x where nik=vr_nik and planperiod=vr_periode and nomorglobal=vr_countdata and doctype=vr_doctype and status in ('P','B'));

				--	end if;
				
				vr_temp_page:=vr_temp_page+1;

				--RAISE NOTICE '%', vr_countdata::text||vr_temp_page::text;
				RAISE NOTICE '%', vr_nik::text||vr_periode::text||'-'||vr_countdata::text||'-'||vr_temp_page::text||'-'||vr_page::text;
				vr_countdata:=vr_countdata-1;
				EXIT WHEN vr_countdata=0;

				
				END LOOP;
	
		RETURN NEXT vr_loopdocdate;
	ELSE */
			vr_page:=1; vr_temp_page:=0;	
			vr_countdata:=case when mod(count(*),12)=0 then count(*)
							when mod(count(*),12)>0 then count(*)+12-mod(count(*),12)
							end as countdata
				from (select ROW_NUMBER() OVER (partition by nik,doctype,planperiod  order by nik,docno,docdate,nomor) AS nomorglobal,* from sc_his.pdca_dtl where nik=vr_nik and planperiod=vr_periode
				order by nik,docno,docdate,nomor) as x;
				
		/*select case when mod(count(*),3)=0 then count(*)
		when mod(count(*),3)>0 then count(*)+3-mod(count(*),3)
		end as countdata
		from (select ROW_NUMBER() OVER (order by nik,docno,docdate,nomor) AS nomorglobal,* from sc_his.pdca_dtl where nik='1115.184' and planperiod='201801'
		order by nik,docno,docdate,nomor) as x; 

		select * from sc
		*/											
				LOOP 
				
				if(vr_temp_page=12) then vr_page:=vr_page+1; vr_temp_page:=0; end if;	
				--	if not exists (select * from 
				--	(select ROW_NUMBER() OVER (order by nik,docno,docdate,nomor) AS nomorglobal,* from sc_his.pdca_dtl ) as x where nik=vr_nik and planperiod=vr_periode and nomorglobal=vr_countdata and doctype=vr_doctype order by nik,docno,docdate,nomor) then 
						
					insert into sc_his.pdca_cetakpage
					(page,nik,docno,nomor,doctype,docref,docdate,docpage,revision,planperiod,descplan,idbu,qtytime,do_c,percentage,remark,userprint,userprintdate)
					(select vr_page as page,nik,docno,nomor,doctype,docref,docdate,docpage,revision,planperiod,descplan,idbu,qtytime,do_c,percentage,remark,vr_nama as userprint,to_char(now(),'YYYY-MM-DD HH24:MI:SS')::timestamp as userprintdate 
					from (select ROW_NUMBER() OVER (partition by nik,doctype,planperiod  order by nik,docno,docdate,nomor) AS nomorglobal,* from sc_his.pdca_dtl ) AS x where nik=vr_nik and planperiod=vr_periode and nomorglobal=vr_countdata and doctype=vr_doctype and status in ('P','B'));

				--	end if;
				
				vr_temp_page:=vr_temp_page+1;

				--RAISE NOTICE '%', vr_countdata::text||vr_temp_page::text;
				RAISE NOTICE '%', vr_nik::text||vr_periode::text||'-'||vr_countdata::text||'-'||vr_temp_page::text||'-'||vr_page::text;
				vr_countdata:=vr_countdata-1;
				EXIT WHEN vr_countdata=0;

				
				END LOOP;
	
	/*END IF;*/

	RETURN;	
END;
$$;

alter function pr_pdca_cetakpage(char, char, char, char) owner to postgres;

