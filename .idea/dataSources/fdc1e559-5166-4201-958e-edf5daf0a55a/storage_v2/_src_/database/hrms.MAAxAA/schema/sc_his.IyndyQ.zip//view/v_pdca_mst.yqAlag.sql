create view v_pdca_mst
            (branch, nik, docno, docdate, docref, doctype, nmdoctype, docpage, revision, tglawal, tglakhir, global_desc,
             planperiod, ttlpercent, ttlplan, avgvalue, inputdate, inputby, updatedate, updateby, canceldate, cancelby,
             approvdate, approvby, status, nmlengkap, bag_dept, nmdept, subbag_dept, nmsubdept, jabatan, nmjabatan,
             lvl_jabatan, nmlvljabatan, grade_golongan, nmgrade, nik_atasan, nik_atasan2, nmatasan1, nmatasan2,
             nmstatus, docdate2, tglawal2, tglakhir2)
as
SELECT COALESCE(x.branch::text, ''::text)         AS branch,
       COALESCE(x.nik::text, ''::text)            AS nik,
       COALESCE(x.docno::text, ''::text)          AS docno,
       COALESCE(x.docdate::text, ''::text)        AS docdate,
       COALESCE(x.docref::text, ''::text)         AS docref,
       COALESCE(x.doctype::text, ''::text)        AS doctype,
       COALESCE(x.nmdoctype, ''::text)            AS nmdoctype,
       COALESCE(x.docpage::text, ''::text)        AS docpage,
       COALESCE(x.revision::text, ''::text)       AS revision,
       COALESCE(x.tglawal::text, ''::text)        AS tglawal,
       COALESCE(x.tglakhir::text, ''::text)       AS tglakhir,
       COALESCE(x.global_desc, ''::text)          AS global_desc,
       COALESCE(x.planperiod::text, ''::text)     AS planperiod,
       COALESCE(x.ttlpercent::text, ''::text)     AS ttlpercent,
       COALESCE(x.ttlplan::text, ''::text)        AS ttlplan,
       COALESCE(x.avgvalue::text, ''::text)       AS avgvalue,
       COALESCE(x.inputdate::text, ''::text)      AS inputdate,
       COALESCE(x.inputby::text, ''::text)        AS inputby,
       COALESCE(x.updatedate::text, ''::text)     AS updatedate,
       COALESCE(x.updateby::text, ''::text)       AS updateby,
       COALESCE(x.canceldate::text, ''::text)     AS canceldate,
       COALESCE(x.cancelby::text, ''::text)       AS cancelby,
       COALESCE(x.approvdate::text, ''::text)     AS approvdate,
       COALESCE(x.approvby::text, ''::text)       AS approvby,
       COALESCE(x.status::text, ''::text)         AS status,
       COALESCE(x.nmlengkap::text, ''::text)      AS nmlengkap,
       COALESCE(x.bag_dept::text, ''::text)       AS bag_dept,
       COALESCE(x.nmdept::text, ''::text)         AS nmdept,
       COALESCE(x.subbag_dept::text, ''::text)    AS subbag_dept,
       COALESCE(x.nmsubdept::text, ''::text)      AS nmsubdept,
       COALESCE(x.jabatan::text, ''::text)        AS jabatan,
       COALESCE(x.nmjabatan::text, ''::text)      AS nmjabatan,
       COALESCE(x.lvl_jabatan::text, ''::text)    AS lvl_jabatan,
       COALESCE(x.nmlvljabatan::text, ''::text)   AS nmlvljabatan,
       COALESCE(x.grade_golongan::text, ''::text) AS grade_golongan,
       COALESCE(x.nmgrade::text, ''::text)        AS nmgrade,
       COALESCE(x.nik_atasan::text, ''::text)     AS nik_atasan,
       COALESCE(x.nik_atasan2::text, ''::text)    AS nik_atasan2,
       COALESCE(x.nmatasan1::text, ''::text)      AS nmatasan1,
       COALESCE(x.nmatasan2::text, ''::text)      AS nmatasan2,
       COALESCE(x.nmstatus::text, ''::text)       AS nmstatus,
       COALESCE(x.docdate2, ''::text)             AS docdate2,
       COALESCE(x.tglawal2, ''::text)             AS tglawal2,
       COALESCE(x.tglakhir2, ''::text)            AS tglakhir2
FROM (SELECT a.branch,
             a.nik,
             a.docno,
             a.docdate,
             a.docref,
             a.doctype,
             a.docpage,
             a.revision,
             a.tglawal,
             a.tglakhir,
             a.global_desc,
             a.planperiod,
             a.ttlpercent,
             a.ttlplan,
             a.avgvalue,
             a.inputdate,
             a.inputby,
             a.updatedate,
             a.updateby,
             a.canceldate,
             a.cancelby,
             a.approvdate,
             a.approvby,
             a.status,
             a.realisasidate,
             a.realisasiby,
             a.chec,
             b.nmlengkap,
             b.bag_dept,
             e1.nmdept,
             b.subbag_dept,
             e2.nmsubdept,
             b.jabatan,
             e3.nmjabatan,
             b.lvl_jabatan,
             e4.nmlvljabatan,
             b.grade_golongan,
             e5.nmgrade,
             b.nik_atasan,
             b.nik_atasan2,
             c.nmlengkap                                                       AS nmatasan1,
             d.nmlengkap                                                       AS nmatasan2,
             CASE
                 WHEN a.doctype = 'ISD'::bpchar THEN 'ISIDENTAL'::text
                 WHEN a.doctype = 'BRK'::bpchar THEN 'BERKALA'::text
                 ELSE NULL::text
                 END                                                           AS nmdoctype,
             f.uraian                                                          AS nmstatus,
             to_char(a.docdate::timestamp with time zone, 'DD-MM-YYYY'::text)  AS docdate2,
             to_char(a.tglawal::timestamp with time zone, 'DD-MM-YYYY'::text)  AS tglawal2,
             to_char(a.tglakhir::timestamp with time zone, 'DD-MM-YYYY'::text) AS tglakhir2
      FROM sc_his.pdca_mst a
               LEFT JOIN sc_mst.karyawan b ON a.nik = b.nik
               LEFT JOIN sc_mst.karyawan c ON b.nik_atasan = c.nik
               LEFT JOIN sc_mst.karyawan d ON b.nik_atasan2 = d.nik
               LEFT JOIN sc_mst.departmen e1 ON b.bag_dept = e1.kddept
               LEFT JOIN sc_mst.subdepartmen e2 ON b.bag_dept = e2.kddept AND b.subbag_dept = e2.kdsubdept
               LEFT JOIN sc_mst.jabatan e3
                         ON b.bag_dept = e3.kddept AND b.subbag_dept = e3.kdsubdept AND b.jabatan = e3.kdjabatan
               LEFT JOIN sc_mst.lvljabatan e4 ON b.lvl_jabatan = e4.kdlvl
               LEFT JOIN sc_mst.jobgrade e5 ON b.grade_golongan = e5.kdgrade
               LEFT JOIN sc_mst.trxtype f ON a.status = f.kdtrx AND f.jenistrx::text = 'PDCA'::text) x
WHERE x.nik IS NOT NULL;

alter table v_pdca_mst
    owner to postgres;

