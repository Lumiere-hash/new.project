create function pr_capture_gaji_pokok() returns SETOF void
    language plpgsql
as
$$
DECLARE 
/*PROSEDUR CAPTURE GAJI WILAYAH */
/* AUTHOR : FIKY
	CAPTURE GAJI
*/

vr_ttlcapture_gaji numeric(18,2):=0;
vr_nominal_masakerja numeric(18,2):=0;
vr_tjjabatan numeric(18,2):=0;
vr_masakerja numeric(18):=0;
vr_nik char(12);

BEGIN		

FOR vr_nik,vr_masakerja in select trim(nik),ceil((to_char(now(),'yyyy-mm-dd')::date-tglmasukkerja)/365::numeric) as suwenenyambut from sc_mst.karyawan where coalesce(statuskepegawaian,'') != 'KO' order by nik
	loop 
		/*select ttlgaji into vr_ttlcapture_gaji from (
		select a.*,b.nominal as nominalwilayah,c.nominal as nominaljabatan,d.nominal as nominalmasakerja,
		(coalesce(b.nominal,0) + coalesce(c.nominal,0) + coalesce(d.nominal,0)) as ttlgaji from sc_mst.lv_m_karyawan a
		left outer join sc_mst.m_wilayah_nominal b on a.kdwilayahnominal=b.kdwilayahnominal
		left outer join sc_mst.jabatan c on a.jabatan=c.kdjabatan
		left outer join sc_mst.m_masakerja d on a.tahunmasakerja::int>=d.awal::int and a.tahunmasakerja::int<=d.akhir::int) as x
		where nik=vr_nik;*/
		
		select ttlgaji,tjjabatan into vr_ttlcapture_gaji,vr_tjjabatan from (
		select a.*,b.nominal as nominalwilayah,c.nominal as nominallvlgp, coalesce(d.nominal,0) as tjjabatan,
		(coalesce(b.nominal,0) + coalesce(c.nominal,0)) as ttlgaji from sc_mst.karyawan a
		left outer join sc_mst.m_wilayah_nominal b on a.kdwilayahnominal=b.kdwilayahnominal
		left outer join sc_mst.m_lvlgp c on a.kdlvlgp=c.kdlvlgp 
		left outer join sc_mst.jabatan d on a.jabatan=d.kdjabatan and d.kdsubdept=a.subbag_dept and d.kddept=a.bag_dept
		) as x
		where nik=vr_nik;


		vr_nominal_masakerja:= coalesce(nominal,0.00) as nominal from sc_mst.m_masakerja where vr_masakerja>=awal and vr_masakerja<=akhir;
		
		if not exists (select * from sc_mst.dtlgaji_karyawan where nik=vr_nik and no_urut=1) then
			insert into sc_mst.dtlgaji_karyawan 
			(kode,no_urut,keterangan,nominal,nik,status)
			values
			('',1,'GAJI POKOK',0,vr_nik,'P');
		else
			update sc_mst.dtlgaji_karyawan set nominal=vr_ttlcapture_gaji where nik=vr_nik and no_urut=1;
		end if;
		if not exists (select * from sc_mst.dtlgaji_karyawan where nik=vr_nik and no_urut=8) then
			insert into sc_mst.dtlgaji_karyawan 
			(kode,no_urut,keterangan,nominal,nik,status)
			values
			('',8,'TUNJANGAN MASA KERJA',vr_nominal_masakerja,vr_nik,'P');
		else
			update sc_mst.dtlgaji_karyawan set nominal=vr_nominal_masakerja where nik=vr_nik and no_urut=8;
		end if;
		if not exists (select * from sc_mst.dtlgaji_karyawan where nik=vr_nik and no_urut=9) then
			insert into sc_mst.dtlgaji_karyawan 
			(kode,no_urut,keterangan,nominal,nik,status)
			values
			('',9,'TUNJANGAN PRESTASI',0,vr_nik,'P');
		else
			---update sc_mst.dtlgaji_karyawan set nominal=0 where nik=vr_nik and no_urut=9;
		end if;
		if not exists (select * from sc_mst.dtlgaji_karyawan where nik=vr_nik and no_urut=7) then
			insert into sc_mst.dtlgaji_karyawan 
			(kode,no_urut,keterangan,nominal,nik,status)
			values
			('',7,'TUNJANGAN JABATAN',vr_tjjabatan,vr_nik,'P');
		else
			update sc_mst.dtlgaji_karyawan set nominal=vr_tjjabatan where nik=vr_nik and no_urut=7;
		end if;
		update sc_mst.dtlgaji_karyawan set status='U' where nik=vr_nik and no_urut=1;
		
	return next vr_nik;
	end loop;
	
END;
$$;

alter function pr_capture_gaji_pokok() owner to postgres;

