create function tr_tmp_stbbm_dtlref() returns trigger
    language plpgsql
as
$$
DECLARE 
	--author by fiky: 31/10/2017
	--update by fiky: 31/10/2017
	--fix
     vr_nomor char(12); 
     vr_cekprefix char(4);
     vr_nowprefix char(4);  
     vr_qtybbm numeric;  
     vr_qtybbmkecil numeric; 
     vr_nodoktypemst char(100); 
BEGIN		
	IF tg_op = 'INSERT' THEN
		--select * from sc_tmp.stbbm_dtlref where nodok is null
		/*IF NOT EXISTS(select * from sc_tmp.stpbk_mst where nodok=new.nodok and nik=new.nik) THEN
			insert into sc_tmp.stpbk_mst 
			(branch,nodok,nodokref,nik,loccode,status,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby)
			(select branch,nodok,nodokref,nik,loccode,status,keterangan,inputdate,inputby,updatedate,updateby,approvaldate,approvalby
			from sc_tmp.stbbm_dtlref where nodok=new.nodok and nik=new.nik);
		END IF; */
	
		RETURN new;
	ELSEIF tg_op = 'UPDATE' THEN
		--select * from sc_trx.stbbm_dtlref
		--select * from sc_tmp.stbbm_dtlref
		--select * from sc_tmp.stbbm_dtl
		vr_nodoktypemst:=coalesce(nodoktype,'') from sc_tmp.stbbm_mst where nodok=new.nodok;
		IF (vr_nodoktypemst='PO') THEN /* UNTUK MASTER TYPE PO*/
			IF (OLD.STATUS!='' AND NEW.STATUS='') THEN

				
			--select * from sc_tmp.stbbm_dtl
			--select * from sc_tmp.stbbm_dtlref	
			--select * from sc_trx.po_dtlref
			update sc_tmp.stbbm_dtlref set 
			qtybbm=round((coalesce(new.qtybbmkecil,0))/(coalesce(new.qtyreckecil,0)/coalesce(new.qtyrec,0))), 
			status=old.status
			where nodok=new.nodok and nodokref=new.nodokref and fromcode=new.fromcode and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and id=new.id;

			vr_qtybbm:=coalesce(qtybbm,0) from  sc_tmp.stbbm_dtlref where nodok=new.nodok and nodokref=new.nodokref and fromcode=new.fromcode and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and id=new.id;
			vr_qtybbmkecil:=coalesce(qtybbmkecil,0) from  sc_tmp.stbbm_dtlref where nodok=new.nodok and nodokref=new.nodokref and fromcode=new.fromcode and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and id=new.id;

			update sc_trx.po_dtlref set 
			qtyterima=coalesce(qtyterima,0)-coalesce(old.qtybbm,0)+vr_qtybbm,
			qtyterima_kecil=coalesce(qtyterima_kecil,0)-coalesce(old.qtybbmkecil,0)+vr_qtybbmkecil
			--qtyterima_kecil=coalesce(qtyterima_kecil,0)-round((coalesce(old.qtyreckecil,0)/coalesce(old.qtyrec,0))*coalesce(old.qtybbm,0))+round((coalesce(new.qtyreckecil,0)/coalesce(new.qtyrec,0))*vr_qtybbm)
			where nodok=new.nodokref and nodokref=new.fromcode and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and id=new.id;

				RAISE NOTICE 'Calling cs_job(%)', vr_qtybbm;
				RAISE NOTICE 'Calling cs_create_job(%)', vr_qtybbmkecil;
				RAISE NOTICE 'Calling cs_create_job(%)', new.fromcode;
		
			delete from sc_mst.trxerror where userid=new.nodok and modul='TMPSTBBM';
			insert into sc_mst.trxerror
			(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
			(new.nodok,0,new.nodok,'','TMPSTBBM');
			
			
				/*UPDATE sc_trx.stbbm_dtlref SET STATUS='P' WHERE
				NODOK=NEW.NODOKTMP AND NIK=NEW.NIK AND KDGROUP=NEW.KDGROUP AND KDSUBGROUP=NEW.KDSUBGROUP AND STOCKCODE=NEW.STOCKCODE; */
			ELSEIF (OLD.STATUS='A' AND NEW.STATUS='C') THEN
				update sc_tmp.stbbm_dtl set
					qtybbm=
					case 
					when trim(satminta)=trim(new.satminta) then coalesce(round((select sum(coalesce(qtybbm,0)) from sc_tmp.stbbm_dtlref where nodok=new.nodok and nodokref=new.nodokref and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and status not in('C','D'))),0)
					when trim(satminta)!=trim(new.satminta) then coalesce(round((select sum(coalesce(qtybbm,0)) from sc_tmp.stbbm_dtlref where nodok=new.nodok and nodokref=new.nodokref and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and status not in('C','D'))/(coalesce(qtyreckecil,0)/coalesce(qtyrec,0))),0)	
					else 0 end,
					qtybbmkecil=coalesce((select sum(coalesce(qtybbmkecil,0)) from sc_tmp.stbbm_dtlref where nodok=new.nodok and nodokref=new.nodokref and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and status not in('C','D')),0)
					where 
					nodok=new.nodok and nodokref=new.nodokref and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and status not in('C','D');	
		
				update sc_trx.po_dtlref set 
					qtyterima=coalesce(qtyterima,0)-coalesce(new.qtybbm,0),
					qtyterima_kecil=coalesce(qtyterima_kecil,0)-round((coalesce(new.qtyreckecil,0)/coalesce(new.qtyrec,0))*coalesce(new.qtybbm,0))
					where nodok=new.nodokref and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and id=new.id;
			ELSEIF (OLD.STATUS='I' AND NEW.STATUS='C') THEN
				update sc_tmp.stbbm_dtl set
					qtybbm=
					case 
					when trim(satminta)=trim(new.satminta) then coalesce(round((select sum(coalesce(qtybbm,0)) from sc_tmp.stbbm_dtlref where nodok=new.nodok and nodokref=new.nodokref and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and status not in('C','D'))),0)
					when trim(satminta)!=trim(new.satminta) then coalesce(round((select sum(coalesce(qtybbm,0)) from sc_tmp.stbbm_dtlref where nodok=new.nodok and nodokref=new.nodokref and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and status not in('C','D'))/(coalesce(qtyreckecil,0)/coalesce(qtyrec,0))),0)	
					else 0 end,
					qtybbmkecil=coalesce((select sum(coalesce(qtybbmkecil,0)) from sc_tmp.stbbm_dtlref where nodok=new.nodok and nodokref=new.nodokref and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and status not in('C','D')),0)
					where 
					nodok=new.nodok and nodokref=new.nodokref and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and status not in('C','D');	
		
				update sc_trx.po_dtlref set 
					qtyterima=coalesce(qtyterima,0)-coalesce(new.qtybbm,0),
					qtyterima_kecil=coalesce(qtyterima_kecil,0)-round((coalesce(new.qtyreckecil,0)/coalesce(new.qtyrec,0))*coalesce(new.qtybbm,0))
					where nodok=new.nodokref and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and id=new.id;


			ELSEIF (OLD.STATUS='C' AND NEW.STATUS='A') THEN
				update sc_tmp.stbbm_dtl set
					qtybbm=
					case 
					when trim(satminta)=trim(new.satminta) then round((select sum(coalesce(qtybbm,0)) from sc_tmp.stbbm_dtlref where nodok=new.nodok and nodokref=new.nodokref and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and status not in('C','D')))
					when trim(satminta)!=trim(new.satminta) then round((select sum(coalesce(qtybbm,0)) from sc_tmp.stbbm_dtlref where nodok=new.nodok and nodokref=new.nodokref and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and status not in('C','D'))/(coalesce(qtyreckecil,0)/coalesce(qtyrec,0)))	
					else 0 end,
					qtybbmkecil=(select sum(coalesce(qtybbmkecil,0)) from sc_tmp.stbbm_dtlref where nodok=new.nodok and nodokref=new.nodokref and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and status not in('C','D'))
					where 
					nodok=new.nodok and nodokref=new.nodokref and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and status not in('C','D');	
		
				update sc_trx.po_dtlref set 
					qtyterima=coalesce(qtyterima,0)+coalesce(new.qtybbm,0),
					qtyterima_kecil=coalesce(qtyterima_kecil,0)+round((coalesce(new.qtyreckecil,0)/coalesce(new.qtyrec,0))*coalesce(new.qtybbm,0))
					where nodok=new.nodokref and kdgroup=new.kdgroup and kdsubgroup=new.kdsubgroup and stockcode=new.stockcode and id=new.id;
			END IF;

					/* TRIGER PEMBATALAN STATUS MASTER KETIKA DIREJECT SEMUA ITEM 
			IF EXISTS(SELECT * FROM SC_TRX.STPBK_MST WHERE STATUS='A' AND NODOK=NEW.NODOKTMP) THEN
				IF NOT EXISTS (SELECT * FROM SC_TMP.stbbm_dtlref WHERE NODOK=NEW.NODOK AND (STATUS='A' OR STATUS='P' OR STATUS='I')) THEN
					UPDATE SC_TMP.STPBK_MST SET STATUS='C' WHERE NODOK=NEW.NODOK;
				ELSEIF EXISTS (SELECT * FROM SC_TMP.stbbm_dtlref WHERE NODOK=NEW.NODOK AND STATUS='A') THEN
					UPDATE SC_TMP.STPBK_MST SET STATUS='A' WHERE NODOK=NEW.NODOK;
					
				END IF;
			END IF;*/
		END IF;
		RETURN NEW;
	ELSEIF tg_op = 'DELETE' THEN
		vr_nodoktypemst:=coalesce(nodoktype,'') from sc_tmp.stbbm_mst where nodok=old.nodok;
		IF (vr_nodoktypemst='PO') THEN /* UNTUK MASTER TYPE PO*/
			IF ( old.status='C') THEN
				update sc_trx.po_dtlref set 
				qtyterima=coalesce(qtyterima,0)-coalesce(old.qtybbm,0),
				qtyterima_kecil=coalesce(qtyterima_kecil,0)-coalesce(old.qtybbmkecil,0)
				where nodok=old.nodokref and kdgroup=old.kdgroup and kdsubgroup=old.kdsubgroup and stockcode=old.stockcode and nodokref=old.fromcode and id=old.id;

				/*update sc_tmp.stbbm_dtl set 
				qtybbm=(coalesce(old.qtybbm,0)-coalesce(old.qtybbm,0)), 
				qtybbmkecil=-coalesce(qtybbmkecil,0)-coalesce(old.qtybbmkecil,0)
				where nodok=old.nodok and nodokref=old.nodokref and kdgroup=old.kdgroup and kdsubgroup=old.kdsubgroup and stockcode=old.stockcode ;
				*/
				delete from sc_mst.trxerror where userid=old.nodok and modul='TMPSTBBM';
				insert into sc_mst.trxerror
				(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
				(old.nodok,0,old.nodok,'','TMPSTBBM');
			ELSEIF( old.status='E' ) THEN
				update sc_tmp.stbbm_dtl set 
				qtybbm=(coalesce(old.qtybbm,0)-coalesce(old.qtybbm,0))+coalesce(old.qtybbm_tmp,0), 
				qtybbmkecil=-coalesce(qtybbmkecil,0)-coalesce(old.qtybbmkecil,0)
				where nodok=old.nodok and nodokref=old.nodokref and kdgroup=old.kdgroup and kdsubgroup=old.kdsubgroup and stockcode=old.stockcode;
			
				update sc_trx.po_dtlref set 
				qtyterima=(coalesce(old.qtybbm,0)-coalesce(old.qtybbm,0))+coalesce(old.qtybbm_tmp,0),
				qtyterima_kecil=(coalesce(qtyterima_kecil,0)-coalesce(old.qtybbmkecil,0))+coalesce(old.qtybbmkecil_tmp,0)
				where nodok=old.nodokref and kdgroup=old.kdgroup and kdsubgroup=old.kdsubgroup and stockcode=old.stockcode and id=old.id;

				delete from sc_mst.trxerror where userid=old.nodok and modul='TMPSTBBM';
				insert into sc_mst.trxerror
				(userid,errorcode,nomorakhir1,nomorakhir2,modul) VALUES
				(old.nodok,0,old.nodok,'','TMPSTBBM');
			
			END IF;
		END IF;
		RETURN old;	
	END IF;
	
END;
$$;

alter function tr_tmp_stbbm_dtlref() owner to postgres;

